CREATE VIEW [dbo].[vZustandsartikel] AS
SELECT AlleZustandsartikel.kZustandArtikel AS AusgangsArtikel, dbo.tArtikel.* FROM
dbo.vArtikelZustandMitStandardZustand AS AlleZustandsartikel
JOIN dbo.vArtikelZustandMitStandardZustand AS AlleZustandsartikel2 ON AlleZustandsartikel2.kHauptartikel = AlleZustandsartikel.kHauptartikel
JOIN dbo.tArtikel ON AlleZustandsartikel2.kZustandArtikel = dbo.tArtikel.kArtikel
go

