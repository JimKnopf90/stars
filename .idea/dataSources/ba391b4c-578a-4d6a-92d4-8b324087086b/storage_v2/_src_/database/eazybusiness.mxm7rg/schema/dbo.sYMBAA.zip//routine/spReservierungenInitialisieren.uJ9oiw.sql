--- 
--- spReservierungenInitialisieren
---

CREATE PROCEDURE [dbo].[spReservierungenInitialisieren]
	@kBestellung INT = NULL,
	@kArtikel INT = NULL
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
	IF(@kBestellung IS NOT NULL AND @kArtikel IS NOT NULL)
	BEGIN
		RAISERROR('spReservierungenInitialisieren kann nur mit maximal 1 Parameter aufgerufen werden.', 10, 10);
		RETURN
	END
	IF(@kBestellung IS NULL AND @kArtikel IS NULL)
	BEGIN
		RAISERROR('spReservierungenInitialisieren darf nur durch einen Entwickler ohne Einschränkungen ausgeführt werden.', 10, 10);
		RETURN
	END
	DECLARE @Type_spUpdateLagerbestand TYPE_spUpdateLagerbestand;
	DECLARE @xPositionen XML;
	DECLARE @xBestellung XML;
	IF(OBJECT_ID('tempdb..#EbayAmazonBestellung') IS NOT NULL)
	BEGIN
		DROP TABLE #EbayAmazonBestellung;
	END
	CREATE TABLE #EbayAmazonBestellung(kKey INT, kPlattform INT, kArtikel INT, fAnzahl DECIMAL(28,15));
	IF(@kArtikel IS NULL AND @kBestellung IS NULL)
	BEGIN
		TRUNCATE TABLE dbo.tReserviert;
		DELETE dbo.tBestellungEckDaten
		FROM dbo.tBestellungEckDaten
		LEFT JOIN dbo.tBestellung ON dbo.tbestellung.kBestellung = dbo.tBestellungEckDaten.kBestellung
		WHERE ISNULL(dbo.tbestellung.nKomplettAusgeliefert, 0) < 2;
		TRUNCATE TABLE dbo.tlagerbestand;
	END
	IF(@kArtikel IS NOT NULL)
	BEGIN
		INSERT INTO @Type_spUpdateLagerbestand(kArtikel)
			SELECT @kArtikel;
		SET @xPositionen = (
			SELECT kKey, nPlattform
				FROM (
					SELECT kBestellpos AS kKey, 1 AS nPlattform
						FROM dbo.tbestellpos 
						WHERE dbo.tbestellpos.tArtikel_kArtikel = @kArtikel
					UNION ALL
					SELECT kBestellpos AS kKey, 1 AS nPlattform
						FROM dbo.tbestellpos 
						WHERE dbo.tbestellpos.kBestellStueckliste IN (SELECT dbo.tbestellpos.kBestellPos 
																			FROM dbo.tBestellpos 
																			WHERE dbo.tbestellpos.tArtikel_kArtikel = @kArtikel)
					UNION ALL
					SELECT kBestellpos AS kKey, 1 AS nPlattform
						FROM dbo.tbestellpos 
						WHERE dbo.tbestellpos.tArtikel_kArtikel IN (SELECT dbo.tArtikel.kArtikel
																		FROM dbo.tArtikel
																		WHERE kVaterArtikel = @kArtikel)
				) AS Result 
				FOR XML PATH('Keys'), TYPE
		);
		SET @xBestellung = (
			SELECT DISTINCT dbo.tbestellpos.tBestellung_kBestellung AS kBestellung
				FROM dbo.tbestellpos
				WHERE dbo.tbestellpos.tArtikel_kArtikel = @kArtikel
				FOR XML PATH('Bestellung'), TYPE
			);
		INSERT INTO #EbayAmazonBestellung(kKey, kPlattform, kArtikel, fAnzahl)
			SELECT dbo.ebay_transaction.kTransaction, 2, @kArtikel, dbo.ebay_transaction.QuantityPurchased * CASE WHEN dbo.teinstellungen.cLootSize = 'Y'
																													THEN ISNULL(dbo.ebay_item.LotSize,1)
																													ELSE 1
																											END
				FROM dbo.ebay_transaction
				LEFT JOIN dbo.ebay_item ON dbo.ebay_item.ItemID = dbo.ebay_transaction.ItemID
				JOIN dbo.tArtikel ON dbo.tArtikel.cArtNr = ebay_transaction.SKU
				CROSS JOIN dbo.teinstellungen
				WHERE dbo.tArtikel.kArtikel = @kArtikel
					AND dbo.ebay_transaction.Status = 4;
		INSERT INTO #EbayAmazonBestellung(kKey, kPlattform, kArtikel, fAnzahl)
			SELECT dbo.ebay_item.kItem, 4, @kArtikel, dbo.ebay_item.Quantity * CASE WHEN dbo.teinstellungen.cLootSize = 'Y'
																													THEN ISNULL(dbo.ebay_item.LotSize,1)
																													ELSE 1
																											END
				FROM dbo.ebay_item 
				CROSS JOIN dbo.teinstellungen
				WHERE dbo.ebay_item.bBestandReserviert = 1
					AND dbo.ebay_item.kArtikel = @kArtikel
					AND Status IN(3,7);
		INSERT INTO #EbayAmazonBestellung(kKey, kPlattform, kArtikel, fAnzahl)
			SELECT dbo.pf_amazon_bestellungpos.kAmazonBestellungPos, 3, @kArtikel, dbo.pf_amazon_bestellungpos.nQuantityPurchased
				FROM dbo.pf_amazon_bestellungpos 
				JOIN dbo.pf_amazon_bestellung ON dbo.pf_amazon_bestellung.kAmazonBestellung = dbo.pf_amazon_bestellungpos.kAmazonBestellung
				JOIN dbo.tArtikel ON dbo.tArtikel.cArtNr = dbo.pf_amazon_bestellungpos.cArtNr
				WHERE dbo.tArtikel.kArtikel = @kArtikel
					AND dbo.pf_amazon_bestellungpos.kAmazonBestellungPos NOT IN(SELECT kAmazonBestellungPos FROM dbo.tbestellpos)
					AND dbo.pf_amazon_bestellung.nStatus < 5
					AND ISNULL(dbo.pf_amazon_bestellung.nDeleted, 0) <> 1;
	END	
	ELSE IF(@kBestellung IS NOT NULL)
	BEGIN
		INSERT INTO @Type_spUpdateLagerbestand(kArtikel)
			SELECT dbo.tbestellpos.tArtikel_kArtikel AS kArtikel
				FROM dbo.tbestellpos 
				WHERE dbo.tbestellpos.tBestellung_kBestellung = @kBestellung;

		SET @xPositionen = (
			SELECT dbo.tbestellpos.kBestellpos AS kKey, 1 nPlattform
				FROM dbo.tbestellpos
				WHERE dbo.tbestellpos.tBestellung_kBestellung = @kBestellung
				FOR XML PATH('Keys'), TYPE
			);
		SET @xBestellung = (
			SELECT DISTINCT dbo.tbestellpos.tBestellung_kBestellung AS kBestellung
				FROM dbo.tbestellpos 
				WHERE dbo.tbestellpos.tBestellung_kBestellung = @kBestellung
				FOR XML PATH('Bestellung'), TYPE
			);
	END
	ELSE
	BEGIN
		INSERT INTO @Type_spUpdateLagerbestand(kArtikel)
				SELECT dbo.tArtikel.kArtikel
				FROM dbo.tArtikel 
				WHERE	dbo.tArtikel.cLagerAktiv = 'Y'
						AND dbo.tArtikel.cAktiv = 'Y';

		SET @xPositionen = 
		(
			SELECT	dbo.tbestellpos.kBestellPos AS kKey, 
					1 AS nPlattform
			FROM dbo.tbestellpos 
			JOIN dbo.tBestellung ON dbo.tbestellpos.tBestellung_kBestellung = dbo.tBestellung.kBestellung
			WHERE	dbo.tBestellung.nKomplettausgeliefert < 2
					AND dbo.tbestellpos.nType <> 2
			FOR XML PATH('Keys'), TYPE
		);
		SET @xBestellung = 
		(
			SELECT DISTINCT dbo.tbestellpos.tBestellung_kBestellung AS kBestellung
			FROM dbo.tbestellpos 
			JOIN dbo.tBestellung ON dbo.tbestellpos.tBestellung_kBestellung = dbo.tBestellung.kBestellung
			WHERE	dbo.tBestellung.nKomplettausgeliefert < 2
					AND dbo.tbestellpos.nType <> 2
			FOR XML PATH('Bestellung'), TYPE
		);
		INSERT INTO #EbayAmazonBestellung(kKey, kPlattform, kArtikel, fAnzahl)
			SELECT	dbo.ebay_transaction.kTransaction AS kKey, 
					2 AS kPlattform, 
					dbo.tArtikel.kArtikel AS kArtikel, 
					dbo.ebay_transaction.QuantityPurchased * CASE WHEN(dbo.teinstellungen.cLootSize = 'Y')
																THEN ISNULL(dbo.ebay_item.LotSize, 1)
																ELSE 1
															END AS fAnzahl
			FROM dbo.ebay_transaction 
			LEFT JOIN dbo.ebay_item ON dbo.ebay_item.ItemID = dbo.ebay_transaction.ItemID
			CROSS JOIN dbo.teinstellungen
			JOIN dbo.tArtikel ON dbo.tArtikel.cArtNr = dbo.ebay_transaction.SKU
			WHERE	dbo.ebay_transaction.Status = 4
					AND dbo.ebay_transaction.kBestellung = 0;
		INSERT INTO #EbayAmazonBestellung(kKey, kPlattform, kArtikel, fAnzahl)
			SELECT	dbo.ebay_item.kItem AS kKey, 
					4 AS kPlattform, 
					dbo.ebay_item.kArtikel AS kArtikel, 
					dbo.ebay_item.Quantity * CASE WHEN(dbo.teinstellungen.cLootSize = 'Y')
																THEN ISNULL(dbo.ebay_item.LotSize, 1)
																ELSE 1
															END AS fAnzahl
			FROM dbo.ebay_item 
			CROSS JOIN dbo.teinstellungen
			WHERE	dbo.ebay_item.bBestandReserviert = 1
					AND Status IN (3, 7);
		INSERT INTO #EbayAmazonBestellung(kKey, kPlattform, kArtikel, fAnzahl)
			SELECT	dbo.pf_amazon_bestellungpos.kAmazonBestellungPos AS kKey, 
					3 AS kPlattform, 
					dbo.tArtikel.kArtikel AS kArtikel, 
					dbo.pf_amazon_bestellungpos.nQuantityPurchased AS fAnzahl
			FROM dbo.pf_amazon_bestellungpos
			JOIN dbo.tArtikel ON tArtikel.cArtNr = pf_amazon_bestellungpos.cArtNr
			JOIN dbo.pf_amazon_bestellung ON dbo.pf_amazon_bestellung.kAmazonBestellung = dbo.pf_amazon_bestellungpos.kAmazonBestellung
			LEFT JOIN dbo.tbestellpos ON dbo.pf_amazon_bestellungpos.kAmazonBestellungPos = dbo.tbestellpos.kAmazonBestellungPos
			WHERE	dbo.pf_amazon_bestellungpos.kAmazonBestellungPos NOT IN (SELECT kAmazonBestellungPos FROM dbo.tbestellpos)
					AND dbo.pf_amazon_bestellung.nStatus < 5
					AND ISNULL(dbo.pf_amazon_bestellung.nDeleted, 0) <> 1
					AND dbo.tbestellpos.kBestellPos IS NULL;
	END
	EXEC dbo.spUpdateLagerbestand @Type_spUpdateLagerbestand;
	EXEC dbo.spReservierungAktualisieren @xPositionen;
	INSERT INTO dbo.tReserviert(kArtikel, fAnzahl, kKey, kPlattform)
		SELECT	#EbayAmazonBestellung.kArtikel, 
				#EbayAmazonBestellung.fAnzahl, 
				#EbayAmazonBestellung.kKey, 
				#EbayAmazonBestellung.kPlattform
		FROM #EbayAmazonBestellung;
	EXEC dbo.spUpdateLagerbestand @Type_spUpdateLagerbestand;
	EXEC dbo.spBestellungEckdatenAktualisieren @xBestellung;
END
go

