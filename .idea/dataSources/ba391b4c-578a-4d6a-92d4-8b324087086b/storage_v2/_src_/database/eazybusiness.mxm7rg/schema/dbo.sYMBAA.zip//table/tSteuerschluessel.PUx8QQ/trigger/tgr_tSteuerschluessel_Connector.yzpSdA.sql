CREATE TRIGGER [dbo].[tgr_tSteuerschluessel_Connector]
ON [dbo].[tSteuerschluessel]
AFTER UPDATE, INSERT, DELETE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN	

	INSERT INTO dbo.tGlobalsQueue (kShop, nType, cName, kKey)
	SELECT dbo.tShop.kShop, 1, 'tSteuer', 1
	FROM dbo.tShop	
	LEFT JOIN dbo.tGlobalsQueue ON dbo.tShop.kShop = dbo.tGlobalsQueue.kShop
		AND dbo.tGlobalsQueue.cName = 'tSteuer'
		AND dbo.tGlobalsQueue.kKey = 1
	WHERE	dbo.tShop.nTyp = 0
			AND dbo.tGlobalsQueue.kKey IS NULL;
				
END
go

