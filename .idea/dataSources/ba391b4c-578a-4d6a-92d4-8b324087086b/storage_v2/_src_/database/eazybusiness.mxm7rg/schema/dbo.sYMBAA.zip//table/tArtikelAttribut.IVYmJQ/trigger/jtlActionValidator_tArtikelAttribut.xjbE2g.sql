CREATE TRIGGER [dbo].[jtlActionValidator_tArtikelAttribut]  
--     
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: SebastianB
--    
ON [dbo].[tArtikelAttribut]  
AFTER DELETE 
AS  
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN 

	--
	--Überprüfen ob Trigger mit Inhalt aufgerufen wird
	--
		IF((SELECT COUNT(1) FROM DELETED) = 0)
		BEGIN
			RETURN
		END

	--
	-- tAttributArtikel aufräumen
	--
		DELETE tArtikelAttributSprache WITH(ROWLOCK)
		FROM tArtikelAttributSprache WITH(ROWLOCK)
		JOIN DELETED ON DELETED.kArtikelAttribut = tArtikelAttributSprache.kArtikelAttribut 
 
 																	 
END
go

