CREATE TRIGGER [dbo].[tgr_tWarenLagerPlatz_INSUPDEL]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--
ON [dbo].[tWarenLagerPlatz]
AFTER INSERT, UPDATE, DELETE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
	--Überprüfen ob Trigger mit Inhalt aufgerufen wird
	IF((SELECT COUNT(1) FROM INSERTED FULL JOIN DELETED ON INSERTED.kWarenLagerPlatz = DELETED.kWarenLagerPlatz) = 0)
	BEGIN
		RETURN
	END
	--
	-- nGesperrt = Alles was auf diesem Platz liegt wird dem verfügbaren Bestand abgezogen. (Siehe spUpdateLagerBestand)
	--
	IF (UPDATE (nGesperrt))
	BEGIN
		DECLARE @typeArtikel AS TYPE_spUpdateLagerbestand;

		INSERT INTO @typeArtikel (kArtikel)
		SELECT DISTINCT kArtikel
			FROM
			(
				SELECT tWarenLagerPlatzArtikel.kArtikel
					FROM INSERTED
					JOIN tWarenLagerPlatzArtikel WITH(NOLOCK) ON INSERTED.kWarenLagerPlatz = tWarenLagerPlatzArtikel.kWarenLagerPlatz
					GROUP BY tWarenLagerPlatzArtikel.kArtikel
				UNION ALL
				SELECT tWarenLagerPlatzArtikel.kArtikel
					FROM DELETED
					JOIN tWarenLagerPlatzArtikel WITH(NOLOCK) ON DELETED.kWarenLagerPlatz = tWarenLagerPlatzArtikel.kWarenLagerPlatz
					GROUP BY tWarenLagerPlatzArtikel.kArtikel
			) AS U1
			WHERE kArtikel = U1.kArtikel;

		EXEC spUpdateLagerBestand @typeArtikel;
	END;

END;
go

