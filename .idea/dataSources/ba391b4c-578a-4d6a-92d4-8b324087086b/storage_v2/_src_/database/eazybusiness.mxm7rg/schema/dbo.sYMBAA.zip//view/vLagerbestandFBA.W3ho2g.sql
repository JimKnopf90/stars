CREATE VIEW [dbo].[vLagerbestandFBA] AS 
SELECT     dbo.vLagerbestandEx.kArtikel,  
CASE  
WHEN tArtikel.cLagerVariation = 'Y' THEN ISNULL(vLagerbestandEx.fLagerbestand + (ISNULL(Res.fReserviert, 0) + ISNULL(ResVater.fRes, 0)), 0)  
ELSE vLagerbestandEx.fLagerbestand  
END AS fLagerbestand, 
ISNULL(ResFBA.fAnzahlFBA , 0) AS fAnzahlFBA 
FROM         dbo.vLagerbestandEx  
LEFT OUTER JOIN 
( 
	SELECT     SUM(fAnzahl) AS fReserviert, kArtikel 
	FROM          dbo.tReserviert 
	GROUP BY kArtikel 
) AS Res ON Res.kArtikel = dbo.vLagerbestandEx.kArtikel  
LEFT OUTER JOIN 
( 
	SELECT     SUM(dbo.tReserviert.fAnzahl) AS fRes, dbo.tartikel.kVaterArtikel 
	FROM          dbo.tartikel  
	LEFT OUTER JOIN 
	dbo.tReserviert ON dbo.tartikel.kArtikel = dbo.tReserviert.kArtikel 
	GROUP BY dbo.tartikel.kVaterArtikel 
) AS ResVater ON ResVater.kVaterArtikel = dbo.vLagerbestandEx.kArtikel  
LEFT OUTER JOIN 
( 
	SELECT SUM(ISNULL(fBestand,0.0)) AS fAnzahlFBA, kArtikel 
	FROM dbo.vLagerbestandProLager 
	JOIN tWarenLager ON tWarenLager.kWarenLager = vLagerbestandProLager.kWarenLager 
	WHERE tWarenLager.nFulfillment = 2 
	GROUP BY dbo.vLagerbestandProLager.kArtikel 
) AS ResFBA ON ResFBA.kArtikel = dbo.vLagerbestandEx.kArtikel  
LEFT OUTER JOIN dbo.tartikel ON dbo.tartikel.kArtikel = dbo.vLagerbestandEx.kArtikel 
GROUP BY dbo.vLagerbestandEx.kArtikel, dbo.vLagerbestandEx.fLagerbestand, Res.fReserviert, ResVater.fRes, dbo.tartikel.cLagerVariation, ResFBA.fAnzahlFBA
go

