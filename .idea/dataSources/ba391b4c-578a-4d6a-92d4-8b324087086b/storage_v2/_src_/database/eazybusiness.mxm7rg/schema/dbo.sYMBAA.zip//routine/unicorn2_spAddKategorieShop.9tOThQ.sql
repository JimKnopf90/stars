
    CREATE PROCEDURE unicorn2_spAddKategorieShop @kShopId INT 
    AS
		DECLARE @kKategorie INT
	
        DECLARE @kShopIdLocal INT
		SET @kShopIdLocal = @kShopId
		
			DECLARE ins1 CURSOR READ_ONLY FAST_FORWARD FOR SELECT tKategorie.kKategorie FROM tKategorie WHERE tKategorie.kKategorie NOT IN (SELECT tKategorieShop.kKategorie FROM tKategorieShop WHERE tKategorieShop.kShop = @kShopIdLocal)
		
			OPEN ins1 
			FETCH NEXT FROM ins1 INTO @kKategorie
			
				WHILE (@@FETCH_STATUS = 0) 						
					BEGIN            
					INSERT INTO tKategorieShop (kKategorie, kShop, cInet, cDelInet, nInBearbeitung) VALUES (@kKategorie, @kShopIdLocal, 'Y', 'N', 0);                                                		
					FETCH NEXT FROM ins1 INTO @kKategorie		        
					END 				            
						
			CLOSE ins1
			DEALLOCATE ins1
    go

