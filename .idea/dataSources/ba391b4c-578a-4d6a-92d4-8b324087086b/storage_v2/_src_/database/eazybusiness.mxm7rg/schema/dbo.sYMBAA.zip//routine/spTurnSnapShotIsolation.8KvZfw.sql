--- 
--- spTurnSnapShotIsolation
---

CREATE PROCEDURE [dbo].[spTurnSnapShotIsolation]
@nAktiv TINYINT,     -- 0 Aus, 1 An
@cMandant VARCHAR(50),	 -- Der Mandant für den die option aktiviert werden soll
@nReturn INT OUT	 -- 0 Erfolgreich geschaltet


-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Author PN    

-- Funktion: Mit dieser Procedur wird snapshot Isolation für den Mandanten geschaltet
	
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;


BEGIN

	DECLARE @DatabaseSQL VARCHAR(500);
	DECLARE @DatabaseSQL2 VARCHAR(500);

	--Zum prüfen on aktiv:
	--SELECT is_read_committed_snapshot_on FROM sys.databases WHERE name= 'Eazybusiness'


	IF (LEFT(CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR), 4) <=  10.0)
	BEGIN

		SET @nReturn = -1; -- Nur aktivierbar ab SQL server 2008

	END;
	ELSE IF (CAST(serverproperty('Edition') AS VARCHAR) LIKE '&Express%')
	BEGIN

		SET @nReturn = -2; -- Nicht für express Edition

	END;
	ELSE
	BEGIN
		IF(@nAktiv = 1) 
		BEGIN

			SET @DatabaseSQL = 'ALTER DATABASE ' + @cMandant + ' SET ALLOW_SNAPSHOT_ISOLATION ON;';
			SET @DatabaseSQL2 = 'ALTER DATABASE ' + @cMandant + ' SET READ_COMMITTED_SNAPSHOT ON WITH ROLLBACK IMMEDIATE;';

		END;
		ELSE
		BEGIN

		    SET @DatabaseSQL = 'ALTER DATABASE ' + @cMandant + ' SET ALLOW_SNAPSHOT_ISOLATION OFF;';
			SET @DatabaseSQL2 = 'ALTER DATABASE ' + @cMandant + ' SET READ_COMMITTED_SNAPSHOT OFF WITH ROLLBACK IMMEDIATE;';

		END;

		EXEC (@DatabaseSQL);
		EXEC (@DatabaseSQL2);
		SET @nReturn = 0;

	END;


END;
go

