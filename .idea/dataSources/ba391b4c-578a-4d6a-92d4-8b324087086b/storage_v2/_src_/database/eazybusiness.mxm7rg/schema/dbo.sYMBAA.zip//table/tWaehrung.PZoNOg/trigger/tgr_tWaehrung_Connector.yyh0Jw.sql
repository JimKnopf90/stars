CREATE TRIGGER [dbo].[tgr_tWaehrung_Connector]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: PN/MP
--
ON [dbo].[tWaehrung]
AFTER INSERT, UPDATE, DELETE
AS 
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
	INSERT INTO dbo.tGlobalsQueue
	(
	    kShop,
	    nType,
	    cName,
	    kKey,
	    cText,
	    dTimeStamp
	)
	SELECT DISTINCT Result.kShop, 0,'tWaehrung', 0,0,GETDATE()
		FROM (
			SELECT dbo.tShop.kShop
				FROM INSERTED 
				CROSS JOIN dbo.tShop 
			UNION ALL
			SELECT dbo.tShop.kShop
				FROM DELETED 
				CROSS JOIN dbo.tShop  
			)AS Result
			WHERE Result.kShop NOT IN 
				(SELECT kShop FROM dbo.tGlobalsQueue WHERE cName ='tWaehrung');
END
go

