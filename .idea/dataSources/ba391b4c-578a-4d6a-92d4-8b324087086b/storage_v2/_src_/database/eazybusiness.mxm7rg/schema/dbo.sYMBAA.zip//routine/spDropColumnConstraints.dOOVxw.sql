--- 
--- spDropColumnConstraints
---

CREATE PROCEDURE [dbo].[spDropColumnConstraints] 
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: AC
--
    @tableName varchar( 128 ), 
    @columnName varchar( 128 )
AS
BEGIN
    SET NOCOUNT ON;
	SET ANSI_NULLS ON;
	SET ANSI_NULL_DFLT_ON ON;
	SET ANSI_PADDING ON;
	SET CONCAT_NULL_YIELDS_NULL ON;
	SET XACT_ABORT OFF;
    DECLARE @sqlDropIndex nvarchar( 1000 ), @constraintName varchar( 128 )
    WHILE 0 = 0
        BEGIN
            SET @constraintName = ( SELECT TOP(1) constraint_name
								FROM information_schema.constraint_column_usage
								WHERE table_name = @tableName
								    AND column_name = @columnName 
							 )
            IF @constraintName IS NULL
                BEGIN 
				BREAK
                END
            EXEC ( 'ALTER TABLE "'+@tableName+'" DROP CONSTRAINT "'+@constraintName+'"' )
        END
    WHILE 0 = 0
        BEGIN
            SET @constraintName = ( SELECT TOP(1) SysObjects.Name AS ContraintName
								FROM SysObjects 
								   INNER JOIN( 
                                                    SELECT Name, ID
											 FROM SysObjects
											 WHERE XType = 'U' 
								    )AS Tab ON Tab.ID = Sysobjects.Parent_Obj
								    INNER JOIN sysconstraints ON sysconstraints.Constid = Sysobjects.ID
								    INNER JOIN SysColumns Col ON Col.ColID = sysconstraints.ColID AND Col.ID = Tab.ID
								    WHERE col.Name = @columnName
									   AND Tab.Name = @tableName 
							 )
            IF @constraintName IS NULL
                BEGIN 
				BREAK
                END
            EXEC ( 'ALTER TABLE "'+@tableName+'" DROP CONSTRAINT "'+@constraintName+'"' )
        END
    WHILE 0 = 0
        BEGIN
            SET @constraintName = ( SELECT TOP(1) 'DROP INDEX ' + idx.name + ' ON ' + tbl.name
								FROM sys.indexes idx 
								INNER JOIN sys.tables tbl ON idx.object_id = tbl.object_id
								INNER JOIN sys.index_columns idxCol ON idx.index_id = idxCol.index_id
                                        INNER JOIN sys.columns col ON idxCol.column_id = col.column_id
								WHERE idx.type <> 0
                                            AND tbl.name = @tableName
								    AND col.name = @columnName 
							 )
            IF @constraintName IS NULL
                BEGIN 
				BREAK
                END
            EXEC ( @constraintName )
        END
END
go

