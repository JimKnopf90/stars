--- 
--- sptLiefArtikelStandardsValidieren
---

CREATE PROCEDURE [dbo].[sptLiefArtikelStandardsValidieren]
@nFuerDropshippingAusfuehren INT = 0
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP
--
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN

	IF(@nFuerDropshippingAusfuehren = 0)
	BEGIN

	--
	-- Schritt 1: Sicherstellen, dass nur ein Standardlieferant gesetzt ist.
	--
	    UPDATE tliefartikel WITH(ROWLOCK) SET tliefartikel.nStandard = 0 
		FROM tliefartikel WITH (ROWLOCK)
		WHERE tliefartikel.nStandard = 1
		AND EXISTS (SELECT * FROM tliefartikel t2  WITH (NOLOCK)
               WHERE t2.tArtikel_kArtikel = tliefartikel.tArtikel_kArtikel 
			   AND t2.nStandard = 1
			   AND t2.kLiefArtikel > tliefartikel.kLiefArtikel)


	--
	-- Schritt 2: Sicherstellen, dass jeder Artikel einen Standard-Lieferanten hat.
	--
		UPDATE tliefartikel WITH(ROWLOCK) SET nStandard = 1
		FROM tliefartikel WITH(ROWLOCK)
		WHERE tliefartikel.kLiefArtikel IN
		(
			--
			-- Den ersten Artikel einer Liste von ausschließlich nicht Standard-Artikeln ermitteln.
			--
			SELECT MIN(ISNULL(t2.kLiefArtikel, 0)) 
			FROM tliefartikel t2 WITH(NOLOCK)
			WHERE t2.tArtikel_kArtikel = tliefartikel.tArtikel_kArtikel
			GROUP BY t2.tArtikel_kArtikel
			HAVING MAX(ISNULL(t2.nStandard, 0)) = 0
		)

	END;
	ELSE IF(@nFuerDropshippingAusfuehren = 1)
	BEGIN

	    --
	    -- Schritt 3: Sicherstellen, dass immmer nur 1 Standarddropshippinglieferant für einen Dropshipping-Artikel gesetzt ist 
	    --
		UPDATE tliefartikel WITH(ROWLOCK) SET tliefartikel.nDropshippingStandard = 0 
		FROM tliefartikel WITH(ROWLOCK)
		WHERE tliefartikel.nDropshippingStandard = 1 AND
		EXISTS
		(		
			--
			-- Zum Ausschluß zu jedem kArtikel den ersten Standard Liefartikel Suchen.
			--
			SELECT * FROM tliefartikel t2  WITH (NOLOCK)
               WHERE t2.tArtikel_kArtikel = tliefartikel.tArtikel_kArtikel 
			   AND t2.nDropshippingStandard = 1
			   AND t2.kLiefArtikel > tliefartikel.kLiefArtikel
		)

	    --
	    -- Schritt 4: Sicherstellen, dass genau ein Dropshipping-Liefartikel der Liste aller Dropshpping-Lieferartikel eines Artikels als Standard definiert ist.
	    --
		UPDATE tliefartikel WITH(ROWLOCK) SET nDropShippingStandard = 1
		FROM tliefartikel WITH(ROWLOCK)
		WHERE tliefartikel.kLiefArtikel IN
		(
			--
			-- Den ersten Artikel einer Liste von ausschließlich nicht Standard-Artikeln ermitteln.
			--
			SELECT MIN(ISNULL(t2.kLiefArtikel, 0)) 
			FROM tliefartikel AS t2 WITH(NOLOCK)
			WHERE t2.nDropShipping = 1
			AND t2.tArtikel_kArtikel = tliefartikel.tArtikel_kArtikel
			GROUP BY t2.tArtikel_kArtikel
			HAVING MAX(ISNULL(t2.nDropShippingStandard, 0)) = 0
		)
		AND tliefartikel.nDropShipping = 1

	END;
END
go

