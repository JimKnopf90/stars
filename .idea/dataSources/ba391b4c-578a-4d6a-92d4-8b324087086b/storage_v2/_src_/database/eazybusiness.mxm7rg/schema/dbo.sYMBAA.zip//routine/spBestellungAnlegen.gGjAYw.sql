--- 
--- spBestellungAnlegen
---

CREATE PROCEDURE [dbo].[spBestellungAnlegen]
	@kRechnung INT,
	@kBenutzer INT,
	@kAdresse INT,
	@kText INT, 
	@kKunde INT,
	@cBestellNr VARCHAR(40),
	@cType CHAR(1),
	@cAnmerkung VARCHAR(4500),
	@dErstellt DATETIME,
	@nZahlungsziel TINYINT,
	@kVersandArt INT,
	@fVersandBruttoPreis DECIMAL(28,14),
	@fRabatt DECIMAL(28,14),
	@kInetBestellung INT,
	@cVersandInfo VARCHAR(255),
	@dVersandt DATETIME,
	@cIdentCode VARCHAR(255),
	@cBeschreibung CHAR(1),
	@cInet CHAR(1),
	@dLieferdatum DATETIME,
	@kBestellHinweis INT,
	@cErloeskonto VARCHAR(64),
	@cWaehrung VARCHAR(20),
	@fFaktor DECIMAL(28,14),
	@kShop INT,
	@kFirma INT,
	@kLogistik INT,
	@nPlatform TINYINT,
	@kSprache INT,
	@fGutschein DECIMAL(28,14),
	@dGedruckt DATETIME,
	@dMailVersandt DATETIME,
	@cInetBestellnr VARCHAR(50),
	@kZahlungsArt INT,
	@kLieferAdresse INT,
	@kRechnungsAdresse INT,
	@nIGL TINYINT,
	@nUStFrei TINYINT,
	@cStatus VARCHAR(255),
	@dVersandMail DATETIME,
	@dZahlungsMail DATETIME,
	@cUserName VARCHAR(255),
	@cVerwendungszweck VARCHAR(255),
	@fSkonto DECIMAL(28,14),
	@kColor INT,
	@nStorno TINYINT,
	@cModulID VARCHAR(255),
	@nZahlungsTyp INT,
	@nHatUpload INT,
	@fZusatzGewicht DECIMAL(28,14),
	@nKomplettAusgeliefert TINYINT,
	@dBezahlt DATETIME,
	@kSplitBestellung INT,
	@cPUIZahlungsdaten VARCHAR(MAX),
	@nPrio INT,
	@cVersandlandISO VARCHAR(5),
	@cUstId VARCHAR(25),
	@nPremium TINYINT,
	@kRueckhalteGrund INT,
	@cJfoid VARCHAR(100),
	@kFulfillmentLieferant INT,
	@cKundenauftragsnummer VARCHAR(255) = NULL,
	@nIstExterneRechnung BIT = 0,
	@kBestellung INT OUTPUT
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
DECLARE @ErrorMessage NVARCHAR(4000);
DECLARE @ErrorSeverity INT;
DECLARE @ErrorState INT;
DECLARE @retry INT;
SET @retry = 5;
WHILE @retry > 0
BEGIN
	SET CONTEXT_INFO 0x5105;
	BEGIN TRY
		BEGIN TRANSACTION
			-- Bei neuen Aufträgen gibt es keine Rechnung (Fehler im Split #15336)
			SET @kRechnung = 0;
			SELECT @kVersandArt = MainVersandArt.kVersandArt
				FROM dbo.tVersandart 
				JOIN dbo.tversandart AS MainVersandArt ON MainVersandArt.kMainVersandArt = dbo.tVersandart.kVersandArt
				WHERE dbo.tVersandart.kVersandArt = @kVersandArt
					AND dbo.tVersandart.kMainVersandart > 0;
			SELECT @cVersandlandISO = CASE WHEN @cVersandlandISO IS NULL OR @cVersandlandISO = ''
										THEN dbo.tFirmaUstIdNr.cLandISO
										ELSE @cVersandlandISO
									END					
				FROM dbo.tFirma
				JOIN dbo.tFirmaUStIdNr ON dbo.tFirmaUStIdNr.kFirma = dbo.tFirma.kFirma
										AND dbo.tFirma.cLandISO = dbo.tFirmaUStIdNr.cLandISO
				WHERE @kFirma = dbo.tFirma.kFirma;
			SELECT @cUstId =	CASE WHEN @cUstId IS NULL OR @cUstId = ''
									THEN dbo.tFirmaUstIdNr.cUStId
									ELSE @cUstId
								END
			FROM dbo.tFirma
			JOIN dbo.tFirmaUStIdNr ON dbo.tFirmaUStIdNr.kFirma = dbo.tFirma.kFirma
									AND @cVersandlandISO = dbo.tFirmaUStIdNr.cLandISO
			WHERE @kFirma = dbo.tFirma.kFirma;

			SELECT @cWaehrung = dbo.tWaehrung.cEAMapping
				FROM dbo.tWaehrung
				WHERE nStandard = 1
					AND @cWaehrung IS NULL OR @cWaehrung = '';
			DECLARE @IGL AS INT;
			DECLARE @ReverseCharge AS INT;
			SET @IGL = 10;
			SET @ReverseCharge = 15;

			IF(@nUStFrei IN (@IGL, @ReverseCharge))
			BEGIN
				SET @cUstId =			ISNULL(
												(SELECT CASE WHEN LEN(ISNULL(dbo.tFirmaUStIdNr.cUStId, '')) > 2 
															THEN dbo.tFirmaUStIdNr.cUStId 
															ELSE NULL 
														END AS cUstId
												FROM dbo.tFirmaUStIdNr
												JOIN dbo.tfirma ON dbo.tFirmaUStIdNr.kFirma = dbo.tfirma.kFirma
													AND dbo.tFirmaUStIdNr.cLandISO = dbo.tfirma.cLandISO
												WHERE	dbo.tfirma.kFirma = @kFirma)
										, @cUstId)
			END;

			IF(@kVersandArt > 0)
			BEGIN

				SELECT  @nPrio =  dbo.tversandart.nPrioritaet
				FROM dbo.tversandart
				WHERE  dbo.tversandart.kVersandArt = @kVersandArt;

			END;
			DECLARE @cVersandlandWaehrung VARCHAR(20);
			SELECT @cVersandlandWaehrung = dbo.tland.cWaehrung
				FROM dbo.tland
				WHERE dbo.tland.cISO = @cVersandlandISO;
			DECLARE @fVersandlandFaktor DECIMAL(28,14);
			SELECT @fVersandlandFaktor = dbo.tWaehrung.fFaktor
				FROM dbo.tWaehrung  
				WHERE dbo.tWaehrung.cEAMapping = @cVersandlandWaehrung;
			INSERT INTO dbo.tbestellung(tRechnung_kRechnung, tBenutzer_kBenutzer, tAdresse_kAdresse, tText_kText,
										tKunde_kKunde, cBestellNr, cType, cAnmerkung, dErstellt, nZahlungsziel, tVersandArt_kVersandArt,
										fVersandBruttoPreis, fRabatt, kInetBestellung, cVersandInfo, dVersandt, cIdentCode,
										cBeschreibung, cInet, dLieferdatum, kBestellHinweis, cErloeskonto, cWaehrung, fFaktor,
										kShop, kFirma, kLogistik, nPlatform, kSprache, fGutschein, dGedruckt, dMailVersandt,
										cInetBestellNr, kZahlungsArt, kLieferAdresse, kRechnungsAdresse, nIGL, nUStFrei, cStatus,
										dVersandMail, dZahlungsMail, cUserName, cVerwendungszweck, fSkonto, kColor, nStorno,
										cModulID, nZahlungsTyp, nHatUpload, fZusatzGewicht, nKomplettAusgeliefert, dBezahlt,
										kSplitBestellung, cPUIZahlungsdaten, nPrio, cVersandlandISO, cUstId, nPremium, cVersandlandWaehrung, 
										fVersandlandWaehrungFaktor, kRueckhalteGrund, cKundenauftragsnummer, nIstExterneRechnung, cJfoid, kFulfillmentLieferant)
				VALUES(@kRechnung, @kBenutzer, @kAdresse, CASE WHEN @kText < 0 THEN 0 ELSE @kText END, @kKunde, @cBestellNr, @cType, @cAnmerkung, @dErstellt, 
						@nZahlungsziel, @kVersandArt, @fVersandBruttoPreis, @fRabatt, @kInetBestellung, @cVersandInfo,
						@dVersandt, @cIdentCode, @cBeschreibung, @cInet, @dLieferdatum, @kBestellHinweis, @cErloeskonto,
						@cWaehrung, @fFaktor, @kShop, @kFirma, @kLogistik, @nPlatform, @kSprache, @fGutschein, @dGedruckt, 
						@dMailVersandt, @cInetBestellnr, @kZahlungsArt, @kLieferAdresse, @kRechnungsAdresse, @nIGL, @nUStFrei,
						@cStatus, @dVersandMail, @dZahlungsMail, @cUserName, @cVerwendungszweck, @fSkonto, CASE WHEN @kColor < 0 THEN 0 ELSE @kColor END, @nStorno,
						@cModulID, @nZahlungsTyp, @nHatUpload, @fZusatzGewicht, @nKomplettAusgeliefert, @dBezahlt, 
						@kSplitBestellung, @cPUIZahlungsdaten, @nPrio, @cVersandlandISO, @cUstId, @nPremium, @cVersandlandWaehrung, 
						@fVersandlandFaktor, @kRueckhalteGrund, @cKundenauftragsnummer, @nIstExterneRechnung, @cJfoid, @kFulfillmentLieferant);
			SELECT @kBestellung = SCOPE_IDENTITY();
			SET @retry = -1;
			SET CONTEXT_INFO 0x0;
		COMMIT
	END TRY
	BEGIN CATCH
	IF(ERROR_NUMBER() = 1205)
			BEGIN
				SET @retry = @retry - 1;
				ROLLBACK;
				IF(@retry = 0)
				BEGIN
					SELECT @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
					RAISERROR (	@ErrorMessage, 
								@ErrorSeverity,
								@ErrorState
					);
					SET CONTEXT_INFO 0x0;
					RETURN;
				END
				WAITFOR DELAY '00:00:00:5';
			END
			ELSE 
			BEGIN
				SET @retry = -1;
				SELECT @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
				ROLLBACK;
				RAISERROR (	@ErrorMessage, 
							@ErrorSeverity,
							@ErrorState
				);
				SET CONTEXT_INFO 0x0;
				RETURN;
			END
	END CATCH
	SET CONTEXT_INFO 0x0;	
END
go

