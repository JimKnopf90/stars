--- 
--- spWarenLagerEingangSplitt
---

CREATE PROCEDURE [dbo].[spWarenLagerEingangSplitt]
	@kWarenLagerEingang INT,             -- Warenlagereingang der geplittet werden soll
	@nSplittMenge DECIMAL(28,14),  -- Die Menge die abgesplittet werden soll
	@kOutWarenLagerEingang INT OUTPUT    -- die Neue Warenlagereinheit die abgesplittet wurde

--  
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Version: $Rev$
-- Datum: $Date$
-- Funktion: Diese Procedur splittet die übergebene Lagereinheit und erstellt eine neue mit der übergebenen Menge

AS 
DECLARE @TableVar TABLE(Nummer INT)
DECLARE @kWarenLagerEingangNew INT
DECLARE @nAnzahlAktuellAltWle  DECIMAL(28,14)
DECLARE @fAnzahlReserviertPickpos DECIMAL(28,14)
DECLARE @dQuellDatum DATETIME
DECLARE @OldContextInfo VARBINARY(128)

SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN TRY
	SELECT 0;

	IF(@nSplittMenge IS not NULL AND @nSplittMenge > 0)
	BEGIN
		-- Virtuelle Tabelle erstellen
		SELECT * INTO #WarenLagerEingang 
			FROM dbo.tWarenLagerEingang  WITH(NOLOCK) 
			WHERE dbo.tWarenLagerEingang.kWarenLagerEingang = @kWarenLagerEingang;	

		SELECT @nAnzahlAktuellAltWle = #WarenLagerEingang.fAnzahlAktuell , @dQuellDatum =  #WarenLagerEingang.dErstellt
			FROM #WarenLagerEingang 
			WHERE #WarenLagerEingang.kWarenLagerEingang = @kWarenLagerEingang;

		IF(@nAnzahlAktuellAltWle >= @nSplittMenge)
		BEGIN	  
			SELECT @fAnzahlReserviertPickpos = fAnzahlReserviertPickpos 
			FROM dbo.tWarenLagerEingang WITH(NOLOCK) 
			WHERE kWarenLagerEingang = @kWarenLagerEingang;
	        
			IF(@fAnzahlReserviertPickpos > 0)
				SET @fAnzahlReserviertPickpos = @fAnzahlReserviertPickpos - @nSplittMenge;
	
			-- Bestand auf alten Wle verringern
			UPDATE dbo.tWarenLagerEingang WITH(ROWLOCK) 
			SET fAnzahl = (fAnzahl - @nSplittMenge),fAnzahlAktuell = (fAnzahlAktuell - @nSplittMenge),fAnzahlReserviertPickpos = @fAnzahlReserviertPickpos
			WHERE kWarenLagerEingang = @kWarenLagerEingang;

			-- PK der Virtuellen Tabelle dropen, damit er in der reallen erstellt werden kann
			ALTER TABLE #WarenLagerEingang DROP COLUMN kWarenLagerEingang;
 
			IF(CONTEXT_INFO() IS NOT NULL)
			BEGIN
			  SET @OldContextInfo = CONTEXT_INFO()
			END;
			ELSE
			BEGIN
			  SET @OldContextInfo = 0x0000
			END;

			SET CONTEXT_INFO 0x5085; -- Keine Trigger hier zwischen
		
			  -- neuen Wle anlegen mit werten vom alten
			INSERT INTO tWarenLagerEingang  WITH(ROWLOCK) 
			SELECT #WarenLagerEingang.* FROM #WarenLagerEingang;

			-- Menge im neuen Wle setzten
			SET @kWarenLagerEingangNew = SCOPE_IDENTITY();


			SET CONTEXT_INFO @OldContextInfo;

			UPDATE dbo.tWarenLagerEingang  WITH(ROWLOCK) 
			SET fAnzahl = @nSplittMenge,fAnzahlAktuell = @nSplittMenge, dErstellt = @dQuellDatum,kWarenLagerEingang_Ursprung = @kWarenLagerEingang, fAnzahlReserviertPickpos = @nSplittMenge
			WHERE kWarenLagerEingang = @kWarenLagerEingangNew;
  
			--Return ist PK vom neuen Wle
			SET @kOutWarenLagerEingang = @kWarenLagerEingangNew;
		END;
		ELSE
		BEGIN
			SELECT -203000017; -- es wird versucht mehr zu splitten als auf der Lagereingang ist, dies muß vorher abgefangen werden
		END;
	END;
END TRY

BEGIN CATCH	
	SELECT -203000018;
END CATCH
go

