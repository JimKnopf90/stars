CREATE TRIGGER [dbo].[jtlActionValidator_teigenschaft]  
--     
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--    
ON [dbo].[teigenschaft]  
AFTER DELETE 
AS  
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN 

	--
	--Überprüfen ob Trigger mit Inhalt aufgerufen wird
	--
		IF((SELECT COUNT(1) FROM DELETED) = 0)
		BEGIN
			RETURN
		END

	--
	-- teigenschaftwert aufräumen
	--
		DELETE teigenschaftwert WITH(ROWLOCK)
		FROM teigenschaftwert WITH(ROWLOCK)
		JOIN DELETED ON teigenschaftwert.kEigenschaft = DELETED.kEigenschaft
	--
	-- tEigenschaftKombiWert aufräumen
	--
		DELETE tEigenschaftKombiWert WITH(ROWLOCK)
		FROM tEigenschaftKombiWert WITH(ROWLOCK)
		JOIN DELETED ON tEigenschaftKombiWert.kEigenschaft = DELETED.kEigenschaft
	--
	-- tEigenschaftSichtbarkeit aufräumen
	--
		DELETE tEigenschaftSichtbarkeit WITH(ROWLOCK)
		FROM tEigenschaftSichtbarkeit WITH(ROWLOCK)
		JOIN DELETED ON tEigenschaftSichtbarkeit.kEigenschaft = DELETED.kEigenschaft
	--
	-- tEigenschaftSprache aufräumen
	--
		DELETE tEigenschaftSprache WITH(ROWLOCK)
		FROM tEigenschaftSprache WITH(ROWLOCK)
		JOIN DELETED ON tEigenschaftSprache.kEigenschaft = DELETED.kEigenschaft
END
go

