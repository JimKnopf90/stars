CREATE TRIGGER [dbo].[jtlActionValidator_tKundenGruppe]
ON [dbo].[tKundenGruppe]
AFTER DELETE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
	DELETE FROM dbo.tShopMappingKundengruppe
		WHERE dbo.tShopMappingKundengruppe.kKundengruppe IN (
			SELECT DELETED.kKundenGruppe FROM DELETED);
END
go

