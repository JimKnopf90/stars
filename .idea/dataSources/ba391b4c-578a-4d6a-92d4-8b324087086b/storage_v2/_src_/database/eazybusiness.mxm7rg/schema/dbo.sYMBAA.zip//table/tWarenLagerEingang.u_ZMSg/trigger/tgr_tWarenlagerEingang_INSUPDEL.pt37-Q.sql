CREATE TRIGGER [dbo].[tgr_tWarenlagerEingang_INSUPDEL]
ON [dbo].[tWarenLagerEingang]
AFTER INSERT, UPDATE, DELETE
AS
     --
	-- Ausnahmen:
	-- spWarenLagerAusgangSchreiben 0x5089
	-- spWarenlagerEingangSchreiben 0x5091
	-- tgr_tPicklistePos_Insert 0x5093
	-- tgr_tPicklistePos_Update 0x5094
	-- tgr_tPicklistePos_Delete 0x5095
	-- jtlActionValidator_tartikel 0x6001
	-- spWMSWareneingangKorrigieren 0x5096
	-- jtlActionValidator_tWarenLagerPlatz 0x5097
	-- spRetourePositionZusammenfassen 0x5130
	--
	IF(CONTEXT_INFO() IN(0x5089,0x5091,0x5092,0x5093,0x5094,0x5095,0x6001,0x5096,0x5097,0x5130))
	BEGIN
		RETURN;
	END;
	IF((UPDATE(kBestellPosUmlagerung))
		AND EXISTS(SELECT * FROM INSERTED JOIN DELETED ON INSERTED.kWarenLagerEingang= DELETED.kWarenLagerEingang))
	BEGIN
		RETURN;
	END;
	ROLLBACK;
	RAISERROR (N'Die Tabelle dbo.tWarenlagerEingang kann nur über die SP spWarenlagerEingangSchreiben gefüllt werden.', 15,1);
go

