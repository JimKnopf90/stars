--- 
--- spWMSPicklisteAnlegen
---

CREATE PROCEDURE [dbo].[spWMSPicklisteAnlegen]
@kBestellung INT,
@kWarenlager INT,
@kBenutzer INT,
@nTeilLiefErlaubt INT,
@kPickliste INT OUT,
@nErrorCode INT OUT

AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;

	
	DECLARE @ErrorMessage NVARCHAR(4000);
	DECLARE @ErrorSeverity INT;
	DECLARE @ErrorState INT;
	DECLARE @retry INT;
	DECLARE @CreatedTransaction INT;
	DECLARE @kSessionIDPickliste INT;
	DECLARE @dAktuellesDatum DATETIME;
	DECLARE @kPicklisteVorlageAktuell INT;
	DECLARE @fMengeErfolgreichReserviert DECIMAL(28,14) = 0;
	DECLARE @kPicklisteStatus INT;

	SET @retry = 5;
	WHILE @retry > 0
	BEGIN
 

	BEGIN TRY
		IF (@@TRANCOUNT = 0)
		BEGIN
		   SET @CreatedTransaction = 1;
		   BEGIN TRANSACTION
		END;
		ELSE
		BEGIN
			SET @CreatedTransaction = 0;
			SAVE TRANSACTION Savepoint0;
		END;


		IF(EXISTS (SELECT * FROM dbo.tBestellungPicklisteLock
				   WHERE dbo.tBestellungPicklisteLock.kBestellung = @kBestellung))
		BEGIN
			RAISERROR (	'Bestellung wird grade von wo anders reserviert.', 18, 1);
			RETURN;

		END;


		SELECT TOP(1) @kPickliste =  dbo.tPicklistePos.kPickliste
		FROM dbo.tPicklistePos 
		JOIN dbo.tbestellpos ON dbo.tbestellpos.kBestellPos = dbo.tPicklistePos.kBestellPos
		WHERE dbo.tbestellpos.tBestellung_kBestellung = @kBestellung
		AND dbo.tPicklistePos.nStatus < 30
		AND dbo.tPicklistePos.kPickliste > 0
		AND dbo.tPicklistePos.kWarenLager = @kWarenlager
		GROUP BY dbo.tPicklistePos.kPickliste;
		
		IF(@kPickliste > 0)
		BEGIN

			IF(@CreatedTransaction = 1)
			BEGIN
				COMMIT;-- Nur wenn kein Savepoint gesetzt
			END
			RETURN;

		END;

		SET @dAktuellesDatum = GETDATE();

		INSERT INTO dbo.tPicklisteVorlage
		(
		    kPickliste, nIstVorlage, nAnzahlBestellungen, kBestellNr, nAnzahlArtikelAuftragMax, nAnzahlArtikelAuftragMin, nTeillieferungen,fTeillieferungenWert,
		    nBoxenVon,  nBoxenBis,nEinArtikelPickliste,fGewichtVon, fGewichtBis, cWarenLagerPlatzVon, cWarenLagerPlatzBis, nSortierung,  cKommentar,dVonDatum,
		    dBisDatum,kBenutzer,dAngelegt,cVersandartNr,cShops, cPlattformen,kWarenlager,cName,nWEPlatzReservieren,nQuickSlot,cWarengruppen,kRollendeKommissionierungPickwagen,
		    nBestellungWMSFreigabe, nMaxAnzahlArtikel, nLadenlokalEinbeziehen,nNichtBezahltVorkommissionieren, nNichtBezahltAutomatischAufVorkommi, cLieferlaender,
		    cLagerbereiche,fPreisAuftragMax, fPreisAuftragMin, cAuftragkennzeichnung,cFirmen, cKundengruppen, cVersandklassen, cZahlungsarten,nEnthaeltArtAusWarengruppe,
		    nAlleOhneWarengruppe,nAlleOhneVersandart, nAlleOhneZahlungsart,nDirektVerpacken, cBenutzer, nSortenrein, nAuftragsArt,nMHDHandling,nMHDMinHaltbarkeit,
		    nArtikelBreiteVon,nArtikelBreiteBis, nArtikelHoeheVon,nArtikelHoeheBis,nArtikelLaengeVon,nArtikelLaengeBis,nMobilerPacktisch,nBoxenNurGanzeStuecklistenAufPL,
		    nAuftragsVolumenVon, nAuftragsVolumenBis,nOhneVolumenAusschliessen
		)
		VALUES
		(
		    0, -- kPickliste - int
		    0, -- nIstVorlage - tinyint
		    0, -- nAnzahlBestellungen - int
		    0, -- kBestellNr - int
		    0, -- nAnzahlArtikelAuftragMax - int
		    0, -- nAnzahlArtikelAuftragMin - int
		    0, -- nTeillieferungen - tinyint
		    0, -- fTeillieferungenWert - decimal
		    0, -- nBoxenVon - int
		    0, -- nBoxenBis - int
		    1, -- nEinArtikelPickliste - tinyint
		    0, -- fGewichtVon - decimal
		    0, -- fGewichtBis - decimal
		    '', -- cWarenLagerPlatzVon - varchar
		    '', -- cWarenLagerPlatzBis - varchar
		    0, -- nSortierung - tinyint
		    '', -- cKommentar - varchar
		    null, -- dVonDatum - datetime
		    null, -- dBisDatum - datetime
		    0, -- kBenutzer - int
		    @dAktuellesDatum, -- dAngelegt - datetime
		    '', -- cVersandartNr - varchar
		    '', -- cShops - varchar
		    '', -- cPlattformen - varchar
		    0, -- kWarenlager - int
		    'Packtisch', -- cName - varchar
		    0, -- nWEPlatzReservieren - tinyint
		    0, -- nQuickSlot - int
		    '', -- cWarengruppen - varchar
		    0, -- kRollendeKommissionierungPickwagen - int
		    0, -- nBestellungWMSFreigabe - tinyint
		    0, -- nMaxAnzahlArtikel - int
		    0, -- nLadenlokalEinbeziehen - tinyint
		    0, -- nNichtBezahltVorkommissionieren - tinyint
		    0, -- nNichtBezahltAutomatischAufVorkommi - tinyint
		    '', -- cLieferlaender - varchar
		    '', -- cLagerbereiche - varchar
		    0, -- fPreisAuftragMax - decimal
		    0, -- fPreisAuftragMin - decimal
		    '', -- cAuftragkennzeichnung - varchar
		    '', -- cFirmen - varchar
		    '', -- cKundengruppen - varchar
		    '', -- cVersandklassen - varchar
		    '', -- cZahlungsarten - varchar
		    0, -- nEnthaeltArtAusWarengruppe - tinyint
		    0, -- nAlleOhneWarengruppe - tinyint
		    0, -- nAlleOhneVersandart - tinyint
		    0, -- nAlleOhneZahlungsart - tinyint
		    0, -- nDirektVerpacken - tinyint
		    @kBenutzer, -- cBenutzer - varchar
		    0, -- nSortenrein - tinyint
		    0, -- nAuftragsArt - tinyint
		    0, -- nMHDHandling - tinyint
		    0, -- nMHDMinHaltbarkeit - int
		    0, -- nArtikelBreiteVon - int
		    0, -- nArtikelBreiteBis - int
		    0, -- nArtikelHoeheVon - int
		    0, -- nArtikelHoeheBis - int
		    0, -- nArtikelLaengeVon - int
		    0, -- nArtikelLaengeBis - int
		    0, -- nMobilerPacktisch - tinyint
		    0, -- nBoxenNurGanzeStuecklistenAufPL - tinyint
		    0, -- nAuftragsVolumenVon - bigint
		    0, -- nAuftragsVolumenBis - bigint
		    0 -- nOhneVolumenAusschliessen - tinyint
		);

		SET @kPicklisteVorlageAktuell = SCOPE_IDENTITY();

		INSERT INTO dbo.tPickliste (kWarenLager, kPicklistenVorlage, nStatus,kSessionId) 
		VALUES (@kWarenLager, @kPicklisteVorlageAktuell, 0,0);

		SET @kPickliste = SCOPE_IDENTITY();



		--
		-- FreiPos und Artikel ohne Lagerbestand auf Pickliste schreiben
		--
		INSERT INTO dbo.tPicklistePos
		(   kPickliste,kWarenLager,kWarenLagerEingang,fAnzahl, kBestellPos, kPicklistePosStatus,kArtikel, kWarenlagerPlatz,kPicklistePos_Ursprung,
		    kLieferscheinPos,kBestellung,nPickPrio,nStatus,kAnsprechpartner )

		SELECT @kPickliste, @kWarenlager,0,dbo.tBestellPos.nAnzahl - ISNULL(dbo.tPicklistePos.fAnzahl,0),dbo.tBestellPos.kBestellPos,0,ISNULL(dbo.tArtikel.kArtikel,0),0,NULL,0,@kBestellung,0,10,NULL
		FROM dbo.tBestellPos
		LEFT JOIN dbo.tArtikel ON dbo.tArtikel.kArtikel = dbo.tBestellPos.tArtikel_kArtikel
		LEFT JOIN dbo.tPicklistePos ON dbo.tPicklistePos.kBestellPos = dbo.tBestellPos.kBestellPos AND dbo.tPicklistePos.nStatus < 40
		WHERE (dbo.tArtikel.kArtikel IS NULL OR dbo.tArtikel.cLagerAktiv = 'N' 
		       OR dbo.tBestellPos.kBestellStueckliste = dbo.tBestellPos.kBestellPos AND dbo.tBestellPos.kBestellStueckliste > 0
			   OR EXISTS (SELECT dbo.teigenschaft.kArtikel 
			              FROM dbo.teigenschaft 
						  WHERE dbo.tArtikel.kArtikel = dbo.teigenschaft.kArtikel AND dbo.teigenschaft.cAktiv = 'Y' AND dbo.tEigenschaft.cTyp != 'PFLICHT-FREIFELD') )
		AND dbo.tBestellPos.tBestellung_kBestellung = @kBestellung
		AND dbo.tBestellPos.nType IN (0,1,11);


		INSERT INTO dbo.tPicklistePosStatus (kPicklistePos, nStatus, kBenutzer, dZeitstempel)  
		SELECT dbo.tPicklistePos.kPicklistePos,10,@kBenutzer,@dAktuellesDatum
		FROM dbo.tPicklistePos 
		WHERE dbo.tPicklistePos.kPickliste = @kPickliste;
		
	

		EXEC dbo.spBestellungReservieren @kPickliste = @kPickliste, @kBestellung = @kBestellung, @kWarenlager = @kWarenlager, 
		                                 @kPicklisteVorlage = @kPicklisteVorlageAktuell, @kBenutzer = @kBenutzer, @nAnzArtMin = 0, 
										 @nAnzArtMax = 0, @nGewMin = 0, @nGewMax = 0, @nTeilLiefErlaubt = @nTeilLiefErlaubt,
										 @fTeilliefPreis = 0,@nWEPlatzReservieren = 0, @nLadenlokalReservieren = 0, @nRetourPlatzReservieren = 0,
										 @nSortierung = 0, @nDebug = 0, @kSessionID = 0, @nEinartikelpickliste = 1,
										 @kReineRollendeKommissionierung = 0,  @fMengeErfolgreichReserviert = @fMengeErfolgreichReserviert OUTPUT;
	        			


		
		IF( NOT EXISTS (SELECT * 
						FROM dbo.tPicklistePos
						WHERE dbo.tPicklistePos.kPickliste = @kPickliste))
		BEGIN

		  IF(@CreatedTransaction = 1)
		  BEGIN
		      ROLLBACK TRANSACTION;
		  END;
		  ELSE
		  BEGIN
		      ROLLBACK TRANSACTION Savepoint0;
		  END;

		  SET @kPickliste = 0;






		  --
		  -- FEHLERBEHANDLUNG. Wieso konnte der Auftrag nicht reserviert werden ?
		  --

		  IF( 0 < (SELECT count(*) FROM tBestellung
		           JOIN tkunde ON tKunde.kKunde  = tBestellung.tKunde_kKunde
		           WHERE kBestellung = @kBestellung
		           AND tkunde.cSperre = 'Y'))
		  BEGIN 
		      SET @nErrorCode = 5131001; --Der Kunde für diese Bestellung ist gesperrt.
			  RETURN;
		  END;
		  
		  
		  IF( 0 < (SELECT count(*) FROM tBestellung
		           WHERE kBestellung = @kBestellung
		           AND tBestellung.kRueckhalteGrund > 0 ))
		  BEGIN
		     SET @nErrorCode = 5131002; -- Bestellung wird zurückgehalten
			 RETURN;
		  END;
		  

		  DECLARE @nRechnungsCount INT
		  SELECT @nRechnungsCount = count(*) 
		  		FROM tBestellung
		  		JOIN tRechnung ON tRechnung.tBestellung_kBestellung = tBestellung.kBestellung
		  		JOIN tgutschrift ON tgutschrift.kRechnung = tRechnung.kRechnung
		            WHERE kBestellung = @kBestellung;
		  
		  
		  IF( 0 < @nRechnungsCount)
		  BEGIN	  
			SET @nErrorCode = 5131004; --Bestellung hat Gutschriften. Bitte beachten sie gutgeschriebene Artikel nicht reserviert werden.
			RETURN;
		  END;
		  
		  DECLARE @FifoAktiv TINYINT = 0;
		  SELECT @FifoAktiv= cValue 
		  FROM tOptions
		  WHERE cKey = 'FIFOAktiv';
		  
		  IF( 1 = @FifoAktiv)
		  BEGIN
		  
		    DECLARE @nStatusBestellung INT;
		    SELECT @nStatusBestellung = Versand.vBestellungLieferInfoProLager.nLieferbarEigen
		    FROM Versand.vBestellungLieferInfoProLager
		    WHERE Versand.vBestellungLieferInfoProLager.kWarenLager = kWarenlager
		    AND Versand.vBestellungLieferInfoProLager.kBestellung = @kBestellung;
		    
		    IF(@nStatusBestellung = 0)
		    BEGIN
		      	SET @nErrorCode = 5131005; --FIFO ist aktiv. Bestellung ist nicht lieferbar. Kein freier Bestand vorhanden.
				RETURN;
		    END;
		      
		      
		    IF(@nStatusBestellung = 1)
		    BEGIN
		       SET @nErrorCode = 5131006; --FIFO ist aktiv. Bestellung ist nur teilweise lieferbar. Nicht genug freier Bestand vorhanden.
			   RETURN;
		    END;
		  END;

		  SET @nErrorCode = 5131099; -- Anderer Grund
		
		END;
		ELSE
		BEGIN

		    SET @nErrorCode = 0;

			INSERT INTO dbo.tPicklisteStatus
			(
			    --kPicklisteStatus - this column value is auto-generated
			    kPickliste,
			    kBenutzer,
			    dZeitstempel,
			    nStatus
			)
			VALUES
			(
			    @kPickliste, -- kPickliste - int
			    @kBenutzer, -- kBenutzer - int
			     getdate(), -- dZeitstempel - datetime
			    10 -- nStatus - int
			);

			SET @kPicklisteStatus = SCOPE_IDENTITY();

			UPDATE tPickliste SET kSessionId = null, kPicklisteStatus = @kPicklisteStatus, kPicklisteStatusAngelegt = @kPicklisteStatus, nStatus = 10
			WHERE kPickliste = @kPickliste;

			IF(@CreatedTransaction = 1)
			BEGIN
				COMMIT;-- Nur wenn kein Savepoint gesetzt
			END;
		END;
	END TRY
	BEGIN CATCH
	-- Dedlock Catch
		IF(ERROR_NUMBER() = 1205)
			BEGIN
				SET @retry = @retry - 1;
				IF(@CreatedTransaction = 1)
				BEGIN
				    ROLLBACK TRANSACTION;
				END
				ELSE
				BEGIN
				    ROLLBACK TRANSACTION Savepoint0;
				END
				IF(@retry = 0)
				BEGIN
					SELECT @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
					RAISERROR (	@ErrorMessage, 
								@ErrorSeverity,
								@ErrorState
					);
					SET CONTEXT_INFO 0x0;
					RETURN;
				END
				EXEC dbo.spWaitRandom;
			END
			ELSE 
			BEGIN
				SET @retry = -1;
				SELECT @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();

				IF(@CreatedTransaction = 1)
				BEGIN
				    ROLLBACK TRANSACTION;
				END
				ELSE
				BEGIN
				    ROLLBACK TRANSACTION Savepoint0;
				END
				RAISERROR (	@ErrorMessage, 
							@ErrorSeverity,
							@ErrorState
				);
				RETURN;
			END;
	END CATCH;
 

	RETURN;
END
go

