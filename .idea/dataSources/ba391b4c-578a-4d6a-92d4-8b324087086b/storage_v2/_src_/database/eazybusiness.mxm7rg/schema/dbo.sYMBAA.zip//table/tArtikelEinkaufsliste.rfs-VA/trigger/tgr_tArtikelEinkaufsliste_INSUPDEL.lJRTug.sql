CREATE TRIGGER [dbo].[tgr_tArtikelEinkaufsliste_INSUPDEL]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP
--
ON [dbo].[tArtikelEinkaufsliste]
AFTER INSERT, UPDATE, DELETE
AS
SET CONCAT_NULL_YIELDS_NULL ON;
SET ANSI_WARNINGS ON;
SET ANSI_PADDING ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
SET QUOTED_IDENTIFIER ON;
BEGIN
	--Überprüfen ob Trigger mit Inhalt aufgerufen wird
	IF((SELECT COUNT(1) FROM INSERTED FULL JOIN DELETED ON INSERTED.kArtikel = DELETED.kArtikel) = 0)
	BEGIN 
		RETURN
	END
	--
	-- Lagerbestände (fAufEinkaufsliste) aktualisieren
	--
	DECLARE @typeArtikel AS TYPE_spUpdateLagerbestand;

	INSERT INTO @typeArtikel (kArtikel)
	SELECT DISTINCT kArtikel
		FROM
		(
			SELECT kArtikel FROM
			(
				SELECT kArtikel AS kArtikel FROM DELETED
					GROUP BY kArtikel
				UNION ALL
				SELECT kArtikel AS kArtikel FROM INSERTED
					GROUP BY kArtikel
			) AS U1
			GROUP BY U1.kArtikel
		) AS U2
		WHERE kArtikel = U2.kArtikel;

	EXEC spUpdateLagerBestand @typeArtikel;
END
go

