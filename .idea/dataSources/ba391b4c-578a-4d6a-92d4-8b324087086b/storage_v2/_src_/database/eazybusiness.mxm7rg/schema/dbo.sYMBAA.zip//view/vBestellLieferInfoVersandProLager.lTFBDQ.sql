CREATE VIEW [dbo].[vBestellLieferInfoVersandProLager] AS
    --
    -- Copyright (c) 2012-2017 by JTL Software GmbH
    -- Datum: $Date: 2017-02-15 07:48:57 +0100 (Mi, 15 Feb 2017) $
    -- Version: $Rev: 54820 $
    -- Autor: SB
    --
   SELECT * FROM vBestellLieferInfoVersand WHERE dbo.vBestellLieferInfoVersand.kWarenlager <> 0
go

