CREATE VIEW [dbo].[vWMSArtikel]
AS

    --
    -- Copyright (c) 2012-2017 by JTL Software GmbH
    -- Datum: $Date$
    -- Version: $Rev$
    -- Autor: PN
    --

SELECT     dbo.tartikel.kArtikel, dbo.tartikel.cArtNr, tArtikelBeschreibung.cName AS cName, tArtikelBeschreibung.cBeschreibung as cBeschreibung, fVKNetto + ((fVKNetto / 100) * tSteuercache.fSteuersatz) AS fVKbrutto, dbo.tartikel.fVKNetto, dbo.tartikel.fUVP, 
                      dbo.tartikel.cAnmerkung, dbo.tartikel.cPreisliste, dbo.tartikel.cAktiv, dbo.tartikel.nLagerbestand, tSteuercache.fSteuersatz AS fMwSt, tEinheitSprache.cName AS cEinheit, 
                      dbo.tartikel.nMindestbestellmaenge, dbo.tartikel.cBarcode, dbo.tartikel.cErloeskonto, 0 AS fVKHaendlerBrutto, 0 AS fVKHaendlerNetto, 
                      dbo.tartikel.cTopArtikel, dbo.tartikel.cInet, dbo.tartikel.cDelInet, dbo.tartikel.fGewicht, dbo.tartikel.cNeu, tArtikelBeschreibung.cKurzBeschreibung AS cKurzBeschreibung, dbo.tartikel.cLagerArtikel, 
                      dbo.tartikel.cTeilbar, dbo.tartikel.cLagerAktiv, dbo.tartikel.cLagerKleinerNull, dbo.tartikel.nMidestbestand, dbo.tartikel.fEKNetto, dbo.tHersteller.cName AS cHersteller, 
                      dbo.tartikel.fEbayPreis, dbo.tartikel.cLagerVariation, dbo.tartikel.nDelete, dbo.tartikel.dMod, dbo.tartikel.fPackeinheit, dbo.tartikel.nVPE, dbo.tartikel.fVPEWert, 
                      VPEEinheitSprache.cName AS cVPEEinheit, dbo.tLieferStatus.cName AS cLieferstatus, dbo.tartikel.cSuchbegriffe, dbo.tartikel.cTaric, dbo.tartikel.cHerkunftsland, dbo.tartikel.kSteuerklasse, 
                      dbo.tartikel.dErstelldatum, tArtikelBeschreibung.cUrlPfad AS cSeo, dbo.tartikel.dErscheinungsdatum, dbo.tartikel.nSort, dbo.tartikel.kVersandklasse, dbo.tartikel.fArtGewicht, 
                      dbo.tartikel.cHAN, dbo.tartikel.cSerie, dbo.tartikel.cISBN, dbo.tartikel.cUNNummer, dbo.tartikel.cGefahrnr, dbo.tartikel.cASIN, dbo.tartikel.kEigenschaftKombi, 
                      dbo.tartikel.kVaterArtikel, dbo.tartikel.nIstVater, dbo.tartikel.nIstMindestbestand, dbo.tartikel.fAbnahmeintervall, dbo.tartikel.kStueckliste, dbo.tartikel.cUPC, 
                      dbo.tartikel.kWarengruppe, dbo.tartikel.cEPID, dbo.tartikel.nMHD, dbo.tartikel.nCharge, dbo.tartikel.nNichtBestellbar, dbo.tartikel.fAmazonVK, dbo.tartikel.nPufferTyp, 
                      dbo.tartikel.nPuffer, dbo.tartikel.nProzentualePreisStaffelAktiv, dbo.tartikel.nSeriennummernVerfolgung, dbo.tartikel.kMassEinheit, dbo.tartikel.fMassMenge, 
                      dbo.tartikel.kGrundPreisEinheit, dbo.tartikel.fGrundpreisMenge, dbo.tartikel.fBreite, dbo.tartikel.fHoehe, dbo.tartikel.fLaenge, dbo.tartikel.nLiefertageWennAusverkauft, 
                      dbo.tartikel.kVPEEinheit, dbo.tartikel.kVerkaufsEinheit,dbo.tartikel.fLetzterEK,dbo.tartikel.dletzterEK, dbo.tArtikel.kZustand, dbo.tArtikel.cJfpid
FROM   dbo.tartikel WITH (NOLOCK) 
CROSS JOIN tSpracheUsed
JOIN tArtikelBeschreibung ON tArtikelBeschreibung.kArtikel = tArtikel.kArtikel AND tArtikelBeschreibung.kSprache = tSpracheUsed.kSprache AND tArtikelBeschreibung.kPlattform = 1
LEFT JOIN tSteuercache ON tSteuercache.kSteuerKlasse = tartikel.kSteuerKlasse  AND dbo.tSteuercache.kFirma = 0 	
LEFT JOIN tLieferStatus ON tLieferStatus.kLieferStatus = tArtikel.kLieferStatus AND tLieferStatus.kSprache = tSpracheUsed.kSprache
LEFT JOIN tHersteller ON tHersteller.kHersteller = tArtikel.kHersteller
LEFT JOIN tEinheitSprache VPEEinheitSprache ON VPEEinheitSprache.kEinheit = tArtikel.kVPEEinheit AND VPEEinheitSprache.kSprache = tSpracheUsed.kSprache
LEFT JOIN tEinheitSprache ON tEinheitSprache.kEinheit = tArtikel.kVerkaufsEinheit AND tEinheitSprache.kSprache = tSpracheUsed.kSprache
WHERE     (dbo.tartikel.cLagerAktiv = 'Y') 
AND (dbo.tartikel.cLagerVariation <> 'Y') 
AND (dbo.tartikel.nIstVater = 0) 
AND (dbo.tartikel.kStueckliste = 0) 
AND tSpracheUsed.nStandard = 1
AND NOT EXISTS (SELECT teigenschaft.kArtikel FROM teigenschaft WHERE tArtikel.kArtikel = teigenschaft.kArtikel AND teigenschaft.cAktiv = 'Y' AND tEigenschaft.cTyp NOT IN ('PFLICHT-FREIFELD','FREIFELD'))
go

