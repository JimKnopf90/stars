--- 
--- spSplitAuftragByMenge
---

CREATE PROCEDURE [dbo].[spSplitAuftragByMenge]
	--
	-- Copyright (c) 2012-2017 by JTL Software GmbH
	-- Datum: $Date$
	-- Version: $Rev$
	--
	@kBestellung INT,
	@kBenutzer INT,
	@kLhm      INT    
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;

    DECLARE @CreatedTransaction BIT
    DECLARE @nRet INT;
    DECLARE @kBestellungNewOrder INT;
    DECLARE @text varchar(1000);
    DECLARE @kWarenlager INT;
    DECLARE @Temp_BestellPosNeu TABLE(kBestellPos INT,kArtikel INT,fMenge DECIMAL(28,5),kBestellstueckliste INT);
    DECLARE @cBestellNrQuell VARCHAR(255);
    DECLARE @cBestellNrSlitt VARCHAR(255);

    IF (@@TRANCOUNT = 0)
    BEGIN
	   SET @CreatedTransaction = 1;
	   BEGIN TRAN
    END;
    ELSE
    BEGIN
	   SET @CreatedTransaction = 0;
	   SAVE TRAN Savepoint1;
    END;



    BEGIN TRY    
		SET @nRet = 0;
		SET @kBestellungNewOrder = 0;

		SELECT @kWarenlager = kWarenlager
		FROM dbo.tLHM
		WHERE kLHM = @kLhm;

	
	     INSERT INTO @Temp_BestellPosNeu
	     SELECT tbestellpos.kbestellpos AS kBestellpos, dbo.tbestellpos.tArtikel_kArtikel, CASE WHEN SUM(dbo.twarenlagereingang.fAnzahl) IS NULL 
	     							            THEN CASE WHEN dbo.tbestellpos.kBestellStueckliste > 0 
													   THEN (cast (SUM(dbo.tbestellpos.nAnzahl)AS DECIMAL) *  (cast (StueckListenAnteile.AnzahlPickposStuecklisten AS DECIMAL) / cast (StueckListenAnteile.AnzahlStuecklistenVater AS DECIMAL)))
													  ELSE SUM(dbo.tbestellpos.nAnzahl) END
	     								       ELSE SUM(dbo.twarenlagereingang.fAnzahl) END AS fAnzahlNeu,
											  dbo.tbestellpos.kBestellStueckliste
	     FROM dbo.tbestellpos WITH(NOLOCK)
	     LEFT JOIN dbo.tpicklistepos WITH(NOLOCK) ON tpicklistepos.kbestellpos = tbestellpos.kbestellpos AND dbo.tpicklistepos.nStatus >= 30 AND dbo.tpicklistepos.nStatus <= 35 
	     LEFT JOIN dbo.twarenlagereingang WITH(NOLOCK) ON dbo.twarenlagereingang.kwarenlagereingang = dbo.tpicklistepos.kwarenlagereingang AND dbo.twarenlagereingang.fAnzahlAktuell > 0 AND dbo.twarenlagereingang.klhm = @kLhm
	     LEFT JOIN dbo.tArtikel ON dbo.tArtikel.kArtikel = dbo.tbestellpos.tArtikel_kArtikel
		OUTER APPLY (SELECT DISTINCT ISNULL(cast (AnzahlInPickPos.AnzahlPickPos AS DECIMAL) / ( cast (AnzahlInPickPos.AnzahlBestellpos AS DECIMAL) / cast (vater.nAnzahl AS DECIMAL)),0) AS AnzahlPickposStuecklisten , vater.nAnzahl AS AnzahlStuecklistenVater
	                 FROM tBestellPos AS BestPosStueckListe
				  LEFT JOIN (SELECT  tbestellpos.kbestellpos ,tbestellpos.nAnzahl 
				             FROM tbestellpos
						   WHERE tbestellpos.tBestellung_kBestellung = @kBestellung
						   ) AS vater ON vater.kbestellpos = BestPosStueckListe.kbestellstueckliste
				  OUTER APPLY (SELECT TOP 1 SUM(CheckPickPos.fAnzahl) AS AnzahlPickPos,  CheckBestellPos.nAnzahl AS AnzahlBestellpos
						   FROM dbo.tpicklistepos AS CheckPickPos
					        JOIN dbo.tbestellpos AS CheckBestellPos ON  CheckBestellPos.kBestellPos = CheckPickPos.kBestellPos
						   WHERE CheckBestellPos.kBestellStueckliste = tBestellPos.kBestellStueckliste 
						   AND CheckBestellPos.tBestellung_kBestellung = @kBestellung 
	 					   AND CheckPickPos.nStatus >= 30 AND CheckPickPos.nStatus <= 35
						   GROUP BY CheckPickPos.kBestellPos,CheckBestellPos.nAnzahl ) AS AnzahlInPickPos -- Wie ist der Anteil der LagerArtikel in der Pickliste

				  WHERE tBestellPos.kBestellStueckliste = BestPosStueckListe.kBestellStueckliste 
				  AND BestPosStueckListe.tBestellung_kBestellung = @kBestellung
				 
				) AS StueckListenAnteile --Brauchen wir um die Freipositionen der Stücklisten , anteilig des Vater absplitten zu können


		WHERE dbo.tbestellpos.tBestellung_kBestellung = @kBestellung 
	     AND (((dbo.twarenlagereingang.kWarenLagerEingang IS NOT NULL OR   --Wir splitten alle WMS-Artikel auf der Pickliste
		    dbo.tbestellpos.nType IN (0,2) OR -- Und alle FreiPos/VersandPos im Auftrag
		    dbo.tArtikel.cLagerAktiv = 'N') -- Und alle die keine LagerArtikel sind
		                  AND (dbo.tbestellpos.cUnique IS NULL OR dbo.tbestellpos.cUnique = '')) --Aber nicht wenn es KonfiArtikel sind, dann wird weiter unten gefiltert
	         OR ((dbo.twarenlagereingang.kWarenLagerEingang IS NOT NULL OR dbo.tbestellpos.nType IN (0,2) OR dbo.tArtikel.cLagerAktiv = 'N')
		         AND LEN(dbo.tbestellpos.cUnique) > 0 AND NOT EXISTS(SELECT * FROM dbo.tbestellpos b2  --Es darf keinen Konfi Artikel geben mit der unique der nicht in der box ist
					    LEFT JOIN dbo.tpicklistepos p2 WITH(NOLOCK) ON p2.kbestellpos = b2.kbestellpos
					    LEFT JOIN dbo.twarenlagereingang w2 WITH(NOLOCK) ON w2.kwarenlagereingang = p2.kwarenlagereingang
					    LEFT JOIN dbo.vWMSArtikel AS WMSArtikel ON WMSArtikel.kArtikel = b2.tArtikel_kArtikel
					    OUTER APPLY (SELECT SUM(p3.fAnzahl) AS fAnzahl
					                 FROM tpicklistepos AS p3
								  WHERE p3.kBestellPos = b2.kBestellPos
								  AND p3.nStatus >= 30 
								  AND p3.nStatus <= 35) AS MengeBestellPosInPickPos
					    WHERE b2.cUnique = dbo.tbestellpos.cUnique -- Hat den gleichen Unique
					    AND b2.tBestellung_kBestellung = @kBestellung  -- 
					    AND WMSArtikel.kArtikel > 0 --Sein Artikel ist WMS artikel
					    -- Aber erfüllt eine der folgenden bedingungen nicht:
					    AND (w2.kWarenLagerEingang IS NULL OR w2.fAnzahlAktuell = 0 OR (p2.nStatus < 30 AND p2.nStatus > 35 OR w2.klhm != @kLhm OR MengeBestellPosInPickPos.fAnzahl < b2.nAnzahl) --Es gibt keinen Warenlagereingang dazu, oder falscher Status oder nicht in der Box
					    ))))
	     GROUP BY dbo.tbestellpos.kbestellpos,dbo.tbestellpos.tArtikel_kArtikel,dbo.tbestellpos.kBestellStueckliste,StueckListenAnteile.AnzahlPickposStuecklisten,StueckListenAnteile.AnzahlStuecklistenVater
		HAVING CASE WHEN SUM(dbo.twarenlagereingang.fAnzahl) IS NULL 
	     		  THEN CASE WHEN dbo.tbestellpos.kBestellStueckliste > 0 
					  THEN (SUM(dbo.tbestellpos.nAnzahl) *  (StueckListenAnteile.AnzahlPickposStuecklisten / StueckListenAnteile.AnzahlStuecklistenVater))
					  ELSE SUM(dbo.tbestellpos.nAnzahl) END
	     		  ELSE SUM(dbo.twarenlagereingang.fAnzahl) END > 0;

	   	INSERT INTO @Temp_BestellPosNeu(kBestellPos,kArtikel,fMenge)
	     SELECT tbestellpos.kBestellStueckliste,Vater.tArtikel_kArtikel, (( cast (MAX(ISNULL(t1.fAnzahlNeu,0.0))AS DECIMAL) / SUM( cast (ISNULL(tbestellpos.nAnzahl,0.0) AS DECIMAL)  )) * Vater.nAnzahl) AS fMengeGesammt
	     FROM tbestellpos
	     JOIN tBestellpos AS Vater ON Vater.kBestellPos = tbestellpos.kBestellStueckliste
	     LEFT JOIN (SELECT BestNeu.kBestellStueckliste,SUM(cast (ISNULL(BestNeu.fMenge,0.0)AS DECIMAL)) fAnzahlNeu
	     		    FROM @Temp_BestellPosNeu BestNeu
	     		    WHERE BestNeu.kBestellPos != BestNeu.kBestellStueckliste
	     		    and BestNeu.kBestellStueckliste > 0
	     		    group by BestNeu.kBestellStueckliste) AS t1 ON  t1.kBestellStueckliste = tbestellpos.kBestellStueckliste
	     WHERE tbestellpos.kBestellPos != tbestellpos.kBestellStueckliste
	     and tbestellpos.kBestellStueckliste > 0
	     and tbestellpos.tBestellung_kBestellung = @kBestellung
	     group by Vater.tArtikel_kArtikel,tbestellpos.kBestellStueckliste,Vater.nAnzahl
	     HAVING MAX(t1.fAnzahlNeu) > 0;
            


		 -- Alle Artikel die abgesplittet werden sollen
	     DECLARE @xSplitBestellPosition AS XML;

		SET @xSplitBestellPosition = (
	     SELECT PosNeu.kBestellPos AS kBestellpos,  PosNeu.fMenge AS fAnzahlNeu
	     FROM @Temp_BestellPosNeu AS PosNeu
		FOR XML PATH ('Bestellpos'), TYPE);



	     IF(@xSplitBestellPosition IS NULL)
		BEGIN

		  SET @nRet = -203000104;-- Keine Positioen zum splitten gefunden
		  SELECT -203000104;-- unbekannter Fehler

		END
	     
	     IF(@nRet = 0)
		BEGIN

		    IF(@xSplitBestellPosition IS NOT NULL)
		    BEGIN
			  EXEC Auftrag.spSplitAuftrag @xSplitBestellPosition, @kBenutzer;
		    END


	  	    -- Die Abgesplittete Bestellung, sie geht bei uns nicht raus.
		    SELECT TOP 1 @kBestellungNewOrder = kBestellung, @cBestellNrSlitt = cBestellNr
		    FROM tBestellung
		    WHERE kSplitBestellung = @kBestellung
		    ORDER BY kBestellung DESC;


		    -- Wir splitten das auch was ausgeliefert wird, deswegen tauschen wir die Bestell Nummern wieder
		    SELECT @cBestellNrQuell = cBestellNr
		    FROM tBestellung
		    WHERE kBestellung = @kBestellung
		    ORDER BY kBestellung DESC;

		    UPDATE tBestellung 
		    SET cBestellNr = @cBestellNrSlitt
		    WHERE kBestellung = @kBestellung;
	    
		    UPDATE tBestellung 
		    SET cBestellNr = @cBestellNrQuell
		    WHERE kBestellung = @kBestellungNewOrder;
		    ---


		    -- Teillieferung des Ursprungs rausnehmen
		    UPDATE tBestellungWMSFreigabe SET nTeillieferungErlaubt = 0
		    WHERE nTeillieferungErlaubt = 1
		    AND kBestellung = @kBestellung;



		    UPDATE tPicklistePos 
				SET tPicklistePos.kBestellung = @kBestellungNewOrder
				FROM tPicklistePos
				JOIN tBestellPos ON tBestellPos.kBestellPos = tPicklistePos.kBestellPos
				WHERE tBestellPos.tBestellung_kBestellung  IN (@kBestellungNewOrder,@kBestellung);


		    EXEC dbo.spSplitPicklisteByAuftrag  
				@kBestellungNewOrder = @kBestellung,
				@kBestellung = @kBestellungNewOrder,
				@kWarenlager = @kWarenlager,
				@kPickliste = null;      


  
		    IF(@kBestellungNewOrder = 0)
			    SET @nRet = -203000106;
		    ELSE
		    BEGIN
			    SELECT @kBestellungNewOrder;

		    END

		END;

		-- Im FehlerFall Rollback
		IF (@nRet = 0 AND @CreatedTransaction = 1) 
		BEGIN
            COMMIT TRAN;
	     END
		ELSE IF (@nRet != 0)
		BEGIN

		  IF (@CreatedTransaction = 1)
		  BEGIN
			 ROLLBACK TRAN;
		  END;
		  ELSE
		  BEGIN
			 ROLLBACK TRAN Savepoint1;
		  END;

		END
	  
		SELECT @nRet;
	END TRY  
	  
	BEGIN CATCH
		SET @text = ERROR_MESSAGE();

		IF (@CreatedTransaction = 1)
		BEGIN
			 ROLLBACK TRAN;
		END;
		ELSE
		BEGIN
			 ROLLBACK TRAN Savepoint1;
		END;

		SET @nRet = -203000105;-- unbekannter Fehler
		SELECT -203000105;-- unbekannter Fehler
	END CATCH
go

