--- 
--- spPlatzUmbuchen
---

CREATE PROCEDURE [dbo].[spPlatzUmbuchen]
@kArtikel INT,
@fAnzahl DECIMAL(28,14),
@kWarenlagerPLatzNeu INT,
@kWarenlagerPlatzAlt INT,
@cKommentar VARCHAR(255),
@kBuchungsart INT,
@kBenutzer INT,
@kLHMNeu INT = NULL,
@kLHMAlt INT = NULL,
@dMhd DATETIME = NULL,
@cChargenNr VARCHAR(255) = NULL
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
	-- Warenlagereingänge ermitteln
	IF(OBJECT_ID('tempdb..#WarenlagerEingaenge') IS NOT NULL)
		BEGIN
			DROP TABLE #WarenlagerEingaenge;
		END
		CREATE TABLE #WarenlagerEingaenge 
		(
			kWarenlagerEingang INT,
			fAnzahlAktuell DECIMAL(28,14),
			fAnzahlAufPickliste DECIMAL(28,14),
			LfdSumme DECIMAL(28,14)
		);
	INSERT INTO #WarenlagerEingaenge
	(
		kWarenlagerEingang,
		fAnzahlAktuell,
		fAnzahlAufPickliste,
		LfdSumme
	)
	SELECT	wA.kWarenLagerEingang,
			wA.fAnzahlAktuell,
			wA.fAnzahlReserviertPickpos AS fAnzahlAufPickliste,
			(SELECT SUM(wB.fAnzahlAktuell - wB.fAnzahlReserviertPickpos)
				FROM dbo.tWarenLagerEingang AS wB
				WHERE wB.kWarenLagerEingang <= wA.kWarenLagerEingang
					AND wB.kArtikel = @kArtikel
					AND wB.kWarenLagerPlatz = @kWarenlagerPlatzAlt
					AND wB.fAnzahlAktuell - wB.fAnzahlReserviertPickpos > 0.0
					AND(wB.dMHD = @dMhd OR @dMhd IS NULL)
					AND(wB.cChargenNr = @cChargenNr OR @cChargenNr IS NULL)
					AND(wB.kLHM = @kLHMAlt OR @kLHMAlt IS NULL OR @kLHMAlt = 0)
			) AS LfdSumme
		FROM dbo.tWarenLagerEingang AS wA
			WHERE wA.kWarenLagerPlatz = @kWarenlagerPlatzAlt
				AND wA.kArtikel = @kArtikel
				AND wA.fAnzahlAktuell - wA.fAnzahlReserviertPickpos > 0.0
				AND(wA.dMHD = @dMhd OR @dMhd IS NULL)
				AND(wA.cChargenNr = @cChargenNr OR @cChargenNr IS NULL)
				AND(wA.kLHM = @kLHMAlt OR @kLHMAlt IS NULL OR @kLHMAlt = 0)
			ORDER BY wA.kWarenLagerEingang;

	--
	-- Ist aureichend Menge zum Umlagern vorhanden (Error: 150001)
	--
	IF(NOT EXISTS(SELECT * FROM #WarenlagerEingaenge WHERE #WarenlagerEingaenge.LfdSumme >= @fAnzahl)) 
	BEGIN
		RAISERROR(150001,15,1, N'Nicht ausreichend Menge vorhanden zum Umbuchen.');
	END
	BEGIN TRANSACTION
		DECLARE @kWarenlagerEingang INT;
		DECLARE @kWarenlagerEingangNeu INT;
		DECLARE @fAnzahlUmbuchen DECIMAL(28,14);
		DECLARE cWarenlagerEingang CURSOR LOCAL FAST_FORWARD FOR
			SELECT #WarenlagerEingaenge.kWarenlagerEingang,
					#WarenlagerEingaenge.fAnzahlAktuell - #WarenlagerEingaenge.fAnzahlAufPickliste AS fAnzahlUmbuchen
				FROM #WarenlagerEingaenge 
				WHERE #WarenlagerEingaenge.LfdSumme <= @fAnzahl;
		OPEN cWarenlagerEingang;
		FETCH NEXT FROM cWarenlagerEingang INTO @kWarenlagerEingang, @fAnzahlUmbuchen;
		WHILE @@FETCH_STATUS = 0
		BEGIN
			EXEC dbo.spPlatzUmbuchenAusfuehren @kWarenlagerEingang, @fAnzahlUmbuchen, @kWarenlagerplatzNeu, @kLHMNeu, @kBuchungsart, 0, @kBenutzer, @cKommentar, @kWarenlagerEingangNeu OUTPUT;
			FETCH NEXT FROM cWarenlagerEingang INTO @kWarenlagerEingang, @fAnzahlUmbuchen;
		END
		CLOSE cWarenlagerEingang;
		DEALLOCATE cWarenlagerEingang;

		SET @kWarenlagerEingang = 0

		SELECT TOP(1) @kWarenlagerEingang = #WarenlagerEingaenge.kWarenlagerEingang,
				@fAnzahlUmbuchen = @fAnzahl - (#WarenlagerEingaenge.LfdSumme - (#WarenlagerEingaenge.fAnzahlAktuell - #WarenlagerEingaenge.fAnzahlAufPickliste))
			FROM #WarenlagerEingaenge 
			WHERE #WarenlagerEingaenge.LfdSumme > @fAnzahl
			ORDER BY #WarenlagerEingaenge.LfdSumme;

	    IF (@kWarenlagerEingang > 0 AND @fAnzahlUmbuchen > 0)
		BEGIN
			EXEC dbo.spPlatzUmbuchenAusfuehren @kWarenlagerEingang, @fAnzahlUmbuchen, @kWarenlagerplatzNeu, @kLHMNeu, @kBuchungsart, 0, @kBenutzer, @cKommentar, @kWarenlagerEingangNeu OUTPUT;
		END;
	COMMIT
END
go

