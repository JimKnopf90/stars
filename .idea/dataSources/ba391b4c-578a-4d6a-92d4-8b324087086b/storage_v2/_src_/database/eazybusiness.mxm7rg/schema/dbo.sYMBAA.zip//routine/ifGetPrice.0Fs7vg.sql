CREATE FUNCTION [dbo].[ifGetPrice] (@kArtikel AS INT, @kKunde AS INT, @kKundengruppe AS INT, @kShop AS INT, @fAnzahl AS INT)
RETURNS DECIMAL(28,15)
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP
-- Beschreibung:	Dient zur Ermittlung eines eindeutigen Preises für einen Artikel.
--					Parameter dürfen nicht NULL sein sondern statt dessen 0.
--
AS
BEGIN

	DECLARE @ReturnValue AS DECIMAL(28,15)

	SET @ReturnValue = 	(	
		SELECT ISNULL	(Sonderpreis.fNettoPreis, 
									ISNULL(AbweichenderVK.fNettoPreis, tArtikel.fVKNetto) * (1.0 - (ISNULL(Rabatt.fRabatt, 0.0) / 100.0))
								)
		FROM tArtikel WITH(NOLOCK)
		LEFT JOIN 
		(
			SELECT TOP(1)	kArtikel = BesterVK.kArtikel,
							fNettoPreis = BesterVK.fNettoPreis
			FROM
			(
				--
				-- Abweichenden VK Netto ermitteln für Kundengruppe
				--
					SELECT TOP(1)	kArtikel = tPreis.kArtikel,
									fNettoPreis = tPreisDetail.fNettoPreis
					FROM tPreis WITH(NOLOCK)
					JOIN tPreisDetail WITH(NOLOCK) ON tPreis.kPreis = tPreisDetail.kPreis
						AND tPreisDetail.nAnzahlAb <= @fAnzahl
					WHERE	tPreis.kKundenGruppe = @kKundengruppe
								AND tPreis.kKunde = 0
								AND tPreis.kShop = @kShop
								AND tPreis.kArtikel = @kArtikel
					ORDER BY tPreisDetail.nAnzahlAb DESC
				UNION ALL
				--
				-- Abweichenden VK Netto ermitteln für Kunden
				--
					SELECT TOP(1)	kArtikel = tPreis.kArtikel,
									fNettoPreis = tPreisDetail.fNettoPreis
					FROM tPreis WITH(NOLOCK)
					JOIN tPreisDetail WITH(NOLOCK) ON tPreis.kPreis = tPreisDetail.kPreis
						AND tPreisDetail.nAnzahlAb <= @fAnzahl
					WHERE	tPreis.kKunde = @kKunde
								AND tPreis.kKundenGruppe = 0
								AND tPreis.kShop = @kShop
								AND tPreis.kArtikel = @kArtikel
					ORDER BY tPreisDetail.nAnzahlAb DESC
			) AS BesterVK
			ORDER BY BesterVK.fNettoPreis ASC
		) AS AbweichenderVK ON tArtikel.kArtikel = AbweichenderVK.kArtikel
		LEFT JOIN
		(
			--
			-- Ermitteln von Sonderpreisen.
			-- Sonderpreise werden nicht mehr rabattiert.
			--
				SELECT TOP(1)	kArtikel = tArtikelSonderpreis.kArtikel,
								fNettoPreis = CONVERT(DECIMAL(28,15), ISNULL(tSonderpreise.fNettoPreis, 0.0))
				FROM tArtikelSonderpreis WITH(NOLOCK)
				JOIN tSonderpreise WITH(NOLOCK) ON tArtikelSonderpreis.kArtikelSonderpreis = tSonderpreise.kArtikelSonderpreis
					AND tSonderpreise.kKundenGruppe = CASE WHEN tSonderpreise.kKundenGruppe = 0 THEN 0 ELSE @kKundengruppe END
					AND tSonderpreise.kShop = CASE WHEN tSonderpreise.kShop = 0 THEN 0 ELSE @kShop END
				JOIN tlagerbestand WITH(NOLOCK) ON tArtikelSonderpreis.kArtikel = tlagerbestand.kArtikel
				JOIN tArtikel WITH(NOLOCK) ON tlagerbestand.kArtikel = tArtikel.kArtikel
				WHERE 	tSonderpreise.fNettopreis IS NOT NULL
						AND tArtikel.kArtikel = @kArtikel
						AND tArtikelSonderpreis.nAktiv = 1
						AND tArtikelSonderpreis.dStart <= GETDATE()
						AND ISNULL(tArtikelSonderpreis.dEnde, GETDATE()) >= GETDATE()						
						AND CASE WHEN tArtikel.cLagerAktiv = 'Y' THEN ISNULL(nIstAnzahl, 0.0) ELSE -1 END < tlagerbestand.fLagerbestand
				ORDER BY tSonderpreise.fNettoPreis ASC
		) AS Sonderpreis ON tArtikel.kArtikel = Sonderpreis.kArtikel
		LEFT JOIN
		(
			--
			-- Ermittlung des größstmöglichen Rabatt aller Rabatte
			--
				SELECT TOP(1)	kArtikel = @kArtikel,
								fRabatt = ISNULL(AlleRabatte.fRabatt, 0.0)
				FROM
				(
					--
					-- Ermittlung des Kundenrabatts
					--
						SELECT TOP(1)	fRabatt = CONVERT(DECIMAL(28,15), tKunde.fRabatt)
						FROM tKunde WITH(NOLOCK)
						WHERE	tKunde.kKunde = @kKunde
								AND tKunde.kKunde > 0
								AND ISNULL(tKunde.fRabatt, 0.0) != 0.0
						UNION ALL
					--
					-- Ermittlung des Kundengruppenrabatts
					--
						SELECT TOP(1)	fRabatt = CONVERT(DECIMAL(28,15), tKundenGruppe.fRabatt)
						FROM tKundenGruppe WITH(NOLOCK)
						WHERE	tKundenGruppe.kKundenGruppe = @kKundengruppe
								AND tKundenGruppe.kKundenGruppe > 0
								AND ISNULL(tKundenGruppe.fRabatt, 0.0) != 0.0
						UNION ALL
					--
					-- Ermittlung des Kategorierabatts
					--
						SELECT TOP(1)	fRabatt = CONVERT(DECIMAL(28,15), tKategorieRabatt.fRabatt)
						FROM tkategorieartikel WITH(NOLOCK)
						JOIN tKategorieRabatt WITH(NOLOCK) ON tkategorieartikel.kKategorie = tKategorieRabatt.kKategorie
							AND tKategorieRabatt.kKundenGruppe = @kKundengruppe
							AND tKategorieRabatt.kShop = @kShop
						WHERE	tkategorieartikel.kArtikel = @kArtikel
								AND ISNULL(tKategorieRabatt.fRabatt, 0.0) != 0.0
				) AS AlleRabatte
				ORDER BY AlleRabatte.fRabatt DESC
		) AS Rabatt ON tArtikel.kArtikel = Rabatt.kArtikel
		WHERE tArtikel.kArtikel = @kArtikel
	)


	RETURN(@ReturnValue)
END
go

