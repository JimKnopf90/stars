--- 
--- spAktualisiereStueckliste
---

CREATE PROCEDURE [dbo].[spAktualisiereStueckliste]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP
--
@Artikel TYPE_spAktualisiereStueckliste READONLY
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
	--
	-- Bekommt #spAktualisiereStuecklisteKomponenten(kArtikel BIGINT) übergeben
	--
	IF(object_id('tempdb..#spAktualisiereStuecklisteKomponenten') IS NOT NULL)
    BEGIN
	  DROP TABLE #spAktualisiereStuecklisteKomponenten
    END;
    CREATE TABLE #spAktualisiereStuecklisteKomponenten (kArtikel BIGINT);
    INSERT INTO #spAktualisiereStuecklisteKomponenten(kArtikel)
	SELECT kArtikel FROM @Artikel
	  

	--
	-- Muss überhaupt aktualisiert werden?	
	--
		IF(ISNULL((SELECT COUNT(kArtikel) FROM #spAktualisiereStuecklisteKomponenten), 0) > 0)
		BEGIN
			
			--
			-- Voreinstellungen abfragen zur Ø EK-Aktualisierung
			-- tOptions ('StuecklistenGLDAutomatik ') (1 = true)
			--

			SET CONTEXT_INFO 0x5009;
				IF(ISNULL((SELECT TOP 1 CONVERT(TINYINT, ISNULL(cValue, '0')) FROM tOptions WITH (NOLOCK) WHERE cKey = 'StuecklistenGLDAutomatik '), 0) = 1)
				BEGIN
					--
					-- Ø EK von Stücklisten aktualisieren
					--
						UPDATE dbo.tartikel WITH(ROWLOCK) SET fEKNetto = ISNULL(U1.EKNettoGesamt, 0.0)
						FROM dbo.tartikel WITH(ROWLOCK)
						JOIN 
						(
							SELECT dbo.tStueckliste.kStueckliste, MAX(ISNULL(StueckEK.EKNettoGesamt, 0.0)) AS EKNettoGesamt
							FROM dbo.tartikel WITH (NOLOCK)
							JOIN dbo.tStueckliste WITH (NOLOCK) ON  dbo.tartikel.kStueckliste = dbo.tStueckliste.kStueckliste
							JOIN
							(
								SELECT dbo.tStueckliste.kStueckliste, SUM(ISNULL(dbo.tartikel.fEKNetto, 0.0) * ISNULL(dbo.tStueckliste.fAnzahl, 0.0)) AS EKNettoGesamt
								FROM dbo.tStueckliste WITH (NOLOCK)
								JOIN dbo.tartikel WITH (NOLOCK) ON dbo.tStueckliste.kArtikel = dbo.tartikel.kArtikel
								GROUP BY dbo.tStueckliste.kStueckliste
							) AS StueckEK ON dbo.tStueckliste.kStueckliste = StueckEK.kStueckliste
							WHERE dbo.tartikel.kStueckliste IN (SELECT kStueckliste FROM dbo.tStueckliste 
													        WHERE  (dbo.tStueckliste.kArtikel IN (SELECT kArtikel FROM #spAktualisiereStuecklisteKomponenten) -- ALLE stücklisten der komponenten die geupdatet wurden
															OR dbo.tStueckliste.kStueckliste IN (SELECT Artikel.kStueckliste								 -- UND ALLE stücklisten Updaten dessen Vater übergeben wurde
															                                 FROM #spAktualisiereStuecklisteKomponenten
																							 JOIN dbo.tArtikel AS Artikel ON Artikel.kArtikel = #spAktualisiereStuecklisteKomponenten.kArtikel
																							 WHERE Artikel.kStueckliste > 0))
												            )
							                          
							GROUP BY dbo.tStueckliste.kStueckliste
						) AS U1 ON dbo.tartikel.kstueckliste = U1.kStueckliste;
				END;

			--
			-- Voreinstellungen abfragen zur Gewichts-Aktualisierung
			-- tOptions ('StuecklistenGewichtsAutomatik ') (1 = true)
			-- fGewicht = Versandgewicht | fArtGewicht = Artikelgewicht
			--

				IF(ISNULL((SELECT TOP 1 CONVERT(TINYINT, ISNULL(cValue, '0')) FROM tOptions WITH (NOLOCK) WHERE cKey = 'StuecklistenGewichtsAutomatik'), 0) = 1)
				BEGIN
					--
					-- Gewicht von Stücklisten aktualisieren
					--
						UPDATE dbo.tartikel WITH(ROWLOCK) 
							SET fArtGewicht = ISNULL(U1.ArtGewichtGesamt, 0.0),
							fGewicht = ISNULL(U1.VersandGewichtGesamt, 0.0)
						FROM dbo.tartikel WITH(ROWLOCK)
						JOIN 
						(
							SELECT dbo.tStueckliste.kStueckliste, 
								MAX(ISNULL(StueckEK.ArtGewichtGesamt, 0.0)) AS ArtGewichtGesamt,
								MAX(ISNULL(StueckEK.VersandGewichtGesamt, 0.0)) AS VersandGewichtGesamt
							FROM dbo.tartikel WITH (NOLOCK)
							--JOIN #spAktualisiereStuecklisteKomponenten AS ArtikelAktualisiert ON tartikel.kArtikel = ArtikelAktualisiert.kArtikel
							JOIN dbo.tStueckliste WITH (NOLOCK) ON dbo.tartikel.kStueckliste = dbo.tStueckliste.kStueckliste
							JOIN
							(
								SELECT dbo.tStueckliste.kStueckliste, 
									SUM(ISNULL(dbo.tartikel.fArtGewicht, 0.0) * ISNULL(dbo.tStueckliste.fAnzahl, 0.0)) AS ArtGewichtGesamt,
									SUM(ISNULL(dbo.tartikel.fGewicht, 0.0) * ISNULL(dbo.tStueckliste.fAnzahl, 0.0)) AS VersandGewichtGesamt
								FROM dbo.tStueckliste WITH (NOLOCK)
								JOIN dbo.tartikel WITH (NOLOCK) ON dbo.tStueckliste.kArtikel = dbo.tartikel.kArtikel
								GROUP BY dbo.tStueckliste.kStueckliste
							) AS StueckEK ON dbo.tStueckliste.kStueckliste = StueckEK.kStueckliste
							WHERE dbo.tartikel.kStueckliste IN (SELECT kStueckliste FROM dbo.tStueckliste 
													            WHERE  (dbo.tStueckliste.kArtikel IN (SELECT kArtikel FROM #spAktualisiereStuecklisteKomponenten) -- ALLE stücklisten der komponenten die geupdatet wurden
														    	OR dbo.tStueckliste.kStueckliste IN (SELECT Artikel.kStueckliste								 -- UND ALLE stücklisten Updaten dessen Vater übergeben wurde
															                                 FROM #spAktualisiereStuecklisteKomponenten
																							 JOIN dbo.tArtikel AS Artikel ON Artikel.kArtikel = #spAktualisiereStuecklisteKomponenten.kArtikel
																							 WHERE Artikel.kStueckliste > 0))
												            )
							GROUP BY dbo.tStueckliste.kStueckliste
						) AS U1 ON dbo.tartikel.kstueckliste = U1.kStueckliste;
				   
				END;
	
		
			UPDATE dbo.tartikel WITH(ROWLOCK) 
				SET dbo.tartikel.cLagerAktiv = ISNULL(U1.cLagerAktiv, 'N'),
					dbo.tartikel.cLagerKleinerNull = CASE ISNULL(U1.cLagerAktiv, 'N') WHEN 'N' THEN 'N' ELSE ISNULL(U1.cLagerKleinerNull, 'N') END,
					dbo.tartikel.cTeilbar = ISNULL(U1.cTeilbar, 'N')		
			FROM dbo.tartikel WITH(ROWLOCK)
			JOIN #spAktualisiereStuecklisteKomponenten ON dbo.tartikel.kArtikel = #spAktualisiereStuecklisteKomponenten.kArtikel
			LEFT JOIN
			(
				SELECT dbo.tStueckliste.kStueckliste,
					MAX(ISNULL(dbo.tartikel.cLagerAktiv, 'N')) AS cLagerAktiv,
					MIN(CASE ISNULL(dbo.tartikel.cLagerAktiv, 'N') WHEN 'N' THEN 'Y' ELSE ISNULL(dbo.tartikel.cLagerKleinerNull, 'N') END ) AS cLagerKleinerNull,
					MIN(ISNULL(dbo.tartikel.cTeilbar, 'N')) AS cTeilbar
				FROM dbo.tartikel WITH(NOLOCK)
				JOIN dbo.tStueckliste WITH(NOLOCK) ON dbo.tartikel.kArtikel = dbo.tStueckliste.kArtikel
				GROUP BY dbo.tStueckliste.kStueckliste
			) AS U1 ON dbo.tartikel.kStueckliste = U1.kStueckliste
			WHERE dbo.tartikel.kStueckliste > 0

			
			SET CONTEXT_INFO 0x0;

		END;

END;
go

