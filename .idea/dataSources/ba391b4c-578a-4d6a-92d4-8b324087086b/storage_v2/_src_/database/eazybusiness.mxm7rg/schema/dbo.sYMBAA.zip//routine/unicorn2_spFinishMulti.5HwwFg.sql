
    CREATE PROCEDURE unicorn2_spFinishMulti @kWawiIdList VARCHAR(MAX), @kShopId INT 
    AS
        DECLARE @kWawiIdListLocal VARCHAR(MAX)
    		SET @kWawiIdListLocal = @kWawiIdList
			
		DECLARE @kShopIdLocal INT
    		SET @kShopIdLocal = @kShopId
    	
        SET DEADLOCK_PRIORITY LOW		
        UPDATE tArtikelShop SET cInet = 'N', nAktion = 0
        WHERE kShop = @kShopIdLocal AND kArtikel IN (SELECT * FROM unicorn2_fSplitInts(@kWawiIdListLocal, ','));
    go

