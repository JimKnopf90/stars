CREATE TRIGGER [dbo].[tgr_tKundenGruppeAttribute_DEL]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP
--
ON [dbo].[tKundenGruppeAttribute]
AFTER DELETE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN

	--Überprüfen ob Trigger gefüllt aufgerufen wird
	IF((SELECT COUNT(1) 
		FROM DELETED
		JOIN dbo.tShopKundenGruppe ON dbo.tShopKundenGruppe.kKundenGruppe = DELETED.kKundenGruppe) = 0)
	BEGIN 
		RETURN;
	END;

	INSERT INTO dbo.tGlobalsQueue (kShop, nType, cName, kKey)
	SELECT dbo.tShopKundenGruppe.kWebShop, 1, 'tKundengruppe', 0
	FROM dbo.tShopKundenGruppe
	JOIN dbo.tShop ON dbo.tShopKundenGruppe.kWebShop = dbo.tShop.kShop
		AND dbo.tShop.nTyp = 0
	JOIN DELETED ON dbo.tShopKundenGruppe.kKundenGruppe = DELETED.kKundenGruppe
	GROUP BY dbo.tShopKundenGruppe.kWebShop;
	
END
go

