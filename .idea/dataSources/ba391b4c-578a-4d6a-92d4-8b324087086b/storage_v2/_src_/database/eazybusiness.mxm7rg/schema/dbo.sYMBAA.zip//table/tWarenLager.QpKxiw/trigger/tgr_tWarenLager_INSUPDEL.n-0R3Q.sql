CREATE TRIGGER [dbo].[tgr_tWarenLager_INSUPDEL]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: SB
--
	ON [dbo].[tWarenLager]
	AFTER INSERT, UPDATE, DELETE
	AS
	SET NOCOUNT ON;
	SET ANSI_NULLS ON;
	SET ANSI_NULL_DFLT_ON ON;
	SET ANSI_PADDING ON;
	SET CONCAT_NULL_YIELDS_NULL ON;
	SET XACT_ABORT OFF;
	BEGIN
		-- Aenderungen in Versand.tVersandlager schreiben
		
		MERGE INTO Versand.tVersandlager 
		USING VersandIntern.vVersandlager ON vVersandlager.kWarenlager = tVersandlager.kWarenlager
		WHEN MATCHED THEN
			UPDATE SET tVersandlager.nTyp = vVersandlager.nTyp
		WHEN NOT MATCHED BY TARGET THEN
			INSERT (kWarenlager, nTyp) VALUES (vVersandlager.kWarenlager, vVersandlager.nTyp)
		WHEN NOT MATCHED BY SOURCE THEN
			DELETE;
	END;
go

