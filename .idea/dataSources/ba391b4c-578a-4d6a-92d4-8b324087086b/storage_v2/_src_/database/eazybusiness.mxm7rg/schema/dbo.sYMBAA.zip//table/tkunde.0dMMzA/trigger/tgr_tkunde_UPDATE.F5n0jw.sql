CREATE TRIGGER [dbo].[tgr_tkunde_UPDATE]    
--      
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: GJ
--        
ON [dbo].[tkunde]
    AFTER UPDATE, INSERT
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN

   

    IF (UPDATE(cVorname) OR UPDATE(cZHaenden) OR UPDATE(cFirma) OR UPDATE(cPLZ) OR UPDATE(cZusatz) OR UPDATE(cEMail) OR UPDATE(cEbayName) OR 
       UPDATE(cTel) OR UPDATE(cUSTID) OR  UPDATE(cStrasse) OR  UPDATE(cOrt) OR  UPDATE(cPLZ) OR  UPDATE(cName))
    BEGIN

    --
    -- Bestehende Kunden-Suchstrings löschen
    --
    DELETE dbo.tKunde_suche WITH( ROWLOCK )
    FROM dbo.tKunde_suche WITH ( ROWLOCK )
         JOIN INSERTED ON dbo.tKunde_suche.kKunde = INSERTED.kKunde;
   

    DECLARE @cValue AS VARCHAR( MAX );
    DECLARE @kKunde AS INT;

	   DECLARE value_cursor CURSOR FORWARD_ONLY

	    FOR SELECT kKunde , 
               RTRIM( LTRIM(  cValue ))AS cValue        
		FROM(              			 
			 SELECT kKunde , 
                    isnull(cVorname + ' ','') +  isnull(cName + ' ','')  AS cValue
             FROM INSERTED
             WHERE INSERTED.cAktiv = 'Y'
             UNION ALL
             
			 SELECT kKunde , 
                    cZHaenden AS cValue
             FROM INSERTED
             WHERE INSERTED.cAktiv = 'Y'
             UNION ALL
             SELECT kKunde , 
                    cFirma AS cValue
             FROM INSERTED
             WHERE INSERTED.cAktiv = 'Y'
             UNION ALL
             SELECT kKunde , 
                    cZusatz AS cValue
             FROM INSERTED
             WHERE INSERTED.cAktiv = 'Y'
             UNION ALL
             SELECT kKunde , 
                    cEMail AS cValue
             FROM INSERTED
             WHERE INSERTED.cAktiv = 'Y'
             UNION ALL
             SELECT kKunde , 
                    cEbayName AS cValue
             FROM INSERTED
             WHERE INSERTED.cAktiv = 'Y'
             UNION ALL
             SELECT kKunde , 
                    cTel AS cValue
             FROM INSERTED
             WHERE INSERTED.cAktiv = 'Y'
             UNION ALL
             SELECT kKunde , 
                    REPLACE( REPLACE( REPLACE( REPLACE( cTel , ' ' , '' ) , '\' , '' ) , '-' , '' ) , '/' , '' )AS cValue
             FROM INSERTED
             WHERE INSERTED.cAktiv = 'Y'
             UNION ALL
             SELECT kKunde , 
                    cUSTID AS cValue
             FROM INSERTED
             WHERE INSERTED.cAktiv = 'Y' 
		   UNION ALL
             SELECT kKunde , 
                    cStrasse AS cValue
             FROM INSERTED
             WHERE INSERTED.cAktiv = 'Y'
		   UNION ALL
             SELECT kKunde , 
                    cOrt AS cValue
             FROM INSERTED
             WHERE INSERTED.cAktiv = 'Y'
		   UNION ALL
             SELECT kKunde , 
                    cPLZ AS cValue
             FROM INSERTED
             WHERE INSERTED.cAktiv = 'Y')AS KundenValues
        WHERE NOT(cValue IS NULL
               OR cValue = '')
         -- AND KundenValues.kKunde = @kKundeToDelete;



	   CREATE TABLE [#tmptKunde_suche](
		   [kKunde] [int] NOT NULL,
		   [cValue] [varchar](255) NULL
	   ) ON [PRIMARY]

	   OPEN value_cursor;
	   FETCH value_cursor INTO @kKunde , @cValue;
	   WHILE @@FETCH_STATUS = 0
		  BEGIN       
			 WITH SplitTable
				AS ( SELECT *
					FROM SplitString( REPLACE( @cValue , ' ' , '|' ) , '|' )
					    UNION
					    SELECT *
					FROM SplitString( REPLACE( REPLACE( @cValue , '-' , ' ' ) , ' ' , '|' ) , '|' ))
				INSERT INTO [#tmptKunde_suche]
				SELECT @kKunde AS kKunde, isnull(st.part + ' ','') + isnull(st2.part + ' ', '') + isnull(st3.part,'') AS cValue
				FROM
					SplitTable AS st
					LEFT JOIN SplitTable AS st2 ON NOT st.part = st2.part
					LEFT JOIN SplitTable AS st3 ON NOT st3.part = st2.part
									  AND NOT st3.part = st.part
				    LEFT JOIN SplitTable st4    ON  NOT st4.part = st4.part AND NOT st4.part = st2.part AND NOT st4.part = st.part
				    LEFT JOIN SplitTable st5    ON  NOT st5.part = st4.part AND NOT st5.part = st3.part AND NOT st5.part = st2.part AND NOT st5.part = st.part;
			
			 FETCH value_cursor INTO @kKunde , @cValue;
		  END;
	   CLOSE value_cursor;
	   DEALLOCATE value_cursor;

	   INSERT INTO dbo.tKunde_suche (kKunde,cValue)
	   SELECT DISTINCT kKunde, LTRIM(RTRIM(cValue)) AS cValue FROM [#tmptKunde_suche] WHERE NOT LTRIM(RTRIM(cValue)) = ''

	   DROP TABLE [#tmptKunde_suche]

    END;
END;
go

