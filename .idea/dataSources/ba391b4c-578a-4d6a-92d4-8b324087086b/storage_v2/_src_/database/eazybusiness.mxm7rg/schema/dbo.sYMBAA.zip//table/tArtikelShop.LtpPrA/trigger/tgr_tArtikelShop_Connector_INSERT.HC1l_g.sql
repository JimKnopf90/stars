CREATE TRIGGER [dbo].[tgr_tArtikelShop_Connector_INSERT]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP
--
ON [dbo].[tArtikelShop]
AFTER INSERT
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN	

	--Überprüfen ob Trigger gefüllt aufgerufen wird
	IF((SELECT COUNT(1) FROM INSERTED FULL JOIN DELETED ON INSERTED.kArtikel = DELETED.kArtikel) = 0)
	BEGIN 
		RETURN;
	END

	DECLARE @Komplett AS INT;
	--DECLARE @Preis AS INT;
	--DECLARE @Bestand AS INT;

	SET @Komplett = 1;
	--SET @Preis = 2;
	--SET @Bestand = 4;

	--
	-- Artikel vollständig zu Webshops senden, wenn Änderungen vorgenommen wurden
	--
	UPDATE dbo.tArtikelShop
		SET dbo.tArtikelShop.nAktion = dbo.tArtikelShop.nAktion | @Komplett,
			dbo.tArtikelShop.cInet = 'Y'
	FROM dbo.tArtikelShop
	JOIN INSERTED ON dbo.tArtikelShop.kArtikel = INSERTED.kArtikel AND dbo.tArtikelShop.kShop = INSERTED.kShop;	
	
	--
	-- Bilder vollständig zu Webshop wenden, wenn Änderungen vorgenommen wurden
	--
	UPDATE dbo.tArtikelbildPlattform
		SET dbo.tArtikelbildPlattform.nInet = 1
	FROM dbo.tArtikelbildPlattform
	JOIN INSERTED ON dbo.tArtikelbildPlattform.kArtikel = INSERTED.kArtikel
		AND dbo.tArtikelbildPlattform.kShop = INSERTED.kShop
	WHERE dbo.tArtikelbildPlattform.nInet = 0;

	--
	-- Evtl. bestehenden Löscheinträge in tQueue entfernen
	--
	DELETE dbo.tQueue
	FROM dbo.tQueue
	JOIN INSERTED ON dbo.tQueue.kShop = INSERTED.kShop
		AND dbo.tQueue.kWert = INSERTED.kArtikel
	WHERE	dbo.tQueue.kPlattform = 2
			AND dbo.tQueue.cName = 'tArtikel'
			AND dbo.tQueue.nAction = 2

	DELETE dbo.tQueue
	FROM dbo.tQueue
	JOIN
	(
		SELECT dbo.tArtikel.kHersteller, INSERTED.kShop
		FROM INSERTED
		JOIN dbo.tShopKonfiguration ON INSERTED.kShop = dbo.tShopKonfiguration.kShop
									AND dbo.tShopKonfiguration.nHerstellerGefiltertSenden = 1
		JOIN dbo.tArtikel ON dbo.tArtikel.kArtikel = INSERTED.kArtikel
		LEFT JOIN (
			SELECT dbo.tHersteller.kHersteller, dbo.tArtikelShop.kShop, COUNT(1) AS Anzahl
				FROM tArtikel
				JOIN dbo.tHersteller ON dbo.tArtikel.kHersteller = dbo.tHersteller.kHersteller
				JOIN dbo.tArtikelShop ON dbo.tArtikel.kArtikel = dbo.tArtikelShop.kArtikel
				GROUP BY dbo.tHersteller.kHersteller, dbo.tArtikelShop.kShop
		) AS Result ON Result.kHersteller = dbo.tArtikel.kHersteller
					AND INSERTED.kShop = Result.kShop
		WHERE Anzahl = 1
	) AS Items ON dbo.tQueue.kWert = Items.kHersteller
			AND dbo.tQueue.cName = 'tHersteller'
			AND dbo.tQueue.kShop = Items.kShop
			AND dbo.tQueue.nAction = 2

	INSERT INTO dbo.tQueue(kWert, kShop, cName, kPlattform, nAction)
	SELECT dbo.tArtikel.kHersteller, INSERTED.kShop, 'tHersteller', 2, 1
	FROM INSERTED
	JOIN dbo.tShopKonfiguration ON INSERTED.kShop = dbo.tShopKonfiguration.kShop
								AND dbo.tShopKonfiguration.nHerstellerGefiltertSenden = 1
	JOIN dbo.tArtikel ON dbo.tArtikel.kArtikel = INSERTED.kArtikel
	LEFT JOIN (
		SELECT dbo.tHersteller.kHersteller, dbo.tArtikelShop.kShop, COUNT(1) AS Anzahl
			FROM tArtikel
			JOIN dbo.tHersteller ON dbo.tArtikel.kHersteller = dbo.tHersteller.kHersteller
			JOIN dbo.tArtikelShop ON dbo.tArtikel.kArtikel = dbo.tArtikelShop.kArtikel
			GROUP BY dbo.tHersteller.kHersteller, dbo.tArtikelShop.kShop
	) AS Result ON Result.kHersteller = dbo.tArtikel.kHersteller
				AND INSERTED.kShop = Result.kShop 
	GROUP BY dbo.tArtikel.kHersteller, INSERTED.kShop, Anzahl
	HAVING Anzahl = COUNT(dbo.tArtikel.kHersteller)
			
END
go

