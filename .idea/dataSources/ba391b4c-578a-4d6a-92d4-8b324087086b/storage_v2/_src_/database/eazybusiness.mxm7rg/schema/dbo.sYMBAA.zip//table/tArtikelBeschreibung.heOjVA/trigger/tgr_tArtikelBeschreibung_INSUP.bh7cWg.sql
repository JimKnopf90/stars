CREATE TRIGGER [dbo].[tgr_tArtikelBeschreibung INSUP]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: PN
--
ON [dbo].[tArtikelBeschreibung]
AFTER INSERT, UPDATE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN

	--Überprüfen ob Trigger gefüllt aufgerufen wird
	IF((SELECT COUNT(1) FROM INSERTED FULL JOIN DELETED ON INSERTED.kArtikel = DELETED.kArtikel) = 0)
	BEGIN 
		RETURN;
	END;
	
	
	IF UPDATE(cName)
	BEGIN
	
		 DELETE dbo.tArtikelSpeicher WITH(ROWLOCK) 
		 FROM dbo.tArtikelSpeicher WITH(ROWLOCK)
		 JOIN INSERTED ON INSERTED.kArtikel = dbo.tArtikelSpeicher.kArtikel
		 WHERE dbo.tArtikelSpeicher.nID = 5;

		 INSERT INTO dbo.tArtikelSpeicher WITH(ROWLOCK) (kArtikel,cNummer,nID,nAktiv)
		 SELECT DISTINCT dbo.tArtikelBeschreibung.kArtikel,LTRIM(RTRIM(dbo.tArtikelBeschreibung.cName)) AS Nummer, 5 AS Art , CASE WHEN dbo.tOptions.cValue = '1' THEN 1 ELSE 0 END AS nAktiv
		 FROM dbo.tArtikelBeschreibung
		 JOIN INSERTED ON INSERTED.kArtikel = dbo.tArtikelBeschreibung.kArtikel 
		 LEFT JOIN dbo.tOptions WITH(NOLOCK) ON dbo.tOptions.cKey = 'ArtikelEigenschaft Artikelname'
		 JOIN tSpracheUsed ON dbo.tArtikelBeschreibung.kSprache = tSpracheUsed.kSprache AND tSpracheUsed.nStandard = 1
	      WHERE dbo.tArtikelBeschreibung.cName IS NOT NULL 
		 AND dbo.tArtikelBeschreibung.cName <> '' 

	END;
	
END
go

