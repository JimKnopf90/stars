CREATE TRIGGER [dbo].[tgr_tLieferschein_INSUPDEL]
ON [dbo].[tLieferschein]
AFTER INSERT, DELETE
AS 
BEGIN
	IF(CONTEXT_INFO() IN (0x5113, 0x5114))
	BEGIN
		RETURN;
	END	
	RAISERROR(N'Die Tabelle dbo.tLieferschein kann nur über die SPs spLieferscheinErstellen und spLieferscheinLoeschen bearbeitet werden.', 15,1);
	ROLLBACK;
END


--DROP TRIGGER [dbo].[tgr_tLieferschein_INSUPDEL]
go

