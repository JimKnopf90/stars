CREATE TRIGGER [dbo].[tgr_tMerkmalwertBildPlattform_UPDATE]  
--     
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Author: Markus Hütz
--    
ON [dbo].[tMerkmalwertBildPlattform]  
AFTER UPDATE
AS  
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
    --
    -- Überprüfen ob Trigger gefüllt aufgerufen wird
    --
    IF NOT EXISTS(SELECT INSERTED.kMerkmalwertBildPlattform FROM INSERTED FULL JOIN DELETED ON INSERTED.kMerkmalwertBildPlattform = DELETED.kMerkmalwertBildPlattform)
    BEGIN
	   RETURN;
    END;

    --
    -- Wenn kBild nicht gleich ist es ein neues Bild und muss übertragen werden
    --
    UPDATE dbo.tMerkmalwertBildPlattform
    SET dbo.tMerkmalwertBildPlattform.nInet = 1
    FROM dbo.tMerkmalwertBildPlattform
    JOIN DELETED ON DELETED.kMerkmalwertBildPlattform = dbo.tMerkmalwertBildPlattform.kMerkmalwertBildPlattform
    JOIN INSERTED ON INSERTED.kMerkmalwertBildPlattform = dbo.tMerkmalwertBildPlattform.kMerkmalwertBildPlattform
    WHERE DELETED.kBild != INSERTED.kBild;

    --
    -- tBild ggfs. aufräumen
    --
    IF(
	   SELECT COUNT(1)
    	   FROM DELETED
	   LEFT JOIN INSERTED ON DELETED.kBild != INSERTED.kBild
	   WHERE INSERTED.kBild IS NULL
    ) > 0
    BEGIN
	   DECLARE @Bilder AS TYPE_spBildLoeschenWennNichtVerwendet;

	   INSERT INTO @Bilder (kBild)
	   SELECT DELETED.kBild
	   FROM DELETED
	   LEFT JOIN INSERTED ON DELETED.kBild != INSERTED.kBild
	   GROUP BY DELETED.kBild;

	   EXEC spBildLoeschenWennNichtVerwendet @Bilder;
    END
END
go

