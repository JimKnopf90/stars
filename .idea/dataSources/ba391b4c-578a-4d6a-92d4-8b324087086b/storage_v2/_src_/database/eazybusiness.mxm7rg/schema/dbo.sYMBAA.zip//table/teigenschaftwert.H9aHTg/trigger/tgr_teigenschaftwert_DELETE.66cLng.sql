CREATE TRIGGER [dbo].[tgr_teigenschaftwert_DELETE]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--
ON [dbo].[teigenschaftwert]
AFTER DELETE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
	--Überprüfen ob Trigger mit Daten gefüllt wird
	IF((SELECT COUNT(1) FROM DELETED) = 0)
	BEGIN
		RETURN;
	END;

	DECLARE @typeArtikel AS TYPE_spUpdateLagerbestand;

	INSERT INTO @typeArtikel (kArtikel)
	SELECT DISTINCT kArtikel
	FROM
	(
		SELECT teigenschaft.kArtikel 
		FROM teigenschaftwert WITH(NOLOCK)
		JOIN teigenschaft WITH(NOLOCK) ON teigenschaft.kEigenschaft = teigenschaftwert.kEigenschaft
		JOIN DELETED ON DELETED.kEigenschaftWert = teigenschaftwert.kEigenschaftWert
	) AS U1
	WHERE kArtikel = U1.kArtikel;

	EXEC spUpdateLagerBestand @typeArtikel;

END
go

