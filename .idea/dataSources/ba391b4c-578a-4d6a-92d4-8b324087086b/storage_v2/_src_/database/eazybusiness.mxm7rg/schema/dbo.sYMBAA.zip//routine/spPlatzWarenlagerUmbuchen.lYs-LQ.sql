--- 
--- spPlatzWarenlagerUmbuchen
---

--- 
--- Ruf die spPlatzUmbuchen auf, prüft dabei aber noch, ob sich das Warenlager geändert hat und korrigiert ggf. tlagerbestandProLagerLagerartikel
--- Zudem wird noch verhindert, dass JTL-Fulfillment Artikel in ein anderes Lager umgelagert werden können.
---

CREATE PROCEDURE [dbo].[spPlatzWarenlagerUmbuchen]
@kArtikel INT,
@fAnzahl DECIMAL(28,14),
@kWarenlagerPLatzNeu INT,
@kWarenlagerPlatzAlt INT,
@cKommentar VARCHAR(255),
@kBuchungsart INT,
@kBenutzer INT,
@kLHMNeu INT = NULL,
@kLHMAlt INT = NULL,
@dMhd DATETIME = NULL,
@cChargenNr VARCHAR(255) = NULL
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
	DECLARE @kWarenlagerAlt INT;
	DECLARE @kWarenlagerNeu INT;
	SELECT @kWarenlagerAlt = WarenlagerPlatz.kWarenLager FROM dbo.tWarenLagerPlatz AS WarenlagerPlatz WHERE WarenlagerPlatz.kWarenLagerPlatz = @kWarenlagerPlatzAlt;
	SELECT @kWarenlagerNeu = WarenlagerPlatz.kWarenLager FROM dbo.tWarenLagerPlatz AS WarenlagerPlatz WHERE WarenlagerPlatz.kWarenLagerPlatz = @kWarenlagerPLatzNeu;
	BEGIN TRY
	IF(@kWarenlagerAlt = @kWarenlagerNeu)
		BEGIN
			EXEC dbo.spPlatzUmbuchen @kArtikel, @fAnzahl, @kWarenlagerPLatzNeu, @kWarenlagerPlatzAlt,@cKommentar,@kBuchungsart,@kBenutzer,@kLHMNeu,@kLHMAlt,@dMhd,@cChargenNr;		
		END
		ELSE		
		BEGIN
			IF ((SELECT COUNT(*)
				FROM dbo.tliefartikel	AS LieferantenArtikel
				-- Artikel, welche über das JTL-Fulfillment Network verschickt werden, haben eine JTL-Fulfillment Product Id (jfpid)
				JOIN dbo.tArtikel		AS Artikel				ON Artikel.kArtikel = LieferantenArtikel.tArtikel_kArtikel AND NOT (Artikel.cJfpid IS NULL OR Artikel.cJfpid = '') 
				-- Ist es ein Fremdartikel, welchen ich als Fulfillment Dienstleister einlager, ist mein Fulfillment-Kunde als Lieferant mit nJTLFulfillment angelegt
				JOIN dbo.tlieferant		AS Lieferant			ON Lieferant.kLieferant = LieferantenArtikel.tLieferant_kLieferant AND LieferantenArtikel.tArtikel_kArtikel = @kArtikel AND Lieferant.nJtlFulfillment = 1) > 0) 
			BEGIN
				RAISERROR('203000901',15,1, N'JTL-Fulfillment Network Artikel können nicht in ein anderes Lager umgelagert werden.');
			END

			EXEC dbo.spPlatzUmbuchen @kArtikel, @fAnzahl, @kWarenlagerPLatzNeu, @kWarenlagerPlatzAlt,@cKommentar,@kBuchungsart,@kBenutzer,@kLHMNeu,@kLHMAlt,@dMhd,@cChargenNr;
			UPDATE tlagerbestandProLagerLagerartikel SET fBestand = fBestand - @fAnzahl WHERE kArtikel =  @kArtikel AND kWarenlager = @kWarenlagerAlt
			UPDATE tlagerbestandProLagerLagerartikel SET fBestand = fBestand + @fAnzahl WHERE kArtikel =  @kArtikel AND kWarenlager = @kWarenlagerNeu
		END
	END TRY
		BEGIN CATCH	
			DECLARE @errorMessage varchar(256) = ERROR_MESSAGE();
			DECLARE @severity INT = ERROR_SEVERITY();
			DECLARE @errorState INT = ERROR_STATE();
			RAISERROR ( @errorMessage, @severity,@errorState );
		END CATCH		
END
go

