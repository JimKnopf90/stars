
    CREATE PROCEDURE unicorn2_spAddChanged @cStatus VARCHAR(10), @cType VARCHAR(50), @kWawiId INT, @cProperty VARCHAR(50) = NULL
    AS
    		BEGIN
    		    DECLARE @cStatusLocal VARCHAR(10) 
    		    DECLARE @cTypeLocal VARCHAR(50)
    		    DECLARE @kWawiIdLocal INT
    		    DECLARE @cPropertyLocal VARCHAR(50)
    		    
    		    SET @cStatusLocal = @cStatus
    		    SET @cTypeLocal = @cType
    		    SET @kWawiIdLocal = @kWawiId
    		    SET @cPropertyLocal = @cProperty		
				
				SET DEADLOCK_PRIORITY LOW
    		    
    		    IF (@kWawiIdLocal IS NOT NULL)
    		        BEGIN    		        
        		        IF (@cStatusLocal = 'Add')
            						BEGIN		
            								IF NOT EXISTS (
            										SELECT * FROM unicorn2_tChangeCache WITH (NOLOCK) WHERE
            								   					 (kWawiId = @kWawiIdLocal AND 
            									 					 cStatus = @cStatusLocal AND
            									 					 cType = @cTypeLocal AND
            									           (cProperty IS NULL OR cProperty = @cPropertyLocal)) OR
            									           (kWawiId = @kWawiIdLocal AND 
            									 					 cStatus = 'Mod' AND
            									 					 cType = @cTypeLocal AND
            									           cProperty IS NULL))									           
            							  		BEGIN
            											  INSERT INTO unicorn2_tChangeCache
            											     (cStatus, cType, cProperty, kWawiId, dChangedDate)
            											  VALUES
            											     (@cStatusLocal, @cTypeLocal, @cPropertyLocal, @kWawiIdLocal, GETDATE())
            							      END   							      
            						END
            				IF(@cStatusLocal = 'Mod')
                				BEGIN		
            								IF NOT EXISTS (
            										SELECT * FROM unicorn2_tChangeCache WITH (NOLOCK) WHERE
            								   					 kWawiId = @kWawiIdLocal AND 
            									 					 (cStatus = @cStatusLocal OR cStatus = 'Add') AND
            									 					 cType = @cTypeLocal AND
            									          (cProperty IS NULL OR cProperty = @cPropertyLocal))
            							  		BEGIN
            											  INSERT INTO unicorn2_tChangeCache
            											     (cStatus, cType, cProperty, kWawiId, dChangedDate)
            											  VALUES
            											     (@cStatusLocal, @cTypeLocal, @cPropertyLocal, @kWawiIdLocal, GETDATE()) 
            							      END
            						END
            				IF(@cStatusLocal = 'ModQuick')
                				BEGIN		
            								IF NOT EXISTS (
            										SELECT * FROM unicorn2_tChangeCache WITH (NOLOCK) WHERE
            								   					 kWawiId = @kWawiIdLocal AND 
            									 					 (cStatus = @cStatusLocal OR cStatus = 'Mod' OR cStatus = 'Add') AND
            									 					 cType = @cTypeLocal AND
            									          (cProperty IS NULL OR cProperty = @cPropertyLocal))
            							  		BEGIN
            											  INSERT INTO unicorn2_tChangeCache
            											     (cStatus, cType, cProperty, kWawiId, dChangedDate)
            											  VALUES
            											     (@cStatusLocal, @cTypeLocal, @cPropertyLocal, @kWawiIdLocal, GETDATE())
            							      END
            						END
            				IF(@cStatusLocal = 'Del')
                				BEGIN	
            						    IF(@cPropertyLocal IS NULL)
            										BEGIN
   							 		    				    		
            																IF NOT EXISTS (
            																		SELECT * FROM unicorn2_tChangeCache WITH (NOLOCK) WHERE
            																   					 kWawiId = @kWawiIdLocal AND 
            																	 					 (cStatus = @cStatusLocal) AND
            																	 					 cType = @cTypeLocal AND
            																	           cProperty IS NULL)
            															  		BEGIN
            																			  INSERT INTO unicorn2_tChangeCache
            																			     (cStatus, cType, cProperty, kWawiId, dChangedDate)
            																			  VALUES
            																			     (@cStatusLocal, @cTypeLocal, @cPropertyLocal, @kWawiIdLocal, GETDATE())
            															      END
            													     																							
            										END
            								ELSE
            										BEGIN
            												
            																					 		    				    		
            																IF NOT EXISTS (
            																		SELECT * FROM unicorn2_tChangeCache WITH (NOLOCK) WHERE
            																   					 kWawiId = @kWawiIdLocal AND 
            																	 					 (cStatus = @cStatusLocal) AND
            																	 					 cType = @cTypeLocal AND
            																	           (cProperty IS NULL OR cProperty = @cPropertyLocal))
            															  		BEGIN
            																			  INSERT INTO unicorn2_tChangeCache
            																			     (cStatus, cType, cProperty, kWawiId, dChangedDate)
            																			  VALUES
            																			     (@cStatusLocal, @cTypeLocal, @cPropertyLocal, @kWawiIdLocal, GETDATE())
            															      END
            													  
            										END	
            						END	    		        
    		        END   		        														    				    			 
        END
    go

