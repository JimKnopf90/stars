--- 
--- spWarenlagerAusgangSchreiben
---

CREATE PROCEDURE [dbo].[spWarenlagerAusgangSchreiben]
	@xWarenlagerAusgaenge XML = NULL,
	--
	-- XML Struktur
	--
	-- <Warenausgang>
	--	<kWarenlagerEingang>
	--	<kLieferscheinPos>
	--	<fAnzahl>
	--	<kWarenlagerPlatz>
	--	<kArtikel>
	--	<cKommentar>
	--	<kBenutzer>
	--	<kBuchungsart>
	-- </WarenEingang>
	--
	@kWarenLagerEingang INT = NULL,
	@kLieferscheinPos INT = NULL,
	@fAnzahl DECIMAL(28,14) = NULL,
	@cKommentar VARCHAR(255) = NULL,
	@kBenutzer INT = NULL,
	@kBuchungsart INT = NULL,
	@nHistorieNichtSchreiben INT = 0,
	@kWarenlagerAusgang INT = NULL OUTPUT
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;

DECLARE @OldContextInfo VARBINARY(128)
DECLARE @ErrorMessage NVARCHAR(4000);
DECLARE @ErrorSeverity INT;
DECLARE @ErrorState INT;
DECLARE @retry INT;
DECLARE @CreatedTransaction INT;
SET @retry = 5;
WHILE @retry > 0
BEGIN

    IF(CONTEXT_INFO() IS NOT NULL)
    BEGIN
	  SET @OldContextInfo = CONTEXT_INFO();
    END;
    ELSE
    BEGIN
       SET @OldContextInfo = 0x0000;
    END;
          
	SET CONTEXT_INFO 0x5089;
	BEGIN TRY

		IF (@@TRANCOUNT = 0)
		BEGIN
		   SET @CreatedTransaction = 1;
		   BEGIN TRANSACTION
		END;
		ELSE
		BEGIN
			SET @CreatedTransaction = 0;
			SAVE TRANSACTION Savepoint1;
		END;

		DECLARE @DATE DATETIME = GETDATE();

		IF(OBJECT_ID('tempdb..#WarenlagerAusgaenge') IS NOT NULL)
		BEGIN
			DROP TABLE #WarenlagerAusgaenge;
		END
		CREATE TABLE #WarenlagerAusgaenge(
			kWarenlagerEingang INT NOT NULL,
			kLieferscheinPos INT NULL,
			fAnzahl DECIMAL(28,14) NOT NULL,
			kWarenLagerPlatz INT NULL,
			kArtikel INT NULL,
			cKommentar VARCHAR(255) NULL,
			dErstellt DATETIME NULL,
			kBenutzer INT NULL,
			kBuchungsart INT NULL
		);
		-- Temporäre Tabelle füllen
		IF(@xWarenlagerAusgaenge IS NOT NULL)
		BEGIN
			INSERT INTO #WarenlagerAusgaenge
			(
			    kWarenlagerEingang,
			    kLieferscheinPos,
			    fAnzahl,
			    cKommentar,
			    dErstellt,
			    kBenutzer,
				kBuchungsart
			)
			SELECT DISTINCT ParamValues.ID.value('kWarenLagerEingang[1]', 'VARCHAR(20)'),
					ISNULL(ParamValues.ID.value('kLieferscheinPos[1]', 'VARCHAR(20)'),0),
					ParamValues.ID.value('fAnzahl[1]', 'VARCHAR(20)'),
					ParamValues.ID.value('cKommentar[1]', 'VARCHAR(255)'),
					GETDATE(),
					ParamValues.ID.value('kBenutzer[1]', 'VARCHAR(20)'),
					ParamValues.ID.value('kBuchungsart[1]', 'VARCHAR(20)')
				FROM @xWarenlagerAusgaenge.nodes('/WarenAusgang') AS ParamValues(ID)
		END
		ELSE
		BEGIN
			INSERT INTO #WarenlagerAusgaenge(kWarenlagerEingang, kLieferscheinPos, fAnzahl,
			    cKommentar, dErstellt, kBenutzer, kBuchungsart)
			VALUES(@kWarenLagerEingang, ISNULL(@kLieferscheinPos,0), @fAnzahl,  
				 @cKommentar, @DATE, @kBenutzer, @kBuchungsart);
		END
		
		UPDATE #WarenlagerAusgaenge
			SET kWarenLagerPlatz = dbo.tWarenlagerEingang.kWarenLagerPlatz,
				kArtikel = dbo.tWarenlagerEingang.kArtikel
		   FROM #WarenlagerAusgaenge
		   JOIN dbo.tWarenlagerEingang ON #WarenlagerAusgaenge.kWarenlagerEingang = dbo.tWarenlagerEingang.kWarenlagerEingang
		--
		-- Parameter auf Korrektheit überprüfen
		--

		-- Überprüfung auf korrekte Parameter beim Aufruf
		IF(NOT EXISTS(SELECT * FROM #WarenlagerAusgaenge))
		BEGIN
			RAISERROR(N'Aufruf dbo.spWarenlagerAusgangSchreiben ohne gültige Parameter', 15,1);
			RETURN;
		END
		IF(EXISTS(SELECT #WarenlagerAusgaenge.kWarenlagerEingang
						FROM #WarenlagerAusgaenge
						WHERE #WarenlagerAusgaenge.kWarenlagerEingang NOT IN(SELECT kWarenLagerEingang FROM dbo.tWarenLagerEingang)
							AND #WarenlagerAusgaenge.kWarenlagerEingang <> 0))
		BEGIN
			RAISERROR(N'Aufruf dbo.spWarenlagerAusgangSchreiben mit ungültigem Warenlagereingang', 15,1);
			RETURN;
		END
		IF(EXISTS(SELECT *
					FROM #WarenlagerAusgaenge 
					JOIN dbo.tWarenLagerEingang ON #WarenlagerAusgaenge.kWarenlagerEingang = dbo.tWarenLagerEingang.kWarenLagerEingang
					WHERE #WarenlagerAusgaenge.fAnzahl > dbo.tWarenLagerEingang.fAnzahlAktuell
							AND dbo.tWarenLagerEingang.kWarenLagerEingang <> 0))
		BEGIN
			RAISERROR(N'Aufruf dbo.spWarenlagerAusgangSchreiben mit Wareneingang der nicht ausreichend offene Menge hat', 15,1);
			RETURN;
		END
		--
		-- Vorberechnung für Bestandsupdate
		--
		IF(OBJECT_ID('tempdb..#Lagerbestand') IS NOT NULL)
		BEGIN
			DROP TABLE #Lagerbestand;
		END
		CREATE TABLE #Lagerbestand(kArtikel INT, nNestingDeep INT NOT NULL, kWarenlager INT);
		CREATE NONCLUSTERED INDEX IX_Lagerbestand_kArtikel_nNestingDeep_TEMP ON #Lagerbestand (kArtikel, nNestingDeep);

		-- Alle betroffenen Artikel sammeln
		INSERT INTO #Lagerbestand(kArtikel, nNestingDeep, kWarenlager)
			SELECT DISTINCT Result.kArtikel, Result.nNestingDeep, Result.kWarenlager
			FROM(
				SELECT #WarenLagerAusgaenge.kArtikel, 0 AS nNestingDeep, dbo.tWarenlagerPlatz.kWarenLager
					FROM #WarenLagerAusgaenge 
					JOIN dbo.tWarenlagerPlatz ON dbo.tWarenlagerPlatz.kWarenlagerPlatz = #WarenLagerAusgaenge.kWarenLagerPlatz
				UNION ALL
				SELECT dbo.tArtikel.kArtikel, 2 AS nNestingDeep, dbo.tWarenlagerPlatz.kWarenLager
					FROM #WarenLagerAusgaenge
					JOIN dbo.tStueckliste ON #WarenLagerAusgaenge.kArtikel = dbo.tStueckliste.kArtikel
					JOIN dbo.tArtikel ON dbo.tArtikel.kStueckliste = dbo.tStueckliste.kStueckliste
					JOIN dbo.tWarenlagerPlatz ON dbo.tWarenlagerPlatz.kWarenlagerPlatz = #WarenLagerAusgaenge.kWarenLagerPlatz
					GROUP BY dbo.tArtikel.kArtikel, dbo.tStueckliste.kStueckliste, dbo.tWarenlagerPlatz.kWarenLager
				UNION ALL
				SELECT Vater.kArtikel, 1 AS nNestingDeep, dbo.tWarenlagerPlatz.kWarenLager
					FROM #WarenLagerAusgaenge 
					JOIN dbo.tArtikel ON #WarenLagerAusgaenge.kArtikel = dbo.tArtikel.kArtikel
					JOIN dbo.tArtikel AS Vater ON Vater.kArtikel = dbo.tArtikel.kVaterArtikel
					JOIN dbo.tWarenlagerPlatz ON dbo.tWarenlagerPlatz.kWarenlagerPlatz = #WarenLagerAusgaenge.kWarenLagerPlatz
					GROUP BY Vater.kArtikel, dbo.tWarenlagerPlatz.kWarenLager
				UNION ALL
				--
				-- Varkombikinder können Teil einer Stückliste sein, die wieder ein Varkombikind ist (#15003)
				--
				SELECT	Stueckliste.kVaterArtikel AS kArtikel,
						1 AS nNestingDeep,
						dbo.tWarenlagerPlatz.kWarenLager
				FROM #WarenLagerAusgaenge
				JOIN dbo.tStueckliste AS einzelneKomponente ON #WarenLagerAusgaenge.kArtikel = einzelneKomponente.kArtikel
				JOIN dbo.tArtikel AS Stueckliste ON einzelneKomponente.kStueckliste = Stueckliste.kStueckliste	
				JOIN dbo.tWarenlagerPlatz ON dbo.tWarenlagerPlatz.kWarenlagerPlatz = #WarenLagerAusgaenge.kWarenLagerPlatz
				WHERE Stueckliste.kVaterArtikel > 0
			) AS Result
		--
		-- WarenlagerAusgang schreiben
		--


			INSERT INTO dbo.tWarenLagerAusgang(kWarenLagerEingang, kLieferscheinPos, fAnzahl, kWarenLagerPlatz,
					kArtikel, cKommentar, dErstellt, kBenutzer, kBuchungsart)
				SELECT #WarenlagerAusgaenge.kWarenlagerEingang,
						#WarenlagerAusgaenge.kLieferscheinPos,
						#WarenlagerAusgaenge.fAnzahl,
						#WarenlagerAusgaenge.kWarenLagerPlatz,
						#WarenlagerAusgaenge.kArtikel,
						#WarenlagerAusgaenge.cKommentar,
						#WarenlagerAusgaenge.dErstellt,
						#WarenlagerAusgaenge.kBenutzer,
						#WarenlagerAusgaenge.kBuchungsart
					FROM #WarenlagerAusgaenge
			SELECT @kWarenlagerAusgang = SCOPE_IDENTITY();
			
			-- WarenlagerEingang fAnzahlOffen reduzieren
			UPDATE dbo.tWarenLagerEingang
				SET fAnzahlAktuell = Result.fAnzahlAktuell - Result.fAnzahl
				FROM
				(SELECT dbo.tWarenLagerEingang.kWarenLagerEingang, dbo.tWarenLagerEingang.fAnzahlAktuell, SUM(#WarenlagerAusgaenge.fAnzahl) AS fAnzahl
					FROM  dbo.tWarenLagerEingang
					JOIN #WarenlagerAusgaenge ON #WarenlagerAusgaenge.kWarenlagerEingang = dbo.tWarenLagerEingang.kWarenLagerEingang
					GROUP BY dbo.tWarenLagerEingang.kWarenLagerEingang, dbo.tWarenLagerEingang.fAnzahlAktuell
				) AS Result
				WHERE dbo.tWarenLagerEingang.kWarenLagerEingang = Result.kWarenLagerEingang
			--
			-- Lagerbestände korrigieren für gebuchte Artikel
			--
			UPDATE dbo.tlagerbestand
				SET fLagerbestand = dbo.tlagerbestand.fLagerbestand - Result.fAnzahl,
					fLagerbestandEigen = dbo.tlagerbestand.fLagerbestandEigen - Result.fAnzahl,
					fVerfuegbar = CASE WHEN Result.nGesperrt = 1
									THEN dbo.tlagerbestand.fVerfuegbar
									ELSE dbo.tlagerbestand.fVerfuegbar - Result.fAnzahl
								END,
					fVerfuegbarGesperrt = CASE WHEN Result.nGesperrt = 1
											THEN dbo.tlagerbestand.fVerfuegbarGesperrt - Result.fAnzahl
											ELSE dbo.tlagerbestand.fVerfuegbarGesperrt
										END
				FROM(
					SELECT dbo.tlagerbestand.kArtikel,
							dbo.tWarenlagerPlatz.nGesperrt, 
							SUM(#WarenlagerAusgaenge.fAnzahl) AS fAnzahl
					FROM dbo.tlagerbestand 
					JOIN #WarenlagerAusgaenge ON dbo.tlagerbestand.kArtikel = #WarenlagerAusgaenge.kArtikel
					JOIN dbo.tWarenlagerPlatz ON #WarenlagerAusgaenge.kWarenLagerPlatz = dbo.tWarenlagerPlatz.kWarenlagerPlatz
					GROUP BY dbo.tlagerbestand.kArtikel, dbo.tWarenlagerPlatz.nGesperrt
				) AS Result
				WHERE dbo.tlagerbestand.kArtikel = Result.kArtikel;

			--
			-- Lagerbestand von Stücklisten
			--
			UPDATE dbo.tlagerbestand
				SET fLagerbestand = dbo.vLagerbestandStueckliste.fLagerbestand,
					fLagerbestandEigen = dbo.vLagerbestandStueckliste.fLagerbestandEigen,
					fVerfuegbar = dbo.vLagerbestandStueckliste.fVerfuegbar,
					fVerfuegbarGesperrt = dbo.vLagerbestandStueckliste.fVerfuegbarGesperrt
				FROM dbo.tlagerbestand
				JOIN dbo.tArtikel ON dbo.tArtikel.kArtikel = dbo.tlagerbestand.kArtikel
				JOIN dbo.tStueckliste ON dbo.tStueckliste.kStueckliste = dbo.tArtikel.kStueckliste
				JOIN #Lagerbestand ON dbo.tStueckliste.kArtikel = #Lagerbestand.kArtikel
				JOIN dbo.vLagerbestandStueckliste ON dbo.tStueckliste.kStueckliste = dbo.vLagerbestandStueckliste.kStueckliste;
				
			--
			-- Aktualisierung von Varkombi Vater
			--
			UPDATE dbo.tlagerbestand 
				SET fLagerbestand = Bestand.fLagerbestand,
					fLagerbestandEigen = Bestand.fLagerbestandEigen,
					fVerfuegbar = Bestand.fVerfuegbar,
					fVerfuegbarGesperrt = Bestand.fVErfuegbarGesperrt
			FROM dbo.tlagerbestand
			JOIN #Lagerbestand ON #Lagerbestand.kArtikel = dbo.tlagerbestand.kArtikel 
			JOIN 
			(
				SELECT dbo.tArtikel.kVaterArtikel AS kArtikel,
						SUM(dbo.tlagerbestand.fLagerbestand) AS fLagerbestand,
						SUM(dbo.tlagerbestand.fLagerbestandEigen) AS fLagerbestandEigen,
						SUM(CASE WHEN dbo.tArtikel.cLagerAktiv = 'Y' 
								THEN dbo.tlagerbestand.fVerfuegbar
								ELSE 0.0
							END) AS fVerfuegbar,
						SUM(CASE WHEN dbo.tArtikel.cLagerAktiv = 'Y' 
								THEN dbo.tlagerbestand.fVerfuegbarGesperrt
								ELSE 0.0
							END) AS fVerfuegbarGesperrt
				FROM dbo.tlagerbestand 
				JOIN dbo.tArtikel ON dbo.tArtikel.kArtikel = dbo.tlagerbestand.kArtikel 
					AND dbo.tArtikel.kVaterArtikel > 0
				GROUP BY dbo.tArtikel.kVaterArtikel
			) AS Bestand ON Bestand.kArtikel = #Lagerbestand.kArtikel
			WHERE #Lagerbestand.nNestingDeep = 1;	
			
			UPDATE dbo.tlagerbestandProLagerLagerartikel
			SET fBestand = dbo.tlagerbestandProLagerLagerartikel.fBestand - WarenlagerAusgaenge.Summe
			FROM dbo.tlagerbestandProLagerLagerartikel
			JOIN (SELECT #WarenlagerAusgaenge.kArtikel, tWarenLagerPlatz.kWarenlager, SUM(fAnzahl) As Summe
					FROM #WarenlagerAusgaenge 
					JOIN dbo.tWarenLagerPlatz ON dbo.tWarenLagerPlatz.kWarenLagerPlatz = #WarenlagerAusgaenge.kWarenLagerPlatz
					GROUP BY #WarenlagerAusgaenge.kArtikel, tWarenLagerPlatz.kWarenLager
				)AS WarenlagerAusgaenge ON WarenlagerAusgaenge.kArtikel = dbo.tlagerbestandProLagerLagerartikel.kArtikel
			WHERE dbo.tlagerbestandProLagerLagerartikel.kWarenlager = WarenlagerAusgaenge.kWarenLager;		
			--
			-- Reservierung aktualisieren
			--
			DECLARE @xBestellpositionen XML;
			SET @xBestellpositionen = (
				SELECT DISTINCT kKey, kPlattform AS nPlattform
					FROM dbo.tReserviert 
					JOIN #Lagerbestand ON dbo.tReserviert.kArtikel = #Lagerbestand.kArtikel
				FOR XML PATH('Keys'), TYPE
			);
			IF(@xBestellpositionen IS NOT NULL)
			BEGIN
			     SET CONTEXT_INFO @OldContextInfo
				EXEC dbo.spReservierungAktualisieren @xBestellpositionen;
			END
			-- Lagerbestand updaten wenn klieferschein = 0
			DECLARE @typeArtikel AS TYPE_spUpdateLagerbestand;

			INSERT INTO @typeArtikel (kArtikel)
			SELECT DISTINCT kArtikel 
			FROM #WarenlagerAusgaenge 
			WHERE kLieferscheinPos = 0 OR kLieferscheinPos IS NULL;

			IF(EXISTS(SELECT * FROM @typeArtikel))
			BEGIN
				EXEC spUpdateLagerbestand @typeArtikel;
			END;

		IF(@nHistorieNichtSchreiben = 0)
		BEGIN

			INSERT INTO dbo.tArtikelHistory
			(
				kWarenLagerPlatz,kArtikel,fAnzahl,dGebucht, kBenutzer, kWarenEingang, kBestellPos, kGutschriftPos, fEKNetto, cKommentar, kBuchungsart, kLieferscheinPos,
				fLagerBestandGesamt, fLagerBestand, kLieferantenBestellungPos, cLieferscheinNr, cChargenNr, dMHD, fVerfuegbar, fReserviert
			)
			SELECT WLA.kWarenLagerPlatz,
			       WLA.kArtikel,-1 * SUM(WLA.fAnzahl) ,
				   @DATE AS dErstellt, WLA.kBenutzer,
				   0 AS kWarenLagerEingang,
				   ISNULL(dbo.tLieferscheinPos.kBestellPos,0) AS  kBestellPos,
				   ISNULL(dbo.tGutschriftPos.kGutschriftPos,0) AS tGutschriftPos,
				   ISNULL(dbo.tWarenLagerEingang.fEKEinzel, ISNULL(dbo.tArtikel.fEKNetto,0.0)) AS fEKEinzel,
				   SUBSTRING(ISNULL(WLA.cKommentar,'') + CASE WHEN LEN(StuffedSerNos.SerNos) > 0 THEN ' Seriennummern: ' + StuffedSerNos.SerNos ELSE '' END ,1,254) AS cKommentar,
				   WLA.kBuchungsart,
				   WLA.kLieferscheinPos,
				   MAX(dbo.tlagerbestand.fLagerbestandEigen) AS fLagerBestandGesamt, 
	   			   MAX(LagerBestandAufPlatz.fAnzahl) AS fLagerBestand,
				   dbo.tWarenLagerEingang.kLieferantenBestellungPos,
				   dbo.tWarenLagerEingang.cLieferscheinNr,
				   dbo.tWarenLagerEingang.cChargenNr,
				   dbo.tWarenLagerEingang.dMHD,
				   ISNULL(dbo.tlagerbestand.fVerfuegbar,0.0),
				   ISNULL(dbo.tlagerbestand.fInAuftraegen,0.0) -- Nur Lagerbestand auf dem Platz wo der WE grade liegt

			FROM #WarenlagerAusgaenge AS WLA
			JOIN dbo.tlagerbestand ON dbo.tlagerbestand.kArtikel = WLA.kArtikel
			JOIN dbo.tArtikel ON dbo.tArtikel.kArtikel = WLA.kArtikel
			JOIN dbo.tWarenLagerEingang ON dbo.tWarenLagerEingang.kWarenLagerEingang = WLA.kWarenlagerEingang
			LEFT JOIN dbo.tLieferscheinPos ON dbo.tLieferscheinPos.kLieferscheinPos = WLA.kLieferscheinPos
			LEFT JOIN dbo.tGutschriftPos ON dbo.tGutschriftPos.kBestellPos = dbo.tLieferscheinPos.kBestellPos
			OUTER APPLY ( SELECT STUFF((
							SELECT ',' + cSeriennr  
							FROM dbo.tLagerArtikel
							WHERE dbo.tLagerArtikel.kLieferscheinPos = WLA.kLieferscheinPos
							FOR XML PATH('')) ,1,1,'') AS SerNos ) AS StuffedSerNos
			OUTER APPLY (SELECT	SUM(tWarenLagerEingang.fAnzahlAktuell) AS fAnzahl
						 FROM dbo.tWarenLagerEingang
						 WHERE dbo.tWarenLagerEingang.kArtikel = WLA.kArtikel
						 AND dbo.tWarenLagerEingang.kWarenLagerPlatz = WLA.kWarenlagerPlatz) AS LagerBestandAufPlatz
	 
			GROUP BY WLA.kWarenLagerPlatz,WLA.kArtikel,WLA.kBenutzer,dbo.tGutschriftPos.kGutschriftPos,ISNULL(dbo.tWarenLagerEingang.fEKEinzel, ISNULL(dbo.tArtikel.fEKNetto,0.0)),
					 WLA.cKommentar, WLA.kBuchungsart, WLA.kLieferscheinPos,ISNULL(dbo.tLieferscheinPos.kBestellPos,0),dbo.tWarenLagerEingang.kLieferantenBestellungPos,
					 dbo.tWarenLagerEingang.cLieferscheinNr,dbo.tWarenLagerEingang.cChargenNr,dbo.tWarenLagerEingang.dMHD,dbo.tlagerbestand.fVerfuegbar,dbo.tlagerbestand.fInAuftraegen,StuffedSerNos.SerNos;

		END;

	    IF(@CreatedTransaction = 1)
		BEGIN
		  COMMIT;
		END;

		SET @retry = -1;
	END TRY
	BEGIN CATCH
    IF(ERROR_NUMBER() = 1205)
			BEGIN
				SET @retry = @retry - 1;
				IF(@CreatedTransaction = 1)
				    ROLLBACK TRAN;
				ELSE
				    ROLLBACK TRAN Savepoint1;

				WAITFOR DELAY '00:00:00:5';
			END
			ELSE 
			BEGIN
				SET @retry = -1;
				SELECT @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();

				IF(@CreatedTransaction = 1)
				   ROLLBACK TRAN;
				ELSE
				   ROLLBACK TRAN Savepoint1;

				RAISERROR (	@ErrorMessage, 
							@ErrorSeverity,
							@ErrorState
				);
				SET CONTEXT_INFO @OldContextInfo;
				RETURN;
			END
	END CATCH
	SET CONTEXT_INFO @OldContextInfo;
END
go

