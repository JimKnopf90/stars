-- 
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Erstellt Rekursiv die Lister der Kategorien, inklusive des kompletten Pfades
-- Datum: $Date$
-- Version: $Rev$
-- Autor: GJ
--

CREATE VIEW vKategorien
AS 
WITH KategorienDeutsch
       AS ( SELECT Kategorie.kKategorie , 
                   Kategorie.kOberKategorie , 
                   KategorieSprache.cName
            FROM
                 dbo.tkategorie AS Kategorie
                 JOIN dbo.tKategorieSprache AS KategorieSprache ON Kategorie.kKategorie = KategorieSprache.kKategorie
			  JOIN dbo.tSpracheUsed SpracheUsed ON KategorieSprache.kSprache = SpracheUsed.kSprache AND SpracheUsed.nStandard = 1 ) 
, KategorienMitRoot
       AS ( SELECT *
            FROM KategorienDeutsch AS kd
            UNION ALL
            SELECT 0 AS kKategorie , 
                   -1 AS kOberKategorie , 
                   'Kategorie' AS cName ) 
, KategorienRek( kKategorie , kOberKategorie , cName , Pfad , Ebene , Sort )
       AS ( SELECT KategorienMitRoot.kKategorie , 
                   KategorienMitRoot.kOberKategorie , 
                   KategorienMitRoot.cName , 
                   KategorienMitRoot.cName AS Pfad , 
                   1 , 
                   CONVERT( VARCHAR( 255 ) , KategorienMitRoot.kKategorie )
            FROM KategorienMitRoot AS KategorienMitRoot
            WHERE KategorienMitRoot.kOberKategorie = 0
            UNION ALL
            SELECT KategorienMitRoot2.kKategorie , 
                   KategorienMitRoot2.kOberKategorie , 
                   KategorienMitRoot2.cName , 
                   CONVERT( VARCHAR( 255 ) , KategorienRekursiv.cName + ' -> ' + KategorienMitRoot2.cName )AS Pfad , 
                   Ebene + 1 , 
                   CONVERT( VARCHAR( 255 ) , CONVERT( VARCHAR( 255 ) , RTRIM( Sort ) + '|' + CONVERT( VARCHAR( 255 ) , KategorienMitRoot2.kKategorie )))
            FROM
                 KategorienMitRoot AS KategorienMitRoot2
                 JOIN KategorienRek AS KategorienRekursiv ON KategorienRekursiv.kKategorie = KategorienMitRoot2.kOberKategorie )
       SELECT KategorienRekursiv.cName , 
              KategorienRekursiv.Pfad , 
              KategorienRekursiv.Ebene , 
              KategorienRekursiv.kKategorie , 
              KategorienRekursiv.Sort
       FROM KategorienRek AS KategorienRekursiv;
go

