--- 
--- spVersandBoxPruefen
---

CREATE PROCEDURE [dbo].[spVersandBoxPruefen]
	@kLHM int,
	@nAusDemWE INT = 0
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--  
AS  
BEGIN	  
	DECLARE @kWarenlager int, @kBestellung int 
  
	SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
	
	SELECT @kBestellung = dbo.tLHMStatus.kBestellung, @kWarenlager = dbo.tWarenlagerPlatz.kWarenlager 
	FROM dbo.tlhm WITH(NOLOCK)
	JOIN dbo.tlhmstatus WITH(NOLOCK) ON dbo.tlhmstatus.klhmstatus = dbo.tlhm.klhmstatus
	JOIN dbo.tWarenlagerPlatz WITH(NOLOCK) ON dbo.tWarenlagerPlatz.kWarenlagerPlatz = dbo.tLHM.kWarenlagerPlatz
	WHERE dbo.tlhmstatus.nstatus = 20
	AND dbo.tLHM.kLHM = @kLHM;
	  
	IF (@kBestellung > 0)
	BEGIN
	    EXEC spVersandBoxBestellungPruefen @kWarenlager = @kWarenlager, @kBestellung = @kBestellung,@nAusDemWE = @nAusDemWE;
	END 
END
go

