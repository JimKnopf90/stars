CREATE TRIGGER [dbo].[tgr_tlieferantenBestellung_INSUPDEL]
ON [dbo].[tLieferantenBestellung]
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
	IF NOT EXISTS(SELECT * FROM INSERTED FULL JOIN DELETED ON INSERTED.kLieferantenBestellung = DELETED.kLieferantenBestellung)
	BEGIN
		RETURN
	END;
	IF(CONTEXT_INFO() IN (0x5120, 0x5121, 0x5122, 0x5126, 0x5129))
	BEGIN
		RETURN;
	END
	IF(NOT(UPDATE(kLieferantenBestellung)
		OR UPDATE(kLieferant)
		OR UPDATE(kSprache)
		OR UPDATE(kLieferantenBestellungRA)
		OR UPDATE(kLieferantenBestellungLA)
		OR UPDATE(nStatus)
		OR UPDATE(kFirma)
		OR UPDATE(kLager)
		OR UPDATE(kKunde)
		OR UPDATE(nDropShipping)
		OR UPDATE(kLieferantenBestellungLieferant)
		OR UPDATE(kBenutzer)
		OR UPDATE(fFaktor)
		OR UPDATE(nDeleted)
		OR UPDATE(nManuellAbgeschlossen)
		OR UPDATE(kLieferschein)
		)
		AND EXISTS(SELECT * FROM INSERTED JOIN DELETED ON INSERTED.kLieferantenBestellung = DELETED.kLieferantenBestellung))
	BEGIN
		RETURN
	END
	ROLLBACK;
	RAISERROR(N'Die Tabelle tlieferantenBestellung kann nur über die SPs spLieferantenBestellungBearbeiten, spLieferantenBestellungErstellen und spLieferantenBestellungLoeschen bearbeitet werden.', 15,1);
END
go

