--- 
--- spNachschubVorschlaegeBerechnen
---

CREATE PROCEDURE [dbo].[spNachschubVorschlaegeBerechnen] 
	@kWarenlager INT,				    -- Warenlager der Bestände   
	@cArtikel VARCHAR(500),			    -- Der Filter aus der Maske, hier kann eine Artilnummer stehen
	@nNurKommPlatz INT,				    -- 1 = Nur artikel auf Kommplatz berechnen , 0 = Alle Artikel
	@nVerkaufsArtikel INT,			    -- 1 = Nur Artikel die verkauft wurden in den letzten X Tagen
	@nVerkaufsTage INT,				    -- Die letzen X Tage
	@cWarengruppenAsList VARCHAR(MAX),     -- der Filter für Warengruppen der Artikel
	@nTageFuerVorschlagBerechnung INT,     -- Zukünftige Tage für die Berechnung
	@nPufferFuerVorschlagBerechnung INT,   -- Prozentualler Puffer der zum endwert addiert wird
	@nLetzeTageFuerVorschlagBerechnung INT -- Es wird soweit zurückgeschaut für die durschnittlischen verkaufsmengen
	
	
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Author PN    

-- Funktion: Mit dieser Prozedur werden Vorschläge für Mindestmengen von Artikeln berechnet.
--		   Die Prozedur ist eng mit ihrer c# Maske verbunden und dient zur Steigerung der performance bei der Berechnung.
	
AS
	DECLARE @cSQLSelect VARCHAR(500);
	DECLARE @cSQLFrom VARCHAR(MAX);
	DECLARE @cSQLWhere VARCHAR(MAX);
	DECLARE @tempVorschlagArtikel  TABLE (kArtikel  INT,fMinMenge DECIMAL(28,14));
	DECLARE @cSQL NVARCHAR(MAX);
	DECLARE @cSQLGROUP VARCHAR(200);
	DECLARE @kArtikel INT
	DECLARE @fMinMenge DECIMAL(28,14)
	DECLARE @fVerkaufsmengeFuerTage DECIMAL(28,14)

BEGIN
	SET NOCOUNT ON;
	SET ANSI_NULLS ON;
	SET ANSI_NULL_DFLT_ON ON;
	SET ANSI_PADDING ON;
	SET CONCAT_NULL_YIELDS_NULL ON;
	SET XACT_ABORT OFF;
	
	--
	-- Anhand der übergebenen Parameter wird ein dynamisches SQL erstellt, zur Berechnung aller benötigten Artikel.
	--
     
	SET @cSQLSelect = N' SELECT tartikel.kArtikel,dbo.tWarenlagerArtikelOptionen.fMindestMenge ' ; 
     
	SET @cSQLFrom = N' FROM vWMSArtikel AS tartikel WITH(NOLOCK)
				JOIN dbo.tWarenLagerEingang  WITH(NOLOCK) ON dbo.tWarenLagerEingang.kArtikel = tartikel.kArtikel AND dbo.tWarenLagerEingang.fAnzahlAktuell > 0
				JOIN dbo.tWarenLagerPlatz  WITH(NOLOCK) ON dbo.tWarenLagerPlatz.kWarenLagerPlatz = dbo.tWarenLagerEingang.kWarenLagerPlatz
				LEFT JOIN dbo.tWarenlagerArtikelOptionen  WITH(NOLOCK) ON dbo.tWarenlagerArtikelOptionen.kArtikel = tartikel.kArtikel AND dbo.tWarenlagerArtikelOptionen.kWarenlager = dbo.tWarenLagerPlatz.kWarenLager
				LEFT JOIN dbo.tWMSLagerBereichPlatz  WITH(NOLOCK) ON dbo.tWMSLagerBereichPlatz.kWarenLagerPlatz = dbo.tWarenLagerPlatz.kWarenLagerPlatz
				LEFT JOIN dbo.tWMSLagerBereich  WITH(NOLOCK) ON dbo.tWMSLagerBereich.kWMSLagerBereich = dbo.tWMSLagerBereichPlatz.kWMSLagerBereich '
    
	IF(@nVerkaufsArtikel > 0)
	BEGIN
	SET @cSQLFrom = @cSQLFrom + N'  LEFT JOIN dbo.tbestellpos  WITH(NOLOCK) ON dbo.tbestellpos.tArtikel_kArtikel = tartikel.kArtikel 
								LEFT JOIN dbo.tLieferscheinpos  WITH(NOLOCK) ON dbo.tLieferscheinpos.kBestellPos = dbo.tbestellpos.kBestellPos  
							    LEFT JOIN dbo.tLieferschein WITH(NOLOCK) ON dbo.tLieferschein.kLieferschein = dbo.tLieferscheinpos.kLieferschein ';
    END 

    SET @cSQLWhere = N' WHERE dbo.tWarenlagerPlatz.kWarenlager = '+ CAST(@kWarenlager AS VARCHAR);
     
    IF (LEN(@cArtikel) > 0)
    BEGIN
		SET @cSQLWhere = @cSQLWhere + N' AND tartikel.cArtNr LIKE ''' + @cArtikel + '%'''; 
    END
     
    IF(@nNurKommPlatz = 1)
    BEGIN
		SET @cSQLWhere = @cSQLWhere + N' AND dbo.tWMSLagerBereich.nTyp = 1 ' ;
    END
     
    IF(@nVerkaufsArtikel = 1)
    BEGIN
		SET @cSQLWhere = @cSQLWhere + N' AND datediff(d, 0, dbo.tLieferschein.dErstellt) >= datediff(d, 0, getdate() - '+CAST(@nVerkaufsTage AS VARCHAR)+ ') ' ;
    END
     
    IF(LEN(@cWarengruppenAsList)>0)
    BEGIN
		SET @cSQLWhere = @cSQLWhere + N' AND tartikel.kWarengruppe IN ('+ @cWarengruppenAsList +') ' ;
    END
     
    SET @cSQLGROUP = ' GROUP BY tartikel.kArtikel,tartikel.cArtNr,dbo.tWarenlagerArtikelOptionen.fMindestMenge,dbo.tWarenlagerArtikelOptionen.fVorschlag' ;

    SET @cSQL = @cSQLSelect + @cSQLFROM + @cSQLWHERE + @cSQLGROUP; 
    INSERT INTO @tempVorschlagArtikel EXECUTE (@cSQL);
    

    --
    -- Cursor über alle Artikel für die wir die MindestMenge berechnen wollen
    --
    DECLARE CUR_ArtikelToCheck CURSOR LOCAL FAST_FORWARD FOR
    SELECT kArtikel,fMinMenge
	FROM @tempVorschlagArtikel;
     

     ---
     --- Vorschläge für Mindestmenge brechnen und eintragen
     ---
     OPEN CUR_ArtikelToCheck    
     FETCH NEXT FROM CUR_ArtikelToCheck INTO  @kArtikel,@fMinMenge

     WHILE (@@FETCH_STATUS = 0)
     BEGIN

		--
		-- Berechnen wieviel Menge des Artikels verkauft wurde in den letzten Tagen
		--
		SELECT @fVerkaufsmengeFuerTage = ISNULL(SUM(ISNULL(dbo.tLieferscheinpos.fAnzahl,0)),0)
			FROM dbo.tartikel WITH(NOLOCK)
			JOIN dbo.tbestellpos  WITH(NOLOCK) ON dbo.tbestellpos.tArtikel_kArtikel = dbo.tartikel.kArtikel 
			JOIN dbo.tLieferscheinpos  WITH(NOLOCK) ON dbo.tLieferscheinpos.kBestellPos = dbo.tbestellpos.kBestellPos  
			JOIN dbo.tLieferschein WITH(NOLOCK) ON dbo.tLieferschein.kLieferschein = dbo.tLieferscheinpos.kLieferschein
			WHERE dbo.tartikel.kArtikel = @kArtikel
				AND DATEDIFF(d, 0, dbo.tLieferschein.dErstellt) >= DATEDIFF(d, 0, GETDATE() - @nLetzeTageFuerVorschlagBerechnung);
    
    
		--
		-- Vorschlags Mindestmenge für die nächsten "@nTageFuerVorschlagBerechnung" Tage Berechnen, anhand von verkaufsdaten der letzten "@nLetzeTageFuerVorschlagBerechnung" Tage
		-- Dazu noch den möglichen Puffer aufaddieren
		-- Errechneter Wert des Vorschlags wird aufgerundet
		--
      

			SET @fVerkaufsmengeFuerTage = (@fVerkaufsmengeFuerTage * @nTageFuerVorschlagBerechnung) / (@nLetzeTageFuerVorschlagBerechnung + 1); -- Da ein Wert von 0 "Heute" bedeutet, muß der Tag für die berechnung addiert werden
			SET @fVerkaufsmengeFuerTage = @fVerkaufsmengeFuerTage + (@fVerkaufsmengeFuerTage/100) * @nPufferFuerVorschlagBerechnung;
			SET @fVerkaufsmengeFuerTage = CEILING(@fVerkaufsmengeFuerTage);

		--
		-- Vorschläge eintragen, falls schon vorhanden nur updaten
		--
		IF(@fMinMenge IS NULL)
		BEGIN
      
               IF(@fVerkaufsmengeFuerTage > 0) 
               BEGIN
               
			    INSERT INTO dbo.tWarenlagerArtikelOptionen WITH(ROWLOCK)
			    (
				    kArtikel,
				    kWarenlager,
				    kWarenLagerPlatz,
				    kWMSLagerBereich,
				    fMindestMenge,
				    fVorschlag
			    )
			    VALUES
			    (
				    @kArtikel,
				    @kWarenlager, 
				    NULL, 
				    NULL, 
				    0, 
				    @fVerkaufsmengeFuerTage
			    );
			END;
      
		END;
		ELSE
		BEGIN
      
               IF(@fVerkaufsmengeFuerTage = 0 AND @fMinMenge = 0)
               BEGIN
               
                DELETE FROM dbo.tWarenlagerArtikelOptionen WITH(ROWLOCK)
                WHERE kArtikel = @kArtikel
			    AND kWarenlager = @kWarenlager;
			  
               END;
               ELSE
               BEGIN
                 UPDATE dbo.tWarenlagerArtikelOptionen WITH(ROWLOCK)
			  	 SET fVorschlag = @fVerkaufsmengeFuerTage 
				 WHERE kArtikel = @kArtikel
			     AND kWarenlager = @kWarenlager;
               END;
			
      
		END;
    
		FETCH NEXT FROM CUR_ArtikelToCheck INTO  @kArtikel,@fMinMenge;
	END;

	CLOSE CUR_ArtikelToCheck;
	DEALLOCATE CUR_ArtikelToCheck;
      
END;
go

