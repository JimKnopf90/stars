CREATE TRIGGER [dbo].[tgr_tGebinde_INSUP]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--
ON [dbo].[tGebinde]
AFTER INSERT, UPDATE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
IF UPDATE(cEAN) OR UPDATE(cUPC)
BEGIN
BEGIN TRANSACTION 
	
	DELETE dbo.tArtikelSpeicher WITH(ROWLOCK) FROM dbo.tArtikelSpeicher WITH(ROWLOCK) 
	JOIN INSERTED ON INSERTED.kArtikel = dbo.tArtikelSpeicher.kArtikel 
	WHERE dbo.tArtikelSpeicher.nID in (6,9);
	
	WITH Alle AS 
	(
			SELECT DISTINCT LTRIM(RTRIM(tGebinde.cEAN)) AS Nummer, dbo.tGebinde.kArtikel, 6 AS Art , CASE WHEN dbo.tOptions.cValue = '1' THEN 1 ELSE 0 END AS nAktiv FROM dbo.tGebinde 
			JOIN INSERTED ON INSERTED.kArtikel = dbo.tGebinde.kArtikel 
			LEFT JOIN dbo.tOptions WITH(NOLOCK) ON dbo.tOptions.cKey = 'ArtikelEigenschaft GebindeEAN'
			WHERE dbo.tGebinde.cEAN IS NOT NULL AND dbo.tGebinde.cEAN <> '' 
			UNION ALL
			SELECT DISTINCT LTRIM(RTRIM(dbo.tGebinde.cUPC)) AS Nummer, dbo.tGebinde.kArtikel, 9 AS Art , CASE WHEN dbo.tOptions.cValue = '1' THEN 1 ELSE 0 END AS nAktiv FROM dbo.tGebinde 
			JOIN INSERTED ON INSERTED.kArtikel = dbo.tGebinde.kArtikel 
			LEFT JOIN dbo.tOptions WITH(NOLOCK) ON dbo.tOptions.cKey = 'ArtikelEigenschaft GebindeUPC'
			WHERE dbo.tGebinde.cUPC IS NOT NULL AND dbo.tGebinde.cUPC <> ''
	)
	INSERT INTO dbo.tArtikelSpeicher WITH(ROWLOCK) (kArtikel,cNummer,nID,nAktiv)
	SELECT DISTINCT Alle.kArtikel, Alle.Nummer, Alle.Art,Alle.nAktiv FROM Alle;


COMMIT
END
go

