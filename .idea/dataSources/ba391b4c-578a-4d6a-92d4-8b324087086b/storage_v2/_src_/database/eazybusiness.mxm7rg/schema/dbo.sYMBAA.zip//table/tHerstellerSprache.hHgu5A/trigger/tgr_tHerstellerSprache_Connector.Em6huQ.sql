CREATE TRIGGER [dbo].[tgr_tHerstellerSprache_Connector]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: PN/MP
--
ON [dbo].[tHerstellerSprache]
AFTER INSERT, UPDATE, DELETE
AS 
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN

	DELETE dbo.tQueue
	FROM dbo.tQueue
	JOIN
	(
		SELECT * FROM INSERTED
		UNION
		SELECT * FROM DELETED
	) AS Items ON dbo.tQueue.kWert = Items.kHersteller
	WHERE dbo.tQueue.cName = 'tHersteller';

	INSERT INTO tQueue(kShop, kPlattform, cName, kWert, nAction)	 
	SELECT dbo.tShop.kShop, 2, 'tHersteller' AS cName, Aktualisiert.kHersteller, 1
	FROM  
	(
		SELECT Hersteller.kHersteller FROM
		(
			SELECT * FROM INSERTED
			UNION
			SELECT * FROM DELETED
		) AS Hersteller
		GROUP BY Hersteller.kHersteller
	) AS Aktualisiert
	CROSS JOIN dbo.tShop;

END
go

