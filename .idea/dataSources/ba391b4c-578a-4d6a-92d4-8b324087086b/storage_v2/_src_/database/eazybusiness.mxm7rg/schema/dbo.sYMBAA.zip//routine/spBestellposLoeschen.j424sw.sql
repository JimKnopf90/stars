--- 
--- spBestellposLoeschen
---

CREATE PROCEDURE [dbo].[spBestellposLoeschen]
	@xBestellpos XML = NULL,
	@kBestellpos INT = NULL
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
DECLARE @ErrorMessage NVARCHAR(4000);
DECLARE @ErrorSeverity INT;
DECLARE @ErrorState INT;
DECLARE @retry INT;
SET @retry = 5;
WHILE @retry > 0
BEGIN
SELECT @xBestellpos;
	SET CONTEXT_INFO 0x5099;
	BEGIN TRY
		BEGIN TRANSACTION
			DECLARE @typeArtikel AS TYPE_spUpdateLagerbestand;
			IF(OBJECT_ID('tempdb..#Bestellpos') IS NOT NULL)
			BEGIN
				DROP TABLE #Bestellpos;
			END
			CREATE TABLE #Bestellpos(kBestellpos INT);
			IF(@xBestellpos IS NOT NULL)
			BEGIN
				INSERT INTO #Bestellpos(kBestellpos)
					SELECT Bestellpos.ID.value('kBestellPos[1]', 'INT')
						FROM @xBestellpos.nodes('Bestellpos') AS Bestellpos(ID);
			END
			ELSE
			BEGIN
				INSERT INTO #Bestellpos(kBestellpos)
					VALUES(@kBestellpos);
			END
			IF(EXISTS(SELECT * 
						FROM #Bestellpos 
						JOIN dbo.tbestellpos ON #Bestellpos.kBestellpos = dbo.tbestellpos.kBestellPos
						JOIN dbo.tArtikel ON dbo.tbestellpos.tArtikel_kArtikel = dbo.tArtikel.kArtikel))
			BEGIN

				INSERT INTO @typeArtikel (kArtikel)
				SELECT DISTINCT dbo.tArtikel.kArtikel
				FROM #Bestellpos 
				JOIN dbo.tbestellpos ON #Bestellpos.kBestellpos = dbo.tbestellpos.kBestellPos
				JOIN dbo.tArtikel ON dbo.tbestellpos.tArtikel_kArtikel = dbo.tArtikel.kArtikel;

			END;

			DECLARE @xBestellungen XML;
		SET @xBestellungen = (
			SELECT dbo.tbestellpos.tBestellung_kBestellung AS kBestellung
				FROM #Bestellpos
				JOIN dbo.tbestellpos ON #Bestellpos.kBestellpos = dbo.tbestellpos.kBestellPos
				GROUP BY dbo.tbestellpos.tBestellung_kBestellung
				FOR XML PATH('Bestellung'), TYPE
			);
			IF(EXISTS(SELECT * 
						FROM dbo.tBestellung
						JOIN dbo.tBestellpos ON tBestellung.kBestellung = tBestellpos.tBestellung_kBestellung
						JOIN #Bestellpos ON #Bestellpos.kBestellpos = tBestellpos.kBestellpos
						WHERE tBestellung.nIstExterneRechnung = 1))
			BEGIN
				RAISERROR('Diese Bestellung darf nicht geändert werden.', 18,10);
				ROLLBACK;
				RETURN;
			END
			DELETE FROM dbo.tbestellpos
				WHERE dbo.tBestellpos.kBestellPos IN (SELECT kBestellPos FROM #Bestellpos);
			DELETE FROM dbo.tReserviert 
				FROM dbo.tReserviert
				JOIN #Bestellpos ON #Bestellpos.kBestellpos = dbo.tReserviert.kKey 
									AND kPlattform = 1;

	
		IF(@xBestellungen IS NOT NULL)
		BEGIN
			EXEC dbo.spBestellungEckdatenAktualisieren @xBestellungen;
		END

			IF(EXISTS(SELECT * FROM @typeArtikel))
			BEGIN
				EXEC spUpdateLagerbestand @typeArtikel;
			END;
			SET @retry = -1;
		COMMIT
	END TRY
	BEGIN CATCH
		IF(ERROR_NUMBER() = 1205)
			BEGIN
				SET @retry = @retry -1;
				ROLLBACK;
				IF(@retry = 0)
				BEGIN
					SELECT @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
					RAISERROR (	@ErrorMessage, 
								@ErrorSeverity,
								@ErrorState
					);
					SET CONTEXT_INFO 0x0;
					RETURN;
				END
				WAITFOR DELAY '00:00:00:5';
			END
			ELSE 
			BEGIN
				SET @retry = -1;
				SELECT @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
				ROLLBACK;
				RAISERROR (	@ErrorMessage, 
							@ErrorSeverity,
							@ErrorState
				);
				SET CONTEXT_INFO 0x0;
				RETURN;
			END
	END CATCH
	SET CONTEXT_INFO 0x0;
END
go

