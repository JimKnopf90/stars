CREATE VIEW dbo.vWarenlagerPlatzArtikel
AS
SELECT twarenlagerEingang.kWarenLagerPlatz, twarenlagerEingang.kArtikel, SUM(twarenlagerEingang.fAnzahlAktuell) AS fAnzahl, dbo.tWarenLagerPlatzArtikel.cKommentar_1, dbo.tWarenLagerPlatzArtikel.cKommentar_2
	FROM twarenlagerEingang
	JOIN dbo.tWarenLagerPlatzArtikel ON tWarenLagerPlatzArtikel.kArtikel = tWarenLagerEingang.kArtikel AND tWarenLagerPlatzArtikel.kWarenLagerPlatz = tWarenLagerEingang.kWarenLagerPlatz
	GROUP BY twarenlagerEingang.kArtikel, twarenlagerEingang.kWarenLagerPlatz, dbo.tWarenLagerPlatzArtikel.cKommentar_1, dbo.tWarenLagerPlatzArtikel.cKommentar_2
go

