--- 
--- spEingangsrechnungStatusSetzen
---

CREATE PROCEDURE [dbo].[spEingangsrechnungStatusSetzen]  
--   
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--   
	@kEingangsrechnung INT  
AS  
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN TRANSACTION  
    UPDATE dbo.tEingangsrechnung  
	   SET dbo.tEingangsrechnung.dBezahlt = (CASE WHEN	((SELECT ISNULL(SUM(ISNULL(dbo.tEingangsrechnungZahlung.fBetrag, 0.0)), 0.0) 
											 FROM dbo.tEingangsrechnungZahlung 
											 WHERE dbo.tEingangsrechnungZahlung.kEingangsrechnung = @kEingangsrechnung) + 0.009) >= ROUND((SELECT SUM(ISNULL(dbo.tEingangsrechnungPos.fMenge, 0.0) * ISNULL(dbo.tEingangsrechnungPos.fEKNetto, 0.0) * (1.0 + (ISNULL(dbo.tEingangsrechnungPos.fMwSt, 0.0) / 100)) + ISNULL(tEingangsrechnungPosZusatzkosten.dWert, 0.0))
																												FROM dbo.tEingangsrechnungPos 
																												JOIN dbo.tEingangsrechnung ON dbo.tEingangsrechnungPos.kEingangsrechnung = dbo.tEingangsrechnung.kEingangsrechnung  
																												LEFT JOIN   
																												(  
																													   SELECT dbo.tEingangsrechnungPosZusatzkosten.kEingangsrechnungPos, SUM(ISNULL(dbo.tEingangsrechnungPosZusatzkosten.dWert, 0.0) * (1.0 + (ISNULL(dbo.tEingangsrechnungPosZusatzkosten.fMwst, 0.0) / 100))) AS dWert  
																													   FROM dbo.tEingangsrechnungPosZusatzkosten 
																													   JOIN dbo.tEingangsrechnungzusatzkosten ON dbo.tEingangsrechnungPosZusatzkosten.kZusatzkosten = dbo.tEingangsrechnungzusatzkosten.kZusatzkosten  
																													   WHERE dbo.tEingangsrechnungzusatzkosten.nPreis = 1  
																													   GROUP BY dbo.tEingangsrechnungPosZusatzkosten.kEingangsrechnungPos  
																												) AS tEingangsrechnungPosZusatzkosten ON tEingangsrechnungPosZusatzkosten.kEingangsrechnungPos = dbo.tEingangsrechnungPos.kEingangsrechnungPos  
																												WHERE dbo.tEingangsrechnungPos.kEingangsrechnung = @kEingangsrechnung), 2)  
								    THEN	(SELECT MAX(dbo.tEingangsrechnungZahlung.dDatum) 
											FROM dbo.tEingangsrechnungZahlung 
											WHERE dbo.tEingangsrechnungZahlung.kEingangsrechnung = @kEingangsrechnung)
 								    ELSE NULL 
								END)  
	   WHERE dbo.tEingangsrechnung.kEingangsrechnung = @kEingangsrechnung  
  
	UPDATE dbo.tEingangsrechnung  
	   SET dbo.tEingangsrechnung.nStatus = (CASE WHEN dbo.tEingangsrechnung.dBezahlt IS NOT NULL  
								    THEN  
									   (CASE WHEN dbo.tEingangsrechnung.nStatus = 5  
										  THEN 20  
										  ELSE dbo.tEingangsrechnung.nStatus END)  
								    ELSE  
									   (CASE WHEN dbo.tEingangsrechnung.nStatus = 20  
										  THEN 5  
										  ELSE dbo.tEingangsrechnung.nStatus END) 
								END)  
	   WHERE dbo.tEingangsrechnung.kEingangsrechnung = @kEingangsrechnung  
COMMIT
go

