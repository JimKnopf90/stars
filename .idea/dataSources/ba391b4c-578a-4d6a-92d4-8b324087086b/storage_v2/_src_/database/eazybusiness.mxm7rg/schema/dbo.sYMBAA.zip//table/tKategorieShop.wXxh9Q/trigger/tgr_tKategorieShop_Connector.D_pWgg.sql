CREATE TRIGGER [dbo].[tgr_tKategorieShop_Connector]
ON [dbo].[tKategorieShop]
AFTER UPDATE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
	
	--Überprüfen ob Trigger gefüllt aufgerufen wird
	IF((SELECT COUNT(1) FROM INSERTED FULL JOIN DELETED ON INSERTED.kKategorie = DELETED.kKategorie AND INSERTED.kShop = DELETED.kShop) = 0)
	BEGIN 
		RETURN;
	END

	UPDATE dbo.tKategoriebildPlattform
		SET dbo.tKategoriebildPlattform.nInet = 1
	FROM dbo.tKategoriebildPlattform
	JOIN INSERTED ON dbo.tKategoriebildPlattform.kKategorie = INSERTED.kKategorie
		AND dbo.tKategoriebildPlattform.kShop = INSERTED.kShop
		AND INSERTED.cInet = 'Y'
	JOIN DELETED ON dbo.tKategoriebildPlattform.kKategorie = DELETED.kKategorie
	WHERE dbo.tKategoriebildPlattform.nInet = 0
		AND INSERTED.cInet <> DELETED.cInet;

END
go

