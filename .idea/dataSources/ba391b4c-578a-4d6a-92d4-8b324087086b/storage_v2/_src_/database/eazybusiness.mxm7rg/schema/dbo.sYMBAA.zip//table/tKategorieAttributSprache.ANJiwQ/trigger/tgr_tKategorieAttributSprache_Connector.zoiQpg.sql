CREATE TRIGGER [dbo].[tgr_tKategorieAttributSprache_Connector]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP
--
ON [dbo].[tKategorieAttributSprache]
AFTER UPDATE, INSERT, DELETE
AS
SET CONCAT_NULL_YIELDS_NULL ON;
SET ANSI_WARNINGS ON;
SET ANSI_PADDING ON;
SET NOCOUNT ON;
BEGIN
	--Überprüfen ob Trigger gefüllt aufgerufen wird
	IF((SELECT COUNT(1) FROM INSERTED FULL JOIN DELETED ON INSERTED.kKategorieAttribut = DELETED.kKategorieAttribut AND INSERTED.kSprache = DELETED.kSprache) = 0)
	BEGIN 
		RETURN;
	END
	
	DECLARE @Komplett AS INT;
	--DECLARE @Preis AS INT;
	--DECLARE @Bestand AS INT;

	SET @Komplett = 1;
	--SET @Preis = 2;
	--SET @Bestand = 4;

	--
	-- Artikel vollständig zu Webshops senden, wenn Änderungen vorgenommen wurden
	--
	UPDATE dbo.tKategorieShop
		SET dbo.tKategorieShop.cInet = 'Y',
			dbo.tKategorieShop.nInBearbeitung = 0
	FROM dbo.tKategorieShop	
	JOIN
	(
		SELECT dbo.tKategorieAttribut.kKategorie, dbo.tKategorieAttribut.kShop
		FROM dbo.tKategorieAttribut		
		JOIN 
		(
			SELECT * FROM INSERTED
			UNION
			SELECT * FROM DELETED
		) AS aktualisiert ON aktualisiert.kKategorieAttribut = dbo.tKategorieAttribut.kKategorieAttribut
	) AS refreshableItems ON tKategorieShop.kKategorie = refreshableItems.kKategorie
		AND (dbo.tKategorieShop.kShop = refreshableItems.kShop OR refreshableItems.kShop = 0)
	WHERE	dbo.tKategorieShop.cInet = 'N'
			OR dbo.tKategorieShop.nInBearbeitung = 1;

END
go

