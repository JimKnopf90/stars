--
-- CleanUp-Trigger für das Löschen von Formularen
--
	CREATE TRIGGER [dbo].[jtlActionValidator_tFormular]
	--
	-- Copyright (c) 2012-2017 by JTL Software GmbH
	-- Datum: $Date$
	-- Version: $Rev$
	-- Autor: MP
	--
	ON [dbo].[tFormular]
	AFTER DELETE
	AS
	SET NOCOUNT ON;
	SET ANSI_NULLS ON;
	SET ANSI_NULL_DFLT_ON ON;
	SET ANSI_PADDING ON;
	SET CONCAT_NULL_YIELDS_NULL ON;
	SET XACT_ABORT OFF;
	BEGIN

		--
		-- Druckeinstellungen entfernen
		--
			DELETE tFormularDruckEinstellung WITH(ROWLOCK)
			FROM tFormularDruckEinstellung WITH(ROWLOCK)
			JOIN DELETED ON tFormularDruckEinstellung.kFormular = DELETED.kFormular

		--
		-- Maileinstellungen entfernen
		--
			DELETE tFormularEMailEinstellung WITH(ROWLOCK)
			FROM tFormularEMailEinstellung WITH(ROWLOCK)
			JOIN DELETED ON tFormularEMailEinstellung.kFormular = DELETED.kFormular

		--
		-- Faxeinstellungen entfernen
		--
			DELETE tFormularFaxEinstellung WITH(ROWLOCK)
			FROM tFormularFaxEinstellung WITH(ROWLOCK)
			JOIN DELETED ON tFormularFaxEinstellung.kFormular = DELETED.kFormular

		--
		-- Formularvorlagen entfernen
		--
			DELETE tFormularVorlage WITH(ROWLOCK)
			FROM tFormularVorlage WITH(ROWLOCK)
			JOIN DELETED ON tFormularVorlage.kFormular = DELETED.kFormular
	
	END
go

