--- 
--- spGetKategorienForLieferant
---

CREATE PROCEDURE [dbo].[spGetKategorienForLieferant]	 
@kLieferant INT
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP
--
AS
BEGIN
	IF(@kLieferant = 0)
	BEGIN

		SELECT	dbo.tKategorie.kKategorie, 
				dbo.tKategorieSprache.cName, 
				dbo.tkategorie.kOberKategorie 
		FROM dbo.tkategorie
		JOIN dbo.tKategorieSprache ON dbo.tKategorieSprache.kKategorie = dbo.tKategorie.kKategorie
			AND dbo.tKategorieSprache.kPlattform = 1
		JOIN dbo.tSpracheUsed ON 1 = 1 
			AND tSpracheUsed.nStandard = 1 
			AND tKategorieSprache.kSprache = tSpracheUsed.kSprache;

	END
	ELSE
	BEGIN
		
		WITH LieferantenKategorien AS
		(
			SELECT	dbo.tkategorie.kKategorie,
					dbo.tkategorie.kOberKategorie
			FROM dbo.tliefartikel
			JOIN dbo.tArtikel ON dbo.tliefartikel.tArtikel_kArtikel = dbo.tArtikel.kArtikel
			JOIN dbo.tkategorieartikel ON CASE WHEN dbo.tArtikel.kVaterArtikel > 0 THEN dbo.tArtikel.kVaterArtikel ELSE dbo.tArtikel.kArtikel END = dbo.tkategorieartikel.kArtikel
			JOIN dbo.tkategorie ON dbo.tkategorieartikel.kKategorie = dbo.tkategorie.kKategorie
			WHERE dbo.tliefartikel.tLieferant_kLieferant = @kLieferant
			GROUP BY	dbo.tkategorie.kKategorie,
						dbo.tkategorie.kOberKategorie
			UNION ALL
			SELECT	dbo.tkategorie.kKategorie,
					dbo.tkategorie.kOberKategorie
			FROM dbo.tkategorie
			JOIN LieferantenKategorien ON dbo.tkategorie.kKategorie = LieferantenKategorien.kOberKategorie
		)
		SELECT	dbo.tKategorieSprache.cName,
				dbo.tkategorie.kKategorie,
				dbo.tkategorie.kOberKategorie
		FROM LieferantenKategorien
		JOIN dbo.tkategorie ON LieferantenKategorien.kKategorie = dbo.tkategorie.kKategorie
		JOIN dbo.tSpracheUsed ON nStandard = 1
		JOIN dbo.tKategorieSprache ON dbo.tkategorie.kKategorie = dbo.tKategorieSprache.kKategorie
			AND dbo.tKategorieSprache.kSprache = dbo.tSpracheUsed.kSprache
			AND dbo.tKategorieSprache.kPlattform = 1
		GROUP BY	dbo.tKategorieSprache.cName,
					dbo.tkategorie.kKategorie,
					dbo.tkategorie.kOberKategorie

	END
END
go

