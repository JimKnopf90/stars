
    CREATE PROCEDURE unicorn2_spSetAllArticleUnicornShopActive
    AS
        DECLARE @kShopLocal INT
        DECLARE @kBenutzerLocal INT
        SET @kBenutzerLocal = 1

    		SET DEADLOCK_PRIORITY LOW

                BEGIN TRY
				    SET @kBenutzerLocal = (SELECT TOP 1 kBenutzer FROM eazybusiness.dbo.tbenutzer WHERE cLogin LIKE '%unicorn%')
                END TRY
                BEGIN CATCH
                END CATCH
                BEGIN TRY
                    IF (@kBenutzerLocal < 1)
                    BEGIN
                        SET @kBenutzerLocal = 1
                    END
                END TRY
                BEGIN CATCH
                END CATCH

				DECLARE uni2shop CURSOR READ_ONLY FAST_FORWARD FOR SELECT kShop FROM eazybusiness.dbo.tShop WITH (NOLOCK) WHERE cAPIKey = 'unicorn2' AND cServerWeb = 'unicorn2'
				OPEN uni2shop

					FETCH NEXT FROM uni2shop INTO @kShopLocal
					WHILE (@@FETCH_STATUS = 0)
						BEGIN
							EXEC eazybusiness.dbo.unicorn2_spSetAllArticleShopActive @kShop = @kShopLocal, @kBenutzer = @kBenutzerLocal
							FETCH NEXT FROM uni2shop INTO @kShopLocal
						END
				CLOSE uni2shop
				DEALLOCATE uni2shop
    go

