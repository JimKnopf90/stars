CREATE FUNCTION GroupColumnsDecimal(@value1 AS DECIMAL(28,15), @value2 AS DECIMAL(28,15))
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MK
--
-- Funktion gibt value1 zurück oder value2 wenn value1 leer ist
--
RETURNS DECIMAL(28,15)
AS
BEGIN
	IF(@value1 IS NULL)
	BEGIN
		RETURN @value2
	END
	RETURN @value1
END
go

