--- 
--- spPicklisteInBox
---

CREATE PROCEDURE [dbo].[spPicklisteInBox]
	@kPickliste INT,             -- Die Pickliste über die der Prozess läuft
	@kArtikel INT,             -- Die Artikel der Pickliste die din die Box gebucht werden sollen
	@cMhd VARCHAR(255),    -- Falls MHDs erfasst wurden, sonst NULL
	@cCharge  VARCHAR(255),    -- Falls Chargen erfasst wurden, sonst NULL
	@nMenge DECIMAL(28,14),   -- Die Menge der Artikel die in die Box gebucht werden sollen
	@kBestellung INT,             -- Die Bestellung über die der Prozess läuft (0 = keine Bestellung beschränkung)
	@kBenutzer INT,
	@kLhm INT,             -- Die Box
	@kWarenlagerPlatz INT,          -- Der Platz von dem gepickt werden soll (0 = keine Platz beschränkung)
	@nPickPosStatus INT,           -- Der Status ab welchen die Pickpositionen betrachtet werden. 20 = Pick, 30 = InBoxlegen. 
	@kLieferschein INT = 0,
	@nRet INT OUT
--  
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$

-- Funktion: Mit dieser Procedur werden alle Artikel (mit MHD/Charge) einer Bestellung in auf eine Box gebucht.
 
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;

	DECLARE @kPicklistePos  BIGINT;
	DECLARE @fPPAnzahl      DECIMAL(28,14);
	DECLARE @fGesAnzahl     DECIMAL(28,14);
	--DECLARE @nRet           INT
	DECLARE @dPLTimestamp   DATETIME;
	DECLARE @cPPChargenNr   VARCHAR(255);
	DECLARE @cPPMHD			    VARCHAR(255);
	DECLARE @kPPWarenLagerPlatz	INT;
	DECLARE @fAufPlatzAnzahl DECIMAL(28,14);
	DECLARE @kNewPicklistePos INT;
	DECLARE @kPicklistePosOld INT;
	DECLARE @CreatedTransaction INT;

	BEGIN TRY

	     IF (@@TRANCOUNT = 0)
	     BEGIN
		  SET @CreatedTransaction = 1;
		  BEGIN TRAN
	     END;
	     ELSE
	     BEGIN
		  SET @CreatedTransaction = 0;
		  SAVE TRAN Savepoint1;
	     END;


		SET @nRet = 0;
		SET @fGesAnzahl = @nMenge;
		SET @dPLTimestamp = GETDATE();
		
		IF(LEN(@cMhd) = 0)
		  SET @cMhd = NULL;
		  
		IF(LEN(@cCharge) = 0)
		  SET @cCharge = null;

		IF(@kBestellung > 0) -- Nur wenn ganze Bestellung gepickt wird
	     BEGIN
	       IF(CONTEXT_INFO() IS NULL) -- Falls wir von Eazyshipping kommen, nicht setzten
	           SET CONTEXT_INFO 0x5052; -- Sonst setzten, damit die BestandsUpdates nicht gemacht werden
	     END;

		-- DerCursor holt alle Pickpositionen von den Artikel zu der Bestellung
		-- Sortierung: zuerst alle Pickpositionen wo die Charge und MHD übereinstimmt, dann die wo die Menge genau der pickmenge ist, dann die Menge aufsteigend
		DECLARE cur_GetPickPos CURSOR LOCAL FAST_FORWARD FOR  
		SELECT dbo.tPicklistePos.kPicklistePos,dbo.tPicklistePos.fAnzahl,dbo.tWarenLagerEingang.cChargenNr,CONVERT(VARCHAR,dbo.tWarenlagerEingang.dMHD, 104) dMHD,dbo.tWarenLagerEingang.kWarenLagerPlatz
			FROM dbo.tPicklistePos WITH(NOLOCK) 
			JOIN dbo.tWarenLagerEingang WITH(NOLOCK) ON dbo.tWarenLagerEingang.kWarenLagerEingang = dbo.tPicklistePos.kWarenLagerEingang
			JOIN dbo.tBestellPos  WITH(NOLOCK) ON dbo.tPicklistePos.kBestellPos = dbo.tBestellPos.kBestellPos
			LEFT JOIN dbo.tWarenLagerEingang AS t2 WITH(NOLOCK) ON t2.kWarenlagerplatz = dbo.tPicklistePos.kWarenlagerplatz
										AND CONVERT(VARCHAR,t2.dMHD, 104) = @cMhd
										AND dbo.tWarenLagerEingang.fAnzahlAktuell > 0
			LEFT JOIN dbo.tWarenLagerEingang AS t3 WITH(NOLOCK) on t3.kWarenlagerplatz = dbo.tPicklistePos.kWarenlagerplatz
										AND t3.cChargenNr= @cCharge
										AND dbo.tWarenLagerEingang.fAnzahlAktuell > 0
		    LEFT JOIN (SELECT tLieferscheinPos.kBestellPos, SUM(tLieferscheinPos.fAnzahl) fAnzahl 
			            FROM tLieferscheinPos
						JOIN tLieferschein ON tLieferschein.kLieferschein = tLieferscheinPos.kLieferschein
						WHERE (tLieferschein.kLieferschein = @kLieferschein OR @kLieferschein = 0)
						GROUP BY tLieferscheinPos.kBestellPos ) AS LieferscheinPos ON LieferscheinPos.kBestellPos = dbo.tBestellPos.kBestellPos
			LEFT JOIN (SELECT ISNULL(tPicklistePos.fAnzahl,0) AS fAnzahl , tLieferscheinPos.kBestellPos 
						 FROM tLieferscheinPos
					     JOIN tPicklistePos ON tPicklistePos.kBestellPos = tLieferscheinPos.kBestellPos
						 AND tPicklistePos.nStatus = 30
						 AND tLieferscheinPos.kLieferschein = @kLieferschein
						 ) AS PickedFromLieferschein ON PickedFromLieferschein.kBestellPos = dbo.tBestellPos.kBestellPos
			WHERE dbo.tPicklistePos.kPickliste = @kPickliste 
				AND dbo.tPicklistePos.nStatus < @nPickPosStatus 
				AND dbo.tPicklistePos.kArtikel = @kArtikel
				AND dbo.tPicklistePos.fAnzahl > 0
				AND (
					@kBestellung = 0 
					OR dbo.tBestellPos.tBestellung_kBestellung = @kBestellung
					)
				AND (
					@kWarenlagerPlatz = 0 
					OR dbo.tPicklistePos.kWarenlagerPlatz = @kWarenlagerPlatz
					)
			ORDER BY CASE WHEN t3.kWarenLagerEingang IS NOT NULL 
						THEN 0 
						ELSE 1 
					END,
					CASE WHEN t2.kWarenLagerEingang IS NOT NULL 
						THEN 0 
						ELSE 1 
					END,
					CASE WHEN LieferscheinPos.kBestellPos IS NOT NULL THEN 0 ELSE 1 END, -- erst alle die Lieferschein haben
					CASE WHEN LieferscheinPos.kBestellPos IS NOT NULL AND  LieferscheinPos.fAnzahl - PickedFromLieferschein.fAnzahl = 0 THEN 1 ELSE 0 END, -- erst alle die nicht komplett vom lieferschein weggepickt sind
					CASE WHEN (LieferscheinPos.kBestellPos IS NOT NULL AND LieferscheinPos.fAnzahl = dbo.tBestellPos.nAnzahl) THEN 0 ELSE 1 END, --zuert die mit kompletten LieferscheinPos
					CASE WHEN dbo.tPicklistePos.fAnzahl = @fGesAnzahl 
						THEN 0 
						ELSE 1 
					END,
					dbo.tPicklistePos.fAnzahl;

		-- Solange kein Fehler und die gesammte pickmenge noch nicht erreicht -> weiter
		WHILE @nRet >= 0 AND @fGesAnzahl > 0
		BEGIN  
 
			-- Hole nächste Pickpos
			OPEN cur_GetPickPos;
			FETCH NEXT FROM cur_GetPickPos INTO @kPicklistePos,@fPPAnzahl,@cPPChargenNr,@cPPMHD,@kPPWarenLagerPlatz;
			CLOSE cur_GetPickPos;
   

			IF(@kPicklistePosOld = @kPicklistePos)  
			  SET @nRet = -203000001; -- Wenn sich die Pickpos wiederholt muß beim picken was falsch gelaufen sein, abbruch um endlosschleife zu verhindern

			IF(@kPicklistePos is null)
			  SET @nRet = -203000002; -- Keine Pickpos gefunden im cursor, kann nicht weiterpicken


			IF(@fPPAnzahl > @fGesAnzahl AND (@fPPAnzahl - @fGesAnzahl) > 0.0001)
			BEGIN
			   SET @fPPAnzahl = @fGesAnzahl;
			END
			 
    
			IF(@nRet < 0)
			  BREAK;

			-- Pickpos in Box legen
			EXEC dbo.spPicklisteposInBox
				@kPicklistePos  = @kPicklistePos,
				@kLhm       = @kLhm,
				@kBenutzer  = @kBenutzer,
				@fPickMenge = @fPPAnzahl,
				@dTimestamp	= @dPLTimestamp,
				@cMhd       = @cMhd,
				@cCharge    = @cCharge,
				@nPickposStatus = @nPickPosStatus,
				@nRet       = @nRet OUTPUT;

			SET @kPicklistePosOld = @kPicklistePos;
			SET @fGesAnzahl = @fGesAnzahl - @fPPAnzahl;
		END;

		DEALLOCATE cur_GetPickPos; 

		IF(@fGesAnzahl > 0) 
			SET @nRet = -203000003; -- Ganze Menge konnte nicht erfasst werden

		IF(@nRet < 0)  -- Bei einen Fehler im prozess, gesammter rollback
		BEGIN


		  IF(@CreatedTransaction = 1)
			 ROLLBACK TRAN;
		  ELSE
		      ROLLBACK TRAN Savepoint1;

		END;
			
		ELSE
		BEGIN

		   IF(CONTEXT_INFO() = 0x5052)
		   BEGIN
		        SET CONTEXT_INFO 0x0000; 

			   --
			   -- Wir aktualisieren den Bestand den wir gebucht haben
			   --
			   DECLARE @Positionen AS XML
			   SET @Positionen = (
				    SELECT Versand.vBestellPosLieferInfo.kBestellPos AS kKey, 1 AS nPlattform
					   FROM dbo.tBestellpos
					   JOIN Versand.vBestellPosLieferInfo ON Versand.vBestellPosLieferInfo.kBestellPos = dbo.tBestellpos.kBestellPos
					   WHERE dbo.tBestellpos.tBestellung_kBestellung = @kBestellung                    
				FOR XML PATH('Keys'), TYPE
				);


			   EXEC dbo.spReservierungAktualisieren @Positionen;
			   EXEC dbo.spBestellungEckdatenAktualisieren    @kBestellung =  @kBestellung;
		    END;

		    IF(@CreatedTransaction = 1)
		      COMMIT TRAN T2;


		END;

		SELECT @nRet; 


	END TRY
	BEGIN CATCH
	   SELECT -203000004; -- unbekannter Fehler


	   IF(@CreatedTransaction = 1)
		  ROLLBACK TRAN;
	   ELSE
		  ROLLBACK TRAN Savepoint1;

	   SET @nRet = -203000004; 
	   
	    INSERT INTO dbo.tLog
	    (dDatum, kBenutzer, cLog,  nTyp,  nVorgang )
	    VALUES
	    (GETDATE(),  @kBenutzer,   ERROR_MESSAGE(),   14,  9);
	END CATCH
go

