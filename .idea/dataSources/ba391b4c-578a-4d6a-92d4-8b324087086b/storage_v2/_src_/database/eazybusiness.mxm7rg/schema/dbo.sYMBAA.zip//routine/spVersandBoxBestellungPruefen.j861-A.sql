--- 
--- spVersandBoxBestellungPruefen
---

CREATE PROCEDURE [dbo].[spVersandBoxBestellungPruefen] 
	@kWarenlager INT,
	@kBestellung INT,
	@nAusDemWe   INT = 0
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--   
AS   
BEGIN	   
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
	DECLARE @KLHMStatus INT, @kLHM INT, @kWarenlagerPlatz INT, @nAnzahlFehlerBeiStueckliste INT, @nTeillieferungErlaubt INT, @nOffeneKonfiPositionen INT, @nGesperrt INT, @kGefundeneBestellung INT
	DECLARE @fReserviert DECIMAL(28,14), @fOffeneMenge DECIMAL(28,14), @fReserviertAufDemWeg DECIMAL(28,14), @nNewBestellung INT
	DECLARE @AuftragNichtKomplett INT


	SELECT dbo.tlhmstatus.* INTO #LHMStatus 
		FROM dbo.tlhm WITH(NOLOCK)  
		JOIN dbo.tlhmstatus WITH(NOLOCK) ON dbo.tlhmstatus.klhmstatus = dbo.tlhm.klhmstatus 
		WHERE dbo.tlhmstatus.kBestellung = @kBestellung  
			AND dbo.tlhmstatus.nstatus = 20 
			AND dbo.tlhm.kwarenlager = @kWarenlager 
			AND ISNULL(dbo.tLhm.nSperre,0) = 0;
 
	SELECT @kLHM = #LHMStatus.kLHM FROM #LHMStatus;
   
	IF (@kLHM > 0) 
	BEGIN 
		SELECT TOP(1) @kGefundeneBestellung = ISNULL(tBestellung.kBEstellung,0), @fOffeneMenge = SUM(Versand.vBestellPosLieferInfo.fAnzahlOffen), @fReserviert = SUM(PickPosAnzahl.fReserviert), 
				@fReserviertAufDemWeg = SUM(isnull(PickposAufDemWeg.fMenge,0)), @nTeillieferungErlaubt = MAX(tBEstellungWMSFreigabe.nTeillieferungErlaubt), 
				@nGesperrt = MAX(ISNULL(tBestellungWMSFreigabe.nSperre,0))   
			FROM dbo.tBestellung WITH(NOLOCK) 
			JOIN dbo.tBestellPos WITH(NOLOCK) ON (dbo.tBestellPos.tBestellung_kBestellung = dbo.tbestellung.kBestellung and (tBestellpos.nType = 1  or tBestellpos.nType = 11))  
			JOIN Versand.vBestellPosLieferInfo WITH(NOLOCK) ON Versand.vBestellPosLieferInfo.kBestellpos = dbo.tBestellpos.kBestellpos
			JOIN vWMSArtikel WITH(NOLOCK) ON vWMSArtikel.kArtikel = dbo.tBestellPos.tArtikel_kArtikel
			LEFT JOIN dbo.tZahlungsart WITH(NOLOCK) ON dbo.tZahlungsart.kZahlungsart = dbo.tBestellung.kZahlungsart
			LEFT JOIN dbo.tBEstellungWMSFreigabe WITH(NOLOCK) on dbo.tBEstellungWMSFreigabe.kBestellung = dbo.tBestellung.kBestellung and dbo.tBEstellungWMSFreigabe.nAktiv = 1
			--Die Menge welche insgesamt Reserviert ist (Ab sTatus 40 gibts auch ne Lieferscheinpos) 
			LEFT JOIN (
				SELECT dbo.tPicklistePos.kBestellpos, dbo.tPicklistePos.kArtikel, SUM(fAnzahl) AS fReserviert FROM dbo.tPicklistePos WITH(NOLOCK)  
					WHERE dbo.tPicklistePos.nStatus < 40  
					GROUP BY dbo.tPicklistePos.kBestellpos, dbo.tPicklistePos.kArtikel) AS PickPosAnzahl ON (PickPosAnzahl.kBestellPos = dbo.tBestellPos.kBestellpos and PickPosAnzahl.kArtikel = vWMSArtikel.kArtikel
					)  
			--Die Menge die in diesem Lager noch nicht in den Boxen ist -> Kein Druck erlaubt 
			LEFT JOIN (SELECT dbo.tPicklistePos.kBestellpos, dbo.tPicklistePos.kArtikel, SUM(fAnzahl) AS fMenge FROM dbo.tPicklistePos WITH(NOLOCK)   
						WHERE dbo.tPicklistePos.nStatus < 30  
						AND dbo.tPicklistepos.kWarenlager = @kWarenlager --DAs Warenlager ist nur hierbei wichtig, weil Pickpositionen die in anderen Lägern noch auf dem Weg sind sind für dieses LAger uninteressant 
						GROUP BY dbo.tPicklistePos.kBestellpos, dbo.tPicklistePos.kArtikel) AS PickposAufDemWeg ON (PickposAufDemWeg.kBestellPos = tBestellPos.kBestellpos and PickposAufDemWeg.kArtikel = vWMSArtikel.kArtikel)  
			WHERE dbo.tBestellung.nKomplettAusgeliefert = 0	 
				AND dbo.tBestellPos.kBestellStueckliste !=  dbo.tBestellPos.kBestellPos
				AND (dbo.tBestellung.dBezahlt IS NOT NULL
				OR ISNULL(dbo.tZahlungsart.nAusliefernVorZahlung,0) = 1)
				AND dbo.tBEstellung.kBestellung = @kBestellung 
			GROUP BY dbo.tBestellung.kbestellung;
 
		--Es dürfen nur Boxen gedruckt werden, wenn folgendes gilt: 
		--1. Es darf keine offene Menge mehr in dem Auftrag exisitieren, d.h. alles muss schon geliefert oder reserviert sein 
		--2. Die Reservierten Mengen müssen im aktuellen Lager schon in den Boxen sein, sie dürfen nicht mehr auf dem Weg sein. Andere Läger interessieren hier nicht, da  
		--3. Oder Teillieferungen erlaubt sind (im tBestellungWMSFreigabe, kann in der Wawi eingestellt werden) und keine Reservierungen mehr auf dem Weg sind
		-- pro Lager einen eigenen Verpackungsprozess gibt 
		IF (@kGefundeneBestellung > 0 AND ( @nGesperrt = 0 AND (((@fOffeneMenge - @fReserviert ) = 0) AND @fReserviertAufDemWeg = 0) 
		   OR (@nTeillieferungErlaubt = 1 AND @fReserviertAufDemWeg = 0)))
		BEGIN 
			--Hier wird nun überprüft ob für Stücklistenartikel folgendes gilt
			--Die Menge eines Kindartikels muss immer genau X-Vater Artikel ergeben -> Es darf kein Rest bei Anzahl / tbestellstueckliste.fAnzahl bleiben
			--Jedes Kind muss gleich viele Väter erzeugen, es darf also nicht sein dass genügend Reifen für 3 Autos, aber nur Fenster für 2 Autos in der Box sind
			--Liefert einen Wert zurück wenn eine Bedingung nicht stimmt
		    SELECT @nAnzahlFehlerBeiStueckliste = COUNT(*)
				FROM
				(
				-- Gruppiert nach Stücklisten
				SELECT InnereAbfrage.kbestellstueckliste,
					CASE SUM(InnereAbfrage.fMengeInBox) WHEN 0 THEN 0 ELSE SUM(InnereAbfrage.fRestWert) END as fRestWert,
					MAX(fMengeDerKomplettenTeile) as fMAXMengeDerKomplettenTeile, MIN(fMengeDerKomplettenTeile) as fMINMengeDerKomplettenTeile
					FROM
					(
						 -- Gruppiert nach allen Bestellpositionen
						SELECT dbo.tbestellpos.kbestellstueckliste, 
							 dbo.tbestellpos.tArtikel_kArtikel,
							 ISNULL(BestellPosMenge.MEnge,0) fMengeInBox, 
							 (ISNULL(tbestellpos.nAnzahl,0) / t2.nAnzahl) fStuecklistenMengeMax,
							 ISNULL(BestellPosMenge.Menge / (ISNULL(dbo.tbestellpos.nAnzahl,0) / t2.nAnzahl),0) fMengeDerKomplettenTeile,
							 CASE (ISNULL(SUM(ISNULL(BestellPosMenge.MEnge,0)),0)) WHEN 0 THEN 0 ELSE SUM(ISNULL(BestellPosMenge.MEnge,0)) % (SUM(ISNULL(dbo.tbestellpos.nAnzahl,0)) / MAX (t2.nAnzahl)) END fRestWert
							FROM dbo.tbestellpos WITH(NOLOCK)
							-- Die Mengen die in der Box Liegen von den BestellPos
							LEFT JOIN (SELECT dbo.tpicklistepos.kbestellpos, dbo.tpicklistepos.kArtikel, sum(dbo.tpicklistepos.fAnzahl) AS MEnge 
										FROM dbo.tpicklistepos WITH(NOLOCK)
										JOIN dbo.tbestellpos WITH(NOLOCK) on dbo.tbestellpos.kbestellpos = dbo.tpicklistepos.kbestellpos
										JOIN dbo.twarenlagereingang WITH(NOLOCK) on dbo.twarenlagereingang.kwarenlagereingang = dbo.tpicklistepos.kwarenlagereingang
										WHERE dbo.twarenlagereingang.klhm = @kLHM
										AND dbo.twarenlagereingang.fAnzahlAktuell > 0
										AND dbo.tbestellpos.tbestellung_kbestellung = @kBestellung
										GROUP BY dbo.tpicklistepos.kbestellpos, dbo.tpicklistepos.kArtikel) AS BestellPosMenge ON (BestellPosMenge.kBestellPos = dbo.tbestellpos.kBestellPos AND BestellPosMenge.kArtikel = dbo.tbestellpos.tArtikel_kArtikel)
							JOIN (SELECT dbo.tbestellpos.kbestellpos ,dbo.tbestellpos.nAnzahl FROM dbo.tbestellpos WITH(NOLOCK) WHERE dbo.tbestellpos.nAnzahl > 0 ) AS t2 ON t2.kbestellpos = dbo.tbestellpos.kbestellstueckliste
							JOIN vWMSArtikel ON vWMSArtikel.kArtikel = dbo.tbestellpos.tArtikel_kArtikel
							WHERE dbo.tbestellpos.tbestellung_kbestellung = @kBestellung
							AND dbo.tbestellpos.kbestellstueckliste > 0
							AND dbo.tbestellpos.kBestellPos != dbo.tbestellpos.kbestellstueckliste
							GROUP BY dbo.tbestellpos.kbestellstueckliste,dbo.tbestellpos.tArtikel_kArtikel, t2.nAnzahl, dbo.tbestellpos.nAnzahl, dbo.tbestellpos.kBestellPos, BestellPosMenge.MEnge
						) AS InnereAbfrage
					GROUP BY InnereAbfrage.kbestellstueckliste
					) AS AussereAbfrage
				WHERE (fRestWert > 0 or fMAXMengeDerKomplettenTeile <> fMINMengeDerKomplettenTeile); --Es dürfen keine Artikel nicht vollständig (bezogen auf Stückliste) in der Box sein und nur gleich viele StücklistenKinder pro Stückliste


			--An dieser Stelle muss noch ein Hinweis gesetzt werden, der auf PRobleme hindeutet
			IF (@nAnzahlFehlerBeiStueckliste > 0)
				RETURN;

			SELECT @nOffeneKonfiPositionen = Versand.vBestellPosLieferInfo.fAnzahlOffen - ISNULL(PickPosAnzahl.fReserviert, 0) 
				FROM dbo.tbestellpos WITH(NOLOCK)
				JOIN Versand.vBestellPosLieferInfo WITH(NOLOCK) ON Versand.vBestellPosLieferInfo.kBestellpos = dbo.tBEstellpos.kBestellpos
				JOIN dbo.tArtikel WITH(NOLOCK) ON dbo.tArtikel.kArtikel = dbo.tbestellpos.tArtikel_kArtikel AND ISNULL(dbo.tArtikel.kStueckliste, 0) = 0
				LEFT JOIN (SELECT dbo.tPicklistePos.kBestellpos, dbo.tPicklistePos.kArtikel, SUM(fAnzahl) AS fReserviert
							FROM dbo.tPicklistePos WITH(NOLOCK)
							GROUP BY dbo.tPicklistePos.kBestellpos, dbo.tPicklistePos.kArtikel) AS PickPosAnzahl
				ON (PickPosAnzahl.kBestellPos = dbo.tBestellPos.kBestellpos AND PickPosAnzahl.kArtikel = dbo.tArtikel.kArtikel)
				WHERE dbo.tbestellpos.tBestellung_kBestellung = @kBestellung
					AND dbo.tBestellpos.cUnique IS NOT NULL 
					AND LEN(dbo.tBestellpos.cUnique) > 0
					AND Versand.vBestellPosLieferInfo.fAnzahlOffen - ISNULL(PickPosAnzahl.fReserviert, 0) > 0  
					AND dbo.tArtikel.cLagerAktiv = 'Y'
					AND dbo.tArtikel.cLagerVariation <> 'Y' 
					AND (dbo.tArtikel.nIstVater = 0) 
					AND (NOT EXISTS (SELECT *
										FROM dbo.teigenschaft WITH(NOLOCK) 
										WHERE cAktiv = 'Y' AND kArtikel = dbo.tartikel.kArtikel));

			IF (@nOffeneKonfiPositionen > 0)
				RETURN;

		     DECLARE @CreatedTransaction BIT
			IF (@@TRANCOUNT = 0)
			BEGIN
				SET @CreatedTransaction = 1;
				BEGIN TRAN;
			END;
		     ELSE
			BEGIN
				SET @CreatedTransaction = 0;
				SAVE TRAN Savepoint1;
		     END;



				BEGIN TRY 		
				--Falls Teillieferung, dann muss der Auftrag gesplittet werden
					IF ((@fOffeneMenge - @fReserviert) > 0 AND @nTeillieferungErlaubt = 1 AND @fReserviertAufDemWeg = 0)
					BEGIN

					   SET @AuftragNichtKomplett = 1;
					   IF(@nAusDemWe = 0)
					   BEGIN
						  EXEC  dbo.spSplitAuftragByMenge @kBestellung = @kBestellung, @kBenutzer = 0, @kLHM = @kLHM 

	  					  -- Zuordnungen der Pickliste neu ordnen
						  SELECT TOP 1 @nNewBestellung = kBestellung
						  FROM tBestellung
						  WHERE kSplitBestellung = @kBestellung
						  ORDER BY kBestellung DESC;

						  SET @AuftragNichtKomplett = 0;
					   END

				     END;
				     ELSE
					BEGIN
					   SET @nNewBestellung = @kBestellung;
					   SET @AuftragNichtKomplett = 0;
					END;
					 


					-- Prüfen ob die selbe bestellung noch in anderen boxen drin ist die noch nicht gedruckt sind (Versandboxen mit Roko)
					DECLARE @BestellungInMehrBoxen INT = 0;
					SELECT @BestellungInMehrBoxen = CASE WHEN COUNT(*) > 1 THEN 1 ELSE 0 END
					FROM dbo.tLHMStatus
					JOIN dbo.tLHM ON dbo.tLHM.kLHMStatus = dbo.tLHMStatus.kLHMStatus
					WHERE dbo.tLHMStatus.kBestellung = @nNewBestellung
					AND dbo.tLHMStatus.nStatus < 30
					AND dbo.tLHM.kWarenlager = @kWarenlager;


				    IF(@nNewBestellung > 0 AND @AuftragNichtKomplett = 0 AND @BestellungInMehrBoxen = 0)
					BEGIN

					    SELECT @kWarenlagerPlatz = kwarenlagerplatz 
						    FROM tlhm WITH(NOLOCK) 
						    WHERE klhm = @kLHM; 
					    --Löscht alle hängenden Aufträge für die LHM von vorher 
					    -- Alle anderen sind abgearbeitet (Status > 10) oder sind Altlasten und existieren nicht mehr in der Box 
					    DELETE FROM dbo.tDruckQueue WITH(ROWLOCK) 
						    WHERE kLHM = @kLHM 
							    AND nStatus < 100;  
			   
					    INSERT INTO dbo.tDruckQueue WITH(ROWLOCK)(dZeitStempel, nStatus, kLHM, kWarenlagerPlatz) 
						    VALUES (GetDate(),10,@kLHM,@kWarenlagerPlatz);
			 
					    UPDATE #LHMStatus 
						    SET nStatus = 30, DZeitstempel = GETDATE(),kBestellung = @nNewBestellung;
					    -- PK der Virtuellen Tabelle dropen, damit er in der reallen erstellt werden kann 
					    ALTER TABLE #LHMStatus 
						    DROP COLUMN kLHMStatus;  
					    INSERT INTO dbo.tLHMStatus 
						    SELECT #LHMStatus.* 
							    FROM #LHMStatus; 
 
					    SET @KLHMStatus = SCOPE_IDENTITY()
					    UPDATE dbo.tLHM WITH(ROWLOCK) 
						    SET KLHMStatus = @KLHMStatus 
						    WHERE kLHM = @kLHM;		
						
					END;

				IF (@CreatedTransaction = 1)
				BEGIN
				    COMMIT TRAN;
				END;
			END TRY 
			BEGIN CATCH 
				IF (@CreatedTransaction = 1)
				BEGIN
				    ROLLBACK TRAN;
				END;
				ELSE
				BEGIN
				    ROLLBACK TRAN Savepoint1;
				END;
			END CATCH 
		END; 
	END;
END;
go

