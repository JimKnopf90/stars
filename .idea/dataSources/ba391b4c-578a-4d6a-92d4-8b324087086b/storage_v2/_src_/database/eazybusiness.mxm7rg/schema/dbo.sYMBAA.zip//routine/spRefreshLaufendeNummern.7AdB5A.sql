--- 
--- spRefreshLaufendeNummern
---

CREATE PROCEDURE [dbo].[spRefreshLaufendeNummern]  
--  
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Info: Diese SP kann entfernt werden, sobald alles auf tLaufendeNummern umgestellt wurde  
--   
AS   
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN TRANSACTION   
   
	-- Kunde   
	IF((SELECT COUNT(NAME) FROM sys.tables WHERE name = 'tLfdnrKunde') > 0)  
	BEGIN  
		UPDATE tLaufendeNummern WITH(ROWLOCK)   
		SET tLaufendeNummern.nNummer = ISNULL((SELECT TOP 1 ISNULL(tLfdnrKunde.nNummer, 1) FROM tLfdnrKunde WITH(NOLOCK)), 1),   
			tLaufendeNummern.cPrefix = (SELECT TOP 1 tAnfangsNr.sKPre FROM tAnfangsNr WITH(NOLOCK)),   
			tLaufendeNummern.cSuffix = (SELECT TOP 1 tAnfangsNr.sKPost FROM tAnfangsNr WITH(NOLOCK))   
		WHERE tLaufendeNummern.cName = 'Kunde'   
	END  
COMMIT
go

