CREATE TRIGGER [dbo].[tgr_tKategoriebildPlattform_INSERT]  
--     
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Author: Markus Hütz
--    
ON [dbo].[tKategoriebildPlattform]  
AFTER INSERT
AS  
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
    --
    -- Überprüfen ob Trigger gefüllt aufgerufen wird
    --
    IF((SELECT COUNT(1) FROM INSERTED) = 0) 
    BEGIN
	   RETURN;
    END;

	--
	-- nInet auf 0 setzen wenn Kategorie gar nicht für Shop aktiv
	--
	UPDATE dbo.tKategoriebildPlattform
		SET dbo.tKategoriebildPlattform.nInet = 0
	FROM dbo.tKategoriebildPlattform
	JOIN INSERTED ON dbo.tKategoriebildPlattform.kKategoriebildPlattform = INSERTED.kKategoriebildPlattform
	LEFT JOIN dbo.tKategorieShop ON INSERTED.kKategorie = dbo.tKategorieShop.kKategorie
		AND INSERTED.kShop = dbo.tKategorieShop.kShop
	WHERE	dbo.tKategorieShop.kKategorie IS NULL
			AND INSERTED.nInet = 1;
END
go

