CREATE TRIGGER [dbo].[tgr_tArtikelbildPlattform_DELETE]  
--     
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Author: Markus Hütz
--    
ON [dbo].[tArtikelbildPlattform]  
AFTER DELETE
AS  
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
    IF((SELECT COUNT(1) FROM DELETED) = 0) 
    BEGIN
	   RETURN;
    END;

    --
    -- DIESER TRIGGER IST IM UPDATE FUER "Bildermigration099926" DEAKTIVERT!!!
    --

    --
    -- tQueue für jeden gelöschten Datensatz schreiben
    --
    INSERT INTO dbo.tQueue (kShop, kPlattform, cName, kWert, nAction, kOption1, kOption2)
    SELECT kShop = DELETED.kShop, kPlattform = DELETED.kPlattform, cName = 'tArtikelbildPlattform', kWert = DELETED.kArtikelbildPlattform, nAction = 2, kOption1 = DELETED.kArtikel, kOption2 = DELETED.nNr
    FROM DELETED
	JOIN dbo.tArtikelShop ON DELETED.kArtikel = dbo.tArtikelShop.kArtikel
						AND DELETED.kShop = dbo.tArtikelShop.kShop
	WHERE DELETED.kShop > 0;

    --
    -- tBild ggfs. aufräumen
    --
    DECLARE @Bilder AS TYPE_spBildLoeschenWennNichtVerwendet;

    INSERT INTO @Bilder (kBild)
	SELECT DELETED.kBild AS 'kBild'
	FROM DELETED
	WHERE DELETED.kPlattform = 1
	GROUP BY DELETED.kBild
	  
    EXEC dbo.spBildLoeschenWennNichtVerwendet @Bilder;

    --
    -- eBay aktualisieren
    --
    DECLARE @Artikel AS XML;
    SET @Artikel =
    (
	   SELECT DELETED.kArtikel AS 'kArtikel'
	   FROM DELETED
	   WHERE DELETED.kPlattform = 30 AND DELETED.nNr <= 12
	   GROUP BY DELETED.kArtikel
	   FOR XML PATH('Artikel'), TYPE
    );
    EXEC dbo.spUpdateEbayBilderLaufendGeplant @Artikel;
END
go

