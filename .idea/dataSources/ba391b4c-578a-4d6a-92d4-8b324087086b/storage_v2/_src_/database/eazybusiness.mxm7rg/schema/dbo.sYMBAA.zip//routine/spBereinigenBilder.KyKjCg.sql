--- 
--- spBereinigenBilder
---

CREATE PROCEDURE [dbo].[spBereinigenBilder]
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
	--
	-- Uebernahme aus spBereinigenBildLeichen
	--
    WITH AllUsed( kBild )
        AS ( SELECT dbo.tArtikelbildPlattform.kBild
             FROM dbo.tArtikelbildPlattform
             --
             -- tEigenschaftWertPict
             --
             UNION ALL
             SELECT dbo.tEigenschaftWertPict.kBild
             FROM dbo.tEigenschaftWertPict
             --
             -- tMerkmalBildPlattform
             --
             UNION ALL
             SELECT dbo.tMerkmalBildPlattform.kBild
             FROM dbo.tMerkmalBildPlattform
             --
             -- tMerkmalWertBildPlattform
             --
             UNION ALL
             SELECT dbo.tMerkmalWertBildPlattform.kBild
             FROM dbo.tMerkmalWertBildPlattform
             --
             -- tKategoriebildPlattform
             --
             UNION ALL
             SELECT dbo.tKategoriebildPlattform.kBild
             FROM dbo.tKategoriebildPlattform
             --
             -- tHerstellerBildPlattform
             --
             UNION ALL
             SELECT dbo.tHerstellerBildPlattform.kBild
             FROM dbo.tHerstellerBildPlattform )

        DELETE FROM dbo.tbild
        WHERE dbo.tbild.kBild NOT IN( SELECT kBild
                                      FROM AllUsed );

	--
	-- Umgekehrt auch loeschen: Verweise auf Bilder muessen ebenfalls geloescht werden
	--
	--
	-- tArtikelbildPlattform
	--
	DELETE Plattformsaetze FROM dbo.tArtikelbildPlattform AS Plattformsaetze
	LEFT JOIN dbo.tBild ON Plattformsaetze.kBild = dbo.tBild.kBild
	WHERE dbo.tBild.kBild IS NULL;

	--
	-- tEigenschaftWertPict
	--
	DELETE Plattformsaetze FROM dbo.tEigenschaftWertPict AS Plattformsaetze
	LEFT JOIN dbo.tBild ON Plattformsaetze.kBild = dbo.tBild.kBild
	WHERE dbo.tBild.kBild IS NULL;

	--
	-- tMerkmalBildPlattform
	--
	DELETE Plattformsaetze FROM dbo.tMerkmalBildPlattform AS Plattformsaetze
	LEFT JOIN dbo.tBild ON Plattformsaetze.kBild = dbo.tBild.kBild
	WHERE dbo.tBild.kBild IS NULL;

    --
    -- tMerkmalWertBildPlattform
    --
	DELETE Plattformsaetze FROM dbo.tMerkmalWertBildPlattform AS Plattformsaetze
	LEFT JOIN dbo.tBild ON Plattformsaetze.kBild = dbo.tBild.kBild
	WHERE dbo.tBild.kBild IS NULL;

    --
    -- tKategoriebildPlattform
    --
	DELETE Plattformsaetze FROM dbo.tKategoriebildPlattform AS Plattformsaetze
	LEFT JOIN dbo.tBild ON Plattformsaetze.kBild = dbo.tBild.kBild
	WHERE dbo.tBild.kBild IS NULL;

    --
    -- tHerstellerBildPlattform
    --
	DELETE Plattformsaetze FROM dbo.tHerstellerBildPlattform AS Plattformsaetze
	LEFT JOIN dbo.tBild ON Plattformsaetze.kBild = dbo.tBild.kBild
	WHERE dbo.tBild.kBild IS NULL;
END;
go

