CREATE VIEW [dbo].[vWMSBoxArtikel]
AS

    --
    -- Copyright (c) 2012-2017 by JTL Software GmbH
    -- Datum: $Date$
    -- Version: $Rev$
    -- Autor: PN
    --


SELECT     tArtikel.kArtikel, tLhm.kLHM, tLHM.cLHMID, tLHM.kWarenlagerPlatz, tBestellung.cBestellNr, tBestellung.kBestellung, tlhmstatus.kbestellung AS kBestellungDerLHM, 
                      tArtikel.cArtNr, CASE WHEN dbo.tWarenLagerOptionen.nArtikelBezeichnungAusArtikel = 1 THEN tArtikelBeschreibung.cName ELSE tbestellpos.cString END AS cName /* cArtName*/ ,
					  tArtikel.cBarcode/* cEanNr*/ , tLhm.kLHMStatus, isNull(sum(CASE tpicklisteposstatus.nStatus WHEN 30 THEN 0 ELSE ISNULL(tPicklistepos.fAnzahl,0.0) END), 0) fAnzahlGes, 
					  min(ISNULL(t2.fAnzahlInBox,0)) fAnzahlInBox, (SELECT  SUM(ISNULL(t3.nAnzahl,0)) - SUM(ISNULL(tGutschriftPos.nAnzahl,0))  AS nAnzahl 
				  FROM tbestellpos as t3
				  LEFT JOIN tGutschriftPos ON tGutschriftPos.kBestellPos = t3.kBestellPos
				  WHERE t3.tBestellung_kBestellung = tBestellung.kBestellung
				  AND t3.tArtikel_kartikel =  tArtikel.kArtikel
				  AND EXISTS (SELECT kBestellPos FROM tPicklistePos WHERE tPicklistePos.kBestellPos = t3.kBestellPos AND tPicklistePos.nStatus < 40)
				  GROUP BY t3.tBestellung_kBestellung,t3.tArtikel_kartikel  ) fAnzahlAuftrag,
                      isNull(tLhm.nSperre, 0) nSperre, tBestellung.dErstellt, tBestellung.dBezahlt, tLieferadresse.cStrasse, tLieferadresse.cOrt, tLieferadresse.cPLZ, tLieferadresse.cLand, 
                      tVersandart.cName cVersName, tversandart.cName cLogistikName, (' (' + tEinheitSprache.cName + ') ') cEinheit

FROM         tLHM JOIN dbo.tWarenLagerOptionen ON tWarenLagerOptionen.kWarenlager = tLHM.kWarenlager
				  JOIN twarenlagerplatz ON tlhm.kwarenlagerplatz = twarenlagerplatz.kwarenlagerplatz 
				  JOIN tLHMStatus ON tLHMStatus.kLHMStatus = tLhm.kLHMStatus
				  JOIN tBestellung ON tBestellung.kBestellung = tLHMStatus.kBestellung 
				  JOIN tBestellpos ON tBestellpos.tBestellung_kBestellung = tBestellung.kBestellung 
                  JOIN tPicklistepos ON tPicklistepos.kBestellpos = tBestellpos.kBestellpos AND twarenlagerplatz.kwarenlager = tPicklistePos.kWarenLager 
				  JOIN tpicklisteposstatus ON tpicklisteposstatus.kpicklisteposstatus = tpicklistepos.kpicklisteposstatus 
				  JOIN twarenlagereingang ON twarenlagereingang.kwarenlagereingang = tpicklistepos.kwarenlagereingang 
				  JOIN tArtikel ON tArtikel.kArtikel = tPicklistepos.kArtikel 
                       LEFT JOIN  (SELECT     SUM(ISNULL(tPicklistePos.fAnzahl,0.0)) fAnzahlInBox, tArtikel.kArtikel, twarenlagereingang.klhm, tbestellpos.tBestellung_kBestellung
                       FROM          tPicklistePos JOIN
                                               twarenlagereingang ON twarenlagereingang.kwarenlagereingang = tpicklistepos.kwarenlagereingang JOIN
                                               tPicklistePosStatus ON tPicklistePosStatus.kPicklistePosStatus = tPicklistePos.kPicklistePosStatus JOIN
                                               tbestellpos ON tpicklistepos.kbestellpos = tbestellpos.kbestellpos JOIN
                                               tArtikel ON tArtikel.kArtikel = tPicklistepos.kArtikel
                       WHERE      tPicklistePosStatus.nStatus >= 30 AND tPicklistePosStatus.nStatus <= 35 AND twarenlagereingang.fAnzahlAktuell > 0 AND 
                                               tpicklistepos.kwarenlagereingang = twarenlagereingang.kwarenlagereingang
                       GROUP BY tArtikel.kArtikel, twarenlagereingang.klhm, tbestellpos.tBestellung_kBestellung) AS t2 ON t2.kArtikel = tArtikel.kArtikel AND t2.klhm = tLHM.klhm AND 
                       t2.tBestellung_kBestellung = tLHMStatus.kBestellung 
                      JOIN tSpracheUsed ON tSpracheUsed.nStandard = 1
				  LEFT JOIN tArtikelBeschreibung ON tArtikelBeschreibung.kArtikel = tArtikel.kArtikel AND tArtikelBeschreibung.kSprache = tSpracheUsed.kSprache AND tArtikelBeschreibung.kPlattform = 1
				  LEFT JOIN tLieferadresse ON tLieferadresse.kLieferAdresse = tBestellung.kBestellung 
				  LEFT JOIN tversandart ON tversandart.kversandart = tBestellung.tVersandArt_kversandart      
				  LEFT JOIN tEinheitSprache ON tEinheitSprache.kEinheit = tArtikel.kVerkaufsEinheit AND tEinheitSprache.kSprache = tSpracheUsed.kSprache             
WHERE     twarenlagereingang.fAnzahlAktuell > 0
GROUP BY tArtikel.kArtikel, tLhm.kLhm, tLHM.cLHMID, tLHM.kWarenlagerPlatz, tBestellung.cBestellNr, tBestellung.kBestellung, tlhmstatus.kbestellung, tArtikel.cArtNr, 
                      tArtikel.cBarcode, tLhm.kLHMStatus, tLhm.nSperre, tBestellung.dErstellt, tBestellung.dBezahlt, tLieferadresse.cStrasse, tLieferadresse.cOrt, 
                      tLieferadresse.cPLZ, tLieferadresse.cLand, tVersandart.cName, tversandart.cName, tEinheitSprache.cName  , tBestellpos.cString, tArtikelBeschreibung.cName,dbo.tWarenLagerOptionen.nArtikelBezeichnungAusArtikel




UNION

SELECT     tArtikel.kArtikel, tLhm.kLHM, tLHM.cLHMID, tLHM.kWarenlagerPlatz, tBestellung.cBestellNr, tBestellung.kBestellung, tlhmstatus.kbestellung AS kBestellungDerLHM, 
                      tArtikel.cArtNr, 
					  CASE WHEN dbo.tWarenLagerOptionen.nArtikelBezeichnungAusArtikel = 1 THEN tArtikelBeschreibung.cName ELSE tbestellpos.cString END AS cName /*cArtName*/ , 
					  tArtikel.cBarcode/*cEanNr*/ , tLhm.kLHMStatus, 0 fAnzahlGes, sum(twarenlagereingang.fanzahl) fAnzahlInBox,
					  (SELECT  SUM(ISNULL(t3.nAnzahl,0)) - SUM(ISNULL(tGutschriftPos.nAnzahl,0))  AS nAnzahl 
				  FROM tbestellpos as t3
				  LEFT JOIN tGutschriftPos ON tGutschriftPos.kBestellPos = t3.kBestellPos
				  WHERE t3.tBestellung_kBestellung = tBestellung.kBestellung
				  AND t3.tArtikel_kartikel =  tArtikel.kArtikel
				  GROUP BY t3.tBestellung_kBestellung,t3.tArtikel_kartikel  ) fAnzahlAuftrag,
                      isNull(tLhm.nSperre, 0) nSperre, tBestellung.dErstellt, tBestellung.dBezahlt, tLieferadresse.cStrasse, tLieferadresse.cOrt, tLieferadresse.cPLZ, tLieferadresse.cLand, 
                      tVersandart.cName cVersName, tversandart.cName cLogistikName, (' (' + tEinheitSprache.cName  + ') ') cEinheit
FROM         tLHM 
			 JOIN dbo.tWarenLagerOptionen ON tWarenLagerOptionen.kWarenlager = tLHM.kWarenlager
			 JOIN tLHMStatus ON tLHMStatus.kLHMStatus = tLhm.kLHMStatus 
			 JOIN twarenlagereingang ON (twarenlagereingang.klhm = tlhm.klhm) 
			 LEFT JOIN tPicklistepos ON tPicklistepos.kwarenlagereingang = twarenlagereingang.kwarenlagereingang 
			 LEFT JOIN tbestellpos ON tpicklistepos.kbestellpos = tbestellpos.kbestellpos 
			 LEFT JOIN tBestellung ON tBestellung.kBestellung = tbestellpos.tBEstellung_kbestellung 
			 JOIN tArtikel ON tArtikel.kArtikel = twarenlagereingang.kArtikel 
			 JOIN tSpracheUsed ON tSpracheUsed.nStandard = 1 
			 LEFT JOIN tArtikelBeschreibung ON tArtikelBeschreibung.kArtikel = tArtikel.kArtikel AND tArtikelBeschreibung.kSprache = tSpracheUsed.kSprache AND tArtikelBeschreibung.kPlattform = 1
			 LEFT JOIN tLieferadresse ON tLieferadresse.kLieferAdresse = tBestellung.kBestellung 
			 LEFT JOIN tversandart ON tversandart.kversandart = tBestellung.tVersandArt_kversandart 
			 LEFT JOIN tEinheitSprache ON tEinheitSprache.kEinheit = tArtikel.kVerkaufsEinheit AND tEinheitSprache.kSprache = tSpracheUsed.kSprache                    
WHERE     (tbestellpos.tBestellung_kBestellung IS NULL OR tbestellpos.tBestellung_kBestellung <> tLHMStatus.kbestellung) 
AND twarenlagereingang.fAnzahlAktuell > 0
GROUP BY tArtikel.kArtikel, tLhm.kLhm, tLHM.cLHMID, tLHM.kWarenlagerPlatz, tBestellung.cBestellNr, tBestellung.kBestellung, tlhmstatus.kbestellung, tArtikel.cArtNr, 
                      tArtikel.cBarcode, tLhm.kLHMStatus, tLhm.nSperre, tBestellung.dErstellt, tBestellung.dBezahlt, tLieferadresse.cStrasse, tLieferadresse.cOrt, 
                      tLieferadresse.cPLZ, tLieferadresse.cLand, tVersandart.cName, tversandart.cName, tEinheitSprache.cName , tBestellpos.cString, tArtikelBeschreibung.cName,
					  dbo.tWarenLagerOptionen.nArtikelBezeichnungAusArtikel

UNION

SELECT   
  tArtikel.kArtikel, tLhm.kLHM, tLHM.cLHMID, tLHM.kWarenlagerPlatz, tBestellung.cBestellNr, tBestellung.kBestellung, tlhmstatus.kbestellung AS kBestellungDerLHM, 
                      tArtikel.cArtNr, CASE WHEN dbo.tWarenLagerOptionen.nArtikelBezeichnungAusArtikel = 1 THEN tArtikelBeschreibung.cName ELSE tbestellpos.cString END AS cName /*cArtName*/ , 
					  tArtikel.cBarcode/*cEanNr*/ , tLhm.kLHMStatus, 0 fAnzahlGes, 0 fAnzahlInBox,
                      (SELECT  SUM(ISNULL(t3.nAnzahl,0)) - SUM(ISNULL(tGutschriftPos.nAnzahl,0))  AS nAnzahl 
				  FROM tbestellpos as t3
				  LEFT JOIN tGutschriftPos ON tGutschriftPos.kBestellPos = t3.kBestellPos
				  WHERE t3.tBestellung_kBestellung = tBestellung.kBestellung
				  AND t3.tArtikel_kartikel =  tArtikel.kArtikel
				  AND NOT EXISTS (SELECT * FROM tPicklistePos WHERE tPicklistePos.kBestellPos = t3.kBestellPos AND tPicklistePos.nStatus < 40)
				  GROUP BY t3.tBestellung_kBestellung,t3.tArtikel_kartikel  ) fAnzahlAuftrag,
                      isNull(tLhm.nSperre, 0) nSperre, tBestellung.dErstellt, tBestellung.dBezahlt, tLieferadresse.cStrasse, tLieferadresse.cOrt, tLieferadresse.cPLZ, tLieferadresse.cLand, 
                      tVersandart.cName cVersName, tversandart.cName cLogistikName, (' (' + tEinheitSprache.cName  + ') ') cEinheit

FROM   tLHM
JOIN dbo.tWarenLagerOptionen ON tWarenLagerOptionen.kWarenlager = tLHM.kWarenlager
JOIN tLHMStatus ON tLHMStatus.kLHMStatus = tLhm.kLHMStatus 
JOIN tBestellung ON tBestellung.kBestellung = tLHMStatus.kBestellung
JOIN tbestellpos ON tbestellpos.tBestellung_kBestellung  = tBestellung.kBestellung
JOIN tArtikel ON tArtikel.kArtikel = tbestellpos.tArtikel_kArtikel 
JOIN tSpracheUsed ON tSpracheUsed.nStandard = 1 
LEFT JOIN tArtikelBeschreibung ON tArtikelBeschreibung.kArtikel = tArtikel.kArtikel AND tArtikelBeschreibung.kSprache = tSpracheUsed.kSprache AND tArtikelBeschreibung.kPlattform = 1 
LEFT JOIN tLieferadresse ON tLieferadresse.kLieferAdresse = tBestellung.kBestellung 
LEFT JOIN tversandart ON tversandart.kversandart = tBestellung.tVersandArt_kversandart 
LEFT JOIN tEinheitSprache ON tEinheitSprache.kEinheit = tArtikel.kVerkaufsEinheit AND tEinheitSprache.kSprache = tSpracheUsed.kSprache     
WHERE  tbestellpos.kBestellPos NOT IN (SELECT kBestellPos FROM tPicklistePos WHERE tPicklistePos.nStatus < 40)
AND tbestellpos.kBestellPos != tbestellpos.kBestellStueckliste
GROUP BY tArtikel.kArtikel, tLhm.kLhm, tLHM.cLHMID, tLHM.kWarenlagerPlatz, tBestellung.cBestellNr, tBestellung.kBestellung, tlhmstatus.kbestellung, tArtikel.cArtNr, 
                       tArtikel.cBarcode, tLhm.kLHMStatus, tLhm.nSperre, tBestellung.dErstellt, tBestellung.dBezahlt, tLieferadresse.cStrasse, tLieferadresse.cOrt, 
                      tLieferadresse.cPLZ, tLieferadresse.cLand, tVersandart.cName, tversandart.cName, tEinheitSprache.cName , tBestellpos.cString,
					  tArtikelBeschreibung.cName, dbo.tWarenLagerOptionen.nArtikelBezeichnungAusArtikel
go

