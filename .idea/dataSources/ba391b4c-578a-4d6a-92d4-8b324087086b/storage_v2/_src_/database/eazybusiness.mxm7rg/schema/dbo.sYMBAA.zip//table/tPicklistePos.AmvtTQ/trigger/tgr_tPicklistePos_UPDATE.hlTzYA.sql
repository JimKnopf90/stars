CREATE TRIGGER [dbo].[tgr_tPicklistePos_UPDATE]     
ON [dbo].[tPicklistePos]     
AFTER UPDATE  
AS     
--       
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP / ?? / FB / MS / MK
--   
SET NOCOUNT ON; 
BEGIN 
     --
     -- Wird nur ausgeführt wenn die fAnzahl sich ändert
     --
	IF((SELECT COUNT(*) FROM INSERTED 
	    FULL JOIN DELETED ON INSERTED.kPicklistePos = DELETED.kPicklistePos
	    WHERE INSERTED.fAnzahl != DELETED.fAnzahl OR INSERTED.nStatus = 40 OR INSERTED.kWarenLagerEingang != DELETED.kWarenLagerEingang) > 0)
    BEGIN
		SET CONTEXT_INFO 0x5094;
		UPDATE tWarenLagerEingang WITH(ROWLOCK) 
			SET fAnzahlReserviertPickpos =
				(
					SELECT ISNULL(SUM(ISNULL(fAnzahl,0.0)),0.0)   
					FROM tPicklistePos WITH(NOLOCK)
					WHERE ISNULL(tPicklistePos.nStatus,0) < 40  
						AND tPicklistePos.kWarenLagerEingang = tWarenLagerEingang.kWarenLagerEingang
				)   
		FROM tWarenLagerEingang WITH(ROWLOCK)
		JOIN 
		(
			SELECT kWarenLagerEingang
			FROM INSERTED
			GROUP BY kWarenLagerEingang
			UNION ALL
			SELECT kWarenLagerEingang
			FROM DELETED
			GROUP BY kWarenLagerEingang
		) AS BetroffeneDatensatze ON tWarenLagerEingang.kWarenLagerEingang = BetroffeneDatensatze.kWarenLagerEingang
		SET CONTEXT_INFO 0x000;
    END

END
go

