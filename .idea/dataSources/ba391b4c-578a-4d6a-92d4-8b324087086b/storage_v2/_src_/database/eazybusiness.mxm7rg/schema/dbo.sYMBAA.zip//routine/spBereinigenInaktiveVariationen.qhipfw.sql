--- 
--- spBereinigenInaktiveVariationen
---

CREATE PROCEDURE [dbo].[spBereinigenInaktiveVariationen]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: GJ
--
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN

    DELETE FROM dbo.teigenschaft
    WHERE teigenschaft.cAktiv = 'N';

END;
go

