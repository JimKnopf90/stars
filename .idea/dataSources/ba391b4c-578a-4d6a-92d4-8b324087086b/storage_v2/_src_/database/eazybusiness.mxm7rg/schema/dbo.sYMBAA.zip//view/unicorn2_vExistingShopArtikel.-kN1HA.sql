
    CREATE VIEW unicorn2_vExistingShopArtikel 
    AS
        SELECT 
			unicorn2_tExistingArtikel.kWawiId AS kWawiId, 
			tShop.kShop AS kShop
		FROM tShop WITH (NOLOCK) 
		JOIN 
			unicorn2_tExistingArtikel WITH (NOLOCK) 
			ON unicorn2_tExistingArtikel.kWawiId IN 
				(SELECT tArtikel.kArtikel FROM tArtikel WITH (NOLOCK))
		WHERE tShop.kShop NOT IN 
			(SELECT tArtikelShop.kShop FROM tArtikelShop WITH (NOLOCK) 
				WHERE tArtikelShop.kArtikel = unicorn2_tExistingArtikel.kWawiId)
    go

