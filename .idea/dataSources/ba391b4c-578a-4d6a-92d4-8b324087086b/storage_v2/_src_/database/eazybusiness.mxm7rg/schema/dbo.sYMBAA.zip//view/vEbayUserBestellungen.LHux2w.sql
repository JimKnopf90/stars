CREATE VIEW vEbayUserBestellungen 
AS 
SELECT EbayUserBestellungen.kBestellung, EbayUserBestellungen.kEbayuser FROM  
( 
	SELECT ebay_transaction.kBestellung, 
	CASE WHEN ebay_transaction.kAlien = 0 THEN ebay_item.kEbayuser ELSE ebay_alienitem.kEbayuser END AS kEbayuser 
	FROM ebay_transaction 
	LEFT JOIN ebay_item ON ebay_transaction.ItemID = ebay_item.ItemID 
	LEFT JOIN ebay_alienitem ON ebay_transaction.ItemID = ebay_alienitem.ItemID 
) AS EbayUserBestellungen 
WHERE EbayUserBestellungen.kEbayuser IS NOT NULL AND EbayUserBestellungen.kBestellung <> 0 
GROUP BY EbayUserBestellungen.kBestellung, EbayUserBestellungen.kEbayuser
go

