CREATE TRIGGER [dbo].[tgr_tMerkmalwertBildPlattform_DELETE]  
--     
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Author: Markus Hütz
--    
ON [dbo].[tMerkmalwertBildPlattform]  
AFTER DELETE
AS  
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
    IF((SELECT COUNT(1) FROM DELETED) = 0) 
    BEGIN
	   RETURN;
    END;

    --
    -- tQueue für jeden gelöschten Datensatz schreiben
    --
    INSERT INTO dbo.tQueue (kShop, kPlattform, cName, kWert, nAction, kOption1, kOption2)
    SELECT DELETED.kShop, DELETED.kPlattform, cName = 'tMerkmalwertBildPlattform', kWert = DELETED.kMerkmalwertBildPlattform, nAction = 2, kOption1 = DELETED.kMerkmalWert, kOption2 = 0
    FROM DELETED
	WHERE DELETED.kShop > 0;

    --
    -- tBild ggfs. aufräumen
    --
	DECLARE @Bilder AS TYPE_spBildLoeschenWennNichtVerwendet;

    INSERT INTO @Bilder (kBild)
	SELECT DELETED.kBild
	FROM DELETED
	GROUP BY DELETED.kBild;

    EXEC spBildLoeschenWennNichtVerwendet @Bilder;
END
go

