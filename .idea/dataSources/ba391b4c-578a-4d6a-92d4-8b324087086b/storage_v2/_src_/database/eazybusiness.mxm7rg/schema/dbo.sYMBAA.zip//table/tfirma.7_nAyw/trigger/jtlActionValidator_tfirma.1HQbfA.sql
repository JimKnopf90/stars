CREATE TRIGGER [dbo].[jtlActionValidator_tfirma]
	--
	-- Copyright (c) 2012-2017 by JTL Software GmbH
	-- Datum: $Date$
	-- Version: $Rev$
	-- Autor: MP
	--
	ON [dbo].[tfirma]
	AFTER DELETE
	AS
	SET NOCOUNT ON;
	SET ANSI_NULLS ON;
	SET ANSI_NULL_DFLT_ON ON;
	SET ANSI_PADDING ON;
	SET CONCAT_NULL_YIELDS_NULL ON;
	SET XACT_ABORT OFF;
	BEGIN

	   -- Die Einträge mit der Firma auch tBenutzerfirma löschen
	   DELETE eazybusiness.dbo.tbenutzerfirma 
	   FROM eazybusiness.dbo.tbenutzerfirma 
	   JOIN eazybusiness.dbo.tMandant ON eazybusiness.dbo.tMandant.kMandant = eazybusiness.dbo.tbenutzerfirma.kMandant
	   JOIN DELETED ON DELETED.kFirma = eazybusiness.dbo.tbenutzerfirma.kFirma 
	   WHERE eazybusiness.dbo.tMandant.cDB = DB_NAME();
	   
	   DELETE dbo.tshipperaccount
	   FROM dbo.tshipperaccount
	   JOIN DELETED ON DELETED.kFirma = dbo.tShipperAccount.kFirma;	 
	
	END;
go

