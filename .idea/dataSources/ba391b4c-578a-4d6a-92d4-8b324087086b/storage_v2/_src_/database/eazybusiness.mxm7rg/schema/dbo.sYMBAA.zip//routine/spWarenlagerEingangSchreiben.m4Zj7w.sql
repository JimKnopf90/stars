--- 
--- spWarenlagerEingangSchreiben
---

CREATE PROCEDURE [dbo].[spWarenlagerEingangSchreiben]
	-- Struktur des XML
	--
	-- <WarenEingang>
	--	<kArtikel INT NOT NULL>
	--	<kWarenLagerPlatz INT NOT NULL>
	--	<kLieferantenBestellungPos INT NULL>
	--	<kBenutzer INT NOT NULL>
	--	<fAnzahl DECIMAL(28,14) NOT NULL>
	--	<fEkEinzel DECIMAL(28,14) NULL>
	--	<cLieferscheinNr VARCHAR(255) NULL>
	--	<cChargenNr VARCHAR(255) NULL>
	--	<dMHD DATETIME NULL>
	--	<dGeliefertAm DATETIME NULL>
	--	<cKommentar VARCHAR(255) NULL>
	--	<kGutschriftPos INT NULL>
	--	<kLHM INT NULL>
	--	<kSessionId INT NULL>
	--	<kBuchungsart INT NOT NULL>
	--  <kBestellPosUmlagerung INT NULL>
	--  <kRMRetourePos  INT NULL>
	-- </WarenEingang>
	--
	@xWarenlagerEingaenge XML = NULL,

	@kArtikel INT = NULL,
	@kWarenLagerPlatz INT = NULL,
	@kLieferantenBestellungPos INT = NULL,
	@kBenutzer INT = NULL,
	@fAnzahl DECIMAL(28,14) = NULL,
	@fEkEinzel DECIMAL(28,14) = NULL,
	@cLieferscheinNr VARCHAR(255) = NULL,
	@cChargenNr VARCHAR(255) = NULL,
	@dMHD DATETIME = NULL,
	@dGeliefertAm DATETIME = NULL,
	@cKommentar VARCHAR(255) = NULL,
	@kGutschriftPos INT = NULL,
	@kLHM INT = NULL,
	@kSessionId INT = NULL,
	@kBuchungsart INT = NULL,
	@kBestellPosUmlagerung INT = NULL,
	@kRMRetourePos  INT = NULL,
	@nHistorieNichtSchreiben INT = 0,
	@kWarenlagerEingang INT = NULL OUTPUT
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
	SET CONTEXT_INFO 0x5091;
	IF(OBJECT_ID('tempdb..#WarenLagerEingaenge') IS NOT NULL)
	BEGIN
		DROP TABLE #WarenLagerEingaenge;
	END
	CREATE TABLE #WarenLagerEingaenge (
		kArtikel INT NOT NULL,
		kWarenLagerPlatz INT NOT NULL,
		kLieferantenBestellungPos INT NULL,
		kBenutzer INT NOT NULL,
		fAnzahl DECIMAL(28,14) NOT NULL,
		fEKEinzel DECIMAL(28,14) NOT NULL,
		cLieferscheinNr VARCHAR(255) NULL,
		cChargenNr VARCHAR(255) NULL,
		dMHD DATETIME NULL,
		dGeliefertAM DATETIME NULL,
		cKommentar VARCHAR(255) NULL,
		kGutschriftPos INT NULL,
		kLHM INT NULL,
		kSessionId INT NULL,
		kWarenLagerEingang_Ursprung INT NULL,
		kBuchungsart INT NOT NULL,
		kBestellPosUmlagerung INT NULL,
		kRMRetourePos INT NULL
	);
	-- Temporäre Tabelle füllen
	IF(@xWarenlagerEingaenge IS NOT NULL)
	BEGIN

	 

		INSERT INTO #WarenLagerEingaenge(
				kArtikel, kWarenLagerPlatz, kLieferantenBestellungPos, kBenutzer, fAnzahl, fEKEinzel, 
				cLieferscheinNr, cChargenNr, dMHD, dGeliefertAM, cKommentar, kGutschriftPos, kLHM, kSessionId, kBuchungsart,kBestellPosUmlagerung,kRMRetourePos)
			
			
			
			SELECT ParamValues.ID.value('kArtikel[1]','VARCHAR(20)'),
					ParamValues.ID.value('kWarenlagerPlatz[1]', 'VARCHAR(20)'),
					ParamValues.ID.value('kLieferantenBestellungPos[1]', 'VARCHAR(20)'),
					ParamValues.ID.value('kBenutzer[1]', 'VARCHAR(20)'),
					ParamValues.ID.value('fAnzahl[1]', 'VARCHAR(20)'),
					ParamValues.ID.value('fEKEinzel[1]', 'VARCHAR(20)'),
					ParamValues.ID.value('cLieferscheinNr[1]', 'VARCHAR(255)'),
					CASE WHEN ParamValues.ID.value('cChargenNr[1]', 'VARCHAR(255)') = ''
						THEN NULL
						ELSE ParamValues.ID.value('cChargenNr[1]', 'VARCHAR(255)')
					END,
					ParamValues.ID.value('dMHD[1]', 'datetime'),				
					ParamValues.ID.value('dGeliefertAM[1]', 'datetime'),
					ParamValues.ID.value('cKommentar[1]', 'VARCHAR(255)'),
					ParamValues.ID.value('kGutschriftPos[1]', 'VARCHAR(20)'),
					ParamValues.ID.value('kLHM[1]', 'VARCHAR(20)'),
					ParamValues.ID.value('kSessionId[1]', 'VARCHAR(20)'),
					ParamValues.ID.value('kBuchungsart[1]', 'VARCHAR(20)'),
					ParamValues.ID.value('kBestellPosUmlagerung[1]', 'VARCHAR(20)'),
					ParamValues.ID.value('kRMRetourePos[1]', 'VARCHAR(20)')
			FROM @xWarenlagerEingaenge.nodes('/WarenEingang') AS ParamValues(ID)
		
	END
	ELSE
	BEGIN
		INSERT INTO #WarenLagerEingaenge(
				kArtikel, kWarenLagerPlatz, kLieferantenBestellungPos, kBenutzer, fAnzahl, fEKEinzel, 
				cLieferscheinNr, cChargenNr, dMHD, dGeliefertAM, cKommentar, kGutschriftPos, kLHM, kSessionId, kBuchungsart,kBestellPosUmlagerung,kRMRetourePos)
			VALUES(@kArtikel, @kWarenLagerPlatz, @kLieferantenBestellungPos, @kBenutzer, @fAnzahl, @fEkEinzel,
				@cLieferscheinNr, CASE WHEN @cChargenNr ='' THEN NULL ELSE @cChargenNr END, @dMHD, @dGeliefertAm, @cKommentar, @kGutschriftPos, @kLHM, @kSessionId, @kBuchungsart,@kBestellPosUmlagerung,@kRMRetourePos);
	END
	IF(NOT EXISTS(SELECT * FROM #WarenLagerEingaenge))
	BEGIN
		--Überprüfung auf korrekte Parameter beim Aufruf.
		RAISERROR(N'Aufruf dbo.spWarenlagerEingangSchreiben ohne gültige Parameter', 15,1);
		RETURN;
	END
	--
	-- Parameter auf Korrektheit überprüfen
	--
	IF(EXISTS(SELECT #WarenLagerEingaenge.kArtikel 
				FROM #WarenLagerEingaenge 
				WHERE #WarenLagerEingaenge.kArtikel NOT IN (SELECT kArtikel FROM dbo.tArtikel)
					AND #WarenLagerEingaenge.kArtikel <> 0))
	BEGIN
		RAISERROR(N'Aufruf dbo.spWarenlagerEingangSchreiben mit falschem kArtikel', 15,1);
		RETURN;
	END;

	IF(EXISTS(SELECT #WarenLagerEingaenge.kWarenLagerPlatz
			  FROM #WarenLagerEingaenge
			  WHERE #WarenLagerEingaenge.kWarenLagerPlatz IN(SELECT kWarenLagerPlatz 
															   FROM dbo.tWarenLagerPlatz
															   JOIN dbo.tWarenlager ON dbo.tWarenlager.kWarenLager = dbo.tWarenLagerPlatz.kWarenLager
															   WHERE dbo.tWarenlager.nAktiv = 0 )))
	BEGIN
		RAISERROR(N'Aufruf dbo.spWarenlagerEingangSchreiben mit inaktiven Warenlager', 15,1);
		RETURN;
	END;

	IF(EXISTS(SELECT #WarenLagerEingaenge.kWarenLagerPlatz
				FROM #WarenLagerEingaenge
				WHERE #WarenLagerEingaenge.kWarenLagerPlatz NOT IN(SELECT kWarenLagerPlatz FROM dbo.tWarenLagerPlatz)))
	BEGIN
		RAISERROR(N'Aufruf dbo.spWarenlagerEingangSchreiben mit ungültigem WarenLagerPlatz', 15,1);
		RETURN;
	END;
	IF(EXISTS(SELECT #WarenLagerEingaenge.kArtikel
				FROM #WarenLagerEingaenge
				JOIN dbo.tArtikel ON dbo.tArtikel.kArtikel = #WarenLagerEingaenge.kArtikel
				WHERE dbo.tArtikel.nIstVater = 1 
					OR dbo.tArtikel.kStueckliste > 0
					OR dbo.tArtikel.cLagerAktiv <> 'Y'))
	BEGIN
		RAISERROR(N'Aufruf dbo.spWarenlagerEingangSchreiben mit StücklistenVater, VarkombiVater oder Artikel arbeitet nicht mit Lagerbestand.', 15,1);
		RETURN;
	END;
	--
	-- Fehlende WarenlagerplatzArtikel Kombinationen anlegen
	--
	INSERT INTO dbo.tWarenLagerPlatzArtikel(kWarenLagerPlatz, kArtikel)
		SELECT DISTINCT #WarenLagerEingaenge.kWarenLagerPlatz, #WarenLagerEingaenge.kArtikel 
			FROM #WarenLagerEingaenge 
			LEFT JOIN tWarenLagerPlatzArtikel ON #WarenLagerEingaenge.kArtikel = dbo.tWarenLagerPlatzArtikel.kArtikel
														AND #WarenLagerEingaenge.kWarenLagerPlatz = dbo.tWarenLagerPlatzArtikel.kWarenLagerPlatz
			WHERE tWarenLagerPlatzArtikel.kArtikel IS NULL;

	--
	-- Vorberechnung für Bestandsupdate
	--
	IF(OBJECT_ID('tempdb..#Lagerbestand') IS NOT NULL)
	BEGIN
		DROP TABLE #Lagerbestand;
	END
	CREATE TABLE #Lagerbestand(kArtikel INT, nNestingDeep INT, kWarenlager INT);
	-- Alle betroffenen Artikel sammeln
	INSERT INTO #Lagerbestand(kArtikel, nNestingDeep, kWarenlager)
		SELECT DISTINCT Result.kArtikel, Result.nNestingDeep, Result.kWarenlager
		FROM(
			SELECT #WarenLagerEingaenge.kArtikel, 0 AS nNestingDeep, dbo.tWarenlagerPlatz.kWarenLager
				FROM #WarenLagerEingaenge 
				JOIN dbo.tWarenlagerPlatz ON dbo.tWarenlagerPlatz.kWarenlagerPlatz = #WarenLagerEingaenge.kWarenLagerPlatz
			UNION ALL
			SELECT dbo.tArtikel.kArtikel, 2 AS nNestingDeep, dbo.tWarenlagerPlatz.kWarenLager
				FROM #WarenLagerEingaenge
				JOIN dbo.tStueckliste ON #WarenLagerEingaenge.kArtikel = dbo.tStueckliste.kArtikel
				JOIN dbo.tArtikel ON dbo.tArtikel.kStueckliste = dbo.tStueckliste.kStueckliste
				JOIN dbo.tWarenlagerPlatz ON dbo.tWarenlagerPlatz.kWarenlagerPlatz = #WarenLagerEingaenge.kWarenLagerPlatz
				GROUP BY dbo.tArtikel.kArtikel,dbo.tStueckliste.kStueckliste,dbo.tWarenlagerPlatz.kWarenLager
			UNION ALL
			SELECT Vater.kArtikel, 1 AS nNestingDeep, dbo.tWarenlagerPlatz.kWarenLager
				FROM #WarenLagerEingaenge 
				JOIN dbo.tArtikel ON #WarenLagerEingaenge.kArtikel = dbo.tArtikel.kArtikel
				JOIN dbo.tArtikel AS Vater ON Vater.kArtikel = dbo.tArtikel.kVaterArtikel
				JOIN dbo.tWarenlagerPlatz ON dbo.tWarenlagerPlatz.kWarenlagerPlatz = #WarenLagerEingaenge.kWarenLagerPlatz
				GROUP BY Vater.kArtikel, dbo.tWarenlagerPlatz.kWarenLager
		) AS Result
	BEGIN TRANSACTION

		DECLARE @DATE DATETIME = GETDATE();

		-- 
		-- WarenlagerEingang schreiben
		--
		INSERT INTO dbo.tWarenLagerEingang
		(
			kArtikel,
			kWarenLagerPlatz,
			kLieferantenBestellungPos,
			kBenutzer,
			fAnzahl,
			fEKEinzel,
			cLieferscheinNr,
			cChargenNr,
			dMHD,
			dErstellt,
			dGeliefertAM,
			cKommentar,
			kGutschriftPos,
			kWarenLagerAusgang,
			kLHM,
			fAnzahlAktuell,
			fAnzahlReserviertPickpos,
			kSessionID,
			kWarenLagerEingang_Ursprung,
			kBuchungsart,
			kBestellPosUmlagerung,
			kRMRetourePos
		)
		SELECT	#WarenLagerEingaenge.kArtikel, 
				#WarenLagerEingaenge.kWarenLagerPlatz, 
				#WarenLagerEingaenge.kLieferantenBestellungPos, 
				#WarenLagerEingaenge.kBenutzer,
				#WarenLagerEingaenge.fAnzahl, 
				ISNULL(#WarenLagerEingaenge.fEKEinzel, ISNULL(dbo.tArtikel.fEKNetto,0.0)),
				#WarenLagerEingaenge.cLieferscheinNr, 
				CASE WHEN #WarenLagerEingaenge.cChargenNr = '' THEN NULL ELSE #WarenLagerEingaenge.cChargenNr END AS cChargenNr, 
				#WarenLagerEingaenge.dMHD, 
				@DATE, 
				#WarenLagerEingaenge.dGeliefertAM, 
				#WarenLagerEingaenge.cKommentar, 
				#WarenLagerEingaenge.kGutschriftPos, 
				NULL, 
				#WarenLagerEingaenge.kLHM, 
				#WarenLagerEingaenge.fAnzahl, 
				0.0, 
				#WarenLagerEingaenge.kSessionId, 
				NULL,
				#WarenLagerEingaenge.kBuchungsart,
				#WarenLagerEingaenge.kBestellPosUmlagerung,
				#WarenLagerEingaenge.kRMRetourePos
			FROM #WarenLagerEingaenge 
			LEFT JOIN dbo.tArtikel ON #WarenLagerEingaenge.kArtikel = dbo.tArtikel.kArtikel
		SELECT @kWarenlagerEingang = SCOPE_IDENTITY();



		--
		-- Lagerbestände korrigieren
		--
		UPDATE dbo.tlagerbestand
			SET fLagerbestand = dbo.tlagerbestand.fLagerbestand + Result.Wareneingaenge,
				fLagerbestandEigen = dbo.tlagerbestand.fLagerbestandEigen + Result.Wareneingaenge,
				fVerfuegbar = ISNULL(dbo.tlagerbestand.fVerfuegbar,0.0) + Result.fVerfuegbar,
				fVerfuegbarGesperrt = ISNULL(dbo.tlagerbestand.fVerfuegbarGesperrt,0.0) + Result.fVerfuegbarGesperrt
			FROM dbo.tlagerbestand
			JOIN (
				SELECT  SUM(#WarenLagerEingaenge.fAnzahl) AS Wareneingaenge, 
						SUM(CASE WHEN dbo.tWarenLagerPlatz.nGesperrt = 0
								THEN #WarenlagerEingaenge.fAnzahl
								ELSE 0.0
							END) AS fVerfuegbar,
						SUM(CASE WHEN dbo.tWarenLagerPlatz.nGesperrt = 1
								THEN  #WarenlagerEingaenge.fAnzahl
								ELSE 0.0
							END) AS fVerfuegbarGesperrt,
						#WarenLagerEingaenge.kArtikel
			FROM #WarenLagerEingaenge 
			JOIN dbo.tWarenLagerPlatz ON dbo.tWarenLagerPlatz.kWarenLagerPlatz = #WarenLagerEingaenge.kWarenLagerPlatz
			GROUP BY #WarenLagerEingaenge.kArtikel
		) AS Result ON Result.kArtikel = dbo.tlagerbestand.kArtikel;
				
		UPDATE dbo.tlagerbestand
			SET dbo.tlagerbestand.fLagerbestand = dbo.vLagerbestandStueckliste.fLagerbestand,
				dbo.tlagerbestand.fLagerbestandEigen = dbo.vLagerbestandStueckliste.fLagerbestandEigen,
				dbo.tlagerbestand.fVerfuegbar = dbo.vLagerbestandStueckliste.fVerfuegbar,
				dbo.tlagerbestand.fVerfuegbarGesperrt = dbo.vLagerbestandStueckliste.fVerfuegbarGesperrt,
				dbo.tlagerbestand.fZulauf = dbo.vLagerbestandStueckliste.fZulauf,
				dbo.tlagerbestand.fAufEinkaufsliste = dbo.vLagerbestandStueckliste.fAufEinkaufsliste,
				dbo.tlagerbestand.dLieferdatum = dbo.vLagerbestandStueckliste.dLieferdatum,
				dbo.tlagerbestand.fInAuftraegen = ISNULL(Reserviert.fInAuftraegen, 0.0)
			FROM dbo.tlagerbestand
			JOIN #Lagerbestand AS U1 ON dbo.tlagerbestand.kArtikel = U1.kArtikel AND U1.nNestingDeep = 2
			JOIN dbo.vLagerbestandStueckliste ON dbo.vLagerbestandStueckliste.kArtikel = U1.kArtikel
			LEFT JOIN 
			(
				SELECT dbo.tReserviert.kArtikel AS kArtikel,
						SUM(dbo.tReserviert.fAnzahl) AS fInAuftraegen 
					FROM dbo.tReserviert 
					GROUP BY dbo.tReserviert.kArtikel
			) AS Reserviert ON dbo.tlagerbestand.kArtikel = Reserviert.kArtikel
		UPDATE dbo.tLagerbestand 
			SET fLagerbestand = Bestand.fLagerbestand,
				fLagerbestandEigen = Bestand.fLagerbestandEigen,
				fZulauf = Bestand.fZulauf,
				fVerfuegbar = Bestand.fVerfuegbar,
				fVerfuegbarGesperrt = Bestand.fVerfuegbarGesperrt
			FROM dbo.tLagerbestand
			JOIN #Lagerbestand ON #Lagerbestand.kArtikel = dbo.tLagerbestand.kArtikel
			JOIN dbo.tArtikel ON dbo.tArtikel.kArtikel = dbo.tlagerbestand.kArtikel
			JOIN (
				SELECT dbo.tArtikel.kVaterArtikel AS kArtikel,
						SUM(dbo.tlagerbestand.fLagerbestand) AS fLagerbestand,
						SUM(dbo.tlagerbestand.fLagerbestandEigen) AS fLagerbestandEigen,
						SUM(dbo.tlagerbestand.fZulauf) AS fZulauf,
						SUM(CASE WHEN ISNULL(dbo.tlagerbestand.fVerfuegbar, 0.0) > 0.0 
							THEN ISNULL(dbo.tlagerbestand.fVerfuegbar, 0.0) 
							ELSE 0.0 
						END) AS fVerfuegbar,
						SUM(dbo.tlagerbestand.fVerfuegbarGesperrt) AS fVerfuegbarGesperrt
					FROM dbo.tlagerbestand 
					JOIN dbo.tArtikel ON dbo.tArtikel.kArtikel = dbo.tlagerbestand.kArtikel AND dbo.tArtikel.kVaterArtikel > 0
					GROUP BY dbo.tArtikel.kVaterArtikel
			) AS Bestand ON Bestand.kArtikel = dbo.tArtikel.kArtikel
			WHERE #Lagerbestand.nNestingDeep = 1;
		IF(EXISTS(SELECT * 
					FROM #Lagerbestand
					JOIN dbo.tArtikel ON dbo.tArtikel.kArtikel = #Lagerbestand.kArtikel
					WHERE dbo.tArtikel.kVaterArtikel > 0))
		BEGIN
			DECLARE @type_spUpdateLagerbestand AS TYPE_spUpdateLagerbestand;
			INSERT INTO @type_spUpdateLagerbestand(kArtikel)
				SELECT dbo.tArtikel.kArtikel
					FROM #Lagerbestand
					JOIN dbo.tArtikel ON dbo.tArtikel.kArtikel = #Lagerbestand.kArtikel
					WHERE dbo.tArtikel.kVaterArtikel > 0;
			EXEC dbo.spUpdateLagerbestand @type_spUpdateLagerbestand;
		END
		--
		-- Reservierungen aktualisieren
		--
		DECLARE @xBestellpositionen XML;
		SET @xBestellpositionen = (
			SELECT DISTINCT kKey, kPlattform AS nPlattform
				FROM dbo.tReserviert 
				JOIN #Lagerbestand ON dbo.tReserviert.kArtikel = #Lagerbestand.kArtikel
				WHERE (dbo.tReserviert.fBestandReserviertEigen < dbo.tReserviert.fAnzahl)
			FOR XML PATH('Keys'), TYPE
		);
		IF(@xBestellpositionen IS NOT NULL)
		BEGIN
			EXEC dbo.spReservierungAktualisieren @xBestellpositionen;
		END

		UPDATE dbo.tlagerbestandProLagerLagerartikel
			SET fBestand = dbo.tlagerbestandProLagerLagerartikel.fBestand + Eingang.Summe
			FROM dbo.tlagerbestandProLagerLagerartikel
			JOIN(SELECT kWarenlager, kArtikel, SUM(#WarenLagerEingaenge.fAnzahl) AS Summe
					FROM #WarenLagerEingaenge 
					JOIN dbo.tWarenLagerPlatz ON dbo.tWarenLagerPlatz.kWarenLagerPlatz = #WarenLagerEingaenge.kWarenLagerPlatz
					GROUP BY tWarenlagerPlatz.kWarenLager, #WarenLagerEingaenge.kArtikel
				) AS Eingang ON tlagerbestandProLagerLagerartikel.kArtikel = Eingang.kArtikel 
				AND tlagerbestandProLagerLagerartikel.kWarenlager = Eingang.kWarenLager;
	
	IF(@nHistorieNichtSchreiben = 0)
	BEGIN
		INSERT INTO dbo.tArtikelHistory
		(
			kWarenLagerPlatz, kArtikel, fAnzahl, dGebucht, kBenutzer, kWarenEingang, kBestellPos, kGutschriftPos, fEKNetto, cKommentar, kBuchungsart, kLieferscheinPos,
		    fLagerBestandGesamt, fLagerBestand, kLieferantenBestellungPos, cLieferscheinNr, cChargenNr, dMHD, fVerfuegbar, fReserviert
		)
		SELECT WLE.kWarenLagerPlatz,
		       WLE.kArtikel,SUM(WLE.fAnzahl) ,
		       @DATE AS dErstellt,
		       WLE.kBenutzer,
			   0 AS kWarenLagerEingang,
			   0 AS  kBestellPos,
			   ISNULL(WLE.kGutschriftPos,0),
			   ISNULL(WLE.fEKEinzel,
			   ISNULL(dbo.tArtikel.fEKNetto,0.0)) AS fEKEinzel,
			   WLE.cKommentar,
			   WLE.kBuchungsart,
			   0 AS kLieferscheinPos,
			   MAX(tlagerbestand.fLagerbestandEigen) AS fLagerBestandGesamt, 
	   		   MAX(LagerBestandAufPlatz.fAnzahl) AS fLagerBestand, -- Nur Lagerbestand auf dem Platz wo der WE grade liegt
			   WLE.kLieferantenBestellungPos,
			   WLE.cLieferscheinNr,
			   WLE.cChargenNr,
			   WLE.dMHD,
			   ISNULL(dbo.tlagerbestand.fVerfuegbar,0),
			   ISNULL(dbo.tlagerbestand.fInAuftraegen,0)
		FROM #WarenLagerEingaenge AS WLE
		JOIN dbo.tlagerbestand ON dbo.tlagerbestand.kArtikel = WLE.kArtikel
		JOIN dbo.tArtikel ON dbo.tArtikel.kArtikel = WLE.kArtikel
		OUTER APPLY (SELECT	SUM(tWarenLagerEingang.fAnzahlAktuell) AS fAnzahl
					 FROM dbo.tWarenLagerEingang
					 WHERE dbo.tWarenLagerEingang.kArtikel = WLE.kArtikel
					 AND dbo.tWarenLagerEingang.kWarenLagerPlatz = WLE.kWarenlagerPlatz) AS LagerBestandAufPlatz
	 
		GROUP BY WLE.kWarenLagerPlatz,WLE.kArtikel,WLE.kBenutzer,ISNULL(WLE.kGutschriftPos,0),ISNULL(WLE.fEKEinzel, ISNULL(dbo.tArtikel.fEKNetto,0.0)),
				 WLE.cKommentar, WLE.kBuchungsart, WLE.kLieferantenBestellungPos,WLE.cLieferscheinNr,WLE.cChargenNr,WLE.dMHD,dbo.tlagerbestand.fInAuftraegen,
				 dbo.tlagerbestand.fVerfuegbar;
    END;
	COMMIT
	SET CONTEXT_INFO 0x000;
	RETURN
END;
go

