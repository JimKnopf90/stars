CREATE VIEW [dbo].[vArtikelZustandMitStandardZustand] AS
SELECT dbo.tArtikelZustand.kHauptartikel, dbo.tArtikelZustand.kZustandArtikel FROM tArtikelZustand
UNION
SELECT dbo.tArtikel.kArtikel AS kHauptartikel, dbo.tArtikel.kArtikel AS kZustandArtikel
FROM dbo.tArtikel WHERE dbo.tArtikel.kZustand = 1
go

