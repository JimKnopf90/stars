--- 
--- spVersandBoxenWarenlagerPruefen
---

CREATE PROCEDURE [dbo].[spVersandBoxenWarenlagerPruefen]
	@kBestellung INT
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--  
AS  
BEGIN	  
	SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;  
	DECLARE @kWarenLager INT;

	--
	-- Über alle nicht verpackten Boxen für die Bestellung
	--
  	DECLARE cur_kBestellung CURSOR LOCAL FAST_FORWARD FOR  
	SELECT dbo.tlhm.kWarenlager
	FROM dbo.tlhm WITH(NOLOCK)
	JOIN dbo.tlhmstatus WITH(NOLOCK) ON dbo.tlhmstatus.klhmstatus = dbo.tlhm.klhmstatus
	WHERE dbo.tlhmstatus.nstatus = 20
	AND dbo.tlhm.klhmtyp = 4
	AND dbo.tlhmstatus.kBestellung = @kBestellung;
	   
	OPEN cur_kBestellung    
	FETCH NEXT FROM cur_kBestellung INTO @kWarenLager;     	   
	WHILE @@FETCH_STATUS = 0    
	BEGIN    
		EXEC dbo.spVersandBoxBestellungPruefen @kWarenlager = @kWarenlager, @kBestellung = @kBestellung;
		FETCH NEXT FROM cur_kBestellung INTO @kWarenLager;
	END  	
	CLOSE cur_kBestellung;    
	DEALLOCATE cur_kBestellung;  
END
go

