--- 
--- spFulfillmentStockUpdate
---

---
--- spFulfillmentStockUpdate
---

CREATE PROCEDURE [dbo].[spFulfillmentStockUpdate] @xFulfillmentWarenlagerEingaenge XML
,                                                @kBenutzer INT
AS
BEGIN
	IF NOT @xFulfillmentWarenlagerEingaenge IS NULL
	BEGIN

		--
		-- Konstanten: Buchungsarten
		--
		DECLARE @BUCHUNGSART_WARENEINGANG INT = 10
		DECLARE @BUCHUNGSART_WARENAUSGANG INT = 20
		DECLARE @BUCHUNGSART_KORREKTURBUCHUNG INT = 30
		DECLARE @BUCHUNGSART_INVENTURBUCHUNG INT = 90
		DECLARE @BUCHUNGSART_ZUSTANDSAENDERUNG INT = 150
		DECLARE @BUCHUNGSART_SONSTIGE INT = 70
		--
		-- Parameter
		--
		DECLARE @kArtikel INT
		DECLARE @kBuchungsart INT
		DECLARE @nSeriennummern INT
		DECLARE @nCharge INT
		DECLARE @nMHD INT
		DECLARE @fAnzahl DECIMAL(28,14)
		DECLARE @fEKNetto DECIMAL(28,14)
		DECLARE @kWarenlager INT
		DECLARE @kWarenlagerPlatz INT
		DECLARE @cChargenNr VARCHAR(255)
		DECLARE @cSeriennummer VARCHAR(128)
		DECLARE @dMHD DATETIME
		DECLARE @cKommentar VARCHAR(255)
		DECLARE @kUmlagerung INT
		DECLARE @kStreckenlagerPlatz INT
		DECLARE @dGebucht datetime
		DECLARE @kBestellPosUmlagerung int
		DECLARE @cLieferscheinNr varchar(255)
		DECLARE @kLieferantenBestellung int
		DECLARE @cArtNr varchar(255)

		--
		-- Cursor über alle Buchungen
		--
		DECLARE buchungen_cursor CURSOR FAST_FORWARD LOCAL
		FOR
		SELECT Artikel.kArtikel                                 AS kArtikel
		,      Artikel.cArtNr                                   AS cArtNr
		,      CASE WHEN Artikel.cLagerArtikel = 'Y' THEN 1
		                                             ELSE 0 END AS nSeriennummern
		,      Artikel.nCharge                                  AS nCharge
		,      Artikel.nMHD                                     AS nMHD
		,	   Artikel.fEKNetto									AS fEKNetto
		,      Eingang.kBuchungsart                             AS kBuchungsart
		,      Eingang.fAnzahl                                  AS fAnzahl
		,      Eingang.cChargenNr                               AS cChargenNr
		,      Eingang.dMHD                                     AS dMHD
		,      Eingang.cKommentar                               AS cKommentar
		,      Eingang.cLieferscheinNr                          AS cLieferscheinNr
		,      Eingang.dGebucht                                 AS dGebucht
		,      Eingang.cSeriennummer                            AS cSeriennummer
		,      WarenlagerPlatz.kWarenLager                      AS kWarenlager
		,      WarenlagerPlatz.kWarenLagerPlatz                 AS kWarenlagerPlatz
		,      Umlagerung.kUmlagerung                           AS kUmlagerung
		,      Umlagerung.kWarenLagerPlatz                      AS kStreckenlagerPlatz
		,      Umlagerung.kBestellPos                           AS kBestellPosUmlagerung
		,      Lieferantenbestellung.kLieferantenBestellung     AS kLieferantenBestellung
		
		FROM      (
		SELECT ParamValues.ID.value('cJfpid[1]','VARCHAR(50)')                                                                                               AS cJfpid
		,      ParamValues.ID.value('cJfwid[1]','VARCHAR(50)')                                                                                               AS cJfwid
		,      ParamValues.ID.value('fAnzahl[1]', 'DECIMAL(28,14)')                                                                                          AS fAnzahl
		,      ParamValues.ID.value('cLieferscheinNr[1]', 'VARCHAR(255)')                                                                                    AS cLieferscheinNr
		,      CASE WHEN ParamValues.ID.value('cChargenNr[1]', 'VARCHAR(255)') = '' THEN NULL
		                                                                            ELSE ParamValues.ID.value('cChargenNr[1]', 'VARCHAR(255)') END           AS cChargenNr
		,      CASE WHEN ParamValues.ID.value('dMHD[1]', 'VARCHAR(50)') = '' THEN NULL
		                                                                     ELSE CONVERT ( datetime,ParamValues.ID.value('dMHD[1]', 'datetime') ,13) END AS dMHD
		,      CONVERT ( datetime,ParamValues.ID.value('dGebucht[1]','datetime'),13)                                                                         AS dGebucht
		,      LTRIM(RTRIM( ParamValues.ID.value('cKommentar[1]', 'VARCHAR(255)') + ' [Fulfillment]'))                                                       AS cKommentar
		,      ParamValues.ID.value('kBuchungsart[1]', 'VARCHAR(20)')                                                                                        AS kBuchungsart
		,      ParamValues.ID.value('cFremdbelegnummer[1]', 'VARCHAR(255)')                                                                                  AS cFremdbelegnummer
		,      ParamValues.ID.value('cSeriennummer[1]', 'VARCHAR(128)')																						 AS cSeriennummer
		FROM @xFulfillmentWarenlagerEingaenge.nodes('/FulfillmentStockHistory') AS ParamValues(ID)
		)                                    AS Eingang              
		JOIN      dbo.tArtikel               AS Artikel               ON Artikel.cJfpid = Eingang.cJfpid
		JOIN      dbo.tWarenLager            AS Warenlager            ON Warenlager.cJfwid = Eingang.cJfwid
		JOIN      dbo.tWarenLagerPlatz       AS WarenlagerPlatz       ON WarenlagerPlatz.kWarenLager = Warenlager.kWarenLager AND WarenlagerPlatz.nStatus = 0 AND WarenlagerPlatz.nGesperrt = 0
		LEFT JOIN dbo.tLieferantenBestellung AS LieferantenBestellung ON LieferantenBestellung.cEigeneBestellnummer = Eingang.cFremdbelegnummer
		LEFT JOIN (
			SELECT Umlagerung.kUmlagerung             
			,      Umlagerung.kLieferantenBestellung  
			,      BestellPos.kBestellPos             
			,      StreckenlagerPlatz.kWarenLagerPlatz
			,      BestellPos.tArtikel_kArtikel        AS kArtikel
			FROM      dbo.tUmlagerung      AS Umlagerung        
			LEFT JOIN dbo.tbestellpos      AS BestellPos         ON BestellPos.tBestellung_kBestellung = Umlagerung.kBestellung
			LEFT JOIN dbo.tWarenLagerPlatz AS StreckenlagerPlatz ON StreckenlagerPlatz.kWarenLager = Umlagerung.kStreckenLager AND StreckenlagerPlatz.kWarenLagerPlatzTyp = 0
			)                               
			AS                                  Umlagerung            ON Umlagerung.kLieferantenBestellung = Lieferantenbestellung.kLieferantenBestellung AND Umlagerung.kArtikel = Artikel.kArtikel


		OPEN buchungen_cursor
		FETCH NEXT FROM buchungen_cursor INTO @kArtikel, @cArtNr, @nSeriennummern, @nCharge, @nMHD,@fEKNetto, @kBuchungsart, @fAnzahl, @cChargenNr, @dMHD, @cKommentar, @cLieferscheinNr,@dGebucht,@cSeriennummer,@kWarenlager, @kWarenlagerPlatz, @kUmlagerung, @kStreckenlagerPlatz, @kBestellPosUmlagerung, @kLieferantenBestellung
		WHILE @@FETCH_STATUS = 0
		BEGIN


			DECLARE @kGutschriftPos int = 0
			DECLARE @kLHM int = 0
			DECLARE @kSessionId int = 0
			DECLARE @fEkEinzel decimal(28,14) = CAST(0 AS DECIMAL(28,14))
			DECLARE @kRMRetourePos int = 0
			DECLARE @nHistorieNichtSchreiben int = 0
			DECLARE @kWarenlagerEingang int = 0
			DECLARE @kLieferantenBestellungPos INT = 0


			--
			-- Wenn es eine Lieferantenbestellung für diesen WE gab, dann Lieferatenbestellungspos aktualisieren
			--
			IF (@kLieferantenBestellung > 0 AND @fAnzahl > 0)
			BEGIN
				DECLARE @xLieferantenbestellungPos AS XML

				SET @xLieferantenbestellungPos = (

				SELECT LieferantenBestellungPos.kLieferantenBestellungPos  AS kLieferantenbestellungPos
				,      LieferantenBestellungPos.kLieferantenbestellung    
				,      LieferantenBestellungPos.kArtikel                  
				,      LieferantenBestellungPos.cArtNr                    
				,      LieferantenBestellungPos.cLieferantenArtNr         
				,      LieferantenBestellungPos.cName                     
				,      LieferantenBestellungPos.cLieferantenBezeichnung   
				,      LieferantenBestellungPos.fUST                      
				,      LieferantenBestellungPos.fMenge                    
				,      LieferantenBestellungPos.cHinweis                  
				,      LieferantenBestellungPos.fEKNetto                  
				,      LieferantenBestellungPos.nPosTyp                   
				,      LieferantenBestellungPos.cNameLieferant            
				,      LieferantenBestellungPos.nLiefertage               
				,      @dGebucht                                           AS dLieferdatum
				,      LieferantenBestellungPos.nSort                     
				,      LieferantenBestellungPos.kLieferscheinPos          
				,      LieferantenBestellungPos.fMengeGeliefert + @fAnzahl AS fMengeGeliefert
				,      LieferantenBestellungPos.cVPEEinheit               
				,      LieferantenBestellungPos.nVPEMenge                 
				FROM tLieferantenBestellungPos AS LieferantenBestellungPos
				WHERE LieferantenBestellungPos.kLieferantenBestellung = @kLieferantenBestellung AND LieferantenBestellungPos.kArtikel = @kArtikel AND @fAnzahl <= (LieferantenBestellungPos.fMenge - LieferantenBestellungPos.fMengeGeliefert
					)

				FOR XML PATH('LieferantenbestellungPos'), TYPE
				)

				SELECT @kLieferantenBestellungPos = ParamValues.ID.value('kLieferantenbestellungPos[1]','INT')
				FROM @xLieferantenbestellungPos.nodes('/LieferantenbestellungPos') AS ParamValues(ID)

				EXECUTE Lieferantenbestellung.spLieferantenBestellungPosBearbeiten @xLieferantenbestellungPos

				EXECUTE Lieferantenbestellung.spLieferantenBestellungStatusUpdate @kLieferantenBestellung
			END

			--
			-- Wenn es eine Umlagerung war, dann aus Streckenlager ausbuchen
			--
			IF (@fAnzahl > 0 AND @kUmlagerung > 0)
			BEGIN
				EXECUTE [FulfillmentNetwork].spMinusbuchung @kArtikel
				,                                           @nSeriennummern
				,                                           @nCharge
				,                                           @nMHD
				,                                           @kStreckenlagerPlatz
				,                                           @fAnzahl
				,                                           @kBenutzer
				,                                           'Ausbuchen aus Streckenlager [Fulfillment]'
				,                                           @cChargenNr
				,                                           @dMHD
				,                                           @kUmlagerung
				,											@cSeriennummer
			END

			--
			-- Wenn es Plusbuchungen gab, dann WarenlagerEingänge schreiben
			--
			IF (@fAnzahl > 0 AND (@kBuchungsart = @BUCHUNGSART_WARENEINGANG OR @kBuchungsart = @BUCHUNGSART_KORREKTURBUCHUNG OR @kBuchungsart = @BUCHUNGSART_INVENTURBUCHUNG))
			BEGIN
				DECLARE @nSeriennummernErstellen INT = @nSeriennummern
				--
				-- Bei einer Umlagerung wurde die Seriennummer bereits wieder frei gegeben und dem richtigen Lager zugeordnet
				--
				IF(@kUmlagerung > 0)
				BEGIN
					SET @nSeriennummernErstellen = 0;
				END
				
				EXECUTE [FulfillmentNetwork].[spPlusbuchung] @kArtikel
				,                                            @nSeriennummernErstellen
				,                                            @nCharge
				,                                            @nMHD
				,                                            @kWarenLager
				,                                            @kWarenLagerPlatz
				,                                            @kLieferantenBestellungPos
				,                                            @kBenutzer
				,                                            @fAnzahl
				,                                            @cLieferscheinNr
				,                                            @cChargenNr
				,                                            @dMHD
				,											 @fEkEinzel
				,                                            @dGebucht
				,                                            @cKommentar
				,                                            @kBuchungsart
				,                                            0
				,											 @cSeriennummer
			END

			--
			-- Wenn es eine Minusbuchung war, dann aus JTL-Fulfillment Lager ausbuchen
			--
			IF (@fAnzahl < 0 AND (@kBuchungsart = @BUCHUNGSART_KORREKTURBUCHUNG  OR @kBuchungsart = @BUCHUNGSART_INVENTURBUCHUNG))
			BEGIN
				DECLARE @fAnzahlAuszubuchen DECIMAL(28,14) = @fAnzahl * -1;

				EXECUTE [FulfillmentNetwork].spMinusbuchung @kArtikel
				,                                           @nSeriennummern
				,                                           @nCharge
				,                                           @nMHD
				,                                           @kWarenlagerPlatz
				,                                           @fAnzahlAuszubuchen
				,                                           @kBenutzer
				,                                           @cKommentar
				,                                           @cChargenNr
				,                                           @dMHD
				,                                           NULL
				,											@cSeriennummer
			END




			FETCH NEXT FROM buchungen_cursor INTO @kArtikel, @cArtNr, @nSeriennummern, @nCharge, @nMHD, @fEKNetto, @kBuchungsart, @fAnzahl, @cChargenNr, @dMHD, @cKommentar, @cLieferscheinNr,@dGebucht,@cSeriennummer, @kWarenlager, @kWarenlagerPlatz, @kUmlagerung, @kStreckenlagerPlatz, @kBestellPosUmlagerung, @kLieferantenBestellung
		END

		CLOSE buchungen_cursor
		DEALLOCATE buchungen_cursor
	END
END
go

