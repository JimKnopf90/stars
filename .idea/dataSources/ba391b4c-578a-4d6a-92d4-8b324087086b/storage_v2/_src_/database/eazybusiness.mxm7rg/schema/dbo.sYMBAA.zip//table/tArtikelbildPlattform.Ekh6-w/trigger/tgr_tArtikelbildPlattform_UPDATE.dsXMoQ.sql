CREATE TRIGGER [dbo].[tgr_tArtikelbildPlattform_UPDATE]  
--     
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Author: Markus Hütz
--    
ON [dbo].[tArtikelbildPlattform]  
AFTER UPDATE
AS  
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
    --
    -- Überprüfen ob Trigger gefüllt aufgerufen wird
    --
    IF NOT EXISTS(SELECT INSERTED.kArtikelbildPlattform FROM INSERTED FULL JOIN DELETED ON INSERTED.kArtikelbildPlattform = DELETED.kArtikelbildPlattform)
    BEGIN
	   RETURN;
    END;

    --
    -- DIESER TRIGGER IST IM UPDATE FUER "Bildermigration099926" DEAKTIVERT!!!
    --

    --
    -- Wenn kBild nicht gleich ist es ein neues Bild und muss übertragen werden
    --
    UPDATE dbo.tArtikelbildPlattform
		SET dbo.tArtikelbildPlattform.nInet = 1
    FROM dbo.tArtikelbildPlattform
    JOIN DELETED ON DELETED.kArtikelbildPlattform = dbo.tArtikelbildPlattform.kArtikelbildPlattform
    JOIN INSERTED ON INSERTED.kArtikelbildPlattform = dbo.tArtikelbildPlattform.kArtikelbildPlattform
    WHERE (DELETED.kBild != INSERTED.kBild OR DELETED.nNr != INSERTED.nNr)
		AND (dbo.tArtikelbildPlattform.kPlattform IN (2, 30) OR dbo.tArtikelbildPlattform.kShop > 0);

	--
	-- nInet auf 0 setzen wenn Artikel gar nicht für Shop aktiv
	--
	UPDATE dbo.tArtikelbildPlattform
		SET dbo.tArtikelbildPlattform.nInet = 0
	FROM dbo.tArtikelbildPlattform
	JOIN INSERTED ON dbo.tArtikelbildPlattform.kArtikelbildPlattform = INSERTED.kArtikelbildPlattform
	LEFT JOIN dbo.tArtikelShop ON INSERTED.kArtikel = dbo.tArtikelShop.kArtikel
		AND INSERTED.kShop = dbo.tArtikelShop.kShop
	WHERE	dbo.tArtikelShop.kArtikel IS NULL
			AND INSERTED.nInet = 1;

	--
	-- Wenn sich die nNr tBild.cHash geaendert hat tQueue-Loescheintrag fuer Quell-nNr und Ziel-nNr anlegen
	--
	INSERT INTO dbo.tQueue (kShop, kPlattform, cName, kWert, nAction, kOption1, kOption2)
	SELECT kShop = DELETED.kShop, kPlattform = DELETED.kPlattform, cName = 'tArtikelbildPlattform', kWert = DELETED.kArtikelbildPlattform, nAction = 2, kOption1 = DELETED.kArtikel, kOption2 = DELETED.nNr
	FROM DELETED
	JOIN INSERTED ON INSERTED.kArtikelbildPlattform = DELETED.kArtikelbildPlattform
	JOIN dbo.tBild AS bildDeleted ON bildDeleted.kBild = DELETED.kBild
	JOIN dbo.tBild AS bildInserted ON bildInserted.kBild = INSERTED.kBild
	WHERE (DELETED.nNr != INSERTED.nNr OR bildDeleted.cHash != bildInserted.cHash) AND DELETED.kPlattform = 2 AND DELETED.nNr < 1000000000

    --
    -- tBild aufräumen
    --
    DECLARE @Bilder AS TYPE_spBildLoeschenWennNichtVerwendet;

    INSERT INTO @Bilder (kBild)
    SELECT DELETED.kBild
	   FROM DELETED
	   JOIN INSERTED ON DELETED.kBild = INSERTED.kBild
	   WHERE DELETED.kPlattform = 1
			AND DELETED.kBild <> INSERTED.kBild
	   GROUP BY DELETED.kBild;

    EXEC dbo.spBildLoeschenWennNichtVerwendet @Bilder;

    --
    -- eBay aktualisieren
    --
    DECLARE @Artikel AS XML;
    SET @Artikel =
    (
	   SELECT DELETED.kArtikel AS 'kArtikel'
	   FROM DELETED
	   WHERE DELETED.kPlattform = 30 AND DELETED.nNr <= 12
	   GROUP BY DELETED.kArtikel
	   FOR XML PATH('Artikel'), TYPE
    );
    EXEC dbo.spUpdateEbayBilderLaufendGeplant @Artikel;

    SET @Artikel =
    (
	   SELECT INSERTED.kArtikel AS 'kArtikel'
	   FROM INSERTED
	   WHERE INSERTED.kPlattform = 30 AND INSERTED.nNr <= 12
	   GROUP BY INSERTED.kArtikel
	   FOR XML PATH('Artikel'), TYPE
    );
    EXEC dbo.spUpdateEbayBilderLaufendGeplant @Artikel;

END
go

