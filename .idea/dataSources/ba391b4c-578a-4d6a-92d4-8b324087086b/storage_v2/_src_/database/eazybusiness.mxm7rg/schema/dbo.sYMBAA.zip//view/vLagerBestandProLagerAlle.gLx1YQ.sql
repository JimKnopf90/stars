CREATE VIEW [dbo].[vLagerBestandProLagerAlle] 
-- View veraltet! dbo.vLagerbestandProLager verwenden
AS   
	SELECT dbo.vLagerbestandProLager.kArtikel, dbo.vLagerbestandProLager.kWarenlager, dbo.vLagerbestandProLager.fBestand
	FROM dbo.vLagerbestandProLager
go

