CREATE VIEW [dbo].[vWareneingangsarchiv] AS
	SELECT
    dbo.tWarenLagerEingang.kWarenLagerEingang,
	dbo.tWarenLagerEingang.dErstellt,
	dbo.tArtikelBeschreibung.cName AS cArtikelname,
	dbo.tArtikel.cArtNr AS cArtikelnummer,
	dbo.tLieferantenBestellung.cEigeneBestellnummer,
	dbo.tLieferantenBestellung.cFremdbelegnummer,
	dbo.tLieferantenBestellung.cInternerKommentar AS cBestellkommentar,
	eazybusiness.dbo.tBenutzer.cName AS cBenutzername,
	dbo.tWarenLagerEingang.fAnzahl,
	dbo.tWarenLagerEingang.fEKEinzel,
	dbo.tLieferant.cFirma AS cLieferantFirma,
	dbo.tWarenLagerEingang.cLieferscheinNr,
	dbo.tWarenLagerEingang.cChargenNr,
	dbo.tWarenLagerEingang.dMHD,
	dbo.tWarenLagerEingang.dGeliefertAM AS dGeliefertAm
	FROM dbo.tWarenLagerEingang
	LEFT JOIN dbo.tArtikel ON tWarenLagerEingang.kArtikel = tArtikel.kArtikel
	LEFT JOIN dbo.tWarenLagerPlatz ON tWarenLagerPlatz.kWarenLagerPlatz = tWarenLagerEingang.kWarenLagerPlatz
	LEFT JOIN dbo.tLieferantenBestellungPos ON tLieferantenBestellungPos.kLieferantenBestellungPos = tWarenLagerEingang.kLieferantenBestellungPos
	LEFT JOIN dbo.tLieferantenBestellung ON tLieferantenBEstellung.kLieferantenBestellung = tLieferantenBestellungPos.kLieferantenBestellung
	LEFT JOIN eazybusiness.dbo.tBenutzer ON eazybusiness.dbo.tBenutzer.kBenutzer = tWarenLagerEingang.kBenutzer
	LEFT JOIN dbo.tLieferant ON tLieferantenBEstellung.kLieferant = tLieferant.kLieferant
	LEFT JOIN dbo.tLiefArtikel ON tLiefArtikel.tArtikel_kArtikel = tArtikel.kArtikel AND tLiefArtikel.tLieferant_kLieferant = tLieferant.kLieferant
	JOIN dbo.tSpracheUsed ON dbo.tSpracheUsed.nStandard = 1 
	JOIN dbo.tArtikelBeschreibung ON dbo.tArtikelBeschreibung.kArtikel = dbo.tArtikel.kArtikel 
									AND dbo.tArtikelBeschreibung.kSprache = dbo.tSpracheUsed.kSprache 
									AND dbo.tArtikelBeschreibung.kPlattform = 1
go

