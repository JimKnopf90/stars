CREATE TRIGGER [dbo].[jtlActionValidator_tEigenschaftKombiWert]  
--     
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Autor: MP
-- Version: $Rev$
--    
ON [dbo].[tEigenschaftKombiWert]  
AFTER DELETE 
AS  
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN 

	--
	--Überprüfen ob Trigger mit Inhalt aufgerufen wird
	--
	IF((SELECT COUNT(1) FROM DELETED) = 0)
	BEGIN
		RETURN;
	END;

	--
	-- ebay_item2kombi aufräumen
	--
	DELETE dbo.ebay_item2kombi
	FROM dbo.ebay_item2kombi
	JOIN DELETED ON DELETED.kEigenschaftKombi = dbo.ebay_item2kombi.kEigenschaftKombi;

	
END;
go

