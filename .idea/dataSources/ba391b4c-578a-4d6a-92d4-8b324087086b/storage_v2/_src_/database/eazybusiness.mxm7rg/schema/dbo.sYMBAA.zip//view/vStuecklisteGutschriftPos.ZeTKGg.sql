CREATE VIEW [dbo].[vStuecklisteGutschriftPos]
AS
SELECT dbo.tgutschriftpos.kGutschriftPos,
		CASE WHEN vStuecklisteInBestellung.tartikel_kArtikel IS NULL
			THEN dbo.tStueckliste.kArtikel
			ELSE vStuecklisteInBestellung.tartikel_kArtikel
		END AS kArtikel,
		CASE WHEN vStuecklisteInBestellung.tartikel_kArtikel IS NULL
			THEN dbo.tStueckliste.fAnzahl
			ELSE vStuecklisteInBestellung.MengeInBestellung
		END AS fAnzahl
	FROM dbo.tgutschriftpos
	JOIN dbo.tArtikel ON dbo.tgutschriftpos.tArtikel_kArtikel = dbo.tArtikel.kArtikel
	LEFT JOIN (
		SELECT	Vater.kBestellStueckliste AS Stueckliste,
			Kind.tArtikel_kArtikel, 
			(Kind.nAnzahl / Vater.nAnzahl) AS MengeInBestellung
		FROM dbo.tbestellpos AS Vater
		JOIN dbo.tbestellpos AS Kind ON Kind.kBestellStueckliste = Vater.kBestellPos
		WHERE Kind.kBestellPos <> Kind.kBestellStueckliste
	) AS vStuecklisteInBestellung ON dbo.tgutschriftpos.kBestellPos = vStuecklisteInBestellung.Stueckliste
	LEFT JOIN dbo.tStueckliste ON dbo.tStueckliste.kStueckliste = dbo.tArtikel.kStueckliste
	WHERE dbo.tArtikel.kStueckliste > 0 OR vStuecklisteInBestellung.tartikel_kArtikel IS NOT NULL
go

