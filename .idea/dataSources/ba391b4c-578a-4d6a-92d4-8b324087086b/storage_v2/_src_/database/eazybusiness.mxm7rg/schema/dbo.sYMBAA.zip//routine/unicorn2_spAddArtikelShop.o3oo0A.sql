
    CREATE PROCEDURE unicorn2_spAddArtikelShop @kShopId INT 
    AS
		DECLARE @kArtikel INT
	
        DECLARE @kShopIdLocal INT
		SET @kShopIdLocal = @kShopId
		
			DECLARE ins1 CURSOR READ_ONLY FAST_FORWARD FOR SELECT tArtikel.kArtikel FROM tArtikel WHERE tArtikel.kArtikel NOT IN (SELECT tArtikelShop.kArtikel FROM tArtikelShop WHERE tArtikelShop.kShop = @kShopIdLocal)
		
			OPEN ins1 
			FETCH NEXT FROM ins1 INTO @kArtikel
			
				WHILE (@@FETCH_STATUS = 0) 						
					BEGIN            
					INSERT INTO tArtikelShop (kArtikel, kShop, cInet, cDelInet, nAktion, nInBearbeitung) VALUES (@kArtikel, @kShopIdLocal, 'Y', 'N', 1, 0);                                                		
					FETCH NEXT FROM ins1 INTO @kArtikel		        
					END 				            
						
			CLOSE ins1
			DEALLOCATE ins1
    go

