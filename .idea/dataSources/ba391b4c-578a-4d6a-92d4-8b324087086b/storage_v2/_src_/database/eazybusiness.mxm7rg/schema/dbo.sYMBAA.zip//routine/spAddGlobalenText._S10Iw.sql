--- 
--- spAddGlobalenText
---

--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: GJ
--
CREATE PROCEDURE [dbo].[spAddGlobalenText]( @cWertVarChar AS NVARCHAR( MAX ) , 
                                  @cName AS VARCHAR( MAX ) , 
                                  @cGruppeName AS NVARCHAR( MAX ) , 
						    @cBeschreibung AS NVARCHAR( MAX ) , 
                                  @cSprache AS VARCHAR( 255 ))
AS
BEGIN
    DECLARE @kSprache AS INT;
    --
    -- Key für die übergebene Sprache suchen und falls nicht in der Wawi verwendet, abbrechen
    --
    SELECT @kSprache = tsu.kSprache
    FROM dbo.tSpracheUsed AS tsu
    WHERE tsu.cNameDeu = @cSprache;
    IF @kSprache IS NULL
        BEGIN
            RETURN SELECT @kSprache
        END;

    --
    -- Ist Attribut @cName in der Gruppe @cGruppeName für Bezugstyp GlobaleTexte (2) noch nicht vorhanden neu einfügen
    --
    DECLARE @kAttribut AS int
    SELECT @kAttribut = Attribut.kAttribut
    FROM
         dbo.tAttribut AS Attribut
         JOIN dbo.tAttributSprache AS AttributSprache ON AttributSprache.kAttribut = Attribut.kAttribut 
	    AND Attribut.cGruppeName = @cGruppeName 
	    AND AttributSprache.cName = @cName
	    AND Attribut.nBezugstyp = 2
	    AND Attribut.kFeldTyp = 3
	    AND AttributSprache.kSprache = 0

    IF(@kAttribut IS NULL) 
    BEGIN
	   DECLARE @nSortierung AS int
	   SET @nSortierung = 1
	   SELECT  @nSortierung = MAX(Attribut.nSortierung) FROM  dbo.tAttribut AS Attribut WHERE Attribut.cGruppeName = @cGruppeName

	   IF(NOT @nSortierung IS NULL)
	   BEGIN
		  SET  @nSortierung = @nSortierung + 1;
	   END
	   ELSE
	   BEGIN
		  SET  @nSortierung = 1;
	   END

	   INSERT INTO dbo.tAttribut
	   (
	       --kAttribut - this column value is auto-generated
	       dbo.tAttribut.nIstMehrsprachig,
	       dbo.tAttribut.nIstFreifeld,
	       dbo.tAttribut.nSortierung,
	       dbo.tAttribut.cBeschreibung,
	       dbo.tAttribut.nBezugstyp,
	       dbo.tAttribut.nAusgabeweg,
	       dbo.tAttribut.nIstStandard,
	       dbo.tAttribut.kFeldTyp,
	       dbo.tAttribut.cRegEx,
	       dbo.tAttribut.cGruppeName
	   )
	   VALUES
	   (
	       -- kAttribut - int
	       1, -- nIstMehrsprachig - tinyint
	       0, -- nIstFreifeld - tinyint
	       @nSortierung, -- nSortierung - int
	       @cBeschreibung, -- cBeschreibung - varchar
	       2, -- nBezugstyp - tinyint
	       0, -- nAusgabeweg - tinyint
	       0, -- nIstStandard - tinyint
	       3, -- kFeldTyp - int
	       N'', -- cRegEx - nvarchar
	      @cGruppeName -- cGruppeName - nvarchar
	   )
	   SET @kAttribut = @@IDENTITY;
	   IF((SELECT COUNT(*) FROM [tAttributSprache] AttributSprache WHERE AttributSprache.kAttribut = @kAttribut AND AttributSprache.kSprache = 0) = 0)
	   BEGIN
		  INSERT INTO dbo.tAttributSprache(
			 dbo.tAttributSprache.kAttribut,
			 dbo.tAttributSprache.kSprache,
			 dbo.tAttributSprache.cName			 
		  ) VALUES 
		  (
			 @kAttribut,
			 0,
			 @cName
		  )
	   END 

	   IF((SELECT count(*) FROM tWawiAttribut WHERE kAttribut = @kAttribut) = 0 )
	   BEGIN
		  INSERT INTO tWawiAttribut 
		  (  kAttribut )
		  VALUES
		  ( @kAttribut )

		  DECLARE @kWawiAttribut AS INT;
		  SET @kWawiAttribut = @@IDENTITY;
		  INSERT INTO dbo.tWawiAttributSprache
(
    dbo.tWawiAttributSprache.kWawiAttribut,
    dbo.tWawiAttributSprache.kSprache,
    dbo.tWawiAttributSprache.cWertVarchar,
    dbo.tWawiAttributSprache.nWertInt,
    dbo.tWawiAttributSprache.fWertDecimal,
    dbo.tWawiAttributSprache.dWertDateTime
)
VALUES
(
    @kWawiAttribut, -- kWawiAttribut - int
    @kSprache, -- kSprache - int
    @cWertVarchar, -- cWertVarchar - nvarchar
    0, -- nWertInt - int
    0, -- fWertDecimal - decimal
    NULL -- dWertDateTime - datetime
)
	   END
    END      
END
go

