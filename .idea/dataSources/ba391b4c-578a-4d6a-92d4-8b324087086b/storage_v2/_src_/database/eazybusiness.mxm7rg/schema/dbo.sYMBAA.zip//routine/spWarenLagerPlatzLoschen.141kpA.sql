--- 
--- spWarenLagerPlatzLöschen
---

CREATE PROCEDURE [dbo].[spWarenLagerPlatzLöschen]
@kWarenlagerPlatz INT
	
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Author PN    

-- Funktion: Mit dieser Procedur werden Warenlagereingänge geändert, ohne übers ausbuchen zu gehen.
-- Vor dem Aufruf der SP sollte bereits sichergestellt sein das sich keine Ware und keine Boxen auf dem Platz befinden.

AS

SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;

DECLARE @cDeletedNameText AS VARCHAR(50);

BEGIN

	     --
		-- WarenlagerArtikelPlatz entfernen
		--
		  DELETE dbo.tWarenlagerPlatzArtikel WITH(ROWLOCK)
	       FROM dbo.tWarenlagerPlatzArtikel WITH(ROWLOCK)
		  WHERE dbo.tWarenlagerPlatzArtikel.kWarenLagerPlatz = @kWarenlagerPlatz
		  AND dbo.tWarenlagerPlatzArtikel.cKommentar_1 IS NULL AND dbo.tWarenlagerPlatzArtikel.cKommentar_1 IS NULL;
						
		--
		-- LHMs auf den Platz löschen
		--	
		   DELETE tLHM WITH(ROWLOCK)
		   FROM tLHM WITH(ROWLOCK)
		   WHERE tLHM.kWarenLagerPlatz = @kWarenlagerPlatz;

		--
		-- Plätze in Lagerbereichen Löschen
		--
		   DELETE dbo.tWMSLagerBereichPlatz 
		   FROM dbo.tWMSLagerBereichPlatz	
		   WHERE dbo.tWMSLagerBereichPlatz.kWarenLagerPlatz = @kWarenlagerPlatz;


		   -- Falls bestand drauf war, wird der Status gelöscht gesetzt. Der Platz bleibt für die Historie bestehen.
		   IF EXISTS(SELECT * FROM dbo.tWarenLagerEingang  
				   WHERE kWarenLagerPlatz = @kWarenlagerPlatz)
		   BEGIN

		     SET @cDeletedNameText = ' (Geloescht am ';

		     SELECT cName FROM dbo.tWarenlagerPlatz
			WHERE kWarenLagerPlatz = @kWarenlagerPlatz;

		     UPDATE dbo.tWarenlagerPlatz
			SET nStatus = 4, cName =  LEFT(tWarenlagerPlatz.cName + @cDeletedNameText +LEFT(CONVERT(VARCHAR, GETDATE(), 120), 20) + ')',50)
			WHERE kWarenLagerPlatz = @kWarenlagerPlatz;


		   END;
		   ELSE -- Keine Artikel auf Platz gewesen ? Dann komplett löschen
		   BEGIN

		     DELETE FROM tWarenlagerPlatz
			WHERE kWarenLagerPlatz = @kWarenlagerPlatz;

		   END;

END;
go

