CREATE TRIGGER [dbo].[tgr_tPreisdetail_INSUPDEL]
ON [dbo].[tPreisDetail]
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
	UPDATE dbo.pf_amazon_angebot_ext
		SET fPreis = pf_amazon_angebot.fPrice
		FROM dbo.pf_amazon_angebot_ext
		JOIN dbo.tArtikel ON pf_amazon_angebot_ext.cSellerSKU = tArtikel.cArtNr
		JOIN dbo.tPreis ON tPreis.kArtikel = tArtikel.kArtikel
		JOIN dbo.pf_user ON pf_user.kKundengruppe = tPreis.kKundenGruppe
		JOIN dbo.pf_amazon_angebot ON pf_amazon_angebot_ext.kUser = pf_amazon_angebot.kUser
										AND pf_amazon_angebot_ext.cSellerSKU = pf_amazon_angebot.cSellerSKU
										AND pf_amazon_angebot_ext.nB2BPreiseSenden = 1
										AND pf_user.kUser = pf_amazon_angebot.kUser
		LEFT JOIN INSERTED ON INSERTED.kPreis = tPreis.kPreis
		LEFT JOIN DELETED ON DELETED.kPreis = tPreis.kPreis AND INSERTED.nAnzahlAb = DELETED.nAnzahlAb
		WHERE (DELETED.kPreis IS NULL AND INSERTED.kPreis IS NOT NULL)
			OR (DELETED.kPreis IS NOT NULL AND DELETED.fNettoPreis <> INSERTED.fNettoPreis AND INSERTED.kPreis IS NOT NULL)
			OR (DELETED.kPreis IS NOT NULL AND INSERTED.kPreis IS NULL);
END
go

