CREATE TRIGGER [dbo].[tgr_tBild_UPDATE]  
--     
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Author: Markus Hütz / Martin Kuen
--    
ON [dbo].[tBild]  
AFTER UPDATE 
AS  
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
    --
    -- Überprüfen ob Trigger gefüllt aufgerufen wird
    --
    IF NOT EXISTS(SELECT INSERTED.kBild FROM INSERTED FULL JOIN DELETED ON INSERTED.kBild = DELETED.kBild)
    BEGIN
	   RETURN;
    END;

    --
    -- Wenn Hash nicht gleich ist es ein neues Bild und muss übertragen werden
    --
    IF EXISTS(SELECT INSERTED.kBild FROM INSERTED JOIN DELETED ON INSERTED.kBild = DELETED.kBild WHERE DELETED.cHash != INSERTED.cHash)
    BEGIN
	   --
	   -- tArtikelbildPlattform
	   --
	   UPDATE dbo.tArtikelbildPlattform
	   SET dbo.tArtikelbildPlattform.nInet = 1
	   FROM dbo.tArtikelbildPlattform
	   JOIN DELETED ON DELETED.kBild = dbo.tArtikelbildPlattform.kBild
	   JOIN INSERTED ON INSERTED.kBild = dbo.tArtikelbildPlattform.kBild
	   WHERE (dbo.tArtikelbildPlattform.kBild = INSERTED.kBild AND DELETED.cHash != INSERTED.cHash)
			AND (dbo.tArtikelbildPlattform.kShop > 0 OR dbo.tArtikelbildPlattform.kPlattform IN (2, 30));

	   --
	   -- tKategoriebildPlattform
	   --
	   UPDATE dbo.tKategoriebildPlattform
	   SET dbo.tKategoriebildPlattform.nInet = 1
	   FROM dbo.tKategoriebildPlattform
	   JOIN DELETED ON DELETED.kBild = dbo.tKategoriebildPlattform.kBild
	   JOIN INSERTED ON INSERTED.kBild = dbo.tKategoriebildPlattform.kBild
	   WHERE (dbo.tKategoriebildPlattform.kBild = INSERTED.kBild AND DELETED.cHash != INSERTED.cHash)
			AND (dbo.tKategoriebildPlattform.kShop > 0 OR dbo.tKategoriebildPlattform.kPlattform IN (2, 30));

	   --
	   -- tEigenschaftWertPict
	   --
	   UPDATE dbo.tEigenschaftWertPict
	   SET dbo.tEigenschaftWertPict.nInet = 1
	   FROM dbo.tEigenschaftWertPict
	   JOIN DELETED ON DELETED.kBild = dbo.tEigenschaftWertPict.kBild
	   JOIN INSERTED ON INSERTED.kBild = dbo.tEigenschaftWertPict.kBild
	   WHERE (dbo.tEigenschaftWertPict.kBild = INSERTED.kBild AND DELETED.cHash != INSERTED.cHash)
			AND (dbo.tEigenschaftWertPict.kShop > 0 OR dbo.tEigenschaftWertPict.kPlattform IN (2, 30));

	   --
	   -- tMerkmalBild
	   --
	   UPDATE dbo.tMerkmalBildPlattform
	   SET dbo.tMerkmalBildPlattform.nInet = 1
	   FROM dbo.tMerkmalBildPlattform
	   JOIN DELETED ON DELETED.kBild = dbo.tMerkmalBildPlattform.kBild
	   JOIN INSERTED ON INSERTED.kBild = dbo.tMerkmalBildPlattform.kBild
	   WHERE (dbo.tMerkmalBildPlattform.kBild = INSERTED.kBild AND DELETED.cHash != INSERTED.cHash)
			AND (dbo.tMerkmalBildPlattform.kShop > 0 OR dbo.tMerkmalBildPlattform.kPlattform IN (2, 30));

	   --
	   -- tMerkmalWertBild
	   --
	   UPDATE dbo.tMerkmalwertBildPlattform
	   SET dbo.tMerkmalwertBildPlattform.nInet = 1
	   FROM dbo.tMerkmalwertBildPlattform
	   JOIN DELETED ON DELETED.kBild = dbo.tMerkmalwertBildPlattform.kBild
	   JOIN INSERTED ON INSERTED.kBild = dbo.tMerkmalwertBildPlattform.kBild
	   WHERE (dbo.tMerkmalwertBildPlattform.kBild = INSERTED.kBild AND DELETED.cHash != INSERTED.cHash)
			AND (dbo.tMerkmalwertBildPlattform.kShop > 0 OR dbo.tMerkmalwertBildPlattform.kPlattform IN (2, 30));

	   --
	   -- tHerstellerBild
	   --
	   UPDATE dbo.tHerstellerBildPlattform
	   SET dbo.tHerstellerBildPlattform.nInet = 1
	   FROM dbo.tHerstellerBildPlattform
	   JOIN DELETED ON DELETED.kBild = dbo.tHerstellerBildPlattform.kBild
	   JOIN INSERTED ON INSERTED.kBild = dbo.tHerstellerBildPlattform.kBild
	   WHERE (dbo.tHerstellerBildPlattform.kBild = INSERTED.kBild AND DELETED.cHash != INSERTED.cHash)
			AND (dbo.tHerstellerBildPlattform.kShop > 0 OR dbo.tHerstellerBildPlattform.kPlattform IN (2, 30));
    END
END
go

