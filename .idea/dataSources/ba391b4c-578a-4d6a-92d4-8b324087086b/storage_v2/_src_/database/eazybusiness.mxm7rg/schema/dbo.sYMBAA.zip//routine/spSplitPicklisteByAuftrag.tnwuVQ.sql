--- 
--- spSplitPicklisteByAuftrag
---

CREATE PROCEDURE [dbo].[spSplitPicklisteByAuftrag]
	--
	-- Copyright (c) 2012-2017 by JTL Software GmbH
	-- Datum: $Date$
	-- Version: $Rev$
	--
	@kBestellung INT, -- Die Bestellung die gesplittet wurde
	@kBestellungNewOrder INT, -- Die neue Bestellung die abgesplittet wurde
	@kWarenlager INT, -- Das Warenlager wo gesplittet wurde
	@kPickliste INT

AS

	DECLARE @nRet INT;
	DECLARE @kArtikelOld INT;
	DECLARE @nAnzahlOld DECIMAL(28,5);
	DECLARE @TempPickPos INT;
	DECLARE @TempMenge DECIMAL(28,5);
	DECLARE @kPickposAktuell  INT;
	DECLARE @fAnzahlPickposAktuell DECIMAL(28,5);
	DECLARE @kBestellPosOld INT;
	DECLARE @kBestellungNow INT;
	DECLARE @kNewPickPos INT;

BEGIN

	SET NOCOUNT ON;
	SET ANSI_NULLS ON;
	SET ANSI_NULL_DFLT_ON ON;
	SET ANSI_PADDING ON;
	SET CONCAT_NULL_YIELDS_NULL ON;
	SET XACT_ABORT OFF;
	SET @nRet = 0;

	--
	-- Die Pickpositionen zwischenspeichern. Zu diesen Zeitpunkt haben die geplittete und die alte Bestellung.
	--

	SELECT * INTO #TempPickpos  
	FROM dbo.tPicklistePos
	WHERE dbo.tpicklistePos.kBestellung = @kBestellung
	AND ((@kPickliste IS NOT NULL AND dbo.tPicklistePos.kPickliste = @kPickliste) OR (@kPickliste IS NULL AND dbo.tpicklistepos.nStatus >= 30 AND dbo.tpicklistepos.nStatus <= 35))

	--
	-- Über alle Bestellpositionen in beiden Bestellungen, gesplittet und alt. Zuerst suchen wir die BestellPos die von Split übrig blieben.
	--
	DECLARE cur_GetOldBestellPos CURSOR LOCAL FAST_FORWARD FOR   
	SELECT dbo.tBestellpos.kBestellPos, dbo.tBestellpos.tArtikel_kArtikel,dbo.tBestellpos.nAnzahl,dbo.tBestellpos.tBestellung_kBestellung
	FROM dbo.tBestellpos
	WHERE dbo.tBestellpos.tBestellung_kBestellung IN (@kBestellung,@kBestellungNewOrder)
	ORDER BY CASE WHEN dbo.tBestellpos.tBestellung_kBestellung = @kBestellung THEN 0 ELSE 1 END,
					   dbo.tBestellpos.tArtikel_kArtikel,
					   dbo.tBestellpos.nAnzahl desc;

	--
	-- Geht alle Bestellpositionen durch und sucht die entsprechenden Mengen in den Pickpositionen. Die gefunden Pickpos werden evtl. gesplittet und
	-- bekommen dan die richtige Bestellpos und Bestellung zugewiesen
	--
	OPEN cur_GetOldBestellPos    
	FETCH NEXT FROM cur_GetOldBestellPos INTO  @kBestellPosOld,@kArtikelOld,@nAnzahlOld,@kBestellungNow
	WHILE (@@FETCH_STATUS = 0  and @nRet >= 0)
	BEGIN

	WHILE (@nAnzahlOld > 0)
	BEGIN
	  
		SET @kPickposAktuell = 0;
		SET @TempPickPos = 0;
		SET @TempMenge = 0;
	  
		SELECT TOP 1 @kPickposAktuell = tPicklistePos.kPicklistePos, @fAnzahlPickposAktuell = tPicklistePos.fAnzahl
		FROM #TempPickpos tpicklistePos
		WHERE tPicklistePos.kArtikel = @kArtikelOld
		AND tPicklistePos.fAnzahl > 0
		ORDER BY CASE WHEN tpicklistePos.kWarenLager = @kWarenlager THEN 0 ELSE 1 END, --Zuert Lager der Pickpos wo gesplittet wurde
				 CASE WHEN fAnzahl = @nAnzahlOld THEN 0 ELSE 1 END,
				 CASE WHEN fAnzahl < @nAnzahlOld THEN 0 ELSE 1 END,
				 tPicklistePos.fAnzahl;

		IF(@kPickposAktuell = 0 OR (@TempPickPos = @kPickposAktuell AND @TempMenge = @fAnzahlPickposAktuell))
		BEGIN
			SET @nAnzahlOld =  0;
		END
		ELSE
		BEGIN
		 
			-- zum vermeiden von endlosschleifen
			SET @TempPickPos = @kPickposAktuell;
			SET @TempMenge = @fAnzahlPickposAktuell;
		 
			IF (@fAnzahlPickposAktuell <= @nAnzahlOld)
			BEGIN
		    
				SET @nAnzahlOld = @nAnzahlOld - @fAnzahlPickposAktuell;
		    
				UPDATE dbo.tPicklistePos 
				SET kBestellPos = @kBestellPosOld, kBestellung = @kBestellungNow
				WHERE dbo.tPicklistePos.kPicklistePos = @kPickposAktuell;
		      
				DELETE FROM #TempPickpos
				WHERE kPicklistePos = @kPickposAktuell;
		    
			END
		ELSE
			BEGIN
		    
				EXEC dbo.spPicklistePosSplitten
				@kPicklistePos = @kPickposAktuell,
				@nMenge = @nAnzahlOld,
				@kNewPicklistePos = @kNewPickPos OUTPUT,
				@nRet = @nRet OUTPUT;
   		
				UPDATE dbo.tPicklistePos
				SET kBestellPos = @kBestellPosOld,kBestellung = @kBestellungNow
				WHERE dbo.tPicklistePos.kPicklistePos = @kNewPickPos;
			 
				UPDATE #TempPickpos SET fAnzahl = fAnzahl - @nAnzahlOld
				WHERE kPicklistePos = @kPickposAktuell;
			
				SET @nAnzahlOld = 0;
		    
			END
		END
	END
    
	
	FETCH NEXT FROM cur_GetOldBestellPos INTO  @kBestellPosOld,@kArtikelOld,@nAnzahlOld,@kBestellungNow;
	END;
	CLOSE cur_GetOldBestellPos;
	DEALLOCATE cur_GetOldBestellPos;

END;
go

