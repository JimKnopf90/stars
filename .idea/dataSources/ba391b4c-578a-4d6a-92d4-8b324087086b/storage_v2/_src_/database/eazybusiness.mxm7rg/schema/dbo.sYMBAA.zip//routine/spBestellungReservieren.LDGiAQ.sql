--- 
--- spBestellungReservieren
---

CREATE PROCEDURE [dbo].[spBestellungReservieren] 
     @kPickliste INT
	,@kBestellung INT
	,@kWarenlager INT
	,@kPicklisteVorlage INT
	,@kBenutzer INT
	,@nAnzArtMin INT
	,@nAnzArtMax INT
	,@nGewMin DECIMAL(28, 14)
	,@nGewMax DECIMAL(28, 14)
	,@nTeilLiefErlaubt INT
	,@fTeilliefPreis DECIMAL(28, 14)
	,@nWEPlatzReservieren INT
	,@nLadenlokalReservieren INT
	,@nRetourPlatzReservieren INT
	,@nSortierung INT
	,@nDebug INT
	,@kSessionID INT
	,@nEinartikelpickliste INT
	,@kReineRollendeKommissionierung INT
	,@fMengeErfolgreichReserviert DECIMAL(28, 14) OUTPUT
AS
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
BEGIN
	SET NOCOUNT ON;
	SET ANSI_NULLS ON;
	SET ANSI_NULL_DFLT_ON ON;
	SET ANSI_PADDING ON;
	SET CONCAT_NULL_YIELDS_NULL ON;
	SET XACT_ABORT OFF;

	DECLARE @kBestellPos INT
		,@kArtikel INT
		,@nTeilmengeWurdeReserviert INT
		,@nTestWert INT
		,@nIsUnique INT
		,@nAnzahlPickpositionenDerPickliste INT
		,@kLetzteBestellpos INT
		,@cUnique VARCHAR(255);
	DECLARE @fAnzahl DECIMAL(28, 14)
		,@fWertDerReserviertenBestellung DECIMAL(28, 14);
	DECLARE @kWarenLagerEingang INT
		,@kPicklistePoS INT
		,@kWarenlagerPlatz INT
		,@nMengeFuerDiesePositionGefunden INT
		,@kStueckliste INT;
	DECLARE @fNochZuReservierendeMenge DECIMAL(28, 14)
		,@fWLEAnzahlAktuell DECIMAL(28, 14)
		,@fPickposReservierungsMenge DECIMAL(28, 14);
	DECLARE @cWarenlagerPlatz VARCHAR(255)
		,@cArtikel VARCHAR(255)
		,@cBestellung VARCHAR(255);
	DECLARE @cTeilbar CHAR(1);
	DECLARE @nMHDHandling INT;
	DECLARE @nMinMHD INT;
	DECLARE @cLagerBereiche VARCHAR(MAX);
	DECLARE @nIsEazyShippingAuftrag INT;
	DECLARE @nRechnungFertigCount INT;
	DECLARE @fGesammtGewicht DECIMAL(28, 14);
	DECLARE @fArtGewicht DECIMAL(28, 14);
	DECLARE @nUniquesFound INT;
	DECLARE @kLastStuecklisteTeilLief INT;
	DECLARE @nBoxenNurGanzeStuecklistenAufPL TINYINT;
	DECLARE @CreatedTransaction INT;
	DECLARE @IstPacktisch INT;
	DECLARE @LastStuecklistenPlatz INT;
	DECLARE @kLastStueckliste INT;
	DECLARE @nStuecklisteVonGleichenPlatz TINYINT = 0;
	DECLARE @nWAKeinAuftragSplittBeiTeillief TINYINT = 0;
	DECLARE @nVorkommissionieren TINYINT = 0;
	DECLARE @nOptionalMHDChargeAnywhere TINYINT = 0; -- Versteckte Option, wenn geschaltet kann man MHDs/Chargen auch reservieren wenn sie durcheinander liegen
	DECLARE @nNachschubPickenLast TINYINT = 0;
	DECLARE @nPlatzPrioBevorzugt TINYINT = 0;

	DECLARE @temporary_FehlerTable TABLE (
		kSessionId INT
		,cText VARCHAR(255)
		,nValue1 INT
		,nValue2 INT
		,nValue3 INT
		,cValue1 VARCHAR(255)
		,cValue2 VARCHAR(255)
		,cValue3 VARCHAR(255)
		,kkey1 INT
		,kkey2 INT
		);
	DECLARE @tempLagerbereiche TABLE (kWMSLagerbereich INT);
	DECLARE @tempToDeletePickPos TABLE (kPicklistePos INT);

	IF (object_id('tempdb..#NotFoundUniques') IS NOT NULL)
	BEGIN
		DROP TABLE #NotFoundUniques
	END;

	CREATE TABLE #NotFoundUniques (cUnique VARCHAR(255));


	IF (object_id('tempdb..#PickPosReserviert') IS NOT NULL)
	BEGIN
		DROP TABLE #PickPosReserviert
	END

	CREATE TABLE #PickPosReserviert (kWarenLagerEingang INT,fAnzahl DECIMAL(28, 14), kBestellPos INT, kArtikel INT, kWarenlagerPlatz INT, kStueckListe INT, cUnique VARCHAR(255) );

	SELECT @IstPacktisch = CASE 
			WHEN dbo.tWarenLager.nLagerplatzVerwaltung = 1
				THEN 0
			ELSE 1
			END
	FROM dbo.tWarenLager
	WHERE dbo.tWarenLager.kWarenLager = @kWarenlager;

	IF(EXISTS(SELECT * FROM dbo.tOptions WHERE dbo.tOptions.cKey='MHDChargeAlternativ' AND dbo.tOptions.cValue = '1'))
	BEGIN
	  SET @nOptionalMHDChargeAnywhere = 1;
	END;

	SET @fMengeErfolgreichReserviert = 0;
	SET @nTeilmengeWurdeReserviert = 0;
	SET @kLetzteBestellpos = 0;
	SET @fGesammtGewicht = 0;

	SELECT @cBestellung = cBEstellNr
	FROM tBEstellung WITH (NOLOCK)
	WHERE kBestellung = @kBestellung;

	SELECT @nIsEazyShippingAuftrag = nEinArtikelPickliste
		,@cLagerBereiche = CASE 
			WHEN LEN(cLagerbereiche) = 0
				THEN ''
			ELSE cLagerbereiche + ','
			END
		,@nMHDHandling = nMHDHandling
		,@nMinMHD = nMHDMinHaltbarkeit
		,@nGewMin = fGewichtVon
		,@nGewMax = fGewichtBis
		,@nStuecklisteVonGleichenPlatz = nStuecklisteVonGleichenPlatz
		,@nNachschubPickenLast = nNachschubPickenLast
		,@nPlatzPrioBevorzugt = nPlatzPrioBeruecksichtigen
		,@nBoxenNurGanzeStuecklistenAufPL = CASE 
			WHEN @kReineRollendeKommissionierung = 1
				THEN 1
			ELSE nBoxenNurGanzeStuecklistenAufPL
			END
	FROM dbo.tPicklisteVorlage WITH (NOLOCK)
	WHERE dbo.tPicklisteVorlage.kPicklistevorlage = @kPicklisteVorlage;


	IF(@kReineRollendeKommissionierung = 0 AND @nIsEazyShippingAuftrag = 0)
	BEGIN

		SELECT @nVorkommissionieren = ISNULL(dbo.tbestellungWMSFreigabe.nVorkommissionieren,0) 
		FROM dbo.tbestellungWMSFreigabe
		WHERE dbo.tbestellungWMSFreigabe.kBestellung = @kBestellung;
	
	END;
	

	SELECT @nWAKeinAuftragSplittBeiTeillief = nWAKeinAuftragSplittBeiTeillief 
	FROM dbo.tWarenLagerOptionen
	WHERE dbo.tWarenLagerOptionen.kWarenLager = @kWarenlager;


	IF (@nTeilLiefErlaubt = 1 AND 
	    @nIsEazyShippingAuftrag = 1 AND 
		@nWAKeinAuftragSplittBeiTeillief = 0)
	BEGIN
		SELECT @nRechnungFertigCount = COUNT(*)
		FROM dbo.trechnung WITH (NOLOCK)
		WHERE dbo.trechnung.tBestellung_kBestellung = @kBestellung
			AND (
				dbo.trechnung.dDruckdatum IS NOT NULL
				OR dbo.trechnung.dEmailversandt IS NOT NULL
				);


		IF (@nRechnungFertigCount > 0)
			SET @nTeilLiefErlaubt = 0;
	END;

	IF (LEN(@cLagerBereiche) > 0)
	BEGIN
		-- Füllt die Temporäre Tabelle, mit werten aus dem komma separierten varchar
		INSERT INTO @tempLagerbereiche (kWMSLagerbereich)
		SELECT CAST(part AS INT)
		FROM [dbo].[SplitString](@cLagerBereiche, ',');
	END;

	--In diesem Cursor werden alle offenen (Nicht ausgelieferte Menge - Menge in Pickpositionen) Positionen für die Bestellung geholt
	DECLARE cur_BestellPos CURSOR LOCAL FAST_FORWARD
	FOR
	SELECT dbo.tbestellpos.kBestellPos
		,dbo.tArtikel.kArtikel
		,Versand.vBestellPosLieferInfo.fAnzahlReserviertEigen AS fAnzahlOffeN
		,tArtikel.cTeilbar
		,ISNULL(dbo.tbestellpos.kBestellstueckliste, 0)
		,CASE ISNULL(dbo.tBestellpos.cUnique, '')
			WHEN ''
				THEN 0
			ELSE 1
			END
		,dbo.tArtikel.fArtGewicht
		,dbo.tbestellpos.cUnique
	FROM dbo.tbestellpos WITH (NOLOCK)
	JOIN Versand.vBestellPosLieferInfo WITH (NOLOCK) ON Versand.vBestellPosLieferInfo.kBestellpos = dbo.tBEstellpos.kBestellpos
	JOIN dbo.tArtikel WITH (NOLOCK) ON dbo.tArtikel.kArtikel = dbo.tbestellpos.tArtikel_kArtikel AND ISNULL(dbo.tArtikel.kStueckliste, 0) = 0
	LEFT JOIN dbo.tbestelleigenschaft WITH (NOLOCK) ON dbo.tbestelleigenschaft.kBestellPos = dbo.tbestellpos.kbestellpos
	WHERE dbo.tbestellpos.tBestellung_kBestellung = @kBestellung
		AND (Versand.vBestellPosLieferInfo.fAnzahlReserviertEigen > 0)
		AND dbo.tArtikel.cLagerAktiv = 'Y'
		AND dbo.tArtikel.cLagerVariation <> 'Y'
		AND (dbo.tbestellpos.kBestellstueckliste != dbo.tbestellpos.kBestellPos)
		AND dbo.tbestelleigenschaft.kbestelleigenschaft IS NULL
		AND (
			NOT EXISTS (
				SELECT *
				FROM dbo.teigenschaft WITH (NOLOCK)
				WHERE cAktiv = 'Y'
					AND kArtikel = dbo.tartikel.kArtikel
					AND dbo.tEigenschaft.cTyp NOT IN ('PFLICHT-FREIFELD','FREIFELD')
				)
			)
	ORDER BY dbo.tbestellpos.kBestellstueckliste,dbo.tbestellpos.kbestellpos;

	OPEN cur_BestellPos

	FETCH NEXT
	FROM cur_BestellPos
	INTO @kBestellPos
		,@kArtikel
		,@fAnzahl
		,@cTeilbar
		,@kStueckliste
		,@nIsUnique
		,@fArtGewicht
		,@cUnique

	--------------------------------------------------------------------------------------
	--Durchläuft jede Bestellpos für die noch Menge reserviert werden kann --START--------
	--------------------------------------------------------------------------------------
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @nUniquesFound = 0;

		SELECT @nUniquesFound = CASE WHEN @nVorkommissionieren = 1 THEN 0 ELSE count(*) END
		FROM #NotFoundUniques
		WHERE #NotFoundUniques.cUnique = @cUnique

		-- Position überspringen wenn die Konfi oder Stückliste bereits als nicht vorhanden markiert worden ist
		IF ( @kLetzteBestellpos <> @kBestellPos AND 
		     @nUniquesFound = 0
		   )
		BEGIN
			SET @kLetzteBestellpos = 0;
			SET @nMengeFuerDiesePositionGefunden = 0;

			-- Falls neue Stückliste, dann nicht den Platz bevorzugen
			IF(@kStueckliste = 0 OR @kStueckliste != @kLastStueckliste OR @nStuecklisteVonGleichenPlatz = 0 )
			BEGIN
				SET @LastStuecklistenPlatz = 0;
			END;

			SELECT @cArtikel = cArtNr
			FROM dbo.tartikel WITH (NOLOCK)
			WHERE kartikel = @kartikel;

			IF (@nDebug = 1)
			BEGIN
				INSERT INTO @temporary_FehlerTable (
					kSessionId
					,cText
					,kkey1
					,kkey2
					,cValue1
					,cValue2
					,nValue1
					)
				VALUES (
					@kSessionID
					,'Es wird Bestand des Artikels ' + @cArtikel + ' mit Menge ' + CAST(@fAnzahl AS VARCHAR) + ' gesucht.'
					,@kBestellung
					,@kArtikel
					,@cBestellung
					,@cArtikel
					,1
					);
			END;

			--Anfang der alten Unterprozedur Bestellpos Reservieren
			SET @nTeilmengeWurdeReserviert = 0;--Gibt an, ob die komplette Menge reserviert werden konnte  
			SET @fNochZuReservierendeMenge = @fAnzahl;

			--Cursor über die WarenlagerEingaenge die den Anforderungen entsprechen.
			DECLARE cur_WarenlagerEingang CURSOR LOCAL FAST_FORWARD
			FOR
			SELECT dbo.tWarenlagerEingang.kWarenLagerEingang
				,dbo.tWarenlagerEingang.fAnzahlAktuell - isnull(dbo.tWarenLagerEingang.fAnzahlReserviertPickpos, 0) - isnull(MAX(BereitsReserviert.fAnzahl),0)
				,dbo.tWarenlagerEingang.kWarenlagerPlatz
			FROM dbo.tWarenLagerEingang WITH (NOLOCK)
			LEFT JOIN (SELECT kWarenLagerEingang, SUM(fAnzahl) AS fAnzahl 
			           FROM #PickPosReserviert 
					   GROUP BY kWarenLagerEingang) AS  BereitsReserviert ON BereitsReserviert.kWarenLagerEingang = dbo.tWarenLagerEingang.kWarenLagerEingang
			JOIN dbo.tWarenLagerPlatz WITH (NOLOCK) ON dbo.tWarenLagerPlatz.kWarenLagerPlatz = dbo.tWarenLagerEingang.kWarenLagerPlatz
				AND dbo.tWarenLagerPlatz.nStatus = 0
				AND dbo.tWarenLagerPlatz.kWarenLager = @kWarenlager
				AND (
					LEN(@cLagerBereiche) = 0
					OR dbo.tWarenLagerPlatz.kWarenLagerPlatz IN (
						SELECT dbo.tWMSLagerBereichPlatz.kWarenLagerPlatz
						FROM dbo.tWMSLagerBereichPlatz WITH (NOLOCK)
						JOIN @tempLagerbereiche AS t1 ON t1.kWMSLagerbereich = dbo.tWMSLagerBereichPlatz.kWMSLagerbereich
						)
					)
				AND (
					dbo.tWarenlagerPlatz.kWarenlagerPlatzTyp IN (
						1
						,7
						)
					OR (
						@nWEPlatzReservieren = 1
						AND dbo.tWarenlagerPlatz.kWarenlagerPlatzTyp = 3
						)
					OR (
						@nLadenlokalReservieren = 1
						AND dbo.tWarenlagerPlatz.kWarenlagerPlatzTyp = 8
						)
					OR (
						@nRetourPlatzReservieren = 1
						AND dbo.tWarenlagerPlatz.kWarenlagerPlatzTyp = 11
						)
					OR (
						@IstPacktisch = 1
						AND dbo.tWarenlagerPlatz.kWarenlagerPlatzTyp = 0
						)
					)
			JOIN dbo.tArtikel WITH (NOLOCK) ON dbo.tWarenlagerEingang.kArtikel = dbo.tARtikel.kArtikel
				--Es dürfen keine Chargen/MHD-Pflichtigen Artikel reserviert werden, bei denen es zwei gleiche Chargen/MHDs
				--auf mehr als einem RegalPlatz, BLockplatz,WE gibt
				--Ansonsten kann der spätere verzögerte Pick inkl. Tauschen beim InDieBoxPacken bzw. Verpacken nicht eindeutig aufgelöst werden
				AND (
					(
						dbo.tArtikel.nCharge = 0
						AND dbo.tArtikel.nMHD = 0
					)
					OR (@nOptionalMHDChargeAnywhere = 1)
					OR (
						NOT EXISTS (
							SELECT dbo.twarenlagereingang.kartikel
							FROM dbo.twarenlagereingang WITH (NOLOCK)
							JOIN dbo.tWarenlagerPlatz WITH (NOLOCK) ON dbo.tWarenlagerPlatz.kwarenlagerplatz = dbo.twarenlagereingang.kwarenlagerplatz
							JOIN dbo.tartikel WITH (NOLOCK) ON dbo.twarenlagereingang.kartikel = dbo.tartikel.kartikel
							WHERE (
									dbo.tartikel.ncharge > 0
									OR dbo.tartikel.nmhd > 0
									)
								AND dbo.twarenlagereingang.fAnzahlAktuell > 0
								AND dbo.tWarenLagerEingang.kArtikel = @kArtikel
								AND dbo.twarenlagerplatz.kWarenlager = @kWarenlager
								AND dbo.tartikel.kartikel = dbo.tWarenLagerEingang.kArtikel
								AND (
									dbo.tWarenlagerPlatz.kWarenlagerPlatzTyp IN (
										1
										,7
										)
									OR (
										@nWEPlatzReservieren = 1
										AND dbo.tWarenlagerPlatz.kWarenlagerPlatzTyp = 3
										)
									OR (
										@nLadenlokalReservieren = 1
										AND dbo.tWarenlagerPlatz.kWarenlagerPlatzTyp = 8
										)
									OR (
										@nRetourPlatzReservieren = 1
										AND dbo.tWarenlagerPlatz.kWarenlagerPlatzTyp = 11
										)
									OR (
										@IstPacktisch = 1
										AND dbo.tWarenlagerPlatz.kWarenlagerPlatzTyp = 0
										)
									)
							GROUP BY dbo.twarenlagereingang.kartikel
								,dbo.twarenlagereingang.cchargennr
								,dbo.twarenlagereingang.dmhd
							HAVING COUNT(DISTINCT dbo.tWarenlagerPlatz.kwarenlagerplatz) > 1
							)
						)
					--es werden nur chargen und MHD-reine plätze betrachtet
					OR (
						tArtikel.nMHD = 1
						AND 2 > (
							SELECT COUNT(DISTINCT tWE2.dMHD)
							FROM dbo.tWarenlagerEingang tWE2 WITH (NOLOCK)
							WHERE kartikel = tartikel.kartikel
								AND tWE2.kwarenlagerplatz = dbo.tWarenLagerEingang.kWarenLagerPlatz
								AND tWE2.fanzahlaktuell > 0
							)
						)
					OR (
						tArtikel.nCharge = 1
						AND 2 > (
							SELECT COUNT(DISTINCT tWE3.cChargenNr)
							FROM dbo.tWarenlagerEingang tWE3 WITH (NOLOCK)
							WHERE tWE3.kartikel = tartikel.kartikel
								AND tWE3.kwarenlagerplatz = dbo.tWarenLagerEingang.kWarenLagerPlatz
								AND tWE3.fanzahlaktuell > 0
							)
						)
					)
			LEFT JOIN (
				SELECT COUNT(dbo.tWarenlagerArtikelOptionen.kArtikel) nCount
					,dbo.tWarenlagerArtikelOptionen.kArtikel
					,CASE 
						WHEN dbo.tWMSLagerBereichPlatz.kWarenLagerPlatz > 0
							THEN dbo.tWMSLagerBereichPlatz.kWarenLagerPlatz
						ELSE dbo.tWarenlagerArtikelOptionen.kWarenLagerPlatz
						END kWarenLagerPlatz
				FROM dbo.tWarenlagerArtikelOptionen WITH (NOLOCK)
				LEFT JOIN dbo.tWMSLagerBereichPlatz WITH (NOLOCK) ON dbo.tWMSLagerBereichPlatz.kWMSLagerBereich = dbo.tWarenlagerArtikelOptionen.kWMSLagerBereich
				WHERE (
						dbo.tWMSLagerBereichPlatz.kWarenLagerPlatz > 0
						OR dbo.tWarenlagerArtikelOptionen.kWarenLagerPlatz > 0
						)
				GROUP BY dbo.tWarenlagerArtikelOptionen.kArtikel
					,dbo.tWMSLagerBereichPlatz.kWarenLagerPlatz
					,dbo.tWarenlagerArtikelOptionen.kWarenLagerPlatz
				) AS t2 ON t2.kArtikel = dbo.tWarenlagerEingang.kArtikel
				AND t2.kWarenLagerPlatz = dbo.tWarenlagerEingang.kWarenLagerPlatz
			WHERE dbo.tWarenLagerEingang.kArtikel = @kArtikel
				AND (
					tArtikel.nMHD = 0
					OR datediff(d, 0, dbo.tWarenlagerEingang.dMHD) >= datediff(d, 0, (GETDATE() + @nMinMHD)) -- Es darf kein abgelaufenes MHD reserviert werden, mindest MHD kann optional angegeben werden 
					OR ISNULL(@nMHDHandling, 0) > 0 -- Erlaubt das einlagern abgelaufener MHDs
					)
			GROUP BY dbo.tWarenlagerEingang.kWarenLagerEingang
				,dbo.tartikel.nmhd
				,dbo.tWarenLagerEingang.dErstellt
				,dbo.tWarenLagerPlatz.nPrio
				,dbo.tWarenLagerPlatz.nsort
				,dbo.tWarenLagerPlatz.cName
				,dbo.twarenlagereingang.dmhd
				,dbo.tWarenlagerEingang.fAnzahlAktuell
				,dbo.tWarenlagerEingang.kWarenlagerPlatz
				,dbo.tWarenLagerEingang.fAnzahlReserviertPickpos
				,t2.nCount
			HAVING dbo.tWarenlagerEingang.fAnzahlAktuell - ISNULL(dbo.tWarenLagerEingang.fAnzahlReserviertPickpos, 0) - ISNULL(MAX(BereitsReserviert.fAnzahl),0) > 0
			ORDER BY
			    -- Stücklisten bevorzugt vom gleichen Platz reservieren (Optional)
				CASE WHEN @LastStuecklistenPlatz = dbo.twarenlagereingang.kWarenLagerPlatz THEN 0 ELSE 1 END,

				-- Wenn der Platz auf dem der Warenlagereingang liegt, im Nachschubbereich ist und Option geschaltet, dann als letztes picken (Optional)
				CASE WHEN @nNachschubPickenLast = 1
					 THEN CASE WHEN EXISTS (SELECT *
											FROM dbo.tWMSLagerBereichPlatz AS tWMSLagerBereichPlatzOrder
											JOIN dbo.tWMSLagerBereich ON dbo.tWMSLagerBereich.kWMSLagerBereich = tWMSLagerBereichPlatzOrder.kWMSLagerBereich
											WHERE tWMSLagerBereichPlatzOrder.kWarenLagerPlatz = dbo.tWarenLagerEingang.kWarenLagerPlatz
											AND dbo.tWMSLagerBereich.nTyp = 2) --Nachschub
							   THEN 1
							   ELSE 0
							   END
					 ELSE 0
					 END,

				-- Falls Vorgabeplatz gefunden (t2.nCount > 0) und entsprechende Option geschaltet, diesen bevorzugen
				CASE 
					WHEN @nSortierung = 5
						OR @nSortierung = 6
						OR @nSortierung = 7
						OR @nSortierung = 8
						THEN CASE 
								WHEN t2.nCount > 0
									THEN 0
								ELSE 1
								END
					ELSE NULL
					END
				,
				--MHD-Artikel werden immer nach MHD ausgelagert
				CASE 
					WHEN dbo.tartikel.nmhd = 1
						AND (
							@nMHDHandling = 0
							OR @nMHDHandling = 1
							)
						THEN dbo.twarenlagereingang.dmhd
					ELSE 0
					END
				,CASE 
					WHEN dbo.tartikel.nmhd = 1
						AND @nMHDHandling = 2
						THEN dbo.twarenlagereingang.dmhd
					ELSE NULL
					END DESC
				,CASE WHEN  @nSortierung IN (0,1,2,3,4,5,6,7,8) AND @nPlatzPrioBevorzugt = 1  
						    THEN dbo.tWarenLagerPlatz.nPrio 
					  ELSE NULL
					  END DESC
				,CASE 
					WHEN @nSortierung IN(0,9,10,11,12)
						THEN dbo.tWarenLagerEingang.dErstellt
					ELSE NULL
					END
				,CASE 
					WHEN @nSortierung IN(9,10,11,12) AND @nPlatzPrioBevorzugt = 1  
						 THEN dbo.tWarenLagerPlatz.nPrio 
					  ELSE NULL
					END DESC
				,CASE 
					WHEN @nSortierung IN(1,5,9) 
						THEN dbo.tWarenLagerPlatz.nsort
					ELSE NULL
					END
				,CASE 
					WHEN @nSortierung IN(2,6,10)
						THEN dbo.tWarenLagerPlatz.cName
					ELSE NULL
					END
				,CASE 
					WHEN @nSortierung IN (3,7,11)
						THEN dbo.tWarenLagerPlatz.nsort
					ELSE NULL
					END DESC
				,CASE 
					WHEN @nSortierung IN (4,8,12)
					    THEN dbo.tWarenLagerPlatz.cName
					ELSE NULL
					END DESC


			--Durchläuft die WarenlagerEingaenge solange, bis genügend Menge reserviert wurde oder bis alle durchsucht wurden
			OPEN cur_WarenlagerEingang

			FETCH NEXT
			FROM cur_WarenlagerEingang
			INTO @kWarenlagerEingang
				,@fWLEAnzahlAktuell
				,@kWarenlagerPlatz;


			-------------------------------------------------------------------------------
			----------- SUCHE WARENLAGEREINGAENGE START------------------------------------
			-------------------------------------------------------------------------------
			WHILE @@FETCH_STATUS = 0
			BEGIN
				SET @nMengeFuerDiesePositionGefunden = 1;

				IF(@kStueckliste > 0  AND @nStuecklisteVonGleichenPlatz = 1 )
				BEGIN
					SET @LastStuecklistenPlatz = @kWarenlagerPlatz;
				END;
				
				
				
				IF (@fNochZuReservierendeMenge > @fWLEAnzahlAktuell)
				BEGIN
					SET @fPickposReservierungsMenge = @fWLEAnzahlAktuell;
					SET @fNochZuReservierendeMenge = @fNochZuReservierendeMenge - @fWLEAnzahlAktuell;
				END
				ELSE
				BEGIN
					SET @fPickposReservierungsMenge = @fNochZuReservierendeMenge;
					SET @fNochZuReservierendeMenge = 0;
				END;

				--Pickposition erstellen
				INSERT INTO #PickPosReserviert
				(        kWarenLagerEingang
						,fAnzahl
						,kBestellPos
						,kArtikel
						,kWarenlagerPlatz
						,kStueckListe
						,cUnique
				)
				VALUES (
					 @kWarenlagerEingang
					,@fPickposReservierungsMenge
					,@kBestellPos
					,@kArtikel
					,@kWarenlagerPlatz
					,@kStueckliste
					,@cUnique
					);

				IF (@nDebug = 1)
				BEGIN
					SELECT @cWarenlagerPlatz = cName
					FROM dbo.twarenlagerplatz WITH (NOLOCK)
					WHERE kwarenlagerplatz = @kWarenlagerPlatz;

					INSERT INTO @temporary_FehlerTable (
						kSessionId
						,cText
						,kkey1
						,kkey2
						,cValue1
						,cValue2
						,nValue1
						)
					VALUES (
						@kSessionID
						,'Es wurde die Menge ' + CAST(@fPickposReservierungsMenge AS VARCHAR) + ' vom Platz ' + @cWarenlagerPlatz + ' reserviert.'
						,@kBestellung
						,@kArtikel
						,@cBestellung
						,@cArtikel
						,1
						);
				END;

				IF (@fTeilliefPreis > 0) --Nur wenn die Einschränkung auf den Preis eingestellt wurde, brauch der Preis berechnet werden  
				BEGIN
					SELECT @fWertDerReserviertenBestellung = (@fWertDerReserviertenBestellung + fVKNetto + ((fVKNetto / 100) * dbo.tSteuercache.fSteuersatz))
					FROM dbo.tArtikel WITH (NOLOCK)
					LEFT JOIN dbo.tSteuercache WITH (NOLOCK) ON dbo.tSteuercache.kSteuerKlasse = dbo.tartikel.kSteuerKlasse
					WHERE kArtikel = @kArtikel;
				END;

				--Es wurde genügend Menge reserviert
				IF (@fNochZuReservierendeMenge = 0)
				BEGIN
					BREAK;
				END;

				--Es wurde noch nicht genügend Menge reserviert, es wird nun der nächste WarenlagerEingang geprüft
				FETCH NEXT
				FROM cur_WarenlagerEingang
				INTO @kWarenlagerEingang
					,@fWLEAnzahlAktuell
					,@kWarenlagerPlatz;
			END;


			-------------------------------------------------------------------------------
			----------- SUCHE WARENLAGEREINGAENGE ENDE------------------------------------
			-------------------------------------------------------------------------------



			-- FehlerSuche für DebugAusgabe
			IF (@nDebug = 1 AND @nMengeFuerDiesePositionGefunden = 0)
				INSERT INTO @temporary_FehlerTable (
					kSessionId
					,cText
					,kkey1
					,kkey2
					,cValue1
					,cValue2
					,nValue1
					)
				VALUES (
					@kSessionID
					,'Es wurde kein Bestand gefunden, der den Anforderungen entspricht.'
					,@kBestellung
					,@kArtikel
					,@cBestellung
					,@cArtikel
					,2
					);

			IF (@nDebug = 1 AND @fNochZuReservierendeMenge > 0)
			BEGIN
				SET @nTestWert = 0;

				--Es wird geprüft, ob für einen MHD/Chargen-Artikel Bestand auf mit der gleichen MHD/Charge auf mehr als einem Platz liegt
				--In diesem Fall kann nicht reserviert werden, weil beim Verpacken nicht aufgelöst werden kann, was von welchem Platz genommen wurde
				SELECT @nTestWert = COUNT(DISTINCT tWarenlagerPlatz.kwarenlagerplatz)
				FROM dbo.twarenlagereingang WITH (NOLOCK)
				JOIN dbo.tWarenlagerPlatz WITH (NOLOCK) ON dbo.tWarenlagerPlatz.kwarenlagerplatz = dbo.twarenlagereingang.kwarenlagerplatz
					AND dbo.tWarenlagerplatz.kwarenlager = @kWarenlager
					AND (
						dbo.tWarenlagerPlatz.kWarenlagerPlatzTyp IN (1,7)
						OR (
							@nWEPlatzReservieren = 1
							AND dbo.tWarenlagerPlatz.kWarenlagerPlatzTyp IN (1,3,7)
							)
						OR (
							@nLadenlokalReservieren = 1
							AND dbo.tWarenlagerPlatz.kWarenlagerPlatzTyp IN (1,8,7)
							)
						OR (
							@nRetourPlatzReservieren = 1
							AND dbo.tWarenlagerPlatz.kWarenlagerPlatzTyp IN (1,11,7)
							)
						OR (
							@IstPacktisch = 1
							AND dbo.tWarenlagerPlatz.kWarenlagerPlatzTyp = 0
							)
						)
				JOIN tartikel WITH (NOLOCK) ON dbo.twarenlagereingang.kartikel = tartikel.kartikel
					AND dbo.tartikel.kartikel = @kArtikel
					AND (
						dbo.tartikel.ncharge > 0
						OR dbo.tartikel.nmhd > 0
						)
				WHERE dbo.twarenlagereingang.fAnzahlAktuell > 0
					-- Existiert der Artikel auf mehr als einen Platz ?
					AND (
						EXISTS (
							SELECT dbo.twarenlagereingang.kartikel
							FROM dbo.twarenlagereingang WITH (NOLOCK)
							JOIN dbo.tWarenlagerPlatz WITH (NOLOCK) ON dbo.tWarenlagerPlatz.kwarenlagerplatz = dbo.twarenlagereingang.kwarenlagerplatz
							JOIN dbo.tartikel WITH (NOLOCK) ON dbo.twarenlagereingang.kartikel = dbo.tartikel.kartikel
							WHERE (
									dbo.tartikel.ncharge > 0
									OR dbo.tartikel.nmhd > 0
									)
								AND dbo.twarenlagereingang.fAnzahlAktuell > 0
								AND dbo.tWarenLagerEingang.kArtikel = @kArtikel
								AND dbo.twarenlagerplatz.kWarenlager = @kWarenlager
								AND dbo.tartikel.kartikel = dbo.tWarenLagerEingang.kArtikel
								AND (
									dbo.tWarenlagerPlatz.kWarenlagerPlatzTyp IN (1,7)
									OR (
										@nWEPlatzReservieren = 1
										AND dbo.tWarenlagerPlatz.kWarenlagerPlatzTyp = 3
										)
									OR (
										@nLadenlokalReservieren = 1
										AND dbo.tWarenlagerPlatz.kWarenlagerPlatzTyp = 8
										)
									OR (
										@nRetourPlatzReservieren = 1
										AND dbo.tWarenlagerPlatz.kWarenlagerPlatzTyp = 11
										)
									OR (
										@IstPacktisch = 1
										AND dbo.tWarenlagerPlatz.kWarenlagerPlatzTyp = 0
										)
									)
							GROUP BY dbo.twarenlagereingang.kartikel
								,dbo.twarenlagereingang.cchargennr
								,dbo.twarenlagereingang.dmhd
							HAVING COUNT(DISTINCT dbo.tWarenlagerPlatz.kwarenlagerplatz) > 1
							)
						)
					-- Sind auf einem Platz wo der Artikel draufliegt auch andere Chargen/MHDs 
					AND (
						dbo.tArtikel.nCharge = 1
						AND 1 < (
							SELECT COUNT(DISTINCT tWE3.cChargenNr)
							FROM dbo.tWarenlagereingang tWE3 WITH (NOLOCK)
							WHERE tWE3.kartikel = tartikel.kartikel
								AND tWE3.kwarenlagerplatz = dbo.tWarenLagerEingang.kWarenLagerPlatz
								AND tWE3.fanzahlaktuell > 0
							)
						OR (
							dbo.tArtikel.nMHD = 1
							AND 1 < (
								SELECT COUNT(DISTINCT tWE2.dMHD)
								FROM dbo.tWarenlagereingang tWE2 WITH (NOLOCK)
								WHERE tWE2.kartikel = tartikel.kartikel
									AND tWE2.kwarenlagerplatz = dbo.tWarenLagerEingang.kWarenLagerPlatz
									AND tWE2.fanzahlaktuell > 0
								)
							)
						);

				IF (@nTestWert IS NOT NULL AND @nTestWert > 0)
					INSERT INTO @temporary_FehlerTable (
						kSessionId
						,cText
						,kkey1
						,kkey2
						,cValue1
						,cValue2
						,nValue1
						)
					VALUES (
						@kSessionID
						,'Achtung! Es kann nur von MHD/Chargen-reinen Plätzen reserviert werden oder wenn sich eine Charge/MHD auf maximal einem Platz befindet.'
						,@kBestellung
						,@kArtikel
						,@cBestellung
						,@cArtikel
						,2
						);
				ELSE
				BEGIN
					SET @nTestWert = 0;

					--Prüfen ob Bestand auf gesperrten Plätzen ist oder auf Klärplatzen
					SELECT @nTestWert = count(dbo.twarenlagereingang.kartikel)
					FROM dbo.twarenlagereingang WITH (NOLOCK)
					JOIN dbo.twarenlagerplatz WITH (NOLOCK) ON dbo.twarenlagerplatz.kwarenlagerplatz = dbo.twarenlagereingang.kwarenlagerplatz
						AND dbo.twarenlagerplatz.kwarenlager = @kWarenlager
						AND (
							@nWEPlatzReservieren = 1
							AND twarenlagerplatz.kwarenlagerplatztyp NOT IN (
								1
								,7
								) --Klärplatz, von diesem wird nie reserviert
							OR twarenlagerplatz.kwarenlagerplatztyp NOT IN (
								1
								,3
								,7
								)
							OR twarenlagerplatz.nStatus > 0
							) --gesperrte Plätze
					WHERE dbo.twarenlagereingang.fanzahlaktuell - dbo.twarenlagereingang.fanzahlreserviertpickpos > 0
						AND dbo.twarenlagereingang.kartikel = @kArtikel;

					IF (@nTestWert IS NOT NULL AND @nTestWert > 0)
						INSERT INTO @temporary_FehlerTable (
							kSessionId
							,cText
							,kkey1
							,kkey2
							,cValue1
							,cValue2
							,nValue1
							)
						VALUES (
							@kSessionID
							,'Es gibt noch Bestand auf gesperrten oder inventur-gesperrten Plätzen oder auf Klärplätzen.'
							,@kBestellung
							,@kArtikel
							,@cBestellung
							,@cArtikel
							,2
							);

					IF (ISNULL(@nMHDHandling, 0) = 0)
					BEGIN
						SET @nTestWert = 0;

						--Prüfen ob Bestand auf mit amgelaufenem MHD existiert
						SELECT @nTestWert = count(dbo.twarenlagereingang.kartikel)
						FROM dbo.twarenlagereingang WITH (NOLOCK)
						JOIN dbo.twarenlagerplatz WITH (NOLOCK) ON dbo.twarenlagerplatz.kwarenlagerplatz = dbo.twarenlagereingang.kwarenlagerplatz
							AND dbo.twarenlagerplatz.kwarenlager = @kWarenlager
							AND dbo.tWarenlagerplatz.nStatus = 0
							AND (
								@nWEPlatzReservieren = 1
								AND dbo.twarenlagerplatz.kwarenlagerplatztyp IN (1,3,7
									) --Klärplatz, von diesem wird nie reserviert
								OR @nLadenlokalReservieren = 1
								AND dbo.twarenlagerplatz.kwarenlagerplatztyp IN (1,8,7)
								OR @nRetourPlatzReservieren = 1
								AND dbo.twarenlagerplatz.kwarenlagerplatztyp IN (1,11,7)
								OR dbo.twarenlagerplatz.kwarenlagerplatztyp IN (1,7)
								) --gesperrte Plätze
						JOIN dbo.tartikel WITH (NOLOCK) ON dbo.tartikel.kartikel = dbo.twarenlagereingang.kartikel
							AND dbo.tartikel.nMHD = 1
						WHERE dbo.twarenlagereingang.fanzahlaktuell - dbo.twarenlagereingang.fanzahlreserviertpickpos > 0
							AND dbo.twarenlagereingang.kartikel = @kArtikel
							AND datediff(d, 0, dbo.tWarenlagerEingang.dMHD) >= datediff(d, 0, (GETDATE() + @nMinMHD));

						IF (@nTestWert IS NOT NULL
							AND @nTestWert > 0)
							INSERT INTO @temporary_FehlerTable (
								kSessionId
								,cText
								,kkey1
								,kkey2
								,cValue1
								,cValue2
								,nValue1
								)
							VALUES (
								@kSessionID
								,'Es gibt noch Bestand mit abgelaufenem MHD für diesen Artikel.'
								,@kBestellung
								,@kArtikel
								,@cBestellung
								,@cArtikel
								,2
								);
					END;

					SET @nTestWert = 0;

					--Prüfen ob Bestand in anderen Warenlagern ist
					SELECT @nTestWert = count(dbo.twarenlagereingang.fanzahlaktuell)
					FROM dbo.twarenlagereingang WITH (NOLOCK)
					JOIN dbo.twarenlagerplatz WITH (NOLOCK) ON dbo.twarenlagerplatz.kwarenlagerplatz = dbo.twarenlagereingang.kwarenlagerplatz
						AND dbo.twarenlagerplatz.kwarenlager <> @kWarenlager
					WHERE dbo.twarenlagereingang.fanzahlaktuell - dbo.twarenlagereingang.fanzahlreserviertpickpos > 0
						AND dbo.twarenlagereingang.kartikel = @kArtikel
					GROUP BY dbo.twarenlagereingang.kartikel
						,dbo.twarenlagerplatz.kwarenlager;

					IF (
							@nTestWert IS NOT NULL
							AND @nTestWert > 0
							)
						INSERT INTO @temporary_FehlerTable (
							kSessionId
							,cText
							,kkey1
							,kkey2
							,cValue1
							,cValue2
							,nValue1
							)
						VALUES (
							@kSessionID
							,'Es gibt noch Bestand in anderen Warenlagern. Hier ist vielleicht eine Umlagerung oder Auslagerung von diesem Lager sinnvoll.'
							,@kBestellung
							,@kArtikel
							,@cBestellung
							,@cArtikel
							,2
							);
				END;
			END;

			IF (@fNochZuReservierendeMenge = @fAnzahl)
				SET @nTeilmengeWurdeReserviert = - 1;--Es wurde keine Menge reserviert  
			ELSE IF (@fNochZuReservierendeMenge > 0)
			BEGIN
				SET @nTeilmengeWurdeReserviert = 1;--Es wurde nur eine Teilmenge reserviert  

				IF (@nDebug = 1)
					INSERT INTO @temporary_FehlerTable (
						kSessionId
						,cText
						,kkey1
						,kkey2
						,cValue1
						,cValue2
						,nValue1
						)
					VALUES (
						@kSessionID
						,'Es wurde nur eine Teilmenge für diese Position gefunden. Fehlmenge: ' + CAST(@fNochZuReservierendeMenge AS VARCHAR)
						,@kBestellung
						,@kArtikel
						,@cBestellung
						,@cArtikel
						,2
						);
			END;

			CLOSE cur_WarenlagerEingang;
			DEALLOCATE cur_WarenlagerEingang;


			--Es konnte nicht die gesamte Menge der letzten Position reserviert werden und Teilmengen sind nicht erlaubt (bei Stuecklistenpositionen im EazyShipping bzw. der reinen Roko sind Teilmengen nie erlaubt)
			--Komplette Reservierungen dieser Bestellung müssen zurückgesetzt werden   
			IF (@nTeilmengeWurdeReserviert <> 0 AND 
			   (@nTeilLiefErlaubt = 0 OR ((@nIsUnique > 0) AND (@nEinartikelpickliste = 1 OR @kReineRollendeKommissionierung = 1))))
			BEGIN
				IF (@nIsUnique > 0 AND (@nEinartikelpickliste = 1 OR @kReineRollendeKommissionierung = 1))
				BEGIN
					INSERT INTO @temporary_FehlerTable (
						kSessionId
						,cText
						,kkey1
						,cValue1
						,nValue1
						)
					VALUES (
						@kSessionID
						,'Konfektionsartikel ('+ CAST(@nIsUnique AS varchar) +') dürfen nicht teilgeliefert werden.'
						,@kBestellung
						,@cBestellung
						,1
						);
				END;

				IF (@nIsUnique > 0 AND @nTeilLiefErlaubt = 1)
				BEGIN
					-- Diese Konfi-Positionen dürfen nicht mehr reserviert werden, hier merken wir sie uns
					INSERT INTO #NotFoundUniques (cUnique)
					VALUES (@cUnique);

					DECLARE @fToDeleteAnzahlUnique DECIMAL(28, 14);

					SELECT @fToDeleteAnzahlUnique = ISNULL(SUM(#PickPosReserviert.fAnzahl), 0)
					FROM #PickPosReserviert WITH (NOLOCK)
					WHERE #PickPosReserviert.cUnique = cUnique;

					SET @kLetzteBestellpos = @kBestellPos;
					SET @fMengeErfolgreichReserviert = @fMengeErfolgreichReserviert + (@fAnzahl - @fNochZuReservierendeMenge) - @fToDeleteAnzahlUnique;--Anzahl der vorher gezählten Stücklisten Pickpos wieder abziehen  
					SET @fNochZuReservierendeMenge = 0;
					SET @fAnzahl = 0;
				END;
				ELSE
				BEGIN
					DELETE FROM #PickPosReserviert; -- Reservierungen löschen

					IF (@nDebug = 1)
						INSERT INTO @temporary_FehlerTable (
							kSessionId
							,cText
							,kkey1
							,cValue1
							,nValue1
							)
						VALUES (
							@kSessionID
							,'Da nur eine Teilmenge gefunden wurde wird der ganze Auftrag zurückgesetzt.'
							,@kBestellung
							,@cBestellung
							,1
							);

					IF (@nRechnungFertigCount > 0)
					BEGIN
						INSERT INTO @temporary_FehlerTable (
							kSessionId
							,cText
							,kkey1
							,cValue1
							,nValue1
							)
						VALUES (
							@kSessionID
							,'Zum Auftrag wurde schon eine Rechnung erzeugt, daher kann er nicht teilgeliefert werden.'
							,@kBestellung
							,@cBestellung
							,1
							);
					END;

					BREAK;
				END;
			END;

	
			IF (@nTeilmengeWurdeReserviert >= 0) --Es wurde eine Teilmenge (1) oder die gesamte Menge (0) reserviert 
			BEGIN
				SET @fMengeErfolgreichReserviert = @fMengeErfolgreichReserviert + @fAnzahl - @fNochZuReservierendeMenge;
				SET @fGesammtGewicht = @fGesammtGewicht + (ISNULL(@fArtGewicht, 0) * (@fAnzahl - @fNochZuReservierendeMenge));
			END;
		END;

		SET @kLastStueckliste = @kStueckliste;

		FETCH NEXT
		FROM cur_BestellPos
		INTO @kBestellPos
			,@kArtikel
			,@fAnzahl
			,@cTeilbar
			,@kStueckliste
			,@nIsUnique
			,@fArtGewicht
			,@cUnique;
	END;

	--------------------------------------------------------------------------------------
	--Durchläuft jede Bestellpos für die noch Menge reserviert werden kann --ENDE--------
	--------------------------------------------------------------------------------------

	CLOSE cur_BestellPos;
	DEALLOCATE cur_BestellPos;

	INSERT INTO @temporary_FehlerTable (
		kSessionId
		,cText
		,kkey1
		,cValue1
		,nValue1
		)
	VALUES (
		@kSessionID
		,cast(@fGesammtGewicht AS VARCHAR)
		,@kBestellung
		,@cBestellung
		,1
		);


	---- Max Gewicht Check --------------------------------------------------------------
	IF ((@nGewMax > 0 OR @nGewMin > 0) AND @nTeilLiefErlaubt = 1)
	BEGIN
		IF (@fGesammtGewicht > @nGewMax OR @fGesammtGewicht < @nGewMin)
		BEGIN
			DELETE FROM #PickPosReserviert;  -- Reservierungen löschen

			IF (@nDebug = 1)
			BEGIN
				IF (@fGesammtGewicht > @nGewMax AND @nGewMax > 0)
					INSERT INTO @temporary_FehlerTable (
						kSessionId
						,cText
						,kkey1
						,cValue1
						,nValue1
						)
					VALUES (
						@kSessionID
						,'Das Gewicht der teilreservierten Bestellung überschreitet das eingestellte Maximal-Gewicht der Picklistenvorlage.'
						,@kBestellung
						,@cBestellung
						,1
						);

				IF (@fGesammtGewicht < @nGewMin AND @nGewMin > 0)
					INSERT INTO @temporary_FehlerTable (
						kSessionId
						,cText
						,kkey1
						,cValue1
						,nValue1
						)
					VALUES (
						@kSessionID
						,'Das Gewicht der teilreservierten Bestellung unterschreitet die eingestellte Minimal-Gewicht der Picklistenvorlage.'
						,@kBestellung
						,@cBestellung
						,1
						);
			END;
		END;
	END;

	-------------------------------------------------------------------------------------
	---- Anpassen von nicht Vollständigen Konfi und Stücklisten Pos ---------------------

	---- Konfi
	IF (@nEinartikelpickliste = 1 OR @kReineRollendeKommissionierung = 1)
	BEGIN

		DELETE #PickPosReserviert 
		FROM #PickPosReserviert
		JOIN #NotFoundUniques ON #NotFoundUniques.cUnique = #PickPosReserviert.cUnique;

	END;

	---- Stueckliste , Nur ganze Stücklisten ausliefern
	IF(EXISTS (SELECT * FROM #PickPosReserviert WHERE kStueckListe > 0) AND @nTeilLiefErlaubt = 1 -- bei Teillieferng 
	                                                                    AND (@nVorkommissionieren = 0 OR @nBoxenNurGanzeStuecklistenAufPL = 1))
	BEGIN

			-- Alle Stücklisten löschen wenn was nicht da ist, das kommt evtl später optional
			--DELETE FROM #PickPosReserviert
			--WHERE #PickPosReserviert.kStueckListe IN (SELECT DISTINCT InnerPPReserviert.kStueckListe
			--										  FROM #PickPosReserviert AS InnerPPReserviert
			--										  JOIN dbo.tbestellpos ON dbo.tbestellpos.kBestellPos = InnerPPReserviert.kBestellPos
			--										  WHERE InnerPPReserviert.kStueckListe > 0
			--										  GROUP BY dbo.tbestellpos.kBestellPos, InnerPPReserviert.kStueckListe
			--										  HAVING SUM(InnerPPReserviert.fAnzahl) < MAX(dbo.tbestellpos.nAnzahl));
		

			-- Ueber alle Stücklistenkomponenten die gefunden wurden, anpassen der Menge auf die maximal gülte für ganze Stuecklisten
			DECLARE cur_StuecklistenPos CURSOR LOCAL FAST_FORWARD
			FOR
			SELECT #PickPosReserviert.fAnzahl , ROUND((SLAnteile.fMaxMengeVater / Vater.nAnzahl) * dbo.tBestellPos.nAnzahl,4), #PickPosReserviert.kWarenLagerEingang, 
				   #PickPosReserviert.kBestellPos, #PickPosReserviert.kStueckListe, #PickPosReserviert.kArtikel
			FROM #PickPosReserviert
			-- Minimale Menge an ganzen Stuecklisten die aus der gefundenen Menge reserviert werden kann, für diese Stückliste
			OUTER APPLY (SELECT ROUND(MIN(FLOOR((ISNULL(InnerPickPosTemp.fAnzahl,0) * Vater.nAnzahl) /  dbo.tBestellPos.nAnzahl)),4) AS fMaxMengeVater
						 FROM dbo.tBestellPos
						 LEFT JOIN #PickPosReserviert AS InnerPickPosTemp ON dbo.tBestellPos.kBestellPos = InnerPickPosTemp.kBestellPos
						 JOIN dbo.tBestellPos AS Vater ON Vater.kBestellPos = #PickPosReserviert.kStueckListe
						 JOIN vWMSArtikel ON vWMSArtikel.kArtikel =   dbo.tBestellPos.tArtikel_kArtikel
						 WHERE dbo.tBestellPos.kBestellStueckliste = #PickPosReserviert.kStueckListe
						 AND dbo.tBestellPos.kBestellStueckliste != dbo.tBestellPos.kBestellPos
			) AS SLAnteile
			JOIN dbo.tBestellPos ON dbo.tBestellPos.kBestellPos = #PickPosReserviert.kBestellPos
			JOIN dbo.tBestellPos AS Vater ON Vater.kBestellPos = #PickPosReserviert.kStueckListe
			WHERE #PickPosReserviert.kStueckListe > 0
			ORDER BY #PickPosReserviert.kStueckListe,#PickPosReserviert.kArtikel;
		
			DECLARE @fAnzahlIst DECIMAL(28, 14);	-- Die Menge der gefunden Artikel
			DECLARE @fAnzahlMax DECIMAL(28, 14);	-- Soviel darf Maximal reserviert werden, wegen Stuecklisten beschraenkungen
			DECLARE @kParWarenlagereingang INT;
			DECLARE @kParBestellPos INT;
			DECLARE @kParStueckListe INT;
			DECLARE @kParArtikel INT;
			DECLARE @kOldStueckListe INT = 0;       -- Letzte Stueckliste Merker
			DECLARE @kOldArtikel INT = 0;		    -- Letztee Artikel Merker
			DECLARE @fMengeErlaubt DECIMAL(28, 14); -- Temp Speicher für Menge 

			OPEN cur_StuecklistenPos;

			FETCH NEXT FROM cur_StuecklistenPos
			INTO @fAnzahlIst,@fAnzahlMax,@kParWarenlagereingang,@kParBestellPos,@kParStueckListe,@kParArtikel;


			WHILE @@FETCH_STATUS = 0
			BEGIN


				IF(@kOldStueckListe != @kParStueckListe OR @kOldArtikel != @kParArtikel)
					SET @fMengeErlaubt = @fAnzahlMax;


				IF(@fAnzahlIst > @fMengeErlaubt)
				BEGIN

					UPDATE #PickPosReserviert SET fAnzahl = @fMengeErlaubt
					WHERE #PickPosReserviert.kWarenLagerEingang = @kParWarenlagereingang
					AND #PickPosReserviert.kBestellPos = @kParBestellPos
					AND #PickPosReserviert.kStueckListe = @kParStueckListe;

					SET @fMengeErlaubt = 0;
				END;
				ELSE
				BEGIN
					SET @fMengeErlaubt = @fMengeErlaubt - @fAnzahlIst;
				END;

				SET @kOldStueckListe = @kParStueckListe;
				SET @kOldArtikel = @kParArtikel;

			FETCH NEXT FROM cur_StuecklistenPos
			INTO @fAnzahlIst,@fAnzahlMax,@kParWarenlagereingang,@kParBestellPos,@kParStueckListe,@kParArtikel;

			END;

			CLOSE cur_StuecklistenPos;
			DEALLOCATE cur_StuecklistenPos;

	END;

	-------------------------------------------------------------------------------------
	SELECT @fMengeErfolgreichReserviert = SUM(#PickPosReserviert.fAnzahl)
	FROM #PickPosReserviert;

	IF ((@nTeilLiefErlaubt = 1 AND @fWertDerReserviertenBestellung < @fTeilliefPreis) OR @fMengeErfolgreichReserviert = 0)
		--Teillieferungen waren erlaubt, jedoch ist der Wert der reservierten Teillieferungen kleiner als die angegebene Mindestgrenze 
	BEGIN

		IF (@nDebug = 1 AND @nTeilLiefErlaubt = 1 AND @fWertDerReserviertenBestellung < @fTeilliefPreis)
		BEGIN
				INSERT INTO @temporary_FehlerTable (
						kSessionId
						,cText
						,kkey1
						,cValue1
						,nValue1
						)
					VALUES (
						@kSessionID
						,'Teillieferungen waren erlaubt, jedoch ist der Wert der reservierten Teillieferungen kleiner als die angegebene Mindestgrenze.'
						,@kBestellung
						,@cBestellung
						,1
						);
		END;
	END;
	ELSE
	BEGIN

	    IF (@@TRANCOUNT = 0)
		BEGIN
			SET @CreatedTransaction = 1;
			BEGIN TRANSACTION
		END;

		INSERT INTO dbo.tPicklistePos
		(
		    kPickliste,
		    kWarenLager,
		    kWarenLagerEingang,
		    fAnzahl,
		    kBestellPos,
		    kArtikel,
		    kWarenlagerPlatz,
		    kBestellung,
			nStatus
		)
		SELECT @kPickliste,@kWarenlager, PPR.kWarenLagerEingang,PPR.fAnzahl,PPR.kBestellPos,PPR.kArtikel,PPR.kWarenlagerPlatz, @kBestellung , 10
		FROM #PickPosReserviert AS PPR
		WHERE PPR.fAnzahl > 0;

		SET CONTEXT_INFO 0x5022;

		INSERT INTO dbo.tPicklistePosStatus (kPicklistePos,nStatus,kBenutzer,dZeitstempel)
		SELECT dbo.tPicklistePos.kPicklistePos,10,@kBenutzer,GETDATE()  
		FROM dbo.tPicklistePos 
		WHERE dbo.tPicklistePos.kPickliste = @kPickliste
		AND dbo.tPicklistePos.kBestellung = @kBestellung;

		UPDATE dbo.tPicklistePos SET kPicklistePosStatus = dbo.tPicklistePosStatus.kPicklistePosStatus
		FROM dbo.tPicklistePos
		JOIN dbo.tPicklistePosStatus ON  dbo.tPicklistePosStatus.kPicklistePos = dbo.tPicklistePos.kPicklistePos AND dbo.tPicklistePosStatus.nStatus = 10
		WHERE dbo.tPicklistePos.kPickliste = @kPickliste
		AND dbo.tPicklistePos.kBestellung = @kBestellung;

		SET CONTEXT_INFO 0x0000;


		IF (@CreatedTransaction = 1)
		BEGIN
			COMMIT TRANSACTION;
		END;
	END;

	IF (@nDebug = 1)
		--Einfügen der lokalen Fehlertabelle
		INSERT INTO dbo.tFehler
		WITH (ROWLOCK)
		SELECT *
		FROM @temporary_FehlerTable;
END;
go

