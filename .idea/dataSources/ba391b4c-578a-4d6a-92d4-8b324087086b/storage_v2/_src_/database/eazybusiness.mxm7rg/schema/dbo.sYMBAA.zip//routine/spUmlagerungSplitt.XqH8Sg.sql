--- 
--- spUmlagerungSplitt
---

CREATE PROCEDURE [dbo].[spUmlagerungSplitt]
	@kUmlagerung INT,             -- Umlagerung der geplittet werden soll
	@kBestellungNeu INT		      -- Die Bestellung die neu Abgesplittet wurde
     
	--
	-- Copyright (c) 2012-2017 by JTL Software GmbH
	-- Datum: $Date$
	-- Version: $Rev$
	-- Autor: PN	
	
	-- Die Procedur splittet eine Umlagerung. Sie muß ausgeführt werden nachdem eine Bestellung gesplittet wurde. Anhand der neu abgesplitteten Bestellung
	-- wir die Lieferentanbestellung der Umlagerung mit angepasst, hier wird auch ein Splitt gemacht analog zu den Bestellungen.
AS
DECLARE  @kLieferantenBestellung INT
DECLARE  @kLieferantenBestellungNew INT
DECLARE  @fMengeToSplitt DECIMAL(28,14)
DECLARE  @kBestellposNeu INT
DECLARE  @kLieferantenBestellungsPos_CUR INT
DECLARE  @fMenge_CUR DECIMAL(28,14)
DECLARE  @kArtikel_CUR INT
DECLARE  @kArtikelToSplitt INT
DECLARE  @kUmlagerungNew INT
  
BEGIN
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
    SELECT * INTO #tUmlagerung 
		FROM tUmlagerung WITH(NOLOCK) 
		WHERE tUmlagerung.kUmlagerung = @kUmlagerung
      
    -- Umlagerung splitten 
    UPDATE #tUmlagerung 
		SET kBestellung = @kBestellungNeu
	ALTER TABLE #tUmlagerung  
		DROP COLUMN kUmlagerung
	INSERT INTO tUmlagerung WITH(ROWLOCK) 
		SELECT #tUmlagerung.* FROM #tUmlagerung
	
	SET @kUmlagerungNew = SCOPE_IDENTITY()

    -- Falls Lieferantenbestellung vorhanden, dann müßen wir diese Mengengenau Splitten
	IF(EXISTS(SELECT * FROM #tUmlagerung WHERE #tUmlagerung.kLieferantenBestellung > 0))
	BEGIN
		SELECT @kLieferantenBestellung = kLieferantenBestellung FROM #tUmlagerung
	  
		-- Splitten Lieferantenbestellung
		SELECT * INTO #tLieferantenbestellung 
			FROM tLieferantenbestellung (NOLOCK)
			WHERE kLieferantenbestellung = @kLieferantenBestellung
	  
		ALTER TABLE #tLieferantenbestellung  
			DROP COLUMN kLieferantenbestellung
	  
		INSERT INTO tLieferantenbestellung WITH(ROWLOCK) 
			SELECT * FROM #tLieferantenbestellung
		SET @kLieferantenBestellungNew = SCOPE_IDENTITY()
	  
		UPDATE tUmlagerung WITH(ROWLOCK) 
			SET tUmlagerung.kLieferantenBestellung = @kLieferantenBestellungNew
			WHERE tUmlagerung.kUmlagerung = @kUmlagerungNew
		--
	  
	  
		-- Alle Bestellpos der gesplitteten Bestellung (Die die nicht reserviert werden sollen)
		SELECT * INTO #tNeuBestellpos 
			FROM tbestellpos WITH (NOLOCK)
			WHERE tbestellpos.tBestellung_kBestellung = @kBestellungNeu
				AND tbestellpos.nType < 2
	  
		-- Alle Lieferantenbestellpos der alten Sendung
		DECLARE cur_GetLieferantenbestellungPosOld CURSOR LOCAL FAST_FORWARD FOR  
		SELECT tLieferantenbestellungPos.kLieferantenBestellungPos,tLieferantenbestellungPos.fMenge,tLieferantenbestellungPos.kArtikel
			FROM tLieferantenbestellungPos WITH (NOLOCK)
			WHERE tLieferantenbestellungPos.kLieferantenBestellung = @kLieferantenBestellung
    
		-- Über alle Bestellpos der gesplitteten Bestellung, wir suchen die Mengen in der Lieferantenbestellung und splitten diese ab.
		-- Nach der While Schleife muß die Lieferantenbestellung die selben Pos haben die die Bestellung, weil die zusätzlichen Mengen abgesplittet wurden.
		WHILE (EXISTS(SELECT * FROM #tNeuBestellpos))
		BEGIN
	  
			SELECT TOP(1) @kBestellposNeu = #tNeuBestellpos.kBestellPos ,@fMengeToSplitt = #tNeuBestellpos.nAnzahl,@kArtikelToSplitt = #tNeuBestellpos.tArtikel_kArtikel
				FROM  #tNeuBestellpos
	  
			-- Über alle Lieferantenbestellpos, suche ArtikelMenge
			OPEN cur_GetLieferantenbestellungPosOld
			FETCH NEXT FROM cur_GetLieferantenbestellungPosOld INTO @kLieferantenBestellungsPos_CUR,@fMenge_CUR,@kArtikel_CUR
			WHILE (@@FETCH_STATUS = 0  AND @fMengeToSplitt > 0)
			BEGIN
	    
				IF(@fMengeToSplitt >= @fMenge_CUR AND @kArtikelToSplitt = @kArtikel_CUR) -- Ganz übernehmen
				BEGIN
					UPDATE tLieferantenBestellungPos  
						WITH(ROWLOCK) SET tLieferantenBestellungPos.kLieferantenBestellung = @kLieferantenBestellungNew
						WHERE  tLieferantenBestellungPos.kLieferantenBestellungPos = @kLieferantenBestellungsPos_CUR
					SET @fMengeToSplitt = @fMengeToSplitt - @fMenge_CUR
				END
				ELSE IF (@fMengeToSplitt < @fMenge_CUR AND @kArtikelToSplitt = @kArtikel_CUR) -- Splitten
				BEGIN
					-- Splitten der neuen Pos 
					SELECT * INTO #tLieferantenBestellungsPosNeu 
						FROM tLieferantenBestellungPos WITH(NOLOCK)
						WHERE kLieferantenBestellungPos = @kLieferantenBestellungsPos_CUR
	       
					ALTER TABLE #tLieferantenBestellungsPosNeu  
						DROP COLUMN kLieferantenBestellungPos
					UPDATE #tLieferantenBestellungsPosNeu 
						SET fMenge = @fMengeToSplitt,kLieferantenBestellung = @kLieferantenBestellungNew
		  
					INSERT INTO tLieferantenBestellungPos WITH(ROWLOCK) 
						SELECT * FROM #tLieferantenBestellungsPosNeu
					--
		  
					-- In der alten Pos die Menge updaten
					UPDATE tLieferantenBestellungPos WITH(ROWLOCK) 
						SET fMenge = (@fMenge_CUR - @fMengeToSplitt) 
						WHERE tLieferantenBestellungPos.kLieferantenBestellungPos = @kLieferantenBestellungsPos_CUR
		  
					SET @fMengeToSplitt = 0 --Fertig
				END

				FETCH NEXT FROM cur_GetLieferantenbestellungPosOld INTO @kLieferantenBestellungsPos_CUR,@fMenge_CUR,@kArtikel_CUR
			END
			CLOSE cur_GetLieferantenbestellungPosOld 
			DEALLOCATE cur_GetLieferantenbestellungPosOld
	  
			DELETE FROM #tNeuBestellpos WHERE #tNeuBestellpos.kBestellPos = @kBestellposNeu
		END
	END
END
go

