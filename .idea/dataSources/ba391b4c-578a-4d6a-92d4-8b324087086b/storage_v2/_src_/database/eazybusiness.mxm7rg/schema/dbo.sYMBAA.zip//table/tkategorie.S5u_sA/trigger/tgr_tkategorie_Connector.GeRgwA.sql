CREATE TRIGGER [dbo].[tgr_tkategorie_Connector]
ON [dbo].[tkategorie]
AFTER UPDATE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
	
	UPDATE dbo.tKategorieShop
		SET dbo.tKategorieShop.cInet = 'Y'
	FROM dbo.tKategorieShop
	JOIN
	(
		--
		-- Kategorien die verschoben wurden
		--
		SELECT INSERTED.kKategorie
		FROM INSERTED
		JOIN DELETED ON INSERTED.kKategorie = DELETED.kKategorie
		WHERE INSERTED.kOberKategorie <> DELETED.kOberKategorie
	) AS KategorienZuAktualisieren ON dbo.tKategorieShop.kKategorie = KategorienZuAktualisieren.kKategorie
	WHERE dbo.tKategorieShop.cInet <> 'Y'

END
go

