CREATE TRIGGER [dbo].[tgr_tKategorieShop_Connector_INSERT]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP
--
ON [dbo].[tKategorieShop]
AFTER INSERT
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN	

	--Überprüfen ob Trigger gefüllt aufgerufen wird
	IF((SELECT COUNT(1) FROM INSERTED) = 0)
	BEGIN 
		RETURN;
	END

	--
	-- Bilder vollständig zu Webshop wenden, wenn Änderungen vorgenommen wurden
	--
	UPDATE dbo.tKategoriebildPlattform
		SET dbo.tKategoriebildPlattform.nInet = 1
	FROM dbo.tKategoriebildPlattform
	JOIN INSERTED ON dbo.tKategoriebildPlattform.kKategorie = INSERTED.kKategorie
		AND dbo.tKategoriebildPlattform.kShop = INSERTED.kShop
	WHERE dbo.tKategoriebildPlattform.nInet = 0;	

	--
	-- Evtl. bestehenden Löscheinträge in tQueue entfernen
	--
	DELETE dbo.tQueue
	FROM dbo.tQueue
	JOIN INSERTED ON dbo.tQueue.kShop = INSERTED.kShop
		AND dbo.tQueue.kWert = INSERTED.kKategorie
	WHERE	dbo.tQueue.cName = 'tkategorie'
			AND dbo.tQueue.nAction = 2
END
go

