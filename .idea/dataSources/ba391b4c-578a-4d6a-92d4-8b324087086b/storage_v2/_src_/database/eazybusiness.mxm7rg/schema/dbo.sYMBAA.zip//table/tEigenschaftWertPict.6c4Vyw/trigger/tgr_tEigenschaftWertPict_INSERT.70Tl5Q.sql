CREATE TRIGGER [dbo].[tgr_tEigenschaftWertPict_INSERT]  
--     
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Author: Markus Hütz
--    
ON [dbo].[tEigenschaftWertPict]  
AFTER INSERT
AS  
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
	IF((SELECT COUNT(1) FROM INSERTED) = 0) 
	BEGIN
		RETURN
	END

     DECLARE @tpk int;
     SET @tpk = (SELECT tpk.nummer FROM tpk WHERE tpk.cName = 'tEigenschaftWertPict') - 1;

     INSERT INTO tEigenschaftWertPict (kEigenschaftWertPict, kEigenschaftWert, kBild, nInet, kPlattform, kShop)
     SELECT @tpk + ROW_NUMBER() OVER (ORDER BY tArtikelShop.kArtikel) AS kEigenschaftWertPict, 
			dbo.teigenschaftwert.kEigenschaftWert, 
			StandardBild.kBild, 
			1 AS nInet, 
			2 AS kPlattform, 
			dbo.tArtikelShop.kShop
     FROM dbo.tArtikelShop
     JOIN dbo.teigenschaft ON dbo.tArtikelShop.kArtikel = dbo.teigenschaft.kArtikel
     JOIN dbo.teigenschaftwert ON dbo.teigenschaftwert.kEigenschaft = dbo.teigenschaft.kEigenschaft
     JOIN INSERTED AS StandardBild ON StandardBild.kEigenschaftWert = dbo.teigenschaftwert.kEigenschaftWert 
		AND ISNULL(StandardBild.kPlattform, 0) IN (1, 0)
	GROUP BY dbo.tArtikelShop.kShop, tArtikelShop.kArtikel, dbo.teigenschaftwert.kEigenschaftWert, StandardBild.kBild;

     UPDATE tpk
     SET
         nummer = (ISNULL((SELECT MAX(kEigenschaftWertPict) FROM tEigenschaftWertPict), 0) + 1),
         dChanged = (SELECT CONVERT(VARCHAR(10),GETDATE(),121))
     WHERE cName = 'tEigenschaftWertPict';
END
go

