CREATE TRIGGER [dbo].[tgr_tShopMappingKundengruppe_Connector]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP
--
ON [dbo].[tShopMappingKundengruppe]
AFTER UPDATE, INSERT, DELETE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
	--Überprüfen ob Trigger gefüllt aufgerufen wird
	IF((SELECT COUNT(1) FROM INSERTED FULL JOIN DELETED ON INSERTED.kKundengruppe = DELETED.kKundengruppe) = 0)
	BEGIN 
		RETURN;
	END
	
	--DECLARE @Komplett AS INT;
	DECLARE @Preis AS INT;
	--DECLARE @Bestand AS INT;

	--SET @Komplett = 1;
	SET @Preis = 2;
	--SET @Bestand = 4;

	UPDATE dbo.tArtikelShop
		SET dbo.tArtikelShop.cInet = 'Y',
			dbo.tArtikelShop.nAktion = dbo.tArtikelShop.nAktion | @Preis,
			dbo.tArtikelShop.nInBearbeitung = 0
	FROM dbo.tArtikelShop
	JOIN dbo.tPreis ON dbo.tArtikelShop.kArtikel = dbo.tPreis.kArtikel;

END
go

