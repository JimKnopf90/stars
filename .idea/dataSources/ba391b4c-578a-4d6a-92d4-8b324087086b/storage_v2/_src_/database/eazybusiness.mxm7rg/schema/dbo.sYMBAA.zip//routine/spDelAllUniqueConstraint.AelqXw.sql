--- 
--- spDelAllUniqueConstraint
---

CREATE PROCEDURE [dbo].[spDelAllUniqueConstraint]
@cTabelle VARCHAR(255)
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
	DECLARE @cName VARCHAR(512)
	DECLARE @nObjectID BIGINT
	SELECT TOP(1) @cName = cstr.name, @nObjectID = cstr.object_id FROM sys.key_constraints AS cstr WITH(NOLOCK) 
		JOIN sys.tables AS tbl ON tbl.object_id = cstr.parent_object_id
		WHERE tbl.name = @cTabelle
			AND cstr.type_desc = 'UNIQUE_CONSTRAINT'
			AND SCHEMA_NAME(tbl.schema_id)=N'dbo'
		ORDER BY cstr.object_id

	WHILE (@cName IS NOT NULL AND LEN(@cName)>0)
	BEGIN
		DECLARE @tsql NVARCHAR(2048)
		SET @tsql = 'ALTER TABLE '+@cTabelle+' DROP CONSTRAINT '+@cName
		EXEC sp_executesql @tsql 		

		SET @cName = NULL
		SELECT TOP(1) @cName = cstr.name, @nObjectID = cstr.object_id FROM sys.key_constraints AS cstr WITH(NOLOCK) 
			JOIN sys.tables AS tbl ON tbl.object_id = cstr.parent_object_id
			WHERE tbl.name = @cTabelle
				AND cstr.type_desc = 'UNIQUE_CONSTRAINT'
				AND SCHEMA_NAME(tbl.schema_id)=N'dbo'
				AND cstr.object_id > @nObjectID
			ORDER BY cstr.object_id
	END
END
go

