CREATE FUNCTION POSITIV(@Value DECIMAL(28,15))
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MK
--
-- Funktion gibt 0.0 zurück wenn der Wert negativ ist sonst den Wert
--
RETURNS DECIMAL(28,15)
AS
BEGIN
	IF(@Value < 0.0)
	BEGIN
		RETURN 0.0
	END
	RETURN @Value
END
go

