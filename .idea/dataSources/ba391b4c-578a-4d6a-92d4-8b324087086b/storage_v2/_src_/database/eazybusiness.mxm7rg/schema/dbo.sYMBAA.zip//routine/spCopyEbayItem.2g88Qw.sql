--- 
--- spCopyEbayItem
---

CREATE PROCEDURE [dbo].[spCopyEbayItem]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: SW
--
	-- =================================================================
	-- MIT EbayArticleHelper.OverwriteEbayitemWithArtikel ABSTIMMEN ! *)
	-- =================================================================
	-- mit EbayItemFormCategoriesModule.AddItemFeatures abzustimmen ! **) 
	-- Artikelmerkmale haben derzeit Vorrang;
	-- Unterschied: Produktkennzeichnungspflicht wird hier nicht berücksichtigt; 
	-- Grund: zu aufwendig und bei sinnvoller Pflege der Merkmale sowieso unnötig
	-- =================================================================

	--
	-- PK des zu kopierenden EbayItems
	--
	@kItemOld INT, 
	--
	-- PK des Artikels, zu dem das neue EbayItem gehören soll;
	-- = 0 => Artikel ändert sich beim Kopieren nicht
	--
	@kArtikelNew INT,
	--
	-- PK der Steuerzone des angemeldeten Benutzers (welchen die DB nicht kennt weil Session-abhängig);
	-- notwendig und aus dem Netto- den Brutto-Artikelpreis (= initialer Angebotspreis) berechnen zu können
	--
	@kSteuerzone INT,
	--
	-- PK des kopierten EbayItems
	--
	@kItemNew INT OUTPUT		
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
    --
    -- Tabelle, um auf Ergebnisse von spGetAndUpdatePk zugreifen zu können
    -- sollte anschließend immer geleert werden
    --
    DECLARE @NewPrimaryKeyTable AS TABLE(NewPrimaryKey INT);
    --
    -- Ergebnis von spGetAndUpdatePk als Skalar
    --
    DECLARE @NewPrimaryKey INT;

    --
    -- kArtikel des zu kopierenden EbayItems
    --
    DECLARE @kArtikelOld INT;
    SET @kArtikelOld = 
	(
		SELECT dbo.ebay_item.kArtikel 
		FROM dbo.ebay_item 
		WHERE dbo.ebay_item.kItem = @kItemOld
	);
    --
    -- wenn der Parameter für den Artikel des neuen EbayItems nicht vergeben ist, 
    -- soll der gleiche Artikel wie für das zu kopierende EbayItem verwendet werden
    --
    IF (@kArtikelNew = 0)
    BEGIN
	    SET @kArtikelNew = @kArtikelOld;
    END;
    --
    -- pseudo-boolsche Variable, die angeben soll, ob das EbayItem beim Kopieren seinen Artikel wechselt
    --
    DECLARE @SameArtikel INT;
    --
    -- Achtung: "@kArtikelNew = 0" wäre ein hinreichende, aber nicht notwendige Bedingung!
    --
    IF (@kArtikelOld = @kArtikelNew)
    BEGIN
	    SET @SameArtikel = 1;
    END
    ELSE
    BEGIN
	    SET @SameArtikel = 0;
    END;

    ----------------------------------------------------------------------
    -- kopiere ebay_item
    ----------------------------------------------------------------------

    --
    -- berechne PK von neuem Datensatz
    --
    DELETE @NewPrimaryKeyTable;
    INSERT @NewPrimaryKeyTable 
    (
	   NewPrimaryKey
    )
    EXEC spGetAndUpdatePk 'ebay_item';
    SET @NewPrimaryKey = (SELECT * FROM @NewPrimaryKeyTable);
    DELETE @NewPrimaryKeyTable;

    --
    -- merke neuen PK für spätere Verwendung
    --
    SET @kItemNew = @NewPrimaryKey;

	--
	-- kopiere ebay_item
	--
	IF(object_id('tempdb..#tempEbayItem') IS NOT NULL)
	BEGIN
		DROP TABLE #tempEbayItem;
	END;
	SELECT * INTO #tempEbayItem 
	FROM (
		SELECT * 
		FROM dbo.ebay_item
		WHERE dbo.ebay_item.kItem = @kItemOld
	) t;
	UPDATE #tempEbayItem	
	SET kItem = @kItemNew,
		kArtikel = @kArtikelNew,
		SKU = 
		(
			SELECT dbo.tArtikel.cArtNr 
			FROM dbo.tArtikel 
			WHERE dbo.tArtikel.kArtikel = @kArtikelNew
		),
		nVariationenAktiv = 
		(
			SELECT dbo.tArtikel.nIstVater
			FROM dbo.tArtikel 
			WHERE dbo.tArtikel.kArtikel = @kArtikelNew
		),
		nLeecher = 0;
	IF (@SameArtikel = 0)
	BEGIN
		UPDATE #tempEbayItem	
		SET kEigenschaft = 
		(
			SELECT CASE WHEN dbo.tArtikel.nIstVater = 0 THEN 0 ELSE 
			(
				SELECT TOP 1 dbo.teigenschaft.kEigenschaft 
				FROM dbo.teigenschaft 
				WHERE dbo.teigenschaft.kArtikel = @kArtikelNew
			) END
			FROM dbo.tArtikel 
			WHERE dbo.tArtikel.kArtikel = @kArtikelNew
		)
	END;
	INSERT dbo.ebay_item
	SELECT * 
	FROM #tempEbayItem;    

    ----------------------------------------------------------------------
    -- kopiere ebay_specific
    ----------------------------------------------------------------------

    INSERT dbo.ebay_specific
    (
	   kItem,
	   cName,
	   cValue,
	   nCustom
    )
    SELECT 
	    @kItemNew, 
	    cName, 
	    cValue, 
	    nCustom
    FROM dbo.ebay_specific 
    WHERE dbo.ebay_specific.kItem = @kItemOld;

	--
	-- ggf. Grundpreis in Kategorieattributen angeben
	--
	IF ((SELECT dbo.ebay_item.SiteID FROM dbo.ebay_item WHERE dbo.ebay_item.kItem = @kItemNew) = 77 AND 
		(SELECT dbo.ebay_item.ListingType FROM dbo.ebay_item WHERE dbo.ebay_item.kItem = @kItemNew) = 'FixedPriceItem' AND
		(SELECT ISNULL(dbo.ebay_item.nVariationenAktiv, 0) FROM dbo.ebay_item WHERE dbo.ebay_item.kItem = @kItemNew) = 0)
	BEGIN
		IF(object_id('tempdb..#ebayGrundpreisKategorieattribute') IS NOT NULL)
		BEGIN
			DROP TABLE #ebayGrundpreisKategorieattribute;
		END;
		CREATE TABLE #ebayGrundpreisKategorieattribute(fVPEWert DECIMAL (18, 2), cName VARCHAR(MAX));
		INSERT #ebayGrundpreisKategorieattribute
		(
			fVPEWert,
			cName
		)
		SELECT tArtikelTemp.fVPEWert, dbo.tEinheitSprache.cName
		FROM dbo.ebay_item 
		JOIN 
		(
			SELECT 
				CASE WHEN (dbo.tArtikel.nVPE = 1 AND dbo.tArtikel.fVPEWert > 0) 
					OR (tVaterArtikel.nVPE = 1 AND tVaterArtikel.fVPEWert > 0)
				THEN dbo.tArtikel.kArtikel
				ELSE 0 END AS kArtikel,
		
				CASE WHEN dbo.tArtikel.nVPE = 1 AND dbo.tArtikel.fVPEWert > 0 
				THEN dbo.tArtikel.kVPEEinheit 
				ELSE tVaterArtikel.kVPEEinheit END AS kVPEEinheit,

				CASE WHEN dbo.tArtikel.nVPE = 1 AND dbo.tArtikel.fVPEWert > 0 
				THEN dbo.tArtikel.fVPEWert
				ELSE tVaterArtikel.fVPEWert END AS fVPEWert
			FROM dbo.tArtikel 
			LEFT JOIN dbo.tArtikel AS tVaterArtikel ON tVaterArtikel.kArtikel = dbo.tArtikel.kVaterArtikel					
		) AS tArtikelTemp ON dbo.ebay_item.kItem = @kItemNew AND tArtikelTemp.kArtikel = dbo.ebay_item.kArtikel
		JOIN dbo.tEinheitSprache ON dbo.tEinheitSprache.kEinheit = tArtikelTemp.kVPEEinheit
		JOIN dbo.tSpracheUsed ON dbo.tSpracheUsed.nStandard = 1 AND tSpracheUsed.kSprache = tEinheitSprache.kSprache;

		DELETE dbo.ebay_specific 
		FROM dbo.ebay_specific JOIN #ebayGrundpreisKategorieattribute 
			ON dbo.ebay_specific.kItem = @kItemNew 
			AND dbo.ebay_specific.cName IN ('Anzahl der Einheiten', 'Maßeinheit');

		INSERT dbo.ebay_specific
		(
			kItem,
			cName,
			cValue,
			nCustom
		)
		SELECT @kItemNew, 
			'Anzahl der Einheiten', 
			REPLACE(CAST(CAST(#ebayGrundpreisKategorieattribute.fVPEWert AS DECIMAL (18, 2)) AS VARCHAR), '.', ','), 
			1
		FROM #ebayGrundpreisKategorieattribute;
		INSERT dbo.ebay_specific
		(
			kItem,
			cName,
			cValue,
			nCustom
		)
		SELECT @kItemNew, 'Maßeinheit', #ebayGrundpreisKategorieattribute.cName, 1
		FROM #ebayGrundpreisKategorieattribute;
	END;

    ----------------------------------------------------------------------
    -- kopiere ebay_ShippingServiceOptions 
    ----------------------------------------------------------------------

    INSERT dbo.ebay_ShippingServiceOptions
    (
	   kItem,
	   ShippingServiceID,
	   ShippingServiceAdditionalCost,
	   ShippingServiceCost,
	   ShippingServicePriority,
	   ShippingService
    )
    SELECT 
	   @kItemNew,
	   ShippingServiceID,
	   ShippingServiceAdditionalCost,
	   ShippingServiceCost,
	   ShippingServicePriority,
	   ShippingService
    FROM dbo.ebay_ShippingServiceOptions 
	WHERE dbo.ebay_ShippingServiceOptions.kItem = @kItemOld;

    ----------------------------------------------------------------------
    -- kopiere ebay_InternationalShippingServiceOption 
    ----------------------------------------------------------------------

    INSERT dbo.ebay_InternationalShippingServiceOption
    (
	   kItem,
	   ShippingServiceID,
	   ShippingServiceAdditionalCost,
	   ShippingServiceCost,
	   ShippingServicePriority,
	   ShipToLocation,
	   ShippingService
    )
    SELECT 
	   @kItemNew,
	   ShippingServiceID,
	   ShippingServiceAdditionalCost,
	   ShippingServiceCost,
	   ShippingServicePriority,
	   ShipToLocation,
	   ShippingService
    FROM dbo.ebay_InternationalShippingServiceOption 
	WHERE dbo.ebay_InternationalShippingServiceOption.kItem = @kItemOld;

    ----------------------------------------------------------------------
    -- kopiere ebay_beschreibungstemplate 
    ----------------------------------------------------------------------

    --
    -- berechne PK von neuem Datensatz
    --
    DELETE @NewPrimaryKeyTable;
    INSERT @NewPrimaryKeyTable 
    (
	   NewPrimaryKey
    )
    EXEC spGetAndUpdatePk 'ebay_beschreibungstemplate';
    SET @NewPrimaryKey = (SELECT * FROM @NewPrimaryKeyTable)
    DELETE @NewPrimaryKeyTable;

    INSERT dbo.ebay_beschreibungstemplate
    (
	   kEbayBeschreibungsTemplate,
	   kEbayuser,
	   kItem,
	   cTitel,
	   cH1,
	   cH2,
	   cBody,
	   cVersandhinweis,
	   PaymentInstructions
    )
    SELECT 
	   @NewPrimaryKey,
	   kEbayuser,
	   @kItemNew,
	   cTitel,
	   cH1,
	   cH2,
	   cBody,
	   cVersandhinweis,
	   PaymentInstructions
    FROM dbo.ebay_beschreibungstemplate 
    WHERE dbo.ebay_beschreibungstemplate.kItem = @kItemOld;

    ----------------------------------------------------------------------
    -- kopiere ebay_data_htmltemplatetagcontent 
    ----------------------------------------------------------------------

    --
    -- locke ebay_data_htmltemplatetagcontent (weil im folgenden PKs für neue Datensätze reserviert werden)
    --
	DECLARE @LockResult INT;
    EXEC @LockResult = Sp_getapplock 
	    @Resource = ebay_data_htmltemplatetagcontent, 
	    @LockMode = 'Exclusive', 
	    @LockOwner = 'Transaction', 
	    @LockTimeout = 500, 
	    @DbPrincipal = 'public'; 

    --
    -- berechne neuen PK für ebay_data_htmltemplatetagcontent 
    --
    DELETE @NewPrimaryKeyTable;
    INSERT @NewPrimaryKeyTable 
    (
	    NewPrimaryKey
    )
    EXEC spGetAndUpdatePk 'ebay_data_htmltemplatetagcontent';
    SET @NewPrimaryKey = 
	(
		SELECT * 
		FROM @NewPrimaryKeyTable
	);
    DELETE @NewPrimaryKeyTable;

    --
    -- erhöhe Wert für neue PKs in tpk um relevante Anzahl von Datensätzen
    --
    UPDATE dbo.tpk
	SET nummer = nummer +
		(
			SELECT COUNT(*) 
			FROM dbo.ebay_data_htmltemplatetagcontent 
			WHERE dbo.ebay_data_htmltemplatetagcontent.kEbayItem = @kItemOld
		) - 1
	WHERE cName = 'ebay_data_htmltemplatetagcontent';

    --
    -- kopiere relevante Datensätze (unter Verwendung der neuen PKs)
    --
    WITH Temp AS 
    (
	    SELECT ROW_NUMBER() OVER(ORDER BY kEbayHtmlTemplateTagContent) AS RowNumber, *
	    FROM dbo.ebay_data_htmltemplatetagcontent 
	    WHERE dbo.ebay_data_htmltemplatetagcontent.kEbayItem = @kItemOld
    ) 
    INSERT dbo.ebay_data_htmltemplatetagcontent
    (
	   kEbayHtmlTemplateTagContent,
	   kEbayHtmlTemplate,
	   cTagName,
	   kEbayItem,
	   cTagValue,
	   cTagOptions
    )
    SELECT 
	    @NewPrimaryKey + RowNumber - 1,
	   kEbayHtmlTemplate,
	   cTagName,
	   @kItemNew,
	   cTagValue,
	   cTagOptions
    FROM Temp;

    --
    -- unlocke ebay_data_htmltemplatetagcontent 
    --
    IF (@LockResult >= 0)
    BEGIN
	    EXEC Sp_releaseapplock 
		    @Resource = ebay_data_htmltemplatetagcontent, 
		    @DbPrincipal = 'public', 
		    @LockOwner = 'Transaction'; 
    END;

    ----------------------------------------------------------------------
    -- kopiere ebay_item2kombi
    ----------------------------------------------------------------------

    IF (@SameArtikel = 1)
    BEGIN
	    INSERT dbo.ebay_item2kombi
	    (
		    kItem,
		    kEigenschaftKombi,
		    fPreis,
		    fAnzahl,
		    fMaxAnzahl,
			cEAN,
			fMinAnzahl
	    )
	    SELECT 
		    @kItemNew,
		    kEigenschaftKombi,
		    fPreis,
		    fAnzahl,
		    fMaxAnzahl,
			cEAN,
			fMinAnzahl
	    FROM dbo.ebay_item2kombi
	    WHERE dbo.ebay_item2kombi.kItem = @kItemOld;
	END
    ELSE
	BEGIN
		INSERT dbo.ebay_item2kombi
	    (
		    kItem,
		    kEigenschaftKombi,
		    fPreis,
		    fAnzahl,
		    fMaxAnzahl,
			cEAN,
			fMinAnzahl
	    )
		SELECT 
			@kItemNew,
		    tArtikel.kEigenschaftKombi,
		    CASE WHEN ISNULL(tArtikel.fEbayPreis, 0) = 0 
				THEN tArtikel.fVKNetto * (1 + (tsteuersatz.fSteuersatz / 100)) 
				ELSE tArtikel.fEbayPreis END,
		    CASE WHEN vLagerbestandEx.fVerfuegbar - tArtikel.nPuffer > 0 
				THEN vLagerbestandEx.fVerfuegbar - tArtikel.nPuffer
				ELSE 0 END,
		    CASE WHEN vLagerbestandEx.fVerfuegbar - tArtikel.nPuffer > 0 
				THEN vLagerbestandEx.fVerfuegbar - tArtikel.nPuffer
				ELSE 0 END,
			'',
			1
		FROM tArtikel 
			JOIN vLagerbestandEx ON tArtikel.kVaterArtikel = @kArtikelNew 
				AND vLagerbestandEx.kArtikel = tArtikel.kArtikel
			JOIN tsteuersatz ON tsteuersatz.kSteuerklasse = tartikel.kSteuerklasse 
				AND tsteuersatz.kSteuerzone = @kSteuerzone
	END;

	----------------------------------------------------------------------
	-- kopiere ebay_itemcompatibility/ebay_itemcomp_bike
	----------------------------------------------------------------------

	INSERT dbo.ebay_itemcompatibility
	(
	    --kItemCompatibility - this column value is auto-generated
	    kItem,
	    kType,
	    cMarke,
	    cModell,
	    cTyp,
	    cPlattform,
	    cBaujahr,
	    cMotor,
	    cHSNTSN,
	    cCompatibilityNote
	)
	SELECT 
		@kItemNew,
		kType,
	    cMarke,
	    cModell,
	    cTyp,
	    cPlattform,
	    cBaujahr,
	    cMotor,
	    cHSNTSN,
	    cCompatibilityNote
	FROM dbo.ebay_itemcompatibility 
	WHERE dbo.ebay_itemcompatibility.kItem = @kItemOld;	

	INSERT dbo.ebay_itemcomp_bike
	(
		--kEbay_itemcomp_bike - this column value is auto-generated
		kItem,
		nEpid,
		cMarke,
		cModell,
		cUntermodell,
		cTyp,
		cBaujahr,
		cStrassenname,
		cCcm,
		cCompatibilityNote
	)
	SELECT
		@kItemNew,
		nEpid,
		cMarke,
		cModell,
		cUntermodell,
		cTyp,
		cBaujahr,
		cStrassenname,
		cCcm,
		cCompatibilityNote
	FROM dbo.ebay_itemcomp_bike 
	WHERE dbo.ebay_itemcomp_bike.kItem = @kItemOld;

	----------------------------------------------------------------------
	----------------------------------------------------------------------

	IF (@SameArtikel = 0)
	BEGIN
		--
		-- Ziel-Artikel != Quell-Artikel => ersetze Vorlagenname, Angebotstitel, Preise und Steuer durch entsprechende Angaben von Ziel-Artikel
		--

		--
		-- berechne kSpracheUsed 
		--
		DECLARE @kSpracheUsed INT;
		SET @kSpracheUsed = 
		(
			SELECT dbo.tSpracheUsed.kSprache
			FROM dbo.ebay_item 
				JOIN dbo.ebay_xx_sites ON dbo.ebay_xx_sites.SiteID = dbo.ebay_item.SiteID		
					AND dbo.ebay_item.kItem = @kItemOld
				JOIN dbo.tSpracheUsed ON dbo.tSpracheUsed.cISO = dbo.ebay_xx_sites.cSprachISO
		);

		--
		-- suche nach Name für eBay
		--
		DECLARE @NameTable AS TABLE (Name VARCHAR(255));

		INSERT @NameTable
		(
			Name
		)
		SELECT dbo.tArtikelBeschreibung.cName
		FROM dbo.tArtikelBeschreibung 
		WHERE dbo.tArtikelBeschreibung.kArtikel = @kArtikelNew
			--
			-- eBay
			--
			AND dbo.tArtikelBeschreibung.kPlattform = 30
			AND dbo.tArtikelBeschreibung.kShop = 0
			AND dbo.tArtikelBeschreibung.kSprache = @kSpracheUsed;

		IF ((SELECT COUNT([@NameTable].Name) FROM @NameTable) = 0)
		BEGIN
			--
			-- kein Name für eBay gefunden => nimm Name für Wawi
			--
			INSERT @NameTable
			(
				Name
			)
			SELECT dbo.tArtikelBeschreibung.cName
			FROM dbo.tArtikelBeschreibung 
			WHERE dbo.tArtikelBeschreibung.kArtikel = @kArtikelNew
				--
				-- Wawi
				--
				AND dbo.tArtikelBeschreibung.kPlattform = 1
				AND dbo.tArtikelBeschreibung.kShop = 0
				AND dbo.tArtikelBeschreibung.kSprache = @kSpracheUsed;
		END;

		--
		-- hole Name aus temporärer Tabelle
		--
		DECLARE @Name VARCHAR(255);
		SET @Name = 
		(
			SELECT [@NameTable].Name
			FROM @NameTable 
		);

		--
		-- berechne Steuersatz
		--
		DECLARE @Steuersatz DECIMAL(14, 4);
		SET @Steuersatz = ISNULL(
		(
			SELECT dbo.tSteuersatz.fSteuersatz
			FROM dbo.tArtikel JOIN dbo.tSteuersatz ON dbo.tArtikel.kArtikel = @kArtikelNew
				AND tSteuersatz.kSteuerklasse = tArtikel.kSteuerklasse 
				AND dbo.tSteuersatz.kSteuerzone = @kSteuerzone
		), 0);

		--
		-- berechne Start-/Kaufpreise 
		--
		DECLARE @Preis DECIMAL(14, 4);
		SET @Preis = 
		(
			SELECT 
				(
					CASE WHEN ISNULL(dbo.tArtikel.fEbayPreis, 0) = 0 
					THEN dbo.tartikel.fVKNetto * (1 + (@Steuersatz / 100))
					ELSE dbo.tArtikel.fEbayPreis END
				) * dbo.tWaehrung.fFaktor 			
			FROM dbo.ebay_item 
				JOIN dbo.tArtikel ON dbo.ebay_item.kItem = @kItemNew
					AND dbo.tArtikel.kArtikel = @kArtikelNew
				JOIN dbo.tWaehrung ON dbo.tWaehrung.cEAMapping = dbo.ebay_item.Currency
		);

		--
		-- update neues EbayItem *)
		--
		UPDATE dbo.ebay_item
		SET Templatename = @Name + '  (' + CONVERT(VARCHAR, GETDATE(), 13) + ')',
			Title = SUBSTRING(@Name, 1, 80),
			CategoryMappingAllowed = 1,
			StartPrice = 
			(
				CASE WHEN dbo.ebay_item.ListingType = 'Chinese' 
				THEN 1 
				ELSE @Preis END
			),
			BuyItNowPrice = 
			(
				CASE WHEN dbo.ebay_item.ListingType = 'Chinese' 
				THEN @Preis 
				ELSE 0 END
			),
			VATPercent = @Steuersatz
		WHERE dbo.ebay_item.kItem = @kItemNew;

		----------------------------------------------------------------------
		----------------------------------------------------------------------

		--
		-- füge Artikelmerkmale hinzu **)
		--

		--
		-- hole Artikelmerkmale
		--
		DECLARE @Merkmale AS TABLE (Name VARCHAR(255), Value VARCHAR(255));			
		INSERT @Merkmale
		(
			Name,
			Value
		)
		SELECT DISTINCT dbo.tMerkmalSprache.cName AS cName, dbo.tMerkmalWertSprache.cWert AS cValue
		FROM dbo.ebay_xx_sites 
			JOIN dbo.tSpracheUsed 
				ON ebay_xx_sites.SiteID = 
				(
					SELECT dbo.ebay_item.SiteID 
					FROM dbo.ebay_item 
					WHERE dbo.ebay_item.kItem = @kItemNew
				)
				AND dbo.tSpracheUsed.cISO = dbo.ebay_xx_sites.cSprachISO
			JOIN dbo.tArtikelMerkmal 
				ON tArtikelMerkmal.kArtikel = @kArtikelNew
			JOIN dbo.tMerkmal 
				ON tMerkmal.kMerkmal = tArtikelMerkmal.kMerkmal
				AND dbo.tMerkmal.nVerwendungszweck IN (2, 3)
			JOIN dbo.tMerkmalWert 
				ON tMerkmalWert.kMerkmal = tMerkmal.kMerkmal
				AND tMerkmalWert.kMerkmalWert = tArtikelMerkmal.kMerkmalWert
			JOIN dbo.tMerkmalSprache 
				ON dbo.tMerkmalSprache.kMerkmal = dbo.tMerkmal.kMerkmal 
				AND dbo.tMerkmalSprache.kSprache = dbo.tSpracheUsed.kSprache
			JOIN dbo.tMerkmalWertSprache 
				ON dbo.tMerkmalWertSprache.kMerkmalWert = dbo.tMerkmalWert.kMerkmalWert 
				AND dbo.tMerkmalWertSprache.kSprache = dbo.tSpracheUsed.kSprache;

		--
		-- übergehe Artikelmerkmale die genau so heißen wie Variationen
		--
		DELETE @Merkmale
		FROM @Merkmale 
		WHERE [@Merkmale].Name IN 
		(
			SELECT dbo.tEigenschaftSprache.cName 
			FROM dbo.ebay_item 				
				JOIN dbo.ebay_xx_sites 
					ON ebay_item.kItem = @kItemNew
					AND ebay_xx_sites.SiteID = ebay_item.SiteID
				JOIN dbo.tSpracheUsed 
					ON dbo.tSpracheUsed.cISO = dbo.ebay_xx_sites.cSprachISO
				JOIN dbo.teigenschaft 
					ON teigenschaft.kArtikel = ebay_item.kArtikel
				JOIN dbo.tEigenschaftSprache 
					ON tEigenschaftSprache.kEigenschaft = teigenschaft.kEigenschaft
					AND tEigenschaftSprache.kSprache = tSpracheUsed.kSprache
		)

		--
		-- hole Kategorieattribute die nur 1 Wert annehmen können (Combobox oder benutzerdefiniert);
		-- hierbei werden beide eBay-Kategorien berücksichtigt
		--
		DECLARE @EbaySpecificsMaxOne AS TABLE(cName VARCHAR(255));			
		INSERT @EbaySpecificsMaxOne
		(
			cName
		)
		SELECT dbo.ebay_specific.cName
		FROM dbo.ebay_specific 
		WHERE dbo.ebay_specific.kItem = @kItemNew 
			AND dbo.ebay_specific.cName NOT IN
			(
				SELECT dbo.ebay_xx_isglobalname.cName
				FROM dbo.ebay_item 
				JOIN dbo.ebay_xx_is ON dbo.ebay_item.kItem = @kItemNew 
					AND dbo.ebay_xx_is.CategoryId = ebay_item.PrimaryCategoryId						
					AND ebay_xx_is.SiteID = ebay_item.SiteID
					AND dbo.ebay_xx_is.nMaxValues > 1 -- Listbox
				JOIN dbo.ebay_xx_isglobalname ON ebay_xx_isglobalname.kName = ebay_xx_is.kName
			);
		IF ((SELECT ISNULL(dbo.ebay_item.SecondaryCategoryId, 0) 
			FROM dbo.ebay_item 
			WHERE dbo.ebay_item.kItem = @kItemNew) != 0)
		BEGIN
			INSERT @EbaySpecificsMaxOne
			(
				cName
			)
			SELECT dbo.ebay_specific.cName
			FROM dbo.ebay_specific 
			WHERE dbo.ebay_specific.kItem = @kItemNew 
				AND dbo.ebay_specific.cName NOT IN
				(
					SELECT dbo.ebay_xx_isglobalname.cName
					FROM dbo.ebay_item 
					JOIN dbo.ebay_xx_is ON dbo.ebay_item.kItem = @kItemNew 
						AND dbo.ebay_xx_is.CategoryId = ebay_item.SecondaryCategoryId
						AND ebay_xx_is.SiteID = ebay_item.SiteID
						AND dbo.ebay_xx_is.nMaxValues > 1 -- Listbox
					JOIN dbo.ebay_xx_isglobalname ON ebay_xx_isglobalname.kName = ebay_xx_is.kName
				);
		END;

		--
		-- update Kategorieattribute die nur 1 Wert annehmen können mit Artikelmerkmalen;
		-- Auflösung willkürlich wenn mehrere gleichnamige Artikelmerkmale vorhanden sind
		--
		UPDATE dbo.ebay_specific
		SET cValue = [@Merkmale].[Value]
		FROM dbo.ebay_specific 
		JOIN @EbaySpecificsMaxOne ON dbo.ebay_specific.kItem = @kItemNew 
			AND [@EbaySpecificsMaxOne].cName = dbo.ebay_specific.cName
		JOIN @Merkmale ON [@Merkmale].Name = dbo.ebay_specific.cName;

		--
		-- füge restliche Artikelmerkmale zu Kategorieattributen hinzu;
		-- maximale Anzahlen zulässiger Werte spielen hier keine Rolle weil überschüssige Werte C#-seitig ignoriert werden
		--
		INSERT dbo.ebay_specific
		(
			kItem,
			cName,
			cValue,
			nCustom
		)
		SELECT @kItemNew, [@Merkmale].Name, [@Merkmale].Value, 0
		FROM @Merkmale LEFT JOIN @EbaySpecificsMaxOne ON [@EbaySpecificsMaxOne].cName = [@Merkmale].Name
		WHERE [@EbaySpecificsMaxOne].cName IS NULL;		
	END;

    RETURN;
END;
go

