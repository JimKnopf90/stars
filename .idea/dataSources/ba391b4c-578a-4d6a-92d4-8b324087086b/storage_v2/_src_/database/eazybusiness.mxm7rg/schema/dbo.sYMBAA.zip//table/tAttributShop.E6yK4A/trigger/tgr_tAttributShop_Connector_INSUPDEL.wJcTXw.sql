CREATE TRIGGER [dbo].[tgr_tAttributShop_Connector_INSUPDEL]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP
--
ON [dbo].[tAttributShop]
AFTER UPDATE, INSERT, DELETE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
 
	DECLARE @Komplett AS INT;
	--DECLARE @Preis AS INT;
	--DECLARE @Bestand AS INT;

	SET @Komplett = 1;
	--SET @Preis = 2;
	--SET @Bestand = 4;
	
	--
	-- Artikel vollständig zu Webshops senden, wenn Änderungen vorgenommen wurden
	--
	UPDATE dbo.tArtikelShop
		SET dbo.tArtikelShop.nAktion = dbo.tArtikelShop.nAktion | @Komplett,
			dbo.tArtikelShop.cInet = 'Y',
			dbo.tArtikelShop.nInBearbeitung = 0
	FROM dbo.tArtikelShop
	JOIN dbo.tArtikelAttribut ON dbo.tArtikelAttribut.kArtikel = dbo.tArtikelShop.kArtikel AND dbo.tArtikelAttribut.kShop = 0
	JOIN
	(
		SELECT DELETED.kAttribut, DELETED.kShop
		FROM DELETED		
		UNION (
			SELECT INSERTED.kAttribut, INSERTED.kShop
			FROM INSERTED
		)
	) AS Items ON Items.kAttribut = dbo.tArtikelAttribut.kAttribut AND dbo.tArtikelShop.kShop = Items.kShop
	WHERE  dbo.tArtikelShop.cInet = 'N'
			OR dbo.tArtikelShop.nAktion & @Komplett = 0
			OR dbo.tArtikelShop.nInBearbeitung = 1;

	--
	-- Kategorie vollständig zu Webshops senden, wenn Änderungen vorgenommen wurden
	--
	UPDATE dbo.tKategorieShop
		SET dbo.tKategorieShop.cInet = 'Y'
	FROM dbo.tKategorieShop
	JOIN dbo.tKategorieAttribut ON dbo.tKategorieAttribut.kKategorie = dbo.tKategorieShop.kKategorie AND dbo.tKategorieAttribut.kShop = 0
	JOIN
	(
		SELECT DELETED.kAttribut, DELETED.kShop
		FROM DELETED		
		UNION (
			SELECT INSERTED.kAttribut, INSERTED.kShop
			FROM INSERTED
		)
	) AS Items ON Items.kAttribut = dbo.tKategorieAttribut.kAttribut AND dbo.tKategorieShop.kShop = Items.kShop
	WHERE dbo.tKategorieShop.cInet = 'N';
END
go

