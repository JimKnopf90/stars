CREATE TRIGGER [dbo].[tgr_tSpracheUsed_UPDATE]     
ON [dbo].[tSpracheUsed]     
AFTER UPDATE  
AS     
--       
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: PN
--   
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN 
     --
     -- Wird nur ausgeführt wenn die nStandard sich ändert
     --
	IF UPDATE(nStandard)
	BEGIN
	
		 DELETE dbo.tArtikelSpeicher WITH(ROWLOCK) 
		 FROM dbo.tArtikelSpeicher WITH(ROWLOCK)
		 WHERE dbo.tArtikelSpeicher.nID = 5;
		 
		 INSERT INTO dbo.tArtikelSpeicher WITH(ROWLOCK) (kArtikel,cNummer,nID,nAktiv)
		 SELECT DISTINCT dbo.tArtikelBeschreibung.kArtikel, LTRIM(RTRIM(dbo.tArtikelBeschreibung.cName)) , 5 , CASE WHEN dbo.tOptions.cValue = '1' THEN 1 ELSE 0 END AS nAktiv
		 FROM dbo.tArtikelBeschreibung 
		 LEFT JOIN dbo.tOptions (NOLOCK) ON dbo.tOptions.cKey = 'ArtikelEigenschaft Artikelname'
		 JOIN dbo.tSpracheUsed ON dbo.tArtikelBeschreibung.kSprache = dbo.tSpracheUsed.kSprache AND dbo.tSpracheUsed.nStandard = 1
		 WHERE dbo.tArtikelBeschreibung.cName IS NOT NULL AND dbo.tArtikelBeschreibung.cName <> '' AND dbo.tArtikelBeschreibung.kPlattform = 1;

	END;

END;
go

