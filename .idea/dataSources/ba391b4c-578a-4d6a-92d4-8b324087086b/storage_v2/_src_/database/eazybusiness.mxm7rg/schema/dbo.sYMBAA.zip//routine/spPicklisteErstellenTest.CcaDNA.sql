--- 
--- spPicklisteErstellenTest
---

CREATE PROCEDURE [dbo].[spPicklisteErstellenTest] 
	@kWarenlager INT, 
	@kPicklisteVorlage INT,
	@kBenutzer INT, 
	@kSessionID INT, 
	@kAnzahl INT OUT
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Version: $Rev$
-- Datum: $Date$
-- 06.08.2014
--
AS 
BEGIN	 
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
	--Returnwerte: 
	--positive Zahl X: Pickliste mit der Nummer X wurde erfolgreich angelegt 
	--0: Es konnte nichts reserviert werden, entweder weil kein BEstand da ist oder weil keine Aufträge reserviert werden sollen 
	--(-999999999): Es trat eine Exception auf und es war zu diesem Zeitpunkt noch nichts reserviert 
	--negative Zahl X: Es trat eine Exception auf, zu dem Zeitpunkt waren jedoch schon Positionen reserviert. Diese sind in der Pickliste X enthalten 

	--
	--DECLARE
	--
	DECLARE @cSQLInsert VARCHAR(MAX), @cSQL NVARCHAR(MAX), @cSQLSelect VARCHAR(MAX), @cSQLFROM VARCHAR(MAX), @cSQLWHERE VARCHAR(MAX), @cSQLORDERBY VARCHAR(MAX), @cSQLGROUP VARCHAR(MAX), @cSQLHAVING VARCHAR(MAX);
	DECLARE @nAnzArtMax INT, @nAnzArtMin INT, @nAnzAuftraege INT, @kBestellNr INT, @nSortierung INT, @nErfolgreich INT, @nBoxVon INT, @nBoxBis INT, @nIstNeueLHM INT , @kLHMStatus INT, @nRetourenPlatzReservieren INT;
	DECLARE @kBestellung INT, @nTeilLiefErlaubt INT, @kVersandBox INT, @nAnzReservierterAuftraege INT, @kPickliste INT, @nAnzahlPositionen INT, @nWEPlatzReservieren INT , @nLadenlokalReservieren INT,  @nEinartikelpickliste INT;
	DECLARE @cVersandArten VARCHAR(255), @cWarengruppen VARCHAR(255), @cShops VARCHAR(255), @cPlattformen VARCHAR(255), @cBoxId VARCHAR(30);
     DECLARE @fTeilliefPreis DECIMAL(28,14), @nGewMin DECIMAL(28,14), @nGewMax DECIMAL(28,14) , @cISO VARCHAR(3000);
	DECLARE @cBestellung VARCHAR(255), @cYes VARCHAR(1), @nNichtBezahltVorkommissionieren INT;
	DECLARE @nTeillieferungErlaubt INT, @nVorkommissionieren INT, @nTeillieferungSpeicher INT, @nBestellungWMSFreigabe INT;
	--Der folgende Parameter gibt an, ob es sich um eine RollendeKommissionierung handelt und falls ja (> 0) um welchen kpickwagen
	--Der Pickwagen ist ein kwarenlagerplatz auf dem sich mehrere klhm befinden. Wenn sich X leere LHM auf dem Wagen befinden, wird versucht X bestellungen zu reservieren und jeweils einer BEstellung einer der lhms auf dem pickwagen zuzuweisen
	DECLARE @kRollendeKommissionierungPickwagen INT, @kPicklisteVorlageAktuell INT, @kReineRollendeKommissionierung INT;
	DECLARE @fPreisAuftragMax DECIMAL(28,14);
	DECLARE @fPreisAuftragMin DECIMAL(28,14);
	DECLARE @cAuftragkennzeichnung VARCHAR(MAX);
	DECLARE @cFirmen VARCHAR(MAX);
	DECLARE @cKundengruppen VARCHAR(MAX);
	DECLARE @cVersandklassen VARCHAR(MAX);
	DECLARE @cZahlungsarten VARCHAR(MAX);
	DECLARE @nEnthaeltArtAusWarengruppe TINYINT;
	DECLARE @nAlleOhneWarengruppe TINYINT;
	DECLARE @nAlleOhneVersandart TINYINT;
	DECLARE @nAlleOhneZahlungsart TINYINT;
	DECLARE @cBenutzer VARCHAR(MAX);
	DECLARE @nAuftragsArt TINYINT;
	DECLARE @nArtikelBreiteVon INT;
	DECLARE @nArtikelBreiteBis INT;
	DECLARE @nArtikelHoeheVon INT;
	DECLARE @nArtikelHoeheBis INT;
	DECLARE @nArtikelLaengeVon INT;
	DECLARE @nArtikelLaengeBis INT;
	DECLARE @nAuftragsVolumenVon BIGINT;
	DECLARE @nAuftragsVolumenBis BIGINT;
	DECLARE @nOhneVolumenAusschliessen INT;
 
	BEGIN TRY 
		SET @kAnzahl = 0;
		SET @nAnzReservierterAuftraege = 0;

		SELECT @kReineRollendeKommissionierung = COUNT(*)
		  FROM dbo.twarenlageroptionen WITH(NOLOCK) 
		  WHERE ISNULL(nRollendeKommissionierung,0) = 1
		  AND ISNULL(nVersandboxenProzessmitRoko,0) = 0
		  AND kWarenlager = @kWarenlager;
	
		DELETE FROM tPicklistenVorschauSync WHERE kPicklisteVorlage = @kPicklisteVorlage;

		SET @kPicklisteVorlageAktuell = @kPicklisteVorlage;

		SELECT @nAnzArtMax = nAnzahlArtikelAuftragMax, @nAnzArtMin = nAnzahlArtikelAuftragMin, @nGewMin = fGewichtVon, @nGewMax = fGewichtBis, @nSortierung = nSortierung, 
			   @cVersandArten = cVersandartNr, @cWarengruppen = cWarengruppen, @cPlattformen = cPlattformen, @cShops = cShops, @nAnzAuftraege = nAnzahlBestellungen, @kBestellNr = kBestellNr, 
			   @nBoxVon = ISNULL(nBoxenVon,0), @nBoxBis = ISNULL(nBoxenBis,999999), @nTeilLiefErlaubt = nTeillieferungen, @fTeilliefPreis = fTeillieferungenWert, 
			   @nLadenlokalReservieren = nLadenlokalEinbeziehen, @nWEPlatzReservieren = nWEPlatzReservieren, @nEinartikelpickliste = nEinartikelpickliste , @nRetourenPlatzReservieren = nRetourenplatzReservieren,
			   @kRollendeKommissionierungPickwagen = ISNULL(kRollendeKommissionierungPickwagen,0), @nBestellungWMSFreigabe = ISNULL(nBestellungWMSFreigabe,0), @nNichtBezahltVorkommissionieren = ISNULL(nNichtBezahltVorkommissionieren,0),@cISO = cLieferlaender,
			   @fPreisAuftragMax = fPreisAuftragMax, @fPreisAuftragMin = fPreisAuftragMin,
			   @cAuftragkennzeichnung = cAuftragkennzeichnung,@cFirmen = cFirmen, @cKundengruppen = cKundengruppen, @cVersandklassen = cVersandklassen,@cZahlungsarten = cZahlungsarten,
			   @nEnthaeltArtAusWarengruppe = nEnthaeltArtAusWarengruppe, @nAlleOhneWarengruppe= nAlleOhneWarengruppe, @nAlleOhneVersandart = nAlleOhneVersandart,
			   @nAlleOhneZahlungsart = nAlleOhneZahlungsart, @cBenutzer = cBenutzer,@nAuftragsArt = nAuftragsArt,@nAuftragsArt = nAuftragsArt, @nArtikelBreiteVon = nArtikelBreiteVon, @nArtikelBreiteBis = nArtikelBreiteBis, @nArtikelHoeheVon = nArtikelHoeheVon,  @nArtikelHoeheBis = nArtikelHoeheBis,
			   @nArtikelLaengeVon = nArtikelLaengeVon, @nArtikelLaengeBis = nArtikelLaengeBis, @nAuftragsVolumenVon = nAuftragsVolumenVon, @nAuftragsVolumenBis = nAuftragsVolumenBis, @nOhneVolumenAusschliessen = nOhneVolumenAusschliessen
			FROM dbo.tPicklisteVorlage  WITH(NOLOCK) 
			WHERE kPicklisteVorlage = @kPicklisteVorlageAktuell;

		SET @cSQLSelect = N'DECLARE  cur_Bestellungen CURSOR FAST_FORWARD FOR  SELECT dbo.tBestellung.kBestellung, ISNULL(dbo.tbestellungWMSFreigabe.nTeillieferungErlaubt,0), ISNULL(dbo.tbestellungWMSFreigabe.nVorkommissionieren,0)'; 
		SET @cSQLFROM = N' FROM dbo.tBestellung  WITH(NOLOCK) ' + 
						N' JOIN dbo.tBestellPos  WITH(NOLOCK) ON (dbo.tBestellPos.tBestellung_kBestellung = tbestellung.kBestellung AND (dbo.tBestellpos.nType = 1 OR dbo.tBestellpos.nType = 11)) ' +
				    	N' JOIN Versand.vBestellPosLieferInfoProLager WITH(NOLOCK) ON Versand.vBestellPosLieferInfoProLager.kBestellpos = dbo.tBestellpos.kBestellpos  and Versand.vBestellPosLieferInfoProLager.kWarenlager = '  + CAST(@kWarenlager AS VARCHAR) + 
						N' LEFT JOIN dbo.tbestellungwmsfreigabe WITH(NOLOCK) ON dbo.tbestellungwmsfreigabe.kbestellung = dbo.tbestellung.kBestellung AND dbo.tBEstellungwmsFreigabe.naktiv = 1 ' +
						N' JOIN Versand.vBestellungLieferInfoProLager WITH(NOLOCK) ON Versand.vBestellungLieferInfoProLager.kBestellung = dbo.tBestellung.kBestellung ' +
						N' JOIN dbo.tArtikel WITH(NOLOCK) ON tArtikel.kArtikel = dbo.tBestellPos.tArtikel_kArtikel AND ISNULL(tArtikel.kStueckliste, 0) = 0 ' +
						N' LEFT JOIN dbo.tKunde WITH(NOLOCK) ON dbo.tKunde.kKunde = dbo.tBestellung.tKunde_kKunde' +
						N' LEFT JOIN dbo.tZahlungsart WITH(NOLOCK) ON dbo.tZahlungsart.kZahlungsart = dbo.tBestellung.kZahlungsart ' +  
						N' LEFT JOIN dbo.tUmlagerung  WITH(NOLOCK) ON dbo.tUmlagerung.kBestellung = dbo.tBestellung.kBestellung ' +  
						N' LEFT JOIN dbo.teigenschaft  WITH(NOLOCK) ON teigenschaft.kArtikel = tArtikel.kArtikel  AND teigenschaft.cAktiv = ''Y''  AND tEigenschaft.cTyp != ''PFLICHT-FREIFELD'' ';
						 
		SET @cSQLWHERE = N'  WHERE (dbo.tBestellung.dBezahlt IS NOT NULL OR ISNULL(dbo.tZahlungsart.nAusliefernVorZahlung,0) = 1 OR (  ' + CAST(@nNichtBezahltVorkommissionieren AS VARCHAR) + N' = 1 AND dbo.tbestellungwmsfreigabe.nvorkommissionieren = 1) )' + 
							N' AND (dbo.tbestellungwmsfreigabe.nSperre IS NULL OR dbo.tbestellungwmsfreigabe.nSperre = 0) ' +
							N' AND dbo.tBestellung.nKomplettAusgeliefert = 0 ' + 
							N' AND dbo.tBestellung.nStorno = 0 ' + 
							N' AND (dbo.tartikel.cLagerAktiv = ''Y'') ' + 
							N' AND (dbo.tartikel.cLagerVariation <> ''Y'') ' + 
							N' AND dbo.teigenschaft.kEigenschaft IS NULL '+
							N' AND (dbo.tBestellung.kRueckhalteGrund IS NULL OR dbo.tBestellung.kRueckhalteGrund = 0) ' + 
							N' AND (dbo.tKunde.cSperre IS NULL OR dbo.tKunde.cSperre != ''Y'' )'+
							N' AND (dbo.tUmlagerung.kUmlagerung IS NULL OR (dbo.tUmlagerung.kUmlagerung > 0 AND dbo.tUmlagerung.kQuellLager =  '  + CAST(@kWarenlager AS VARCHAR) + N' ))' +
						    N' AND (Versand.vBestellungLieferInfoProLager.nLieferbarEigen = 2  OR (Versand.vBestellungLieferInfoProLager.nLieferbarEigen = 1 AND (dbo.tbestellungwmsfreigabe.nTeillieferungErlaubt = 1 OR dbo.tbestellungwmsfreigabe.nvorkommissionieren = 1) ) )  ' +
						    N' AND Versand.vBestellungLieferInfoProLager.kWarenlager = ' + CAST(@kWarenlager AS VARCHAR) + N' ' +
							N' AND NOT EXISTS (SELECT kBestellung FROM dbo.tBestellungPicklisteLock  WITH(NOLOCK) WHERE dbo.tBestellungPicklisteLock.kBestellung = dbo.tBEstellung.kBestellung) ' +
							N' AND NOT EXISTS (SELECT * FROM dbo.tpickliste WITH(NOLOCK)  ' +
							N' 		JOIN dbo.tpicklistevorlage WITH(NOLOCK) ON dbo.tpicklistevorlage.kpicklistevorlage = dbo.tpickliste.kpicklistenvorlage  ' +
							N' 		JOIN dbo.tpicklistepos  WITH(NOLOCK) ON dbo.tPicklistepos.kPickliste = dbo.tPickliste.kPickliste  ' +
							N' 		WHERE dbo.tpicklistepos.kbestellung = dbo.tBestellung.kBestellung  ' +
							N' 			AND (dbo.tpicklistevorlage.nEinArtikelPickliste = 1  OR ' +  CAST(ISNULL(@kReineRollendeKommissionierung,0) AS VARCHAR)  + ' > 0) ' +
							N' 			AND dbo.tPicklistePos.nStatus < 40)  '; 

		SET @cSQLGROUP = N' GROUP BY dbo.tBestellung.kBestellung,dbo.tbestellungWMSFreigabe.nTeillieferungErlaubt,dbo.tbestellungWMSFreigabe.nVorkommissionieren '; 
	 
	 
		--Menge einschränken, nur Aufträge die mindestens X Artikel enthalten.
		--Trotzdem muss auch bei 0 dies ausgeführt werden, damit keine Aufträge betrachtet werden, deren Positionen schon komplett reserviert sind 
		IF (@nAnzArtMin > 0)
			SET @cSQLHAVING =  N' HAVING SUM(Versand.vBestellPosLieferInfoProLager.fAnzahlOffen ) >= 0 AND SUM(Versand.vBestellPosLieferInfoProLager.fAnzahlOffen) >= ' +  CAST(@nAnzArtMin AS VARCHAR) + N' ';  	  
		ELSE
			SET @cSQLHAVING =  N' HAVING SUM(Versand.vBestellPosLieferInfoProLager.fAnzahlOffen ) > 0 '; 
 

		IF (@nAnzArtMax != 999999) 
			SET @cSQLHAVING = @cSQLHAVING + N' AND SUM(Versand.vBestellPosLieferInfoProLager.fAnzahlOffen ) <= ' +  CAST(@nAnzArtMax AS VARCHAR) + N' '; 
 


		-- Gewicht der Bestellungen einschränken 
		IF (@nGewMax > 0) 
		BEGIN 
  			SET @cSQLHAVING = @cSQLHAVING + N' AND (1 = dbo.tbestellungwmsfreigabe.nteillieferungErlaubt OR SUM((Versand.vBestellPosLieferInfoProLager.fAnzahlOffen) * tArtikel.fGewicht) < ' + CAST(@nGewMax AS VARCHAR) + ') '; 
		END 
	
		IF (@nGewMin > 0) 
		BEGIN 
		   SET @cSQLHAVING = @cSQLHAVING + N' AND (1 = dbo.tbestellungwmsfreigabe.nteillieferungErlaubt OR SUM((Versand.vBestellPosLieferInfoProLager.fAnzahlOffen) * tArtikel.fGewicht) > ' + CAST(@nGewMin AS VARCHAR) + ') '; 
		END 
	
		IF(@fPreisAuftragMax > 0 OR @fPreisAuftragMin > 0)
		BEGIN
	
		SET @cSQLFROM = @cSQLFROM + N' LEFT JOIN (SELECT CAST(ROUND(SUM((dbo.tbestellpos.nAnzahl*dbo.tbestellpos.fVKNetto*(100-dbo.tbestellpos.fRabatt)/100.0)*(100+dbo.tbestellpos.fMwSt)/100), 2) AS DECIMAL(28,14)) fVKBrutto,dbo.tbestellpos.tBestellung_kBestellung  
                                     FROM dbo.tbestellpos WITH(NOLOCK) 
                                     GROUP by dbo.tbestellpos.tBestellung_kBestellung ) AS b1 ON b1.tBestellung_kBestellung  = dbo.tBestellung.kBestellung ';
	  
	  
		IF @fPreisAuftragMax > 0
			SET @cSQLHAVING = @cSQLHAVING + N' AND MAX (b1.fVKBrutto) <= ' + CAST (@fPreisAuftragMax AS VARCHAR);
	   
		IF @fPreisAuftragMin > 0
			SET @cSQLHAVING = @cSQLHAVING + N' AND MAX (b1.fVKBrutto) >= ' + CAST (@fPreisAuftragMin AS VARCHAR);	  
	END
	
	IF(@nAuftragsArt = 1) 
		BEGIN
			SET @cSQLWHERE = @cSQLWHERE + N' AND dbo.tBestellung.cType = ''U'' ';
		END
		ELSE IF (@nAuftragsArt = 2) 
		BEGIN
			SET @cSQLWHERE = @cSQLWHERE + N' AND dbo.tBestellung.cType = ''B'' ';
		END
		ELSE
		BEGIN
			SET @cSQLWHERE = @cSQLWHERE + N' AND (dbo.tBestellung.cType = ''B'' OR dbo.tBestellung.cType = ''U'') ';
		END
	
		IF (LEN(ISNULL(@cFirmen,'')) > 0)
		BEGIN
		  SET @cSQLWHERE = @cSQLWHERE + N' AND dbo.tBestellung.kFirma IN (' + @cFirmen + N') ';
		END
	
		IF (LEN(ISNULL(@cKundengruppen,'')) > 0)
		BEGIN
		  SET @cSQLWHERE = @cSQLWHERE + N' AND dbo.tKunde.kKundengruppe IN (' + @cKundengruppen + N') ';
		END
	
		IF (LEN(ISNULL(@cVersandklassen,'')) > 0)
		BEGIN
		  SET @cSQLWHERE = @cSQLWHERE + N' AND tArtikel.kVersandklasse IN (' + @cVersandklassen + N') ';
		END
	
		IF (LEN(ISNULL(@cBenutzer,'')) > 0)
		BEGIN
		  SET @cSQLWHERE = @cSQLWHERE + N' AND '  + CAST(@kBenutzer as VARCHAR)+ ' IN (' + @cBenutzer + N') ';
		END
	
	
		IF @nAlleOhneZahlungsart > 0
		BEGIN
		   IF(LEN(ISNULL(@cZahlungsarten,'')) > 0) 
			 SET @cZahlungsarten = @cZahlungsarten + N',0';
		   ELSE
			 SET @cZahlungsarten = N'0';
		END
	
		IF (LEN(ISNULL(@cZahlungsarten,'')) > 0)
		BEGIN
			SET @cSQLWHERE = @cSQLWHERE + N' AND dbo.tBestellung.kZahlungsArt IN (' + @cZahlungsarten + N') ';
		END
	
	
		-- Wo versandart gebraucht wird, joinen
		IF (@cAuftragkennzeichnung like '%4%' OR @cAuftragkennzeichnung like '%8%')  
		BEGIN
			SET @cSQLFROM = @cSQLFROM + N' JOIN dbo.tversandart  WITH(NOLOCK) ON dbo.tVersandart.kVersandart = dbo.tBestellung.tVersandArt_kVersandArt '; 
		END
 
		--Auf Versandarten einschränken, PKs werden als Komma-separierter String übergeben 
		IF @nAlleOhneVersandart > 0
		BEGIN
		   IF(LEN(ISNULL(@cVersandArten,'')) > 0) 
			 SET @cVersandArten = @cVersandArten + N',0';
		   ELSE
			 SET @cVersandArten = N'0';
		END
	
		IF (LEN(ISNULL(@cVersandArten,'')) > 0) 
		BEGIN 
		   SET @cSQLWHERE = @cSQLWHERE + N' AND (dbo.tBestellung.tVersandArt_kVersandArt IN (' + @cVersandArten + N') OR  dbo.tBestellung.tVersandArt_kVersandArt IN (  SELECT dbo.tversandart.kversandart  
																																							FROM dbo.tversandart WITH(NOLOCK)
																																							WHERE dbo.tversandart.nEigeneversandArt = 0
																																						AND dbo.tversandart.kMainVersandart in (' + @cVersandArten + N',0))) ';
		END 

		--Einschränken auf bestimmte Auftragskennzeichnungen z.b. priorisiert, vorkommissionieren, teilliefern
		IF (@cAuftragkennzeichnung like '%1%')
		BEGIN
			SET @cSQLWHERE = @cSQLWHERE + N' AND ISNULL(dbo.tbestellung.nPrio,0) > 0 ';
		END

		IF (@cAuftragkennzeichnung like '%2%')
		BEGIN
			SET @cSQLWHERE = @cSQLWHERE + N' AND ISNULL(dbo.tBestellungWMSFreigabe.nVorkommissionieren,0) = 1 ';
		END

		IF (@cAuftragkennzeichnung like '%3%')
		BEGIN
			SET @cSQLWHERE = @cSQLWHERE + N' AND ISNULL(dbo.tBestellungWMSFreigabe.nTeillieferungErlaubt,0) = 1 ';
		END
	
		IF (@cAuftragkennzeichnung like '%4%')
		BEGIN
			SET @cSQLWHERE = @cSQLWHERE + N' AND ISNULL(dbo.tversandart.nPrioritaet,0) > 0 ';
		END

		IF (  @cAuftragkennzeichnung LIKE '%5%')
		BEGIN
			SET @cSQLWHERE = @cSQLWHERE + N' AND ISNULL(dbo.tBestellung.nPrio,0) = 0 ';
		END

		IF (@cAuftragkennzeichnung LIKE '%6%')
		BEGIN
			SET @cSQLWHERE = @cSQLWHERE + N' AND ISNULL(dbo.tBestellungWMSFreigabe.nVorkommissionieren,0) = 0 ';
		END

		IF (@cAuftragkennzeichnung LIKE '%7%')
		BEGIN
			SET @cSQLWHERE = @cSQLWHERE + N' AND ISNULL(dbo.tBestellungWMSFreigabe.nTeillieferungErlaubt,0) = 0 ';
		END	
	
		IF (@cAuftragkennzeichnung LIKE '%8%')
		BEGIN			
			SET @cSQLWHERE = @cSQLWHERE + N' AND ISNULL(dbo.tversandart.nPrioritaet,0) = 0 ';
		END
	
	
		 IF @nAlleOhneWarengruppe > 0
		 BEGIN
			IF(LEN(ISNULL(@cWarengruppen,'')) > 0) 
				SET @cWarengruppen = @cWarengruppen + N',0';
			ELSE
				SET @cWarengruppen = N'0';
		 END
	   
		--Auf Warengruppen einschränken, PKs werden als Komma-separierter String übergeben 
		IF (LEN(ISNULL(@cWarengruppen,'')) > 0) 
		BEGIN 
	 
			IF(@nEnthaeltArtAusWarengruppe > 0)
			BEGIN

				SET @cSQLFROM = @cSQLFROM + N' JOIN (  SELECT BestPos1.tBestellung_kBestellung 
													   FROM dbo.tbestellpos AS BestPos1 WITH(NOLOCK)
													   JOIN tartikel AS Art1 WITH(NOLOCK) ON BestPos1.tartikel_kartikel = Art1.kartikel
													   AND Art1.kwarengruppe IN  (' + @cWarengruppen + N')
													   GROUP BY BestPos1.tBestellung_kBestellung
								                     ) AS Warengruppen ON  Warengruppen.tBestellung_kBestellung = dbo.tBestellung.kBestellung '

			 END
			 ELSE
			 BEGIN	
				SET @cSQLWHERE = @cSQLWHERE + N' AND NOT EXISTS ( SELECT * FROM dbo.tbestellpos AS BestPos1  WITH(NOLOCK)  ' +
									 N'  JOIN tartikel  AS Art1  WITH(NOLOCK) ON BestPos1.tartikel_kartikel = Art1.kartikel ' +
									 N'  WHERE (BestPos1.ntype = 1 OR BestPos1.nType = 11)' +
									 N'		AND BestPos1.tbestellung_kbestellung = dbo.tbestellung.kbestellung ' +
									 N'		AND Art1.kwarengruppe NOT IN  (' + @cWarengruppen + N')) ';
									 
			END							 
		END 

		
	     IF (@nArtikelBreiteBis > 0 OR @nArtikelHoeheBis > 0  OR @nArtikelLaengeBis > 0 ) 
	     BEGIN

			SET @cSQLWHERE = @cSQLWHERE +  N' AND EXISTS (SELECT count(*)
					  FROM dbo.tbestellpos  WITH(NOLOCK)
					  JOIN dbo.tartikel  WITH(NOLOCK) ON dbo.tbestellpos.tartikel_kartikel = dbo.tartikel.kartikel
					  WHERE dbo.tbestellpos.tbestellung_kbestellung = dbo.tbestellung.kbestellung
					  HAVING ((MAX(dbo.tartikel.fBreite) <= '+CAST(@nArtikelBreiteBis AS VARCHAR)+'  OR '+CAST(@nArtikelBreiteBis AS VARCHAR)+' = 0) AND MIN(dbo.tartikel.fBreite) >= '+CAST(@nArtikelBreiteVon AS VARCHAR)+' 
					  AND (MAX(dbo.tartikel.fHoehe) <=  '+CAST(@nArtikelHoeheBis AS VARCHAR)+'  OR '+CAST(@nArtikelHoeheBis AS VARCHAR)+' = 0) AND MIN(dbo.tartikel.fHoehe) >= '+CAST(@nArtikelHoeheVon AS VARCHAR)+' 
					  AND (MAX(dbo.tartikel.fLaenge) <=  '+CAST(@nArtikelLaengeBis AS VARCHAR)+'  OR '+CAST(@nArtikelLaengeBis AS VARCHAR)+' = 0) AND MIN(dbo.tartikel.fLaenge) >= '+CAST(@nArtikelLaengeVon AS VARCHAR)+' )) ';
		END;


		IF (@nAuftragsVolumenBis > 0 AND @nAuftragsVolumenVon < @nAuftragsVolumenBis) 
		BEGIN

			SET @cSQLWHERE = @cSQLWHERE + N' AND 0 < ( SELECT COUNT(*) FROM
											   			( SELECT SUM(ArtikelVolumen.fVolumen) AS fVolumen, SUM(ArtikelVolumen.HasNullValues) AS HasNullValues
											   			  FROM
															( SELECT (MAX(VolArt.fBreite) * MAX(VolArt.fHoehe) *  MAX(VolArt.fLaenge) * SUM(tbestellpos.nAnzahl)) AS  fVolumen, CASE WHEN MAX(VolArt.fBreite) = 0 OR MAX(VolArt.fHoehe) = 0 OR  MAX(VolArt.fLaenge) = 0 THEN 1 ELSE 0 END AS HasNullValues
											   				  FROM dbo.tbestellpos  WITH(NOLOCK)
											   				  JOIN dbo.tartikel VolArt WITH(NOLOCK) ON dbo.tbestellpos.tartikel_kartikel = VolArt.kartikel
											   				  WHERE dbo.tbestellpos.tbestellung_kbestellung =  dbo.tbestellung.kbestellung
											   				  GROUP BY VolArt.kArtikel ) AS ArtikelVolumen
											   			  HAVING  SUM(ArtikelVolumen.fVolumen) <=  '+CAST(@nAuftragsVolumenBis AS VARCHAR)+' AND  SUM(ArtikelVolumen.fVolumen) >= '+CAST(@nAuftragsVolumenVon AS VARCHAR)+' AND (('+CAST(@nOhneVolumenAusschliessen AS VARCHAR)+' = 1 AND  SUM(ArtikelVolumen.HasNullValues) = 0) OR  '+CAST(@nOhneVolumenAusschliessen AS VARCHAR)+' = 0)
											   			) AS VolumenTest) ';
		END;


		IF (LEN(ISNULL(@cShops,'')) > 0 AND LEN(ISNULL(@cPlattformen,'')) > 0) 
		BEGIN 
			SET @cSQLWHERE = @cSQLWHERE + N' AND (dbo.tBestellung.kShop IN (' + @cShops + N') OR dbo.tBestellung.nPlatform IN (' + @cPlattformen + N'))'; 
		END
 
		IF (LEN(ISNULL(@cShops,'')) > 0 AND LEN(ISNULL(@cPlattformen,'')) = 0) 
		BEGIN 
			SET @cSQLWHERE = @cSQLWHERE + N' AND dbo.tBestellung.kShop IN (' + @cShops + N') '; 
		END
 
		IF (LEN(ISNULL(@cPlattformen,'')) > 0 AND LEN(ISNULL(@cShops,'')) = 0) 
		BEGIN 		
			SET @cSQLWHERE = @cSQLWHERE + N' AND dbo.tBestellung.nPlatform IN (' + @cPlattformen + N') '; 
		END
	  
		IF (@kBestellNr > 0) 
		BEGIN 
			SET @cSQLWHERE = @cSQLWHERE + N' AND dbo.tBestellung.kBestellung = ' + CAST(@kBestellNr AS VARCHAR); 
		END;  
	
		IF (LEN(ISNULL(@cISO,'')) > 0) 
		BEGIN 		
			SET @cSQLFROM = @cSQLFROM + N' JOIN dbo.tlieferadresse  WITH(NOLOCK) ON dbo.tlieferadresse.klieferadresse = dbo.tBestellung.klieferadresse ';
			SET @cSQLWHERE = @cSQLWHERE + N' AND dbo.tlieferadresse.cISO IN  (' + @cISO + N')' ;							    
		END
	
	 
		--Bei 1-Artikel-Picklisten (eazy-Shipping) darf keine Bestellung reserviert werden, welche schon für eine Versandbox vorgesehen ist,
		--da der Auftrag sonst in 2 Teilen rausgeht
		IF (@nEinartikelpickliste = 1)
		BEGIN
			SET @cSQLWHERE = @cSQLWHERE + N' AND NOT EXISTS (SELECT * FROM dbo.tlhm  WITH(NOLOCK) ' +
									N' JOIN dbo.tlhmstatus WITH(NOLOCK) ON dbo.tlhmstatus.klhmstatus = dbo.tlhm.klhmstatus ' +
									N' WHERE dbo.tlhmstatus.nstatus > 10 ' +
									N' AND dbo.tlhm.kWarenlager = ' + CAST(@kWarenlager AS VARCHAR) + ' ' +
									N' AND dbo.tlhmstatus.kbestellung = dbo.tbestellung.kBestellung) ';
		END
	 
		SET @cSQL = @cSQLSelect + @cSQLFROM + @cSQLWHERE + @cSQLGROUP + @cSQLHAVING;    
    
		EXEC sp_executesql @cSQL;
	  
		OPEN cur_Bestellungen   
		FETCH NEXT FROM cur_Bestellungen INTO @kBestellung, @nTeillieferungErlaubt ,@nVorkommissionieren    
	  
		WHILE @@FETCH_STATUS = 0   
		BEGIN   	
			SELECT @cBestellung = cBEstellNr 
			FROM tBEstellung WITH(NOLOCK)  
			WHERE kBestellung = @kBestellung;
 
		SET @kVersandBox = 0;
		SET @nIstNeueLHM = 0;


		--Keine freien Versandboxen mehr vorhanden, trotzdem die kompletten BEstellungen durchlaufen, 
		--weil für eine der Bestellungen evtl. schon eine Box reserviert/belegt sein kann 
	
		SET @nTeillieferungSpeicher = @nTeilLiefErlaubt;
		--Wenn die Bestellung als Teillieferung oder als Zum Vorkommissionieren freigeben deklariert ist, darf auch 
		--bei der Reservierung nur eine Teilmenge reserviert werden. Vorkommissionieren werden darf jedoch nur, wenn mit Versandboxen gearbeitet wird
		IF (@nTeillieferungErlaubt = 1 OR (@nVorkommissionieren = 1 AND @nEinartikelpickliste = 0))
		    SET @nTeilLiefErlaubt = 1;
		ELSE
		    SET @nTeilLiefErlaubt = 0;

		EXEC spBestellungReservierenTest @kPickliste = @kPickliste, @kBestellung = @kBestellung, @kWarenlager = @kWarenlager, @kPicklisteVorlage = @kPicklisteVorlageAktuell, 
		                                @kBenutzer = @kBenutzer, @nAnzArtMin = @nAnzArtMin, @nAnzArtMax = @nAnzArtMax, @nGewMin = @nGewMin, @nGewMax = @nGewMax, 
		                                @nTeilLiefErlaubt = @nTeilLiefErlaubt, @fTeilliefPreis = @fTeilliefPreis, @nWEPlatzReservieren = @nWEPlatzReservieren, @nLadenlokalReservieren = @nLadenlokalReservieren,  
										@nRetourenPlatzReservieren = @nRetourenPlatzReservieren,@nSortierung = @nSortierung, @kSessionID = @kSessionID, @nEinartikelpickliste = @nEinartikelpickliste, 
										@kReineRollendeKommissionierung = @kReineRollendeKommissionierung, @nErfolgreich = @nErfolgreich OUTPUT;
	        			
		SET @nTeilLiefErlaubt = @nTeillieferungSpeicher;     

		IF (@nErfolgreich = 1) 
		BEGIN     
	   		SET @nAnzReservierterAuftraege =  @nAnzReservierterAuftraege + 1;
			SET @kAnzahl = @nAnzReservierterAuftraege;
		END
  
	   FETCH NEXT FROM cur_Bestellungen INTO @kBestellung, @nTeillieferungErlaubt ,@nVorkommissionieren   
	END;
 
	CLOSE cur_Bestellungen;
	DEALLOCATE cur_Bestellungen; 
	  
	INSERT INTO tPicklistenVorschauSync (kPicklisteVorlage,dLastUpdate,nAnzahl) 
	VALUES (@kPicklisteVorlage,GETDATE(),@kAnzahl);
	 
	END TRY 
	BEGIN CATCH	
	   SET  @kAnzahl = -999999999;
	END CATCH	 
END
go

