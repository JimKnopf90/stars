CREATE TRIGGER [dbo].[tgr_tliefartikel_INSUPDEL]  
-- 
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
--  
ON [dbo].[tliefartikel]   
AFTER INSERT, UPDATE, DELETE   
AS   
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN

     DECLARE @TriggerINSERT INT;
	DECLARE @TriggerUPDATE INT;
	DECLARE @TriggerDELETE INT;
	DECLARE @ISInserted INT;
	DECLARE @ISDeleted INT;

	SET @ISInserted = CASE WHEN EXISTS (SELECT * FROM INSERTED) THEN 1 ELSE 0 END;
	SET @ISDeleted = CASE WHEN EXISTS (SELECT * FROM DELETED) THEN 1 ELSE 0 END;

	SET @TriggerINSERT = CASE WHEN @ISInserted = 1 AND @ISDeleted = 0 THEN 1 ELSE 0 END;
	SET @TriggerUPDATE = CASE WHEN @ISInserted = 1 AND @ISDeleted = 1 THEN 1 ELSE 0 END;
	SET @TriggerDELETE = CASE WHEN @ISInserted = 0 AND @ISDeleted = 1 THEN 1 ELSE 0 END;

    	-- Bei Delete, in der Einkaufsliste die Lieferantenzuordnung löschen
	IF(@TriggerDELETE = 1)
	BEGIN

	   UPDATE dbo.tArtikelEinkaufsliste
	   SET kLieferant = NULL
	   FROM dbo.tArtikelEinkaufsliste
	   JOIN DELETED ON DELETED.tArtikel_kArtikel = dbo.tArtikelEinkaufsliste.kArtikel 
	                   AND DELETED.tLieferant_kLieferant = dbo.tArtikelEinkaufsliste.kLieferant;

	END;

	UPDATE dbo.tArtikel 
		SET tArtikel.nLiefertageWennAusverkauft = tliefartikel.nLieferzeit
	FROM dbo.tArtikel
	JOIN dbo.tliefartikel ON tArtikel.kArtikel = tliefartikel.tArtikel_kArtikel
	JOIN 
	(
		SELECT INSERTED.tArtikel_kArtikel
		FROM INSERTED
		JOIN DELETED ON INSERTED.tArtikel_kArtikel = DELETED.tArtikel_kArtikel
		UNION
		SELECT INSERTED.tArtikel_kArtikel
		FROM INSERTED 
		WHERE NOT EXISTS(SELECT DELETED.tArtikel_kArtikel FROM DELETED)
	) AS Result ON Result.tArtikel_kArtikel = tArtikel.kArtikel
	WHERE	tArtikel.nAutomatischeLiefertageberechnung = 1 
			AND tliefartikel.nStandard = 1
			AND tArtikel.nLiefertageWennAusverkauft <> tliefartikel.nLieferzeit;

	IF(@TriggerINSERT = 1 OR @TriggerUPDATE = 1)
	BEGIN

	    --
	    -- dLbGeaendert aktualisieren wenn sich Lieferantenbestand ändert
	    --
	    IF (UPDATE(fLagerbestand))   
	    BEGIN
		    UPDATE dbo.tliefartikel   
		    SET dbo.tliefartikel.dLBGeaendert = GETDATE()   
		    FROM dbo.tliefartikel  
		    JOIN INSERTED ON INSERTED.kLiefArtikel = dbo.tliefartikel.kLiefArtikel
		    LEFT JOIN DELETED ON INSERTED.kLiefArtikel = DELETED.kLiefArtikel
		    WHERE ISNULL(DELETED.fLagerbestand, 0.0) != INSERTED.fLagerbestand;
	    END;


		DECLARE @COUNT INT
		SET @COUNT = 0

		SELECT  @COUNT = COUNT(1) FROM INSERTED 
		   LEFT JOIN DELETED ON INSERTED.kLiefArtikel = DELETED.kLiefArtikel 
		   WHERE (DELETED.tArtikel_kArtikel IS NULL AND INSERTED.tArtikel_kArtikel > 0 AND LEN(INSERTED.cLiefArtNr) > 0)
		   OR (DELETED.tArtikel_kArtikel = INSERTED.tArtikel_kArtikel AND INSERTED.cLiefArtNr != DELETED.cLiefArtNr)


		  -- Falls sich ein neue LieferantenArtikel mit einer LiefArtNr rein kommt, oder ein bestehender geändert wird. Den Artikelspeicher anpassen.
	    IF(@COUNT> 0)
	    BEGIN
			    DELETE dbo.tArtikelSpeicher WITH(ROWLOCK) 
			    FROM dbo.tArtikelSpeicher WITH(ROWLOCK)
			    JOIN INSERTED ON INSERTED.tArtikel_kArtikel = dbo.tArtikelSpeicher.kArtikel
			    WHERE dbo.tArtikelSpeicher.nID = 8;

			    INSERT INTO dbo.tArtikelSpeicher WITH(ROWLOCK) (cNummer,kArtikel,nID,nAktiv)
			    SELECT DISTINCT LTRIM(RTRIM(dbo.tLiefArtikel.cLiefArtNr)) AS Nummer, dbo.tLiefArtikel.tArtikel_kArtikel, 8 AS Art , CASE WHEN dbo.tOptions.cValue = '1' THEN 1 ELSE 0 END AS nAktiv						    
			    FROM dbo.tLiefArtikel  WITH(NOLOCK)
			    JOIN dbo.tArtikel  WITH(NOLOCK) ON tArtikel.kArtikel = dbo.tLiefArtikel.tArtikel_kArtikel  
			    JOIN INSERTED ON INSERTED.tArtikel_kArtikel = dbo.tArtikel.kArtikel
			    LEFT JOIN dbo.tOptions WITH(NOLOCK) ON dbo.tOptions.cKey = 'ArtikelEigenschaft LieferantenArtNummer'
			    WHERE dbo.tLiefArtikel.cLiefArtNr IS NOT NULL  
			    AND dbo.tLiefArtikel.cLiefArtNr <> '';



	    END;

	

	    --Überprüfen ob Trigger gefüllt aufgerufen wird und ob nLagerBeachten oder fLagerbestand geändert wurde
	    IF((SELECT COUNT(1) FROM INSERTED FULL JOIN DELETED ON INSERTED.kLiefArtikel = DELETED.kLiefArtikel 
			    WHERE DELETED.fLagerbestand IS NULL 
				    OR DELETED.nLagerBeachten IS NULL 
				    OR  INSERTED.fLagerbestand <> DELETED.fLagerbestand 
				    OR INSERTED.nLagerBeachten <> DELETED.nLagerBeachten) > 0)
	    BEGIN

		    UPDATE dbo.tliefartikel WITH(ROWLOCK) 
		    SET dbo.tliefartikel.nLagerBeachten = 0
		    FROM dbo.tliefartikel WITH(ROWLOCK)
		    JOIN dbo.tartikel WITH(NOLOCK) ON dbo.tliefartikel.tArtikel_kArtikel = dbo.tartikel.kArtikel
		    JOIN INSERTED ON dbo.tliefartikel.kLiefArtikel = INSERTED.kLiefArtikel
		    WHERE ISNULL(tartikel.kStueckliste, 0) > 0 
			    OR ISNULL(tartikel.nIstVater, 0) > 0 
			    OR ISNULL(tartikel.cLagerVariation, 'N') = 'Y';
		   --
		   -- Lagerbestand berechnen
		   --
		   DECLARE @typeArtikel AS TYPE_spUpdateLagerbestand;

		   INSERT INTO @typeArtikel (kArtikel)
		   SELECT DISTINCT INSERTED.tArtikel_kArtikel
		   FROM INSERTED;
				  
		   EXEC dbo.spUpdateLagerBestand @typeArtikel;		

		   --
		   -- Reservierungen verteilen
		   --
		   DECLARE @Positionen AS XML
		   SET @Positionen = (
			   SELECT DISTINCT dbo.tReserviert.kKey, dbo.tReserviert.kPlattform AS nPlattform
			   FROM dbo.tReserviert WITH(NOLOCK)
			   JOIN INSERTED ON dbo.tReserviert.kArtikel = INSERTED.tArtikel_kArtikel
			   FOR XML PATH('Keys'), TYPE
		   )
		   EXEC dbo.spReservierungAktualisieren @Positionen

		   DELETE FROM dbo.tliefartikel 
		   WHERE dbo.tliefartikel.tLieferant_kLieferant NOT IN (SELECT dbo.tlieferant.kLieferant FROM dbo.tlieferant);

	   END;

     END;

END
go

