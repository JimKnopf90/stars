CREATE VIEW [dbo].[vSteuercache]
AS
	SELECT	Steuercache.kFirma,
			Steuercache.fSteuersatz,
			Steuercache.kSteuerKlasse,
			Steuercache.kSteuerZone
	FROM
	(
		--
		-- Steuerzonen in der DB
		--
		SELECT	dbo.tsteuersatz.kSteuerklasse AS kSteuerKlasse,
				dbo.tsteuersatz.fSteuersatz AS fSteuersatz,
				dbo.tsteuerzone.kFirma AS kFirma,
				dbo.tsteuerzone.kSteuerzone AS kSteuerZone
		FROM dbo.tsteuerzone	
		JOIN dbo.tsteuersatz ON dbo.tsteuerzone.kSteuerzone = dbo.tsteuersatz.kSteuerzone
		JOIN dbo.tsteuerzoneland ON dbo.tsteuerzone.kSteuerzone = dbo.tsteuerzoneland.kSteuerzone
		JOIN
		(
			SELECT TOP 1	0 AS kFirma,
							dbo.tland.cISO AS cIso
			FROM dbo.tfirma
			JOIN dbo.tland ON dbo.tfirma.cLand = dbo.tland.cName
			WHERE dbo.tfirma.cAktiv = 'Y'
			UNION ALL
			SELECT	dbo.tfirma.kFirma AS kFirma,
					dbo.tland.cISO AS cIso
			FROM dbo.tfirma
			JOIN dbo.tland ON dbo.tfirma.cLand = dbo.tland.cName	
		) AS Firmenländer ON dbo.tsteuerzone.kFirma = Firmenländer.kFirma
			AND dbo.tsteuerzoneland.cISO = Firmenländer.cIso
		--
		-- Fallback für Firmen auf Global
		--
		UNION ALL
		SELECT	dbo.tsteuersatz.kSteuerklasse AS kSteuerKlasse,
				dbo.tsteuersatz.fSteuersatz AS fSteuersatz,
				dbo.tfirma.kFirma AS kFirma,
				dbo.tsteuerzone.kSteuerzone AS kSteuerZone
		FROM dbo.tsteuerzone
		CROSS JOIN dbo.tfirma
		LEFT JOIN
		(
			SELECT	dbo.tsteuersatz.kSteuerklasse AS kSteuerKlasse,
					dbo.tsteuersatz.fSteuersatz AS fSteuersatz,
					dbo.tsteuerzone.kFirma AS kFirma,
					dbo.tsteuerzone.kSteuerzone AS kSteuerZone
			FROM dbo.tsteuerzone
			JOIN dbo.tsteuersatz ON dbo.tsteuerzone.kSteuerzone = dbo.tsteuersatz.kSteuerzone
		) AS vorhandeneFirmeneinstellungen ON dbo.tfirma.kFirma = vorhandeneFirmeneinstellungen.kFirma
		JOIN dbo.tsteuersatz ON dbo.tsteuerzone.kSteuerzone = dbo.tsteuersatz.kSteuerzone
		JOIN dbo.tsteuerzoneland ON dbo.tsteuerzone.kSteuerzone = dbo.tsteuerzoneland.kSteuerzone
		JOIN
		(
			SELECT TOP 1	0 AS kFirma,
							dbo.tland.cISO AS cIso
			FROM dbo.tfirma
			JOIN dbo.tland ON dbo.tfirma.cLand = dbo.tland.cName
			WHERE dbo.tfirma.cAktiv = 'Y'
			UNION ALL
			SELECT	dbo.tfirma.kFirma AS kFirma,
					dbo.tland.cISO AS cIso
			FROM dbo.tfirma
			JOIN dbo.tland ON dbo.tfirma.cLand = dbo.tland.cName	
		) AS Firmenländer ON dbo.tsteuerzone.kFirma = Firmenländer.kFirma
			AND dbo.tsteuerzoneland.cISO = Firmenländer.cIso
		WHERE	dbo.tsteuerzone.kFirma = 0
				AND vorhandeneFirmeneinstellungen.kFirma IS NULL
	) AS Steuercache
go

