CREATE TRIGGER [dbo].[tgr_tZahlungsabgleichAusgang_DELETE]  
ON [dbo].[tZahlungsabgleichAusgang]  
AFTER DELETE
AS  
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
    IF((SELECT COUNT(1) FROM DELETED) = 0) 
    BEGIN
	   RETURN;
    END;

    DELETE dbo.tZahlungsabgleichAusgangsLog
    FROM dbo.tZahlungsabgleichAusgangsLog
    JOIN DELETED ON DELETED.kZahlungsabgleichAusgang = dbo.tZahlungsabgleichAusgangsLog.kZahlungsabgleichAusgang
    WHERE dbo.tZahlungsabgleichAusgangsLog.kZahlungsabgleichAusgang = DELETED.kZahlungsabgleichAusgang;
END
go

