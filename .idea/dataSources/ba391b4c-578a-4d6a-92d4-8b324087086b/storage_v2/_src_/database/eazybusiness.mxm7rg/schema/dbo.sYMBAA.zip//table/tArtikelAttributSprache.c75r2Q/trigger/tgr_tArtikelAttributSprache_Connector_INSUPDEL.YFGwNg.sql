CREATE TRIGGER [dbo].[tgr_tArtikelAttributSprache_Connector_INSUPDEL]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP
--
ON [dbo].[tArtikelAttributSprache]
AFTER UPDATE, INSERT, DELETE
AS
SET CONCAT_NULL_YIELDS_NULL ON;
SET ANSI_WARNINGS ON;
SET ANSI_PADDING ON;
SET NOCOUNT ON;
BEGIN
	/*--Überprüfen ob Trigger gefüllt aufgerufen wird
	IF((SELECT COUNT(1) FROM INSERTED FULL JOIN DELETED ON INSERTED.kArtikelAttribut = DELETED.kArtikelAttribut AND INSERTED.kSprache = DELETED.kSprache) = 0)
	BEGIN 
		RETURN;
	END*/
	
	DECLARE @Komplett AS INT;
	--DECLARE @Preis AS INT;
	--DECLARE @Bestand AS INT;

	SET @Komplett = 1;
	--SET @Preis = 2;
	--SET @Bestand = 4;
	
	--
	-- Artikel vollständig an alle Webshops senden in denen die entsprechenden Attribute aktiv sind
	--
	UPDATE dbo.tArtikelShop
		SET dbo.tArtikelShop.nAktion = dbo.tArtikelShop.nAktion | @Komplett,
			dbo.tArtikelShop.cInet = 'Y',
			dbo.tArtikelShop.nInBearbeitung = 0
	FROM dbo.tArtikelShop	
	JOIN dbo.tArtikelAttribut ON dbo.tArtikelAttribut.kArtikel = dbo.tArtikelShop.kArtikel
	JOIN dbo.tAttribut ON dbo.tArtikelAttribut.kAttribut = dbo.tAttribut.kAttribut
	JOIN
	(
		SELECT DELETED.kArtikelAttribut
		FROM DELETED
		UNION
		SELECT INSERTED.kArtikelAttribut
		FROM INSERTED
	) AS Items ON Items.kArtikelAttribut = dbo.tArtikelAttribut.kArtikelAttribut
	JOIN dbo.tAttributShop ON dbo.tAttributShop.kAttribut = dbo.tArtikelAttribut.kAttribut AND dbo.tAttributShop.kShop = tArtikelShop.kShop
	WHERE  dbo.tArtikelShop.cInet = 'N'
			OR dbo.tArtikelShop.nAktion & @Komplett = 0
			OR dbo.tArtikelShop.nInBearbeitung = 1;

	UPDATE dbo.tArtikelShop
		SET dbo.tArtikelShop.nAktion = dbo.tArtikelShop.nAktion | @Komplett,
			dbo.tArtikelShop.cInet = 'Y',
			dbo.tArtikelShop.nInBearbeitung = 0
	FROM dbo.tArtikelShop	
	JOIN dbo.tArtikelAttribut ON dbo.tArtikelAttribut.kArtikel = dbo.tArtikelShop.kArtikel
	JOIN dbo.tAttribut ON dbo.tArtikelAttribut.kAttribut = dbo.tAttribut.kAttribut
		AND dbo.tAttribut.nIstFreifeld = 1
	JOIN
	(
		SELECT DELETED.kArtikelAttribut
		FROM DELETED
		UNION
		SELECT INSERTED.kArtikelAttribut
		FROM INSERTED
	) AS Items ON Items.kArtikelAttribut = dbo.tArtikelAttribut.kArtikelAttribut
	WHERE  dbo.tArtikelShop.cInet = 'N'
			OR dbo.tArtikelShop.nAktion & @Komplett = 0
			OR dbo.tArtikelShop.nInBearbeitung = 1;
END
go

