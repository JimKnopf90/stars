CREATE TRIGGER [dbo].[jtlActionValidator_tWarenLager]
	--
	-- Copyright (c) 2012-2017 by JTL Software GmbH
	-- Datum: $Date$
	-- Version: $Rev$
	-- Autor: MaikS
	--
	ON [dbo].[tWarenLager]
	AFTER DELETE
	AS
	SET NOCOUNT ON;
	SET ANSI_NULLS ON;
	SET ANSI_NULL_DFLT_ON ON;
	SET ANSI_PADDING ON;
	SET CONCAT_NULL_YIELDS_NULL ON;
	SET XACT_ABORT OFF;
	BEGIN
	  IF EXISTS(SELECT 1 FROM DELETED)
	  BEGIN
		--
		-- WarenlagerArtikelOptionen entfernen
		--
			DELETE tWarenlagerArtikelOptionen WITH(ROWLOCK)
			FROM tWarenlagerArtikelOptionen WITH(ROWLOCK)
			JOIN DELETED ON tWarenlagerArtikelOptionen.kWarenLager = DELETED.kWarenLager
				
		--
		-- tWarenLagerAusgang entfernen
		--
			DELETE tWarenLagerAusgang  WITH(ROWLOCK)
			FROM tWarenLagerAusgang  WITH(ROWLOCK)
			JOIN tWarenlagerPlatz WITH(NOLOCK) ON tWarenlagerPlatz.kWarenLagerPlatz = tWarenLagerAusgang.kWarenLagerPlatz			
			JOIN DELETED ON tWarenlagerPlatz.kWarenLager = DELETED.kWarenLager
		--
		-- tWarenLagerEingang entfernen
		--
			DELETE tWarenLagerEingang  WITH(ROWLOCK)
			FROM tWarenLagerEingang  WITH(ROWLOCK)
			JOIN tWarenlagerPlatz  WITH(NOLOCK) ON tWarenlagerPlatz.kWarenLagerPlatz = tWarenLagerEingang.kWarenLagerPlatz			
			JOIN DELETED ON tWarenlagerPlatz.kWarenLager = DELETED.kWarenLager
						
		--
		-- tWarenLagerEingangHistorie entfernen
		--
			DELETE tWarenLagerEingangHistorie  WITH(ROWLOCK)
			FROM tWarenLagerEingangHistorie  WITH(ROWLOCK)
			JOIN tWarenlagerPlatz  WITH(NOLOCK) ON (tWarenlagerPlatz.kWarenLagerPlatz = tWarenLagerEingangHistorie.kWarenLagerPlatzStart	OR tWarenlagerPlatz.kWarenLagerPlatz = tWarenLagerEingangHistorie.kWarenLagerPlatzZiel)			
			JOIN DELETED ON tWarenlagerPlatz.kWarenLager = DELETED.kWarenLager
	
		--
		-- tWarenLagerFulFillmentDienstleister  entfernen
		--
			DELETE tWarenLagerFulFillmentDienstleister  WITH(ROWLOCK)
			FROM tWarenLagerFulFillmentDienstleister  WITH(ROWLOCK)
			JOIN DELETED ON tWarenLagerFulFillmentDienstleister .kWarenLager = DELETED.kWarenLager
			
		--
		-- tWarenLagerOptionen  entfernen
		--
			DELETE tWarenLagerOptionen  WITH(ROWLOCK)
			FROM tWarenLagerOptionen  WITH(ROWLOCK)
			JOIN DELETED ON tWarenLagerOptionen .kWarenLager = DELETED.kWarenLager

				--
		-- tWmsInventurlog  entfernen
		--			
			DELETE tWmsInventurlog   WITH(ROWLOCK)
			FROM tWmsInventurlog   WITH(ROWLOCK)
			JOIN tWarenlagerPlatz  WITH(NOLOCK) ON tWarenlagerPlatz.kWarenLagerPlatz = tWmsInventurlog.kWarenLagerPlatz			
			JOIN DELETED ON tWarenlagerPlatz.kWarenLager = DELETED.kWarenLager


		--
		-- tWarenLagerPlatz  entfernen
		--
			DELETE tWarenLagerPlatz  WITH(ROWLOCK)
			FROM tWarenLagerPlatz  WITH(ROWLOCK)
			JOIN DELETED ON tWarenLagerPlatz .kWarenLager = DELETED.kWarenLager

			
		--
		-- tWarenLagerPrioGlobal  entfernen
		--
			DELETE tWarenLagerPrioGlobal  WITH(ROWLOCK)
			FROM tWarenLagerPrioGlobal  WITH(ROWLOCK)
			JOIN DELETED ON tWarenLagerPrioGlobal .kWarenLager = DELETED.kWarenLager
			
		--
		-- tPickliste  entfernen
		--
			DELETE tPickliste  WITH(ROWLOCK)
			FROM tPickliste  WITH(ROWLOCK)
			JOIN DELETED ON tPickliste .kWarenLager = DELETED.kWarenLager

		--
		-- tFulfillmentAuftrag   entfernen
		--
			DELETE tFulfillmentAuftrag   WITH(ROWLOCK)
			FROM tFulfillmentAuftrag   WITH(ROWLOCK)
			JOIN DELETED ON tFulfillmentAuftrag.kWarenLager = DELETED.kWarenLager
						
		--
		-- tDruckQueue  entfernen
		--
			
			DELETE tDruckQueue  WITH(ROWLOCK)
			FROM tDruckQueue  WITH(ROWLOCK)
			JOIN tWarenlagerPlatz  WITH(NOLOCK) ON tWarenlagerPlatz.kWarenLagerPlatz = tDruckQueue.kWarenLagerPlatz			
			JOIN DELETED ON tWarenlagerPlatz.kWarenLager = DELETED.kWarenLager
			
		--
		-- tWMSInventur   entfernen
		--
			DELETE tWMSInventur   WITH(ROWLOCK)
			FROM tWMSInventur   WITH(ROWLOCK)
			JOIN DELETED ON tWMSInventur .kWarenLager = DELETED.kWarenLager
			
		--
		-- tlagerartikel   entfernen
		--
			DELETE tlagerartikel   WITH(ROWLOCK)
			FROM tlagerartikel  WITH(ROWLOCK)
			JOIN DELETED ON tlagerartikel.kWarenLager = DELETED.kWarenLager
			
		--
		-- tFormularVorlagen anpassen
		--
			UPDATE tFormularVorlage WITH(ROWLOCK)
				SET tFormularVorlage.kWarenLager = 0
			FROM tFormularVorlage WITH(ROWLOCK)
			JOIN DELETED ON tFormularVorlage.kWarenLager = DELETED.kWarenLager

	    --
		-- tArtikelHistory   entfernen
		--
			DELETE tArtikelHistory   WITH(ROWLOCK)
			FROM tArtikelHistory   WITH(ROWLOCK)
			JOIN tWarenlagerPlatz  WITH(NOLOCK) ON tWarenlagerPlatz.kWarenLagerPlatz = tArtikelHistory.kWarenLagerPlatz			
			JOIN DELETED ON tWarenlagerPlatz.kWarenLager = DELETED.kWarenLager

        --
		-- tInventur    entfernen
		--
			DELETE tInventur    WITH(ROWLOCK)
			FROM tInventur    WITH(ROWLOCK)
			JOIN tWarenlagerPlatz  WITH(NOLOCK) ON tWarenlagerPlatz.kWarenLagerPlatz = tInventur.kWarenLagerPlatz			
			JOIN DELETED ON tWarenlagerPlatz.kWarenLager = DELETED.kWarenLager

		--
		-- tLHM     entfernen
		--
			DELETE tLHM   WITH(ROWLOCK)
			FROM tLHM   WITH(ROWLOCK)
			JOIN DELETED ON tLHM .kWarenLager = DELETED.kWarenLager
	END
END
go

