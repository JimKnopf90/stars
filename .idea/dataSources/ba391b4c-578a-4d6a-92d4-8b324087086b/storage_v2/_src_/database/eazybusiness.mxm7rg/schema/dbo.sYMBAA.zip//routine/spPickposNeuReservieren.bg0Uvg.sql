--- 
--- spPickposNeuReservieren
---

CREATE PROCEDURE [dbo].[spPickposNeuReservieren]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--
@kPicklistePos BIGINT , 
@kBenutzer INT , 
@nRet INT OUTPUT
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN TRAN T1;
DECLARE @kArtikel BIGINT;
DECLARE @kWarenlager INT;
DECLARE @cWarenlagerPlatzVon VARCHAR( 255 );
DECLARE @cWarenlagerPlatzbis VARCHAR( 255 );
DECLARE @nWEPlatzReservieren INT;
DECLARE @fAnzahl DECIMAL;
DECLARE @fNochZuReservierendeMenge DECIMAL;
DECLARE @fWLEAnzahlAktuell DECIMAL;
DECLARE @fPickposReservierungsMenge DECIMAL;
DECLARE @kWarenlagerPlatz INT;
DECLARE @kWarenlagerPlatzNeu INT;
DECLARE @kPickliste BIGINT;
DECLARE @nSortierung INT;
DECLARE @kWarenlagerEingang INT;
DECLARE @kBestellPos INT;
DECLARE @kOldPickpos INT;
DECLARE @kBestellung INT;
DECLARE @cLagerBereiche VARCHAR(MAX);
DECLARE @tempLagerbereiche TABLE (kWMSLagerbereich INT);

BEGIN TRY
    SET @nRet = 0;

    -- Infos aus der alten Pickpos holen
    SELECT @kArtikel = tPicklistePos.kArtikel , 
           @kWarenlager = tPicklistePos.kWarenlager , 
           @cWarenlagerPlatzVon = tpicklistevorlage.cWarenlagerPlatzVon , 
           @cWarenlagerPlatzbis = tpicklistevorlage.cWarenlagerPlatzbis , 
           @nWEPlatzReservieren = tpicklistevorlage.nWEPlatzReservieren , 
           @fAnzahl = tPicklistePos.fAnzahl , 
           @kWarenlagerPlatz = tPicklistePos.kWarenlagerPlatz , 
           @kPickliste = tPicklistePos.kPickliste , 
           @nSortierung = tpicklistevorlage.nSortierung , 
           @kBestellPos = tPicklistePos.kBestellPos,
		 @kOldPickpos = tPicklistePos.kPicklistePos,
		 @kBestellung = tPicklistePos.kBestellung,
		 @cLagerBereiche = tpicklistevorlage.cLagerbereiche
    FROM
         dbo.tPicklistePos WITH ( NOLOCK )
         JOIN dbo.tpickliste WITH ( NOLOCK )ON dbo.tpickliste.kPickliste = dbo.tPicklistePos.kPickliste
         LEFT JOIN dbo.tpicklistevorlage WITH ( NOLOCK )ON dbo.tpicklistevorlage.kpicklistevorlage = dbo.tpickliste.kpicklistenvorlage
    WHERE kPicklistePos = @kPicklistePos;


   
     IF(LEN(@cLagerBereiche) > 0)
    BEGIN
	
	   -- Füllt die Temporäre Tabelle, mit werten aus dem komma separierten varchar
	   INSERT INTO @tempLagerbereiche (kWMSLagerbereich) 
	   SELECT  CAST(part as INT) FROM [dbo].[SplitString] (@cLagerBereiche,',');

    END
      

    -- Cursor über die WarenlagerEingaenge die den Anforderungen entsprechen.
    DECLARE cur_WarenlagerEingang CURSOR LOCAL FAST_FORWARD
        FOR SELECT tWarenlagerEingang.kWarenLagerEingang , 
                   tWarenlagerEingang.fAnzahlAktuell - ISNULL( tWarenLagerEingang.fAnzahlReserviertPickpos , 0 ) , 
                   tWarenlagerEingang.kWarenlagerPlatz
            FROM
                 dbo.tWarenLagerEingang WITH ( NOLOCK )
                 JOIN dbo.tWarenLagerPlatz WITH ( NOLOCK )ON dbo.tWarenLagerPlatz.kWarenLagerPlatz = tWarenLagerEingang.kWarenLagerPlatz
                                                     AND dbo.tWarenLagerPlatz.kWarenLager = @kWarenlager
                                                     AND dbo.tWarenLagerPlatz.kWarenLagerPlatz != @kWarenlagerPlatz
										   AND (
											 LEN(@cLagerBereiche) = 0 
											 OR dbo.tWarenLagerPlatz.kWarenLagerPlatz IN (SELECT dbo.tWMSLagerBereichPlatz.kWarenLagerPlatz 
																			  FROM dbo.tWMSLagerBereichPlatz WITH(NOLOCK)
																			  JOIN @tempLagerbereiche AS t1 ON t1.kWMSLagerbereich = dbo.tWMSLagerBereichPlatz.kWMSLagerbereich)
											)
                                                     AND (@cWarenlagerPlatzVon IS NULL
                                                       OR dbo.tWarenlagerPlatz.cName > @cWarenlagerPlatzVon)
                                                     AND (@cWarenlagerPlatzbis IS NULL
                                                       OR dbo.tWarenlagerPlatz.cName < @cWarenlagerPlatzBis)
                                                     AND (dbo.tWarenlagerPlatz.kWarenlagerPlatzTyp IN( 1 , 7 )
                                                       OR @nWEPlatzReservieren = 1
                                                      AND dbo.tWarenlagerPlatz.kWarenlagerPlatzTyp IN( 1 , 3 , 7 ))
                 JOIN dbo.tArtikel WITH ( NOLOCK )ON dbo.tWarenlagerEingang.kArtikel = dbo.tArtikel.kArtikel
                                             AND (dbo.tArtikel.nMHD = 0
                                               OR dbo.tWarenlagerEingang.dMHD < GETDATE( ))
                                                 --Es dürfen keine Chargen/MHD-Pflichtigen Artikel reserviert werden, bei denen es zwei gleiche Chargen/MHDs
                                                 --auf mehr als einem RegalPlatz, BLockplatz,WE gibt
                                                 --Ansonsten kann der spätere verzögerte Pick inkl. Tauschen beim "InDieBoxPacken" bzw. "Verpacken" nicht eindeutig aufgelöst werden
                                             AND (dbo.tArtikel.nCharge = 0
                                              AND dbo.tArtikel.nMHD = 0
                                               OR NOT EXISTS( 
                                                             SELECT dbo.twarenlagereingang.kartikel
                                                             FROM
                                                                  dbo.twarenlagereingang WITH ( NOLOCK )
                                                                  JOIN dbo.tWarenlagerPlatz WITH ( NOLOCK )ON dbo.tWarenlagerPlatz.kwarenlagerplatz = dbo.twarenlagereingang.kwarenlagerplatz
                                                                  JOIN dbo.tartikel WITH ( NOLOCK )ON dbo.twarenlagereingang.kartikel = dbo.tartikel.kartikel
                                                             WHERE(dbo.tartikel.ncharge > 0
                                                                OR dbo.tartikel.nmhd > 0)
                                                              AND dbo.twarenlagereingang.fAnzahlAktuell > 0
                                                              AND dbo.tWarenLagerEingang.kArtikel = @kArtikel
                                                              AND dbo.twarenlagerplatz.kWarenlager = @kWarenlager
                                                              AND dbo.tartikel.kartikel = dbo.tWarenLagerEingang.kArtikel
                                                              AND (dbo.tWarenlagerPlatz.kWarenlagerPlatzTyp IN( 1 , 7 )
                                                                OR @nWEPlatzReservieren = 1
                                                               AND dbo.tWarenlagerPlatz.kWarenlagerPlatzTyp IN( 1 , 3 , 7 ))
                                                             GROUP BY dbo.twarenlagereingang.kartikel , 
                                                                      dbo.twarenlagereingang.cchargennr , 
                                                                      dbo.twarenlagereingang.dmhd
                                                             HAVING COUNT( DISTINCT dbo.tWarenlagerPlatz.kwarenlagerplatz ) > 1 ))
            WHERE dbo.tWarenLagerEingang.kArtikel = @kArtikel
              AND dbo.tWarenLagerEingang.fAnzahlAktuell > 0
            --Es darf kein abgelaufenes MHD reserviert werden
            GROUP BY dbo.tWarenlagerEingang.kWarenLagerEingang , 
                     dbo.tartikel.nmhd , 
                     dbo.tWarenLagerEingang.dErstellt , 
					 dbo.tWarenLagerPlatz.nPrio , 
                     dbo.tWarenLagerPlatz.nsort , 
                     dbo.tWarenLagerPlatz.cName , 
                     dbo.twarenlagereingang.dmhd , 
                     dbo.tWarenlagerEingang.fAnzahlAktuell , 
                     dbo.tWarenlagerEingang.kWarenlagerPlatz , 
                     dbo.tWarenLagerEingang.fAnzahlReserviertPickpos
            HAVING dbo.tWarenlagerEingang.fAnzahlAktuell - ISNULL( dbo.tWarenLagerEingang.fAnzahlReserviertPickpos , 0 ) > 0
            ORDER BY
            --MHD-Artikel werden immer nach MHD ausgelagert
            CASE dbo.tartikel.nmhd WHEN 1 THEN dbo.twarenlagereingang.dmhd
            ELSE 0
            END, 
            CASE 
			WHEN @nSortierung IN(0,9,10,11,12)
				THEN dbo.tWarenLagerEingang.dErstellt
			ELSE NULL
			END
			,CASE 
			WHEN @nSortierung IN(1,5,9) 
				THEN dbo.tWarenLagerPlatz.nPrio
			ELSE NULL
			END DESC
			,CASE 
			WHEN @nSortierung IN(1,5,9) 
				THEN dbo.tWarenLagerPlatz.nsort
			ELSE NULL
			END
			,CASE 
			WHEN @nSortierung IN(2,6,10)
				THEN dbo.tWarenLagerPlatz.cName
			ELSE NULL
			END
			,CASE 
			WHEN @nSortierung IN (3,7,11)
				THEN dbo.tWarenLagerPlatz.nPrio
			ELSE NULL 
			END DESC
			,CASE 
			WHEN @nSortierung IN (3,7,11)
				THEN dbo.tWarenLagerPlatz.nsort
			ELSE NULL
			END DESC
			,CASE 
			WHEN @nSortierung IN (4,8,12)
				THEN dbo.tWarenLagerPlatz.cName
			ELSE NULL
			END DESC;

    SET @fNochZuReservierendeMenge = @fAnzahl;

    --Durchläuft die WarenlagerEingaenge solange, bis genügend Menge reserviert wurde oder bis alle durchsucht wurden
    OPEN cur_WarenlagerEingang;
    FETCH NEXT FROM cur_WarenlagerEingang INTO @kWarenlagerEingang , @fWLEAnzahlAktuell , @kWarenlagerPlatzNeu;
    WHILE @@FETCH_STATUS = 0
        BEGIN

            IF @fNochZuReservierendeMenge > @fWLEAnzahlAktuell
                BEGIN
                    SET @fPickposReservierungsMenge = @fWLEAnzahlAktuell;
                    SET @fNochZuReservierendeMenge = @fNochZuReservierendeMenge - @fWLEAnzahlAktuell;
                END;
            ELSE
                BEGIN
                    SET @fPickposReservierungsMenge = @fNochZuReservierendeMenge;
                    SET @fNochZuReservierendeMenge = 0;
                END;
            --Pickposition erstellen
            INSERT INTO dbo.tPicklistePos WITH( ROWLOCK )( kPickliste , 
                                                       kWarenLager , 
                                                       kWarenLagerEingang , 
                                                       fAnzahl , 
                                                       kBestellPos , 
                                                       kArtikel , 
                                                       kWarenlagerPlatz ,
											kBestellung )
            VALUES( @kPickliste , 
                    @kWarenlager , 
                    @kWarenlagerEingang , 
                    @fPickposReservierungsMenge , 
                    @kBestellPos , 
                    @kArtikel , 
                    @kWarenlagerPlatzNeu,
				@kBestellung );
            SET @kPicklistePos = SCOPE_IDENTITY( );
            INSERT INTO dbo.tPicklistePosStatus WITH( ROWLOCK )( kPicklistePos , 
                                                             nStatus , 
                                                             kBenutzer , 
                                                             dZeitstempel )
            VALUES( @kPicklistePos , 
                    10 , 
                    @kBenutzer , 
                    GETDATE( )); 
		
            --Es wurde genügend Menge reserviert
            IF @fNochZuReservierendeMenge = 0
                BEGIN BREAK;
                END; 

            --Es wurde noch nicht genügend Menge reserviert, es wird nun der nächste WarenlagerEingang geprüft
            FETCH NEXT FROM cur_WarenlagerEingang INTO @kWarenlagerEingang , @fWLEAnzahlAktuell , @kWarenlagerPlatz;
        END; 

    CLOSE cur_WarenlagerEingang;
	DEALLOCATE cur_WarenlagerEingang; 
    -- Alte Pickpos löschen
    DELETE FROM dbo.tPicklistePos WITH( ROWLOCK )
    WHERE kPicklistePos = @kOldPickpos;

    IF @fNochZuReservierendeMenge > 0
        BEGIN
            SET @nRet = 203000159; -- Dies ist nur ein hinweis, kein Rollback
        END;


    IF @nRet >= 0
        BEGIN
            COMMIT TRAN T1;
        END
    ELSE
        BEGIN
            ROLLBACK TRAN T1;
        END;

    SELECT @nRet;
END TRY
BEGIN CATCH
    SELECT-203000105; -- unbekannter Fehler

    DECLARE @text VARCHAR( MAX );
    SET @text = ERROR_MESSAGE( );

    ROLLBACK TRAN T1;
END CATCH;
go

