CREATE VIEW dbo.vLagerbestandProLager
AS
WITH StuecklistenLagerartikel(kArtikel, kWarenlager, fBestand) AS
(
	-- NormaleArtikel
	SELECT kArtikel, kWarenlager, fBestand 
		FROM dbo.tlagerbestandProLagerLagerartikel
	UNION ALL
	-- Stücklisten
	SELECT kArtikel, kWarenlager, fLagerbestand AS fBestand
		FROM dbo.vLagerbestandStuecklisteProLager
)
SELECT kArtikel, kWarenlager, fBestand
	FROM StuecklistenLagerartikel
UNION ALL
SELECT Vater.kArtikel, Result.kWarenlager,CAST(Result.fBestand AS DECIMAL(28,14)) AS fBestand
	FROM dbo.tArtikel AS Vater
	JOIN (
		SELECT Kind.kVaterArtikel, StuecklistenLagerartikel.kWarenlager, SUM(StuecklistenLagerartikel.fBestand) AS fBestand
			FROM StuecklistenLagerartikel
			JOIN dbo.tArtikel AS Kind ON Kind.kVaterArtikel = StuecklistenLagerartikel.kArtikel
			GROUP BY Kind.kVaterArtikel, StuecklistenLagerartikel.kWarenlager
		) AS Result ON Result.kVaterArtikel = Vater.kArtikel
go

