CREATE TRIGGER [dbo].[tgr_tArtikelSichtbarkeit_Connector]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP
--
ON [dbo].[tArtikelSichtbarkeit]
AFTER UPDATE, INSERT, DELETE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
	--Überprüfen ob Trigger gefüllt aufgerufen wird
	IF((SELECT COUNT(1) FROM INSERTED 
		FULL JOIN DELETED ON INSERTED.kArtikel = DELETED.kArtikel
		AND INSERTED.kArtikel = DELETED.kArtikel) = 0)
	BEGIN 
		RETURN;
	END
	
	DECLARE @Komplett AS INT;
	--DECLARE @Preis AS INT;
	--DECLARE @Bestand AS INT;

	SET @Komplett = 1;
	--SET @Preis = 2;
	--SET @Bestand = 4;

	--
	-- Artikel vollständig zu Webshops senden, wenn Änderungen vorgenommen wurden
	--
	UPDATE dbo.tArtikelShop
		SET dbo.tArtikelShop.nAktion = dbo.tArtikelShop.nAktion | @Komplett,
			dbo.tArtikelShop.cInet = 'Y',
			dbo.tArtikelShop.nInBearbeitung = 0
	FROM dbo.tArtikelShop
	JOIN
	(
		SELECT *
		FROM DELETED
		UNION
		SELECT *
		FROM INSERTED
	) AS refreshableItems ON dbo.tArtikelShop.kArtikel = refreshableItems.kArtikel
		AND refreshableItems.kShop = dbo.tArtikelShop.kShop
	WHERE	dbo.tArtikelShop.cInet = 'N'
			OR dbo.tArtikelShop.nAktion & @Komplett = 0
			OR dbo.tArtikelShop.nInBearbeitung = 1;

END
go

