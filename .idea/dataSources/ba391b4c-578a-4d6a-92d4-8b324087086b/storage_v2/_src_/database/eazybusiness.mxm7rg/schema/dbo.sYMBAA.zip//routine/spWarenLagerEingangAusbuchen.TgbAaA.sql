--- 
--- spWarenLagerEingangAusbuchen
---

CREATE PROCEDURE [dbo].[spWarenLagerEingangAusbuchen]
	@kWarenlagereingang INT,
	@fMenge DECIMAL(28,14),
	@cKommentar VARCHAR(255),
	@nBuchungsArt INT,
	@kWarenLager INT,
	@kBenutzer INT,
	@dDatum DATETIME,
	@nRet INT OUTPUT
         
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Author PN
-- Version: $Rev$

-- Funktion: Bucht die Übergebene Menge des Warenlagereingangs aus         
--           Die Prozedur wird bisher nur für Inventur aus WMS verwendet, für weitere verwendungen kann sie entsprechend erweitert werden.         
AS

DECLARE @cLagerKleinerNull VARCHAR(255)
DECLARE @nFulfillment INT
DECLARE @kArtikel INT
DECLARE @fBuchungsMenge DECIMAL(28,14)
DECLARE @cErrorLog VARCHAR(MAX)
DECLARE @kWarenlagerplatz INT

BEGIN TRAN T3
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
	BEGIN TRY
    SET @nRet = 0
	
	SELECT @cLagerKleinerNull = tArtikel.cLagerKleinerNull,@kArtikel = tArtikel.kArtikel, @kWarenlagerplatz = tWarenLagerEingang.kWarenLagerPlatz
		FROM tWarenLagerEingang WITH(NOLOCK)
		JOIN tArtikel WITH(NOLOCK) ON tArtikel.kArtikel =  tWarenLagerEingang.kArtikel
		WHERE  tWarenLagerEingang.kWarenLagerEingang = @kWarenlagereingang
	
	SELECT @nFulfillment = tWarenlager.nFulfillment
		FROM tWarenlager WITH(NOLOCK)
		WHERE kWarenLager = @kWarenLager
     
    IF(@nFulfillment < 2)
    BEGIN
		INSERT INTO tWarenLagerAusgang WITH (ROWLOCK) (kWarenLagerEingang,kWarenLagerPlatz,kLieferscheinPos,kArtikel,fAnzahl,cKommentar,dErstellt,kBenutzer) 
			VALUES (@kWarenlagereingang,@kWarenlagerplatz,0,@kArtikel,@fMenge,@cKommentar,@dDatum,@kBenutzer)
     
        SET @fBuchungsMenge = @fMenge * (-1)         
		EXEC spBestandBuchenManuell
			@kArtikel = @kArtikel,
			@fAnzahl = @fBuchungsMenge,
			@kWarenLagerPlatz = @kWarenlagerplatz,
			@kWareneingang = 0,
			@kPlattform = 1,
			@kBenutzer = @kBenutzer,
			@cKommentar = @cKommentar,
			@kBuchungsart = @nBuchungsArt,
			@kLieferscheinPos = 0
     
		END
		ELSE
		BEGIN      
			IF(@nFulfillment = 2 OR @cLagerKleinerNull = 'Y')
			BEGIN
				INSERT INTO tWarenLagerAusgang WITH (ROWLOCK) (kWarenLagerEingang,kWarenLagerPlatz,kLieferscheinPos,kArtikel,fAnzahl,cKommentar,dErstellt,kBenutzer) 
					VALUES (0,0,0,@kArtikel,@fMenge,@cKommentar,@dDatum,@kBenutzer)
			END
			SET @fBuchungsMenge = @fMenge * (-1)
     
			EXEC spBestandBuchenManuell
				@kArtikel = @kArtikel,
				@fAnzahl = @fBuchungsMenge,
				@kWarenLagerPlatz = 0,
				@kWareneingang = 0,
				@kPlattform = 1,
				@kBenutzer = @kBenutzer,
				@cKommentar = @cKommentar,
				@kBuchungsart = @nBuchungsArt,
				@kLieferscheinPos = 0
		END
		IF @nRet = 0
			COMMIT TRAN T3
		ELSE
			ROLLBACK TRAN T3
	END TRY
	BEGIN CATCH
		ROLLBACK TRAN T3    
		SET @nRet = -203000202 -- unbekannter Fehler Inventur
		SET @cErrorLog = CAST(ERROR_NUMBER() AS VARCHAR) + ' : ' +
                     CAST(ERROR_SEVERITY() AS VARCHAR) + ' : ' +
                     CAST(ERROR_STATE() AS VARCHAR) + ' : ' +
                     CAST(ERROR_PROCEDURE() AS VARCHAR) + ' : ' +
                     CAST(ERROR_LINE() AS VARCHAR) + ' : ' +
                     ERROR_MESSAGE()
		INSERT INTO tLog (dDatum,cLog,kBenutzer,nTyp,nVorgang) 
		VALUES (@dDatum,@cErrorLog,@kBenutzer,16,2)
	END CATCH
go

