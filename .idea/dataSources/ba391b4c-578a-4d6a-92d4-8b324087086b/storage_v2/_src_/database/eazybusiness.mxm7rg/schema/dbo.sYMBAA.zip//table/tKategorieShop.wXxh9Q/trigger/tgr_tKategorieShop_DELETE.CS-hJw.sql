CREATE TRIGGER [dbo].[tgr_tKategorieShop_DELETE]
ON [dbo].[tKategorieShop]
AFTER DELETE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
    IF((SELECT COUNT(1) FROM DELETED) = 0) 
    BEGIN
	   RETURN;
    END;

	--
	-- tQueue schreiben um Kategorien aus Shop zu löschen
	--
	INSERT INTO dbo.tQueue(kShop, kPlattform, cName, kWert, nAction)
	SELECT DELETED.kShop, 2, 'tkategorie', DELETED.kKategorie, 2
	FROM DELETED;

	--
	-- tKategoriebildPlattform loeschen
	--
	UPDATE dbo.tKategoriebildPlattform
		SET dbo.tKategoriebildPlattform.nInet = 0
	FROM dbo.tKategoriebildPlattform
	JOIN DELETED ON dbo.tKategoriebildPlattform.kKategorie = DELETED.kKategorie
		AND dbo.tKategoriebildPlattform.kShop = DELETED.kShop
	WHERE dbo.tKategoriebildPlattform.nInet = 1;	
END
go

