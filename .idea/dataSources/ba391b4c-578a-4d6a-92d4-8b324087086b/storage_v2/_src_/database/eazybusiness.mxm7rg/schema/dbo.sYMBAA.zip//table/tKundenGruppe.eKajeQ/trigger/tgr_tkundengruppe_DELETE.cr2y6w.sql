CREATE TRIGGER tgr_tkundengruppe_DELETE
ON dbo.tkundengruppe
AFTER DELETE
AS
BEGIN
	IF(EXISTS(SELECT DELETED.* 
				FROM DELETED
				JOIN dbo.pf_user ON DELETED.kKundenGruppe = pf_user.kKundengruppe))
	BEGIN
		ROLLBACK;
		RAISERROR('Kundengruppe kann nicht gelöscht werden da sie bei einem Amazonkonto hinterlegt ist', 18,10);
		RETURN;
	END
END
go

