CREATE VIEW [dbo].[vArtikelHistory] AS
SELECT * FROM tArtikelHistory
go

