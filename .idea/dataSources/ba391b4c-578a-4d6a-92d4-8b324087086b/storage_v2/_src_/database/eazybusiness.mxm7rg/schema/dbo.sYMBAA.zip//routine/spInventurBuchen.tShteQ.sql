--- 
--- spInventurBuchen
---

CREATE PROCEDURE [dbo].[spInventurBuchen]
    @kWmsInventur   INT,             -- Die Inventur die Gebucht werden soll
    @kBenutzer      INT,			  -- Der Benutzer der ausbucht
    @kWarenlager    INT,              -- Warenlager der Inventur
    @dBuchungsDatum Datetime,         -- BuchungsDatum , wir nehmen das aus dem WMS
    @nRet           INT OUTPUT        -- Falls != 0 , dann Fehler

-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Author PN
-- Version: $Rev$

-- Funktion: Mit dieser Procedur wird eine WMS Inventur gebucht. Anhand der Differenzen werden Warenlagereingaenge entweder hinzugefügt oder weggebucht
--           Falls bei einer Buchung ein Fehler auftritt, wird ALLES zurückgesetzt. Unbekannte Fehler werden in tLog gespeichert.

	
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
DECLARE @kWarenlagerPlatz      INT;
DECLARE @cPlatzName			   VARCHAR(255);
DECLARE @kArtikel              INT;
DECLARE @dMHD				 DATETIME;
DECLARE @cCharge			 VARCHAR(255);
DECLARE @fMengeIst		      DECIMAL(28,14);
DECLARE @fMengeSoll		      DECIMAL(28,14);
DECLARE @fMengeAktuell	      DECIMAL(28,14);
DECLARE @fDifferenz		      DECIMAL(28,14);
DECLARE @cLagerAktiv		 VARCHAR(255);
DECLARE @kWarenlagereingang    INT;
DECLARE @fBuchungsMenge        DECIMAL(28,14);
DECLARE @fMengeZuBuchen        DECIMAL(28,14);
DECLARE @fAnzahlAktuell	      DECIMAL(28,14);
DECLARE @fAnzahlReserviertPickpos  DECIMAL(28,14);
DECLARE @cLagerArtikel         VARCHAR(255);
DECLARE @nAnfangsMenge		 INT;
DECLARE @cErrorLog		      VARCHAR(MAX);
DECLARE @klagerartikel	      INT;
DECLARE @TableVar		      TABLE(Nummer INT);
DECLARE @fEkNetto             DECIMAL(28,14);

IF(OBJECT_ID('tempdb..#WarenLagerEingaengeInv') IS NOT NULL)
	BEGIN
		DROP TABLE #WarenLagerEingaengeInv;
	END
	CREATE TABLE #WarenLagerEingaengeInv (
		kArtikel INT NOT NULL,
		kWarenLagerPlatz INT NOT NULL,
		kBenutzer INT NOT NULL,
		fAnzahl DECIMAL(28,14) NOT NULL,
		fEKEinzel DECIMAL(28,14) NOT NULL,
	     cChargenNr VARCHAR(255) NULL,
		dMHD DATETIME NULL,
		dErstellt DATETIME NULL,
		cKommentar VARCHAR(255) NULL,
		kGutschriftPos INT NULL,
		fanzahlreserviertPickpos DECIMAL(28,14) NOT NULL,
		kSessionId INT NULL,
		kWarenLagerEingang_Ursprung INT NULL
	);

IF(OBJECT_ID('tempdb..#WarenLagerEingaengeZumAusbuchenInv') IS NOT NULL)
	BEGIN
		DROP TABLE #WarenLagerEingaengeZumAusbuchenInv;
	END
	CREATE TABLE #WarenLagerEingaengeZumAusbuchenInv (
		kWarenLagerEingang INT NOT NULL,
		kLieferscheinPos INT NULL,
		fAnzahl DECIMAL(28,14) NOT NULL,
		cKommentar VARCHAR(MAX) NULL,
		kBenutzer INT NOT NULL,
		kBuchungsart INT NOT NULL
	);

	IF(OBJECT_ID('tempdb..#ArtikelNichtLageraktiv') IS NOT NULL)
	BEGIN
		DROP TABLE #ArtikelNichtLageraktiv;
	END
	CREATE TABLE #ArtikelNichtLageraktiv (
		kArtikel INT NOT NULL
	);

BEGIN TRY
	 SET @nRet = 0;

     DECLARE cur_GetArtikelMengenGrouped CURSOR LOCAL FAST_FORWARD FOR  
     SELECT dbo.tWmsInventurlog.kWarenlagerPlatz,
            dbo.tWmsInventurlog.kArtikel,
            dbo.tWmsInventurlog.dMHD,
            CASE WHEN dbo.tWmsInventurlog.cCharge ='' THEN null ELSE dbo.tWmsInventurlog.cCharge END AS cCharge,
            (SUM(dbo.tWmsInventurlog.fAnzahl) - SUM(dbo.tWmsInventurlog.fDifferenz)) fMengeIst, 
            SUM(dbo.tWmsInventurlog.fAnzahl) fMengeSoll,
            MIN(ISNULL(t2.fMenge,0)) fMengeAktuell,
            SUM(dbo.tWmsInventurlog.fDifferenz) fDifferenz,
            tArtikel.cLagerAktiv,
			dbo.tWarenLagerPlatz.cName,
			tArtikel.cLagerArtikel
     FROM dbo.tWmsInventurlog WITH(NOLOCK)
	 JOIN dbo.tWarenLagerPlatz ON dbo.tWarenLagerPlatz.kWarenLagerPlatz = dbo.tWmsInventurlog.kWarenlagerPlatz
     JOIN dbo.tArtikel WITH(NOLOCK) on dbo.tArtikel.kArtikel = dbo.tWmsInventurlog.kArtikel
     LEFT JOIN [eazybusiness].[dbo].[tBenutzer] WITH(NOLOCK) ON tBenutzer.kBenutzer = dbo.tWmsInventurlog.kBenutzer
     LEFT JOIN (SELECT SUM(ISNULL(dbo.tWarenlagereingang.fAnzahlAktuell,0)) fMenge,dbo.tWarenlagereingang.kWarenlagerPlatz,dbo.tWarenlagereingang.kArtikel,dbo.tWarenlagereingang.dMHD,ISNULL(dbo.tWarenlagereingang.cChargenNr,'') AS cChargenNr
                                                            FROM dbo.tWarenlagereingang WITH(NOLOCK) WHERE dbo.tWarenlagereingang.fAnzahlAktuell > 0 
                                                            GROUP BY dbo.tWarenlagereingang.kWarenlagerPlatz,dbo.tWarenlagereingang.kArtikel,dbo.tWarenlagereingang.dMHD,ISNULL(dbo.tWarenlagereingang.cChargenNr,'')) 
                                                            AS t2 ON t2.kWarenlagerPlatz = dbo.tWmsInventurlog.kWarenlagerPlatz
                                                                    AND t2.kArtikel = dbo.tWmsInventurlog.kArtikel
                                                                    AND (t2.dMHD =  dbo.tWmsInventurlog.dMHD or (t2.dMHD IS NULL AND dbo.tWmsInventurlog.dMHD IS NULL))
                                                                    AND (t2.cChargenNr = dbo.tWmsInventurlog.cCharge OR (t2.cChargenNr IS NULL OR t2.cChargenNr = '' ) AND (dbo.tWmsInventurlog.cCharge IS NULL OR dbo.tWmsInventurlog.cCharge = '' ))
     WHERE dbo.tWmsInventurlog.kWmsInventur = @kWmsInventur
     GROUP BY dbo.tWmsInventurlog.kWarenlagerPlatz,dbo.tWmsInventurlog.kArtikel,dbo.tArtikel.cArtNr,dbo.tWmsInventurlog.dMHD,CASE WHEN dbo.tWmsInventurlog.cCharge ='' THEN null ELSE dbo.tWmsInventurlog.cCharge END,dbo.tArtikel.cLagerAktiv,dbo.tWarenLagerPlatz.cName,tArtikel.cLagerArtikel
     HAVING SUM(dbo.tWmsInventurlog.fDifferenz) <> 0;


     OPEN cur_GetArtikelMengenGrouped 
	 FETCH NEXT FROM cur_GetArtikelMengenGrouped INTO @kWarenlagerPlatz, @kArtikel, @dMHD ,@cCharge ,@fMengeIst ,@fMengeSoll,@fMengeAktuell,@fDifferenz,@cLagerAktiv,@cPlatzName,@cLagerArtikel;
	 WHILE @@FETCH_STATUS = 0 AND @nRet = 0
     BEGIN
     
	 IF(@cLagerAktiv != 'Y')
	 BEGIN

		INSERT INTO #ArtikelNichtLageraktiv (kArtikel) VALUES (@kArtikel);

	 END;

     SET @fMengeZuBuchen = ABS(@fDifferenz);
     
     IF(@fDifferenz < 0) --Wenn weniger gezählt, Warenlagereingänge ausbuchen
     BEGIN

	     --
	     -- Über alle Warenlagereingänge des aktiven Artikels auf dem Platz
	     --
	     DECLARE cur_GetWarenlagerEingaengeForWMSUmbuchung CURSOR LOCAL FAST_FORWARD FOR 
	     SELECT dbo.twarenlagereingang.kWarenLagerEingang,dbo.twarenlagereingang.fAnzahlAktuell,ISNULL(dbo.twarenlagereingang.fAnzahlReserviertPickpos,0) fAnzahlReserviertPickpos,dbo.tartikel.fEKNetto
	     FROM  dbo.twarenlagereingang WITH(NOLOCK)
	     LEFT JOIN dbo.tartikel WITH(NOLOCK) ON dbo.tArtikel.kArtikel = dbo.twarenlagereingang.kartikel 
	     LEFT JOIN dbo.tWarenlagerPlatz WITH(NOLOCK) ON dbo.tWarenlagerPlatz.kWarenlagerPLatz = dbo.tWarenlagerEingang.kWarenlagerPlatz
	     WHERE dbo.tArtikel.kArtikel = @kArtikel
	     AND dbo.tWarenlagerPlatz.kWarenlagerPlatz = @kWarenlagerPlatz 
	     AND fAnzahlAktuell > 0 
	     AND (@dMHD is null OR  CONVERT(VARCHAR(255), dbo.tWarenlagerEingang.dMHD, 104) = CONVERT(VARCHAR(255), @dMHD , 104))
	     AND (LEN(ISNULL(@cCharge,'')) = 0 OR cChargenNr = isnull(@cCharge,''));
         
	     
         OPEN cur_GetWarenlagerEingaengeForWMSUmbuchung 
	     FETCH NEXT FROM cur_GetWarenlagerEingaengeForWMSUmbuchung INTO @kWarenlagereingang,@fAnzahlAktuell,@fAnzahlReserviertPickpos, @fEkNetto
	     WHILE (@@FETCH_STATUS = 0 AND @fMengeZuBuchen > 0 AND @nRet = 0)
         BEGIN
          

            IF(@fAnzahlAktuell - @fAnzahlReserviertPickpos) > @fMengeZuBuchen
               SET @fBuchungsMenge = @fMengeZuBuchen;
            ELSE
               SET @fBuchungsMenge = (@fAnzahlAktuell - @fAnzahlReserviertPickpos);
          
	     
	        INSERT INTO #WarenLagerEingaengeZumAusbuchenInv (kWarenlagerEingang,kLieferscheinPos,fAnzahl,cKommentar,kBenutzer,kBuchungsart) 
	        VALUES (@kWarenlagereingang,null,@fBuchungsMenge,'Inventur vom Platz: ' + CAST(@cPlatzName AS VARCHAR),@kBenutzer,100);
	     
            SET @fMengeZuBuchen = (@fMengeZuBuchen - @fBuchungsMenge);
          
	   FETCH NEXT FROM cur_GetWarenlagerEingaengeForWMSUmbuchung INTO @kWarenlagereingang,@fAnzahlAktuell,@fAnzahlReserviertPickpos, @fEkNetto
       END;
       
       IF(@cLagerArtikel = 'Y')
       BEGIN
		;WITH t AS
		(
			SELECT TOP(CAST (ABS(@fDifferenz) as INT)) *
			FROM dbo.tLagerArtikel WITH (ROWLOCK)
			WHERE kArtikel = @kArtikel
			AND kWarenlager = @kWarenlager
			AND ISNULL(kLieferscheinPos,0) = 0
			ORDER BY CASE cSeriennr when '#$KEINE$#' then 0 else 1 end
		)
		UPDATE t SET kLieferscheinPos = 999999999;
       END;
       
       CLOSE cur_GetWarenlagerEingaengeForWMSUmbuchung;
	   DEALLOCATE cur_GetWarenlagerEingaengeForWMSUmbuchung;

     END;
     
     
     IF(@fDifferenz > 0) --Wenn mehr gezählt als auf Platz, Warenlagereingang erzeugen
     BEGIN
     
       IF(@cLagerArtikel = 'Y') 
       BEGIN
       
	       SET @nAnfangsMenge = CAST (@fMengeZuBuchen as INT);
                     
	       WHILE @nAnfangsMenge > 0
	       BEGIN
	       
               DELETE FROM @TableVar
	           INSERT INTO @TableVar(Nummer) EXEC dbo.spGetAndUpdatePK 'tlagerartikel'
	           SET @klagerartikel = (SELECT Nummer FROM @TableVar);
	          				
	          
	          	INSERT INTO dbo.tlagerartikel  WITH(ROWLOCK) (kLager,kLagerOrt,kArtikel,cSeriennr,fEK,cBeschreibung1,cBeschreibung2,kBestellPos,kLieferscheinPos,kWarenlager,kLieferant) 
	          	VALUES (0,0,@kArtikel,'#$KEINE$#',0,'','',0,0,@kWarenlager,0);
	          
	               SET @nAnfangsMenge = @nAnfangsMenge - 1;
	          END;
       
       END;

	   INSERT INTO #WarenLagerEingaengeInv WITH(ROWLOCK) (kArtikel,kWarenLagerPlatz,kBenutzer,fAnzahl,fEKEinzel,dErstellt,kSessionID,cKommentar,cChargenNr,dMHD,fanzahlreserviertPickpos) 
	   VALUES (@kArtikel,@kWarenlagerPlatz,@kBenutzer,@fMengeZuBuchen,ISNULL(@fEkNetto,0),@dBuchungsDatum,0,'Inventur vom Platz: ' + CAST(@cPlatzName AS VARCHAR) ,@cCharge,@dMHD,0);
     
     END;
     
     FETCH NEXT FROM cur_GetArtikelMengenGrouped INTO @kWarenlagerPlatz, @kArtikel, @dMHD ,@cCharge ,@fMengeIst ,@fMengeSoll,@fMengeAktuell,@fDifferenz,@cLagerAktiv,@cPlatzName,@cLagerArtikel;
     END;


	 DECLARE @xWarenlagerEingaenge XML;
	    SET @xWarenlagerEingaenge = (
	    SELECT kArtikel,kWarenlagerPlatz,kBenutzer,fAnzahl,fEKEinzel,cChargenNr,dMHD,cKommentar,kSessionId,100 AS kBuchungsart, 0 AS kBestellPosUmlagerung,0 AS kRTMRetourePos
	    FROM #WarenLagerEingaengeInv
	    FOR XML PATH('WarenEingang'), TYPE
	    );


     DECLARE @xWarenlagerEingaengeZumAusbuchen XML;
	    SET @xWarenlagerEingaengeZumAusbuchen = (
	    SELECT kWarenLagerEingang,kLieferscheinPos,fAnzahl,cKommentar,kBenutzer,kBuchungsart
	    FROM #WarenLagerEingaengeZumAusbuchenInv
	    FOR XML PATH('WarenAusgang'), TYPE
	    );


	BEGIN TRAN T2

	-- Alle Artikel in der Inventur die nicht lageraktiv waren, lageraktiv machen
	UPDATE dbo.tArtikel SET cLagerAktiv = 'Y'
	FROM dbo.tArtikel
	JOIN #ArtikelNichtLageraktiv ON  #ArtikelNichtLageraktiv.kArtikel = dbo.tArtikel.kArtikel

	IF EXISTS(SELECT * FROM #WarenLagerEingaengeInv)
	BEGIN
	    EXEC dbo.spWarenlagerEingangSchreiben @xWarenlagerEingaenge  = @xWarenlagerEingaenge;
	END;

	IF EXISTS(SELECT * FROM #WarenLagerEingaengeZumAusbuchenInv)
	BEGIN
	    EXEC dbo.spWarenlagerAusgangSchreiben @xWarenlagerEingaengeZumAusbuchen;
	END;

     IF (@nRet = 0)
       COMMIT TRAN T2;
     ELSE
       ROLLBACK TRAN T2;


END TRY
BEGIN CATCH
    
    IF(@@TRANCOUNT > 0)
    BEGIN
       ROLLBACK TRAN T2;
    END;
   
    
    SET @nRet = -203000201; -- unbekannter Fehler Inventur
    SET @cErrorLog = CAST(ERROR_NUMBER() as VARCHAR) + ' : ' +
                     CAST(ERROR_SEVERITY() as VARCHAR) + ' : ' +
                     CAST(ERROR_STATE() as VARCHAR) + ' : ' +
                     CAST(ERROR_PROCEDURE() as VARCHAR) + ' : ' +
                     CAST(ERROR_LINE() as VARCHAR) + ' : ' +
                     ERROR_MESSAGE();


    

    INSERT INTO dbo.tLog WITH(ROWLOCK) (dDatum,cLog,kBenutzer,nTyp,nVorgang) 
    VALUES (@dBuchungsDatum,@cErrorLog,@kBenutzer,16,2);

END CATCH;
go

