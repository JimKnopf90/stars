CREATE FUNCTION [dbo].[ifPickposToBox]( @nWarenlager INT , 
                                   @kPickliste INT )
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor:			GJ
--
RETURNS TABLE
AS
RETURN
WITH StandardArtikel
    AS ( SELECT Artikel.kArtikel , 
                Artikel.cArtNr , 
                Artikel.cBarcode , 
                Artikel.cHAN , 
                Artikel.cASIN , 
                Artikel.cUPC , 
                Artikel.cISBN , 
                Artikel.nCharge , 
                Artikel.nMHD , 
                Artikel.cTeilbar , 
                ArtikelBeschreibung.cName AS cName , 
                VPEEinheitSprache.cName AS cEinheit
         FROM
              dbo.tartikel AS Artikel
              JOIN dbo.tSpracheUsed AS SpracheUsed ON SpracheUsed.nStandard = 1
              JOIN dbo.tArtikelBeschreibung as ArtikelBeschreibung ON ArtikelBeschreibung.kArtikel = Artikel.kArtikel
                                       AND ArtikelBeschreibung.kSprache = SpracheUsed.kSprache
                                       AND ArtikelBeschreibung.kPlattform = 1
              LEFT JOIN dbo.tEinheitSprache AS VPEEinheitSprache ON VPEEinheitSprache.kEinheit = Artikel.kVPEEinheit
                                                            AND VPEEinheitSprache.kSprache = SpracheUsed.kSprache ) , 
Pickpositionen
    AS ( SELECT DISTINCT PicklistePos.kArtikel , 
                         CAST( SUM( CASE WHEN PicklistePos.nStatus < 30 THEN PicklistePos.fAnzahl
                                        ELSE 0
                                    END )AS DECIMAL(28,14) )AS fGesAnzahl , 
                         CAST( SUM( CASE WHEN PicklistePos.nStatus = 30 THEN PicklistePos.fAnzahl
                                        ELSE 0
                                    END )AS DECIMAL(28,14) )AS fGesAnzahlInBox , 
                         ISNULL(WarenLagerEingang.cChargenNr, '') AS cChargenNr , 
                         ISNULL(WarenLagerEingang.dMHD, '') as dMHD , 
                         PicklistePos.kBestellung , 
                         MAX( PicklistePosStatus.dZeitstempel )AS dLastDate
         FROM
              dbo.tPicklistePos AS PicklistePos
              JOIN tPickliste AS Pickliste ON Pickliste.kPickliste = PicklistePos.kPickliste
              JOIN tWarenLagerEingang AS WarenLagerEingang ON WarenLagerEingang.kWarenLagerEingang = PicklistePos.kWarenLagerEingang
              LEFT JOIN tPicklistePosStatus AS PicklistePosStatus ON PicklistePosStatus.kPicklistePosStatus = PicklistePos.kPicklistePosStatus
         WHERE PicklistePos.kPickliste = @kPickliste
           AND PicklistePos.kWarenlager = @nWarenlager
         GROUP BY PicklistePos.kArtikel , 
                  ISNULL(WarenLagerEingang.cChargenNr, '') , 
                  ISNULL(WarenLagerEingang.dMHD, '') , 
                  PicklistePos.kBestellung ) , 
Boxenview
    AS ( SELECT DISTINCT StandardArtikel.cArtNr , 
                         StandardArtikel.cName , 
                         StandardArtikel.cBarcode , 
                         StandardArtikel.cHAN , 
                         StandardArtikel.cASIN , 
                         StandardArtikel.cUPC , 
                         StandardArtikel.cISBN , 
                         StandardArtikel.cEinheit , 
                         StandardArtikel.nCharge , 
                         StandardArtikel.nMHD , 
                         CASE WHEN StandardArtikel.cTeilbar = 'Y' THEN 1
                             ELSE 0
                         END AS nTeilbar , 
                         Pickpositionen.kArtikel , 
                         Pickpositionen.fGesAnzahl , 
                         Pickpositionen.fGesAnzahlInBox , 
                         Pickpositionen.cChargenNr AS cCharge , 
                         Pickpositionen.dMHD , 
                         Pickpositionen.dLastDate , 
                         CONVERT( VARCHAR , Pickpositionen.dMhd , 104 )AS cMhd , 
                         Pickpositionen.kBestellung , 
                         LHM.kLHM , 
                         LHM.cLHMId , 
                         Bestellung.cBestellNr , 
                         CASE WHEN Bild.kBild IS NULL THEN 0
                             ELSE 1
                         END AS nBild
         FROM
              Pickpositionen
              JOIN StandardArtikel ON StandardArtikel.kArtikel = Pickpositionen.kArtikel
              JOIN dbo.tLHMStatus AS LHMStatus ON LHMStatus.kBestellung = Pickpositionen.kBestellung
              JOIN dbo.tLHM AS LHM ON LHM.kLHMStatus = LHMStatus.kLHMStatus
              JOIN tBestellung AS Bestellung ON Bestellung.kBestellung = Pickpositionen.kBestellung
              LEFT JOIN tArtikelbildPlattform AS ArtikelbildPlattform ON ArtikelbildPlattform.kartikel = StandardArtikel.kArtikel
                                             AND ArtikelbildPlattform.kplattform = 10002
              LEFT JOIN tBild AS Bild ON Bild.kBild = ArtikelbildPlattform.kbild ) , 
Sorter
    AS ( SELECT kLHM , 
                MAX( dLastDate )AS maxLastDate , 
                MIN( dLastDate )AS minLastDate , 
                SUM( fGesAnzahl )AS fSumGesAnzahl
         FROM Boxenview
         GROUP BY kLHM )

    SELECT ROW_NUMBER( )OVER( ORDER BY CASE WHEN Sorter.fSumGesAnzahl = 0 THEN CAST( Sorter.maxLastDate AS DECIMAL(28,14) ) * -1
                                           ELSE CAST( Sorter.maxLastDate AS DECIMAL(28,14) )
                                       END DESC , Sorter.maxLastDate DESC , CASE WHEN Boxenview.fGesAnzahl = 0 THEN DATEADD( SECOND , -1 , Sorter.minLastDate )
                                                                                ELSE Boxenview.dLastDate
                                                                            END DESC ) AS rowNumber , 
           Boxenview.* , 
           Sorter.maxLastDate , 
           Sorter.minLastDate
    FROM
         Boxenview
         JOIN Sorter ON Boxenview.kLHM = Sorter.kLHM;
go

