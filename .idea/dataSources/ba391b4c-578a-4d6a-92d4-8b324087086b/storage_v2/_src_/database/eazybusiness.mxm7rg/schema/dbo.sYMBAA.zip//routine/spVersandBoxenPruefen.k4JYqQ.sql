--- 
--- spVersandBoxenPruefen
---

CREATE PROCEDURE [dbo].[spVersandBoxenPruefen]
	@kWarenlager INT
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--  
AS  
BEGIN	  
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF; 
	DECLARE @kBestellung INT
  	DECLARE cur_kBestellung CURSOR LOCAL FAST_FORWARD FOR  
		SELECT tLhmStatus.kBestellung 
			FROM tlhm WITH(NOLOCK)
			JOIN tlhmstatus WITH(NOLOCK) ON tlhmstatus.klhmstatus = tlhm.klhmstatus
			WHERE tlhmstatus.nstatus = 20
				AND tlhm.klhmtyp = 4
				AND tlhm.kwarenlager = @kWarenlager
				AND tlhmstatus.kBestellung > 0 	  
	   
	OPEN cur_kBestellung    
	FETCH NEXT FROM cur_kBestellung INTO @kBestellung     	   
	WHILE @@FETCH_STATUS = 0    
	BEGIN    
		EXEC spVersandBoxBestellungPruefen @kWarenlager = @kWarenlager, @kBestellung = @kBestellung
		FETCH NEXT FROM cur_kBestellung INTO @kBestellung    
	END  	
	CLOSE cur_kBestellung    
	DEALLOCATE cur_kBestellung   
END
go

