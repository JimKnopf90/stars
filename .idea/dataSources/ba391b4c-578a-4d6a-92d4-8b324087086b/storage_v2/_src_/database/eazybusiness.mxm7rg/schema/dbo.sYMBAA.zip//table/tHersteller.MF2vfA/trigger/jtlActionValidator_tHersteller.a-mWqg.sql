CREATE TRIGGER [dbo].[jtlActionValidator_tHersteller]  
--     
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--    
ON [dbo].[tHersteller]  
AFTER DELETE 
AS  
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN 

	--
	--Überprüfen ob Trigger mit Inhalt aufgerufen wird
	--
	IF((SELECT COUNT(1) FROM DELETED) = 0)
	BEGIN
		RETURN;
	END;

	DELETE dbo.tHerstellerBildPlattform
	FROM dbo.tHerstellerBildPlattform
	JOIN DELETED ON dbo.tHerstellerBildPlattform.kHersteller = DELETED.kHersteller

	DELETE dbo.tHerstellerSprache
	FROM dbo.tHerstellerSprache
	JOIN DELETED ON dbo.tHerstellerSprache.kHersteller = DELETED.kHersteller

	UPDATE dbo.tArtikel
		SET dbo.tArtikel.kHersteller = 0
	FROM dbo.tArtikel
	JOIN DELETED ON dbo.tArtikel.kHersteller = DELETED.kHersteller

	DELETE dbo.tQueue
	FROM dbo.tQueue
	JOIN DELETED ON dbo.tQueue.kWert = DELETED.kHersteller
	WHERE dbo.tQueue.cName = 'tHersteller';

	INSERT INTO tQueue(kShop, kPlattform, cName, kWert, nAction)	 
	SELECT dbo.tShop.kShop, 2, 'tHersteller' AS cName, DELETED.kHersteller, 2
	FROM DELETED
	CROSS JOIN dbo.tShop
	
END;
go

