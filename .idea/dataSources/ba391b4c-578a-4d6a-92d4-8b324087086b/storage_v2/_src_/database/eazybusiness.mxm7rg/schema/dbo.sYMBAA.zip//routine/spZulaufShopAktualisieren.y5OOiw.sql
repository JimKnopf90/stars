--- 
--- spZulaufShopAktualisieren
---

CREATE PROCEDURE [dbo].[spZulaufShopAktualisieren] 
--
-- Die SP füllt die Felder dZulaufVerfuegbarAm und nZulaufVerfuegbarAm in tArtikel
--	
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
	BEGIN 
	
	--
	-- Prüfen ob Aktualisierung überhaupt erfolgen soll
	--
	DECLARE @cOptionZulaufAktualisieren AS VARCHAR(30);
	SET @cOptionZulaufAktualisieren = 'ShopZulaufAktualisieren';

	IF(ISNULL((SELECT cValue FROM dbo.tOptions WHERE cKey = @cOptionZulaufAktualisieren), 1) = 0)
	BEGIN
		RETURN;
	END;

	--
	-- Prüfen ob Aktualisierung immer erfolgen soll
	--
	DECLARE @cOptionZulaufImmerAktualisieren AS VARCHAR(30);
	SET @cOptionZulaufImmerAktualisieren = 'ShopZulaufImmerAktualisieren';

	DECLARE @cOptionZuletztAktualisiert AS VARCHAR(30);
	SET @cOptionZuletztAktualisiert = 'ShopZulaufZuletztAktualisiert';

	IF(ISNULL((SELECT cValue FROM dbo.tOptions WHERE cKey = @cOptionZulaufImmerAktualisieren), 1) = 0)
	BEGIN
		--
		-- Prüfen ob die letzte Aktualisierung länger als 24 Stunden her ist
		--
		IF( (SELECT DATEDIFF(hour, CONVERT(DATETIME, (SELECT ISNULL((SELECT cValue FROM dbo.tOptions WHERE cKey = @cOptionZuletztAktualisiert), CONVERT(VARCHAR(20), DATEADD(day, -1, GETDATE())))), 102), GETDATE())) < 24)
		BEGIN
			RETURN;
		END;
	END;

	MERGE INTO dbo.tOptions AS Ziel
	USING (SELECT CONVERT(VARCHAR, GETDATE(), 102) AS Zeitstempel) AS Source
	ON (Ziel.cKey = @cOptionZuletztAktualisiert)
	WHEN MATCHED THEN
		UPDATE SET Ziel.cValue = Source.Zeitstempel
	WHEN NOT MATCHED BY TARGET THEN
		INSERT (cKey, cValue)
		VALUES (@cOptionZuletztAktualisiert, Source.Zeitstempel);

	IF(OBJECT_ID('tempdb..#LieferantenBestellungen') IS NOT NULL)
	BEGIN
		DROP TABLE #LieferantenBestellungen;
	END
	CREATE TABLE #LieferantenBestellungen 
			(
				kLieferantenBestellung INT, 
				dLieferdatum DATETIME,
				nStatus INT,
				kArtikel INT,
				fMenge DECIMAl(28,14),
				fMengeGeliefert DECIMAl(28,14)
			);
	INSERT INTO #LieferantenBestellungen(kLieferantenBestellung, dLieferdatum, nStatus, kArtikel, fMenge,fMengeGeliefert)
		SELECT	dbo.tLieferantenBestellungPos.kLieferantenBestellung,
				CONVERT(DATE, dbo.tLieferantenBestellungPos.dLieferdatum) AS dLieferdatum,
				dbo.tLieferantenBestellung.nStatus,
				dbo.tLieferantenBestellungPos.kArtikel,
				dbo.tLieferantenBestellungPos.fMenge,
				dbo.tLieferantenBestellungPos.fMengeGeliefert
			FROM dbo.tLieferantenBestellungPos
			JOIN dbo.tLieferantenBestellung ON dbo.tLieferantenBestellung.kLieferantenBestellung = dbo.tLieferantenBestellungPos.kLieferantenBestellung
			JOIN
			(
				SELECT kArtikel
				FROM dbo.tArtikelShop
				GROUP BY kArtikel
			)
			AS tartikelShop ON tartikelShop.kArtikel = dbo.tLieferantenBestellungPos.kArtikel
			WHERE dbo.tLieferantenBestellung.nStatus IN(20,30);
				
	DECLARE @tArtikel AS TABLE(kArtikel INT);				
	UPDATE dbo.tArtikel
	SET dZulaufVerfuegbarAm = Result1.Lieferdatum,
		nZulaufVerfuegbarMenge = Result1.Verfuegbar
	OUTPUT INSERTED.kArtikel INTO @tArtikel
	FROM dbo.tArtikel
	JOIN
	(
		SELECT	Result.kArtikel, 
				MIN(Result.dLieferdatum) AS Lieferdatum, 
				MIN(Result.Verfuegbar) AS Verfuegbar
		FROM 
		(
			SELECT  LaufendeSumme.lfd_Sum /*+ dbo.tlagerbestand.fLagerbestandEigen*/ - dbo.tlagerbestand.fInAuftraegen AS Verfuegbar,
					LaufendeSumme.dLieferdatum,
					dbo.tlagerbestand.kArtikel
			FROM dbo.tlagerbestand 
			JOIN 
			(
				SELECT	(	SELECT  SUM( CASE WHEN b.fMenge-b.fMengeGeliefert < 0 THEN 0 ELSE  b.fMenge-b.fMengeGeliefert END)
							FROM #LieferantenBestellungen AS b
							WHERE b.dLieferdatum <= a.dLieferdatum AND a.kArtikel = b.kArtikel
						) lfd_Sum,
						a.kArtikel,
						a.dLieferdatum
				FROM #LieferantenBestellungen AS a
			) AS LaufendeSumme ON LaufendeSumme.kArtikel = dbo.tlagerbestand.kArtikel
			WHERE LaufendeSumme.lfd_Sum + dbo.tlagerbestand.fLagerbestandEigen - dbo.tlagerbestand.fInAuftraegen > 0
		) AS Result
					GROUP BY Result.kArtikel	
	) AS Result1 ON Result1.kArtikel = dbo.tArtikel.kArtikel;

	--
	-- Alle Stücklistenkomponenten-Artikel in Lieferantenbestellungen, die genug komponenten haben um mindistens eine Stückliste aufzufüllen. Das Lieferdatum und die StücklistenAnzahl wird ausgegeben
	--
	WITH LaufendeSumme AS 
	(  	   
		SELECT	dbo.tStueckliste.kArtikel, 
				LaufendeSumme.dLieferdatum AS dLieferdatum,  
				CONVERT(INT, ((LaufendeSumme.lfd_Sum - dbo.tlagerbestand.fInAuftraegen) / tStueckliste.fAnzahl)) AS AnzahlStueckliste
		FROM dbo.tStueckliste
		JOIN dbo.tlagerbestand ON dbo.tlagerbestand.kArtikel = dbo.tStueckliste.kArtikel 
		JOIN 
		(  
			SELECT (	SELECT  SUM( CASE WHEN bestellungen.fMenge-bestellungen.fMengeGeliefert < 0 THEN 0 ELSE bestellungen.fMenge-bestellungen.fMengeGeliefert END)
						FROM #LieferantenBestellungen AS bestellungen
						WHERE	bestellungen.dLieferdatum <= bestellungenRekursiv.dLieferdatum 
								AND bestellungenRekursiv.kArtikel = bestellungen.kArtikel
					) lfd_Sum, bestellungenRekursiv.kArtikel, bestellungenRekursiv.dLieferdatum
			FROM #LieferantenBestellungen AS bestellungenRekursiv 
		) AS LaufendeSumme  ON LaufendeSumme.kArtikel = dbo.tlagerbestand.kArtikel
		WHERE CAST (((LaufendeSumme.lfd_Sum - dbo.tlagerbestand.fInAuftraegen) / tStueckliste.fAnzahl) AS INT) > 0
	)		
	--
	-- Alle Stücklistenväter updaten, anhand der Verfügbarkeit der Kinder. Betrachtet werden die Kinder die zuerst alle Stückliste voll liefern können.
	--
	UPDATE dbo.tArtikel
		SET dZulaufVerfuegbarAm = StuecklistenAnzahl.dLieferdatum,
			nZulaufVerfuegbarMenge = StuecklistenAnzahl.AnzahlStueckliste
	OUTPUT INSERTED.kArtikel INTO @tArtikel
    FROM dbo.tArtikel
	CROSS APPLY 
	(
			SELECT	tStueckliste.kStueckliste AS kStueckliste,   
					CASE WHEN MIN(ISNULL(juengsterArtikel.AnzahlStueckliste, 0)) = 0 
						THEN NULL 
						ELSE MAX(juengsterArtikel.dLieferdatum) 
					END AS dLieferdatum, 
					MIN(ISNULL(juengsterArtikel.AnzahlStueckliste, 0)) AS AnzahlStueckliste
			FROM dbo.tStueckliste
			OUTER APPLY 
			(
				SELECT TOP(1)	LaufendeSumme.dLieferdatum, 
								LaufendeSumme.AnzahlStueckliste, 
								LaufendeSumme.kArtikel    -- Wir brauchen von jedem Artikel nur den jüngsten eintrag
				FROM LaufendeSumme 
				WHERE LaufendeSumme.kArtikel = dbo.tStueckliste.kArtikel 
				ORDER by dLieferdatum 
			) AS juengsterArtikel
			WHERE dbo.tStueckliste.kStueckliste = dbo.tArtikel.kStueckliste 
			GROUP BY  dbo.tStueckliste.kStueckliste
	) AS StuecklistenAnzahl
	WHERE dbo.tArtikel.kStueckliste > 0;

	UPDATE dbo.tArtikel
		SET dZulaufVerfuegbarAm = NULL,
			nZulaufVerfuegbarMenge = 0
	WHERE kArtikel NOT IN (SELECT kArtikel FROM @tArtikel)
		AND dZulaufVerfuegbarAm IS NOT NULL;

END
go

