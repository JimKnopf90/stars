CREATE TRIGGER [dbo].[tgr_tSteuerzoneLand_Connector]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP
--
ON [dbo].[tSteuerzoneLand]
AFTER UPDATE, INSERT, DELETE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN	

	INSERT INTO dbo.tGlobalsQueue (kShop, nType, cName, kKey)
	SELECT dbo.tShop.kShop, 1, 'tSteuer', 1
	FROM dbo.tShop	
	LEFT JOIN dbo.tGlobalsQueue ON dbo.tShop.kShop = dbo.tGlobalsQueue.kShop
		AND dbo.tGlobalsQueue.cName = 'tSteuer'
		AND dbo.tGlobalsQueue.kKey = 1
	WHERE	dbo.tShop.nTyp = 0
			AND dbo.tGlobalsQueue.kKey IS NULL;
				
END
go

