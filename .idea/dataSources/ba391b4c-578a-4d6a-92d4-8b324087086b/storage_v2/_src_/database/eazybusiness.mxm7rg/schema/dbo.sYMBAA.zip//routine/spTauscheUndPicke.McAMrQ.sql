--- 
--- spTauscheUndPicke
---

CREATE PROCEDURE [dbo].[spTauscheUndPicke]
  @kPicklistePos    INT,              -- Pickpos die gepickt werden soll
  @nMenge           DECIMAL(28,14),    -- Menge die gepickt werden soll
  @cCharge          VARCHAR(255),     -- Charge die gepickt werden soll
  @cMHD             VARCHAR(255),     -- MHD das gepickt werden soll
  @kLhm             INT,              -- Auf dieses LHM wird gepickt, falls 0 wird keine umlagerung gemacht
  @kBenutzer        INT,              
  @nStatusNachPick  INT,              -- Der Status der Pickpos nach dem Pick
  @nRestmengeLoeschen INT,            -- 1 = Es werden die Restmengen von dem Warenlagereingang von dem wir absplitten gelöscht
  @nRet             INT OUT

--  
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- 

-- Funktion:
-- Diese Procedur versucht die übergebene Menge für die Pickposition zu picken. Falls Charge oder MHD übergeben wurden, kann ein tausch der Warenlagereingänge stattfinden, damit die richtige Charge/MHD gepicket wird.
  
AS

SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;

	DECLARE @kWarenLagerPlatz INT -- Warenlagerplatz der übergebenen Pickpos
	DECLARE @kArtikel         INT  -- Artikel der übergebenen Pickpos
	DECLARE @kWarenLagerEingang INT  -- Warenlagereingang des Tauschpartners
	DECLARE @nPPIdent         INT -- ID ob der des Tauschpartner eine Pickpos hat
	DECLARE @fAnzahlAktuell   DECIMAL(28,14) -- PickposAnzahl des Tauschpartners
	DECLARE @fGesAnzahl       DECIMAL(28,14) -- Die gesammte Menge die noch gepickt werden soll
	DECLARE @kIsPicklistePos  INT  -- Die aktuelle Pickpositiion die gepickt werden soll
	DECLARE @kTauschPicklistePos INT -- Die  Pickposition des Tauschpartners
	DECLARE @kWarenLagerEingangQuell INT -- Warenlagereingang des aktuellen picks
	DECLARE @dPLTimestamp     DATETIME -- Zeitstempel -> Systemzeit
	DECLARE @kNewPicklistePos INT;	-- Pickpos
	DECLARE @kNewTauschPicklistePos INT;

	BEGIN 
		SET @nRet = 0;

		SELECT @kWarenLagerPlatz = dbo.tWarenLagerEingang.kWarenLagerPlatz, @kArtikel = dbo.tWarenLagerEingang.kArtikel
			FROM dbo.tPicklistePos WITH(NOLOCK)
			JOIN dbo.tWarenLagerEingang WITH(NOLOCK) ON dbo.tWarenLagerEingang.kWarenLagerEingang = dbo.tPicklistePos.kWarenLagerEingang
			WHERE dbo.tPicklistePos.kPicklistePos = @kPicklistePos


		-- Virtuelle Tabelle erstellen
		-- Sucht alle Warenlagereingänge die mit dem übergebenen Eingaben übereinstimmen (charge,mhd,platz). Es wird unterschieden zwischen Warenlagereingängen die in einer pickpos sind und den ohne
		SELECT  kWarenLagerEingang,nPPIdent,fAnzahlAktuell,kPicklistePos
			INTO #TempWarenLagerEingang 
			FROM(
				SELECT dbo.tWarenLagerEingang.kWarenLagerEingang, 1 AS nPPIdent,tPicklistePos.fAnzahl AS fAnzahlAktuell,dbo.tPicklistePos.kPicklistePos kPicklistePos
					FROM dbo.tWarenLagerEingang WITH(NOLOCK)
					JOIN dbo.tPicklistePos WITH(NOLOCK) ON dbo.tPicklistePos.kWarenLagerEingang = dbo.tWarenLagerEingang.kWarenLagerEingang AND dbo.tPicklistePos.nStatus < 40
					WHERE (
							@cCharge IS NULL 
							OR dbo.tWarenLagerEingang.cChargenNr = @cCharge
							)
						AND (
							@cMHD IS NULL 
							OR CONVERT(VARCHAR,tWarenlagerEingang.dMHD, 104) = @cMHD
							)
						AND dbo.tWarenLagerEingang.fAnzahlAktuell > 0
						AND dbo.tWarenLagerEingang.kWarenLagerPlatz = @kWarenLagerPlatz
						AND dbo.tWarenLagerEingang.kArtikel = @kArtikel
				UNION
				SELECT dbo.tWarenLagerEingang.kWarenLagerEingang, 0 AS nPPIdent,(dbo.tWarenLagerEingang.fAnzahlAktuell-dbo.twarenlagereingang.fAnzahlReserviertPickpos) AS fAnzahlAktuell, NULL AS kPicklistePos
					FROM dbo.tWarenLagerEingang WITH(NOLOCK)
					WHERE (
							@cCharge IS NULL 
							OR dbo.tWarenLagerEingang.cChargenNr = @cCharge
							)
						AND (
							@cMHD IS NULL
							OR CONVERT(VARCHAR,dbo.tWarenlagerEingang.dMHD, 104) = @cMHD
							)
						AND dbo.tWarenLagerEingang.fAnzahlAktuell-dbo.twarenlagereingang.fAnzahlReserviertPickpos > 0
						AND dbo.tWarenLagerEingang.kWarenLagerPlatz = @kWarenLagerPlatz
						AND dbo.tWarenLagerEingang.kArtikel = @kArtikel
				) AS T1
			ORDER BY nPPIdent,
				CASE WHEN fAnzahlAktuell = @nMenge 
					THEN 0 
					ELSE 1 
				END,
				fAnzahlAktuell DESC;

		DECLARE cur_GetWarenLagerEingang CURSOR LOCAL FAST_FORWARD FOR  
		SELECT * FROM #TempWarenLagerEingang;

		SET @fGesAnzahl = @nMenge;
		SET @kIsPicklistePos = @kPicklistePos;
		SET @dPLTimestamp = GETDATE();

		-- Holt sich den nächsten passenden Warenlagereingang um ihn zu picken
		OPEN cur_GetWarenLagerEingang    
		FETCH NEXT FROM cur_GetWarenLagerEingang INTO  @kWarenLagerEingang,@nPPIdent,@fAnzahlAktuell,@kTauschPicklistePos;
  
		-- Keinen gefunden -> Ende. 
		-- Kein Fehler, Warenlageringang gefunden und GesammtAnzahl noch nicht gepickt -> Weitermachen.
		WHILE (@@FETCH_STATUS = 0  and @nRet >= 0 AND @fGesAnzahl > 0)
		BEGIN  
			SET @kNewPicklistePos = 0;

			IF(@kWarenLagerEingang IS NULL)
			BEGIN
				SET @nRet = -203000022; -- Keinen Tauschpartner gefunden
				BREAK;
			END

			IF(@fGesAnzahl > @fAnzahlAktuell)
			BEGIN

			EXEC dbo.spPlatzUmbuchenPickposition
				 @kWarenlagerplatzNeu = @kWarenLagerPlatz,
				 @kPicklistePos = @kIsPicklistePos,
				 @kLHM = 0,
				 @kBuchungsart = 140,
				 @kBenutzer = @kBenutzer,
				 @fAnzahl = @fAnzahlAktuell,
				 @cKommentar = 'Splitt WMS-TauscheUndPicke',
				 @kPicklistePosNeu = @kNewPicklistePos OUTPUT;
			END;

			IF (@nPPIdent = 0) -- Wenn WLE keine PP hat dann übernehmen wir ihn für unsere PP
			BEGIN
				UPDATE dbo.tPicklistePos WITH(ROWLOCK) 
				SET dbo.tPicklistePos.kWarenLagerEingang = @kWarenLagerEingang 
			     WHERE dbo.tPicklistePos.kPicklistePos = @kIsPicklistePos;

				IF(@fAnzahlAktuell > @fGesAnzahl)
					SET @fAnzahlAktuell = @fGesAnzahl;

			END;
			ELSE  -- Falls WLE eine PP hat -> TAUSCHEN
			BEGIN 
			     
				-- aktuelles WLE der PP vom Pick holen
				SELECT @kWarenLagerEingangQuell = dbo.tWarenLagerEingang.kWarenLagerEingang
				FROM dbo.tPicklistePos WITH(NOLOCK)
				JOIN dbo.tWarenLagerEingang WITH(NOLOCK) ON dbo.tWarenLagerEingang.kWarenLagerEingang = dbo.tPicklistePos.kWarenLagerEingang
				WHERE dbo.tPicklistePos.kPicklistePos = @kIsPicklistePos;

				-- Wenn Tausch-PP mehr Menge hat als wir picken wollen, Tausch-PP splitten
				IF(@fAnzahlAktuell > @fGesAnzahl)
				BEGIN
					SET @fAnzahlAktuell = @fGesAnzahl;

				    EXEC dbo.spPlatzUmbuchenPickposition
					@kWarenlagerplatzNeu = @kWarenLagerPlatz, --Muß auf den gleichen Platz liegen
					@kPicklistePos = @kTauschPicklistePos,
					@kLHM = 0,
					@kBuchungsart = 140,
					@kBenutzer = @kBenutzer,
					@fAnzahl = @fGesAnzahl,
					@cKommentar = 'Splitt WMS-TauscheUndPicke',
					@kPicklistePosNeu = @kNewTauschPicklistePos;

					 -- Der Warenlagereingang der TauschPickPos kann sich durch splitten geändert haben
				    SELECT @kWarenLagerEingang = kWarenLagerEingang
					FROM tPicklistePos 
					WHERE kPicklistePos = @kTauschPicklistePos;

				END;
				BEGIN
					--Tauch-PP bekommt die WLE der Quell PP
					UPDATE dbo.tPicklistePos WITH(ROWLOCK) 
					SET dbo.tPicklistePos.kWarenLagerEingang = @kWarenLagerEingangQuell 
					WHERE dbo.tPicklistePos.kPicklistePos = @kTauschPicklistePos;

					-- Quell PP bekommt die WLE des Tauch-PP
					UPDATE dbo.tPicklistePos WITH(ROWLOCK) 
					SET dbo.tPicklistePos.kWarenLagerEingang = @kWarenLagerEingang 
					WHERE dbo.tPicklistePos.kPicklistePos = @kIsPicklistePos;
				END; 
			END;


			-- PICKEN
			EXEC @nRet = dbo.spPicklisteposPicken
				@kPicklistePos  = @kIsPicklistePos,
				@kLhm  = @kLhm,
				@kBenutzer  = @kBenutzer,
				@fPickMenge = @fAnzahlAktuell,
				@dTimestamp = @dPLTimestamp,
				@nRestmengeLoeschen = 0,
				@nStatusNachPick = @nStatusNachPick;


			-- Die Menge die wir in diesen durchlauf gepickt haben von der gesammtpickmenge abziehen
			SET @fGesAnzahl = @fGesAnzahl - @fAnzahlAktuell;

			IF(@kNewPicklistePos > 0)
				SET @kIsPicklistePos = @kNewPicklistePos
      
			-- Hole nächsten möglichen Tauschpartner
			FETCH NEXT FROM cur_GetWarenLagerEingang INTO  @kWarenLagerEingang,@nPPIdent,@fAnzahlAktuell,@kTauschPicklistePos;  
		END;


	CLOSE cur_GetWarenLagerEingang;
	DEALLOCATE cur_GetWarenLagerEingang;


	IF(@fGesAnzahl > 0)
		SET @nRet = -203000023; -- Konnte nicht ganze Menge tauschen

    SELECT @nRet;
END;
go

