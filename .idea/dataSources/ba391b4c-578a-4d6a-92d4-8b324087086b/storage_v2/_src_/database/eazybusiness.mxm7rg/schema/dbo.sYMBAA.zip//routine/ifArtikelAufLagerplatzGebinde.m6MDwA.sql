CREATE FUNCTION [dbo].[ifArtikelAufLagerplatzGebinde]( @kWarenLagerPlatz AS INT )
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor:			GJ
-- Beschreibung:	Gibt eine Liste von Artikel zurück, die auf dem Lagerplatz liegen, incl. Gebinde. Filtern über nGebinde = 1
--
RETURNS TABLE
AS
RETURN
    WITH StandardArtikel
        AS ( SELECT tartikel.kartikel , 
                    tartikel.cArtNr , 
                    tartikel.nCharge , 
                    tartikel.nMHD , 
                    tartikel.cBarcode , 
                    tartikel.cUPC , 
                    tartikel.cASIN , 
                    tartikel.cISBN , 
                    tartikel.cHAN , 
                    tartikel.cTeilbar , 
                    tArtikelBeschreibung.cName AS cName
               FROM
                    tartikel JOIN tSpracheUsed ON nStandard = 1
                             JOIN tArtikelBeschreibung ON tArtikelBeschreibung.kArtikel = tartikel.kArtikel
                                                      AND tArtikelBeschreibung.kSprache = tSpracheUsed.kSprache
                                                      AND tArtikelBeschreibung.kPlattform = 1 ) , wWarenlagereingang
        AS ( SELECT twarenlagereingang.kArtikel , 
                    CAST( SUM( ISNULL( twarenlagereingang.fAnzahlaktuell - ISNULL( twarenlagereingang.fAnzahlReserviertPickpos , 0 ) , 0 ))AS DECIMAL(28,14) )fGesAnzahl , 
                    CAST( SUM( ISNULL( twarenlagereingang.fAnzahlaktuell , 0 ))AS DECIMAL(28,14) )fGesAnzahlRes , 
                    ISNULL( twarenlagereingang.cChargenNr , '' )AS cCharge , 
                    twarenlagereingang.dMHD
               FROM twarenlagereingang
               WHERE twarenlagereingang.kwarenlagerplatz = @kWarenLagerPlatz
                 AND twarenlagereingang.fAnzahlaktuell > 0
               GROUP BY twarenlagereingang.kArtikel , 
                        ISNULL( twarenlagereingang.cChargenNr , '' ) , 
                        twarenlagereingang.dMHD ) , Res
        AS ( SELECT wWarenlagereingang.kArtikel , 
                    tartikel.cArtNr , 
                    tartikel.cName , 
                    wWarenlagereingang.fGesAnzahl , 
                    wWarenlagereingang.fGesAnzahlRes , 
                    tartikel.nCharge , 				
                    tartikel.nMHD , 
                    tartikel.cBarcode , 
                    tartikel.cUPC , 
                    tartikel.cASIN , 
                    tartikel.cISBN , 
                    tartikel.cHAN , 
                    CASE
                    WHEN tartikel.cTeilbar = 'Y' THEN 1
                        ELSE 0
                    END AS nTeilbar , 
                    wWarenlagereingang.cCharge AS cChargenNr, 
                    wWarenlagereingang.dMHD AS MHD
               FROM
                    wWarenlagereingang JOIN StandardArtikel AS tartikel ON tartikel.kartikel = wWarenlagereingang.kartikel ) , Artikelliste
        AS ( SELECT Res.* , 
                    CAST( DATEPART( day , Res.MHD )AS VARCHAR( 2 )) + '.' + CAST( DATEPART( MONTH , Res.MHD )AS VARCHAR( 2 )) + '.' + CAST( DATEPART( YEAR , Res.MHD )AS VARCHAR( 4 ))AS cMHD , 
                    CAST( DATEPART( YEAR , Res.MHD )AS VARCHAR( 4 )) + '-' + CAST( DATEPART( MONTH , Res.MHD )AS VARCHAR( 2 )) + '-' + CAST( DATEPART( day , Res.MHD )AS VARCHAR( 2 ))AS dMHD , 
                    CASE
                    WHEN SUM( tBild.kbild )IS NULL THEN 0
                        ELSE 1
                    END nBild
               FROM
                    Res LEFT JOIN tArtikelbildPlattform ON tArtikelbildPlattform.kartikel = Res.kArtikel                                                       
                        LEFT JOIN tBild ON tBild.kBild = tArtikelbildPlattform.kbild
               GROUP BY Res.kArtikel , 
                        Res.cArtNr , 
                        Res.cName , 
                        Res.fGesAnzahl , 
                        Res.fGesAnzahlRes , 
                        Res.nCharge , 
                        Res.nMHD , 
                        Res.cBarcode , 
                        Res.cUPC , 
                        Res.cASIN , 
                        Res.cISBN , 
                        Res.cHAN , 
                        Res.cChargenNr, 
                        Res.MHD , 
                        Res.nTeilbar ) , Gebindeliste
        AS ( SELECT Artikelliste.* , 
                    tGebinde.fAnzahl AS fAnzahlGebinde , 
                    '' AS cEANGebinde , 
                    tGebinde.cUPC AS cUPCGebinde , 
                    1 AS nGebinde
               FROM
                    Artikelliste JOIN dbo.tGebinde ON Artikelliste.kArtikel = dbo.tGebinde.kArtikel
				JOIN dbo.tArtikelSpeicher tas	  ON tas.kArtikel = dbo.tGebinde.kArtikel AND 
				((tas.cNummer = dbo.tGebinde.cUPC AND tas.nID = 9 AND tas.nAktiv= 1)) 
				UNION ALL
				SELECT Artikelliste.* , 
                    tGebinde.fAnzahl AS fAnzahlGebinde , 
                    tGebinde.cEAN AS cEANGebinde , 
                    '' AS cUPCGebinde , 
                    1 AS nGebinde
               FROM
                    Artikelliste JOIN dbo.tGebinde ON Artikelliste.kArtikel = dbo.tGebinde.kArtikel
				JOIN dbo.tArtikelSpeicher tas	  ON tas.kArtikel = dbo.tGebinde.kArtikel AND 
				((tas.cNummer = dbo.tGebinde.cEAN AND tas.nID = 6 AND tas.nAktiv= 1)) )
        SELECT ROW_NUMBER( )OVER( ORDER BY Artikelliste.cArtNr )AS rownum , 
               * , 
               0 AS fAnzahlGebinde , 
               NULL AS cEANGebinde , 
               NULL AS cUPCGebinde , 
               0 AS nGebinde
          FROM Artikelliste
        UNION
        SELECT 2147483647 AS rownum , 
               *
          FROM Gebindeliste;
go

