CREATE TRIGGER [dbo].[jtlActionValidator_tkategorie]
--     
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--    
ON [dbo].[tkategorie]
AFTER DELETE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
    IF NOT EXISTS(SELECT * FROM DELETED)
    BEGIN 
	   RETURN;
    END;
    DECLARE @Cinfo VARBINARY(128);  
    SELECT @Cinfo = Context_Info(); 
    IF @Cinfo = 0x55555
    BEGIN
	   RETURN;
    END;  
    IF(OBJECT_ID('tempdb..#Kategorie') IS NOT NULL)
    BEGIN	  
	   DROP TABLE #Kategorie;
    END;

    --
    -- Kategoriebaum erzeugen
    --
    IF(OBJECT_ID('tempdb..#KategorieBaum') IS NOT NULL)
    BEGIN	  
	   DROP TABLE #KategorieBaum;
    END;
    WITH KategorieBaum AS (
	   SELECT t.kKategorie, t.kOberKategorie 
		  FROM DELETED AS t
	   UNION ALL
	   SELECT t.kKategorie, t.kOberKategorie 
		  FROM dbo.tkategorie AS t 
		  INNER JOIN KategorieBaum AS r ON t.kOberKategorie = r.kKategorie
    )
    SELECT kKategorie INTO #KategorieBaum 
	   FROM KategorieBaum;
    --
    -- Löschen der zugehörigen Einträge
    --

    -- KategorieBilder
    DELETE tKategoriebildPlattform
	   FROM tKategoriebildPlattform
	   JOIN #KategorieBaum ON tKategoriebildPlattform.kKategorie = #KategorieBaum.kKategorie;

    -- Attribute
    DELETE tKategorieAttribut
	   FROM tKategorieAttribut
	   JOIN #KategorieBaum ON #KategorieBaum.kKategorie = tKategorieAttribut.kKategorie;
	   
    -- Rabatt
    DELETE tKategorieRabatt
	   FROM tKategorieRabatt
	   JOIN #KategorieBaum ON #KategorieBaum.kKategorie = tKategorieRabatt.kKategorie;

    -- Sichtbarkeit
    DELETE tKategorieSichtbarkeit
	   FROM tKategorieSichtbarkeit
	   JOIN #KategorieBaum ON #KategorieBaum.kKategorie = tKategorieSichtbarkeit.kKategorie;

    -- Sprache
    DELETE tKategorieSprache
	   FROM tKategorieSprache
	   JOIN #KategorieBaum ON #KategorieBaum.kKategorie = tKategorieSprache.kKategorie;

	--
	-- Evtl. bestehende Queue leeren (z.B. falls Aktualisierung im Shop vorgesehen war)
	--
	DELETE dbo.tQueue
		FROM dbo.tQueue
		JOIN DELETED ON dbo.tQueue.kWert = DELETED.kKategorie 
					AND dbo.tQueue.cName = 'tkategorie';

    INSERT INTO tQueue(kShop, kPlattform, cName, kWert, nAction)	 
	   SELECT tKategorieShop.kShop, 0,'tArtikel' AS cName, #KategorieBaum.kKategorie, 2
		  FROM #KategorieBaum
		  JOIN tKategorieShop ON #KategorieBaum.kKategorie = tKategorieShop.kKategorie
		  JOIN tkategorieartikel ON tkategorieartikel.kKategorie = #KategorieBaum.kKategorie
		  JOIN tArtikelShop ON tArtikelShop.kArtikel = tkategorieartikel.kArtikel 
			 AND tArtikelShop.kShop = tKategorieShop.kShop
			 WHERE NOT EXISTS
		  (
			 SELECT tkategorie.kKategorie FROM tkategorie
			 JOIN tKategorieShop ON #KategorieBaum.kKategorie = tKategorieShop.kKategorie
			 JOIN tkategorieartikel ON tkategorieartikel.kKategorie = #KategorieBaum.kKategorie
			 JOIN tArtikelShop ON tArtikelShop.kArtikel = tkategorieartikel.kArtikel 
				AND tArtikelShop.kShop = tKategorieShop.kShop
			 WHERE tKategorie.kKategorie NOT IN (SELECT kKategorie FROM #KategorieBaum)
		  )	

    -- KategorieShop
    DELETE tKategorieShop
	   FROM tKategorieShop
	   JOIN #KategorieBaum ON #KategorieBaum.kKategorie = tKategorieShop.kKategorie;
	      

    -- KategorieArtikel
    DELETE tKategorieArtikel
	   FROM tKategorieArtikel
	   JOIN #KategorieBaum ON #KategorieBaum.kKategorie = tKategorieArtikel.kKategorie;

	UPDATE dbo.tShop
		SET dbo.tShop.kKategorie = 0
	FROM dbo.tShop
	JOIN DELETED ON dbo.tShop.kKategorie = DELETED.kKategorie;

    -- Kategorie löschen
    BEGIN TRANSACTION
	   SET CONTEXT_INFO 0x55555;
	   DELETE tkategorie
		  FROM tkategorie
		  JOIN #KategorieBaum ON #KategorieBaum.kKategorie = tkategorie.kKategorie;
    COMMIT;		  
END;
go

