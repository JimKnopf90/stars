--- 
--- spWMSBestandUndPicklisteBuchen
---

CREATE PROC [dbo].[spWMSBestandUndPicklisteBuchen]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--    	

@kBestellung INT,
@kPickliste INT,
@kPlattform INT,
@kBenutzer INT,
@cKommentar VARCHAR(255), --'Versand mit EazyShipping'    
@kBuchungsart INT,
@kLieferschein INT


---
--- Bucht alle Warenlagerausgänge für eine Bestellung. Und die dazugehörigen Abhängigkeiten. Setzten den Picklistenstatus hoch.
--- VORSICHT : ES WERDEN KEINE SERIENNUMMERN GEBUCHT !!!
---

AS

     DECLARE @IsNowDate DATETIME;
	 DECLARE @ErrorMessage NVARCHAR(4000);
	 DECLARE @ErrorSeverity INT;
	 DECLARE @ErrorState INT;

     SET NOCOUNT ON;
	 SET ANSI_NULLS ON;
	 SET ANSI_NULL_DFLT_ON ON;
	 SET ANSI_PADDING ON;
	 SET CONCAT_NULL_YIELDS_NULL ON;
	 SET XACT_ABORT OFF;
BEGIN

     SET @IsNowDate = GETDATE()

	IF(object_id('tempdb..#WarenlagerEingaengeZumUpdate') IS NOT NULL)
	BEGIN
		DROP TABLE ##WarenlagerEingaengeZumUpdate
	END
     CREATE TABLE #WarenlagerEingaengeZumUpdate (kWarenLagerEingang INT,fAnzahlAktuell DECIMAL(28,14),kPicklistePos INT,
	                                             kLieferscheinPos INT,kArtikel INT, kWarenLagerPlatz INT,kStueckliste INT,cLagerVariation CHAR(1),nIstVater INT,fEKNetto DECIMAL(28,14),cLagerAktiv CHAR(1),kBestellPos INT);


     -- Temporäre Tabelle füllen, mit allen Warenlagereingängen die gebucht werden sollen
	INSERT INTO #WarenlagerEingaengeZumUpdate
     SELECT dbo.tWarenLagerEingang.kWarenLagerEingang, SUM(dbo.tWarenLagerEingang.fAnzahlAktuell) fAnzahlAktuell,dbo.tPicklistePos.kPicklistePos,
		     dbo.tLieferscheinPos.kLieferscheinPos,dbo.tWarenLagerEingang.kArtikel,dbo.tWarenLagerEingang.kWarenLagerPlatz,dbo.tArtikel.kStueckliste,
			dbo.tArtikel.cLagerVariation,dbo.tArtikel.nIstVater,dbo.tartikel.fEKNetto,dbo.tartikel.cLagerAktiv,dbo.tbestellpos.kBestellPos
	FROM dbo.tWarenLagerEingang WITH(NOLOCK) 
	JOIN dbo.tPicklistePos WITH(NOLOCK) ON dbo.tPicklistePos.kWarenLagerEingang = dbo.tWarenLagerEingang.kWarenLagerEingang
	JOIN dbo.tbestellpos WITH(NOLOCK) ON dbo.tbestellpos.kBestellPos = dbo.tPicklistePos.kBestellPos
	JOIN dbo.tLieferscheinPos WITH(NOLOCK) ON dbo.tLieferscheinPos.kBestellPos = dbo.tbestellpos.kBestellPos AND dbo.tLieferscheinPos.kLieferschein = @kLieferschein
	JOIN dbo.tArtikel WITH(NOLOCK) ON dbo.tArtikel.kArtikel = dbo.tWarenLagerEingang.kArtikel
	WHERE dbo.tPicklistePos.kPickliste = @kPickliste
	AND dbo.tbestellpos.tBestellung_kBestellung = @kBestellung
	AND dbo.tWarenLagerEingang.fAnzahlAktuell > 0
	AND dbo.tPicklistePos.nStatus > 20
	GROUP BY dbo.tWarenLagerEingang.kWarenLagerEingang,dbo.tPicklistePos.kPicklistePos,dbo.tLieferscheinPos.kLieferscheinPos,dbo.tWarenLagerEingang.kArtikel,dbo.tWarenLagerEingang.kWarenLagerPlatz,
	dbo.tArtikel.kStueckliste,dbo.tArtikel.cLagerVariation,dbo.tArtikel.nIstVater,dbo.tartikel.fEKNetto,dbo.tartikel.cLagerAktiv,dbo.tbestellpos.kBestellPos;


    IF(EXISTS (SELECT * FROM #WarenlagerEingaengeZumUpdate)) -- Es könnt sein das gar keine Warenlagereingänge gefunden werden (Packtisch).
    BEGIN





	   DECLARE @xWarenlagerAusgaenge XML;
	   SET @xWarenlagerAusgaenge = (
		    SELECT kWarenLagerEingang AS kWarenLagerEingang,
				    kLieferscheinPos AS kLieferscheinPos,
				    fAnzahlAktuell AS fAnzahl,
				    @cKommentar AS cKommentar,
				    @kBenutzer AS kBenutzer,
				    @kBuchungsart AS kBuchungsart
			    FROM #WarenlagerEingaengeZumUpdate
			    FOR XML PATH('WarenAusgang'), TYPE
		    );


	    EXEC spWarenlagerAusgangSchreiben
	    @xWarenlagerAusgaenge = @xWarenlagerAusgaenge

	END;


	DECLARE @retry INT;
	SET @retry = 10;
	WHILE @retry > 0
	BEGIN TRY

		 -- Status der Pickpos auf 40 setzten
		INSERT INTO dbo.tPicklistePosStatus WITH(ROWLOCK) (kPicklistePos,kBenutzer,nStatus,dZeitstempel) 
		SELECT DISTINCT kPicklistePos,@kBenutzer,40,@IsNowDate
		FROM #WarenlagerEingaengeZumUpdate;

		-- LieferscheinPos in der PicklistePos setzen
		UPDATE dbo.tPicklistePos WITH(ROWLOCK) 
		SET dbo.tPicklistePos.kLieferscheinpos = #WarenlagerEingaengeZumUpdate.kLieferscheinPos,dbo.tPicklistePos.nStatus = 40
		FROM  dbo.tPicklistePos WITH(ROWLOCK) 
		JOIN #WarenlagerEingaengeZumUpdate ON #WarenlagerEingaengeZumUpdate.kPicklistePos = dbo.tPicklistePos.kPicklistePos;

		SET @retry = -1;
	END TRY
	BEGIN CATCH
	    IF(ERROR_NUMBER() = 1205 AND @retry > 1)
		BEGIN
			SET @retry = @retry - 1;
			WAITFOR DELAY '00:00:00:9';
		END;
		ELSE 
		BEGIN


		    SELECT @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();

			SET @retry = -1;
			RAISERROR (	@ErrorMessage, 
						@ErrorSeverity,
						@ErrorState);

			RETURN;
		END;
	END CATCH;

END;
go

