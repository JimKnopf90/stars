--- 
--- spBestellungenNichtBezahlteAufVorkommissionieren
---

CREATE PROCEDURE [dbo].[spBestellungenNichtBezahlteAufVorkommissionieren] 
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--   
AS   
BEGIN	   
    SET NOCOUNT ON;
	SET ANSI_NULLS ON;
	SET ANSI_NULL_DFLT_ON ON;
	SET ANSI_PADDING ON;
	SET CONCAT_NULL_YIELDS_NULL ON;
	SET XACT_ABORT OFF;

    INSERT INTO tBestellungWMSFreigabe (kBEstellung, dZeitStempel, kBenutzer, nTeillieferungErlaubt, nVorkommissionieren, nAktiv, nSperre)
	   SELECT tBestellung.kBestellung, 
			 GetDate() AS dZeitStempel,
			 0 AS kBenutzer, 
			 ISNULL(tBestellungWMSFreigabe.nTeillieferungErlaubt,0) AS nTeillieferungErlaubt, 
			 1 AS nVorkommissionieren,
			 1 AS nAktiv,
			 ISNULL(tBestellungWMSFreigabe.nSperre,0) nSperre
		  FROM tBestellung WITH(NOLOCK)
		  LEFT JOIN tZahlungsart WITH(NOLOCK) ON tBestellung.kZahlungsart = tZahlungsart.kZahlungsart
		  LEFT JOIN tBestellungWMSFreigabe WITH(NOLOCK) ON tBestellungWMSFreigabe.kBestellung = tBestellung.kBestellung and tBestellungWMSFreigabe.nAktiv = 1
		  WHERE tBestellung.nKomplettAusgeliefert = 0
			 AND tBestellung.dBezahlt IS NULL
			 AND ISNULL(tZahlungsart.nAusliefernVorZahlung,0) = 0
			 AND cType = 'B'
			 AND ISNULL(tBestellungWMSFreigabe.nVorkommissionieren,0) = 0
END
go

