CREATE TRIGGER [dbo].[tgr_tartikel_INSUP]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP/MK
--
ON [dbo].[tArtikel]
AFTER INSERT, UPDATE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;

DECLARE @typeSlArtikel AS TYPE_spAktualisiereStueckliste;
DECLARE @typeArtikel AS TYPE_spUpdateLagerbestand;
DECLARE @IsVater AS INT;

BEGIN
	--Überprüfen ob Trigger gefüllt aufgerufen wird
	IF((SELECT COUNT(1) FROM INSERTED FULL JOIN DELETED ON INSERTED.kArtikel = DELETED.kArtikel) = 0)
	BEGIN 
		RETURN
	END

	--
	-- Wurde Artikel zum Vaterartikel oder Stückliste oder wurde Lagerbestand aktiv gesetzt? --> Lagerbestand neu kalkulieren
	--
		IF (UPDATE (fGewicht) OR UPDATE (nIstVater) OR UPDATE (kStueckliste) OR UPDATE (cLagerVariation) OR UPDATE (cLagerAktiv) OR UPDATE(cLagerKleinerNull) OR UPDATE(cTeilbar) OR UPDATE(fEKNetto) OR UPDATE(fArtGewicht) OR UPDATE(kVaterArtikel))
		BEGIN
			INSERT INTO dbo.tlagerbestandProLagerLagerartikel(kArtikel, kWarenlager, fBestand)
				SELECT kArtikel, kWarenlager, 0.0
					FROM INSERTED 
					CROSS JOIN dbo.tWarenlager
					WHERE INSERTED.kArtikel NOT IN(SELECT kArtikel FROM dbo.tlagerbestandProLagerLagerartikel)
						AND INSERTED.kStueckliste = 0 
						AND INSERTED.nIstVater = 0;


			DELETE tlagerbestandProLagerLagerartikel
			FROM dbo.tlagerbestandProLagerLagerartikel
			JOIN INSERTED ON INSERTED.kArtikel = tlagerbestandProLagerLagerartikel.kArtikel
			WHERE (INSERTED.kStueckliste > 0 OR INSERTED.nIstVater > 0);

			--
			-- Wird die Lagerführung eines Artikels (de-)aktiviert müssen die Lagerplätze ggf. wieder angelegt werden.
			--
			INSERT INTO dbo.tWarenLagerPlatzArtikel WITH(ROWLOCK) (kWarenLagerPlatz, kArtikel)
			SELECT U1.kWarenLagerPlatz, U1.kArtikel FROM 
			(
				SELECT dbo.tWarenLagerEingang.kWarenLagerPlatz, dbo.tWarenLagerEingang.kArtikel, 0.0 AS fAnzahl
					FROM dbo.tWarenLagerEingang WITH(NOLOCK)
					LEFT JOIN dbo.tWarenLagerPlatzArtikel WITH(NOLOCK) ON dbo.tWarenLagerEingang.kArtikel = dbo.tWarenLagerPlatzArtikel.kArtikel 
																			AND dbo.tWarenLagerEingang.kWarenLagerPlatz = dbo.tWarenLagerPlatzArtikel.kWarenLagerPlatz
					JOIN INSERTED ON dbo.tWarenLagerEingang.kArtikel = INSERTED.kArtikel
					JOIN DELETED ON INSERTED.kArtikel = DELETED.kArtikel
					WHERE dbo.tWarenLagerPlatzArtikel.kWarenLagerPlatz IS NULL 
						AND ISNULL(dbo.tWarenLagerEingang.fAnzahlAktuell, 0.0) > 0.0 
						AND ISNULL(INSERTED.cLagerAktiv, 'N') <> ISNULL(DELETED.cLagerAktiv, 'N')
					GROUP BY dbo.tWarenLagerEingang.kWarenLagerPlatz, dbo.tWarenLagerEingang.kArtikel
				UNION ALL
				SELECT dbo.tWarenLagerAusgang.kWarenLagerPlatz, dbo.tWarenLagerAusgang.kArtikel, 0.0 AS fAnzahl
					FROM dbo.tWarenLagerAusgang WITH(NOLOCK)
					LEFT JOIN dbo.tWarenLagerPlatzArtikel WITH(NOLOCK) ON dbo.tWarenLagerAusgang.kArtikel = tWarenLagerPlatzArtikel.kArtikel 
																			AND dbo.tWarenLagerAusgang.kWarenLagerPlatz = dbo.tWarenLagerPlatzArtikel.kWarenLagerPlatz
					JOIN INSERTED ON dbo.tWarenLagerAusgang.kArtikel = INSERTED.kArtikel
					JOIN DELETED ON INSERTED.kArtikel = DELETED.kArtikel
					WHERE dbo.tWarenLagerPlatzArtikel.kWarenLagerPlatz IS NULL 
							AND ISNULL(dbo.tWarenLagerAusgang.kWarenLagerEingang, 0) = 0 
							AND ISNULL(INSERTED.cLagerAktiv, 'N') <> ISNULL(DELETED.cLagerAktiv, 'N')
					GROUP BY dbo.tWarenLagerAusgang.kWarenLagerPlatz, dbo.tWarenLagerAusgang.kArtikel
			) AS U1
			GROUP BY U1.kArtikel, U1.kWarenLagerPlatz, U1.fAnzahl				

			SET @IsVater = 0;
			If UPDATE (kStueckliste) OR UPDATE(fEkNetto) -- Falls Stückliste geändert wurde
			BEGIN
				IF ((SELECT COUNT(*) FROM INSERTED
				     WHERE (INSERTED.kStueckliste > 0  AND NOT EXISTS (SELECT * FROM DELETED))
				     OR (INSERTED.kStueckliste > 0  AND  EXISTS (SELECT * FROM DELETED WHERE DELETED.kArtikel = INSERTED.kArtikel AND DELETED.kStueckliste != INSERTED.kStueckliste))) > 0)

				BEGIN
				    SET @IsVater = 1;

					INSERT INTO @typeArtikel (kArtikel)
					SELECT DISTINCT kArtikel AS 'kArtikel'
					   FROM
					   (
						   SELECT dbo.tStueckliste.kArtikel 
						   FROM INSERTED
						   JOIN dbo.tStueckliste ON dbo.tStueckliste.kStueckliste = INSERTED.kStueckliste
						   GROUP BY dbo.tStueckliste.kArtikel
					   ) AS U1
					   WHERE kArtikel = U1.kArtikel


				   INSERT INTO @typeSlArtikel (kArtikel)
				   SELECT kArtikel FROM @typeArtikel
					
				   EXEC dbo.spUpdateLagerbestand @typeArtikel
				   IF CONTEXT_INFO() <> 0x5009 OR CONTEXT_INFO() IS NULL
				   BEGIN
					   EXEC dbo.spAktualisiereStueckliste @typeSlArtikel;
				   END;

				END;

				IF(EXISTS(SELECT TOP 1 * FROM INSERTED WHERE kVaterartikel > 0))
				BEGIN
					DECLARE @typeVarKomArtikel TYPE_spAktualisiereVarkombivater;

					INSERT INTO @typeVarKomArtikel (kArtikel)
				    SELECT kArtikel 
					   FROM
					   (
						   SELECT INSERTED.kArtikel 
						   FROM INSERTED
						   WHERE INSERTED.kVaterartikel > 0						   
						   GROUP BY INSERTED.kArtikel
					   ) AS U1
					   WHERE kArtikel = U1.kArtikel

				   EXEC Artikel.spAktualisiereVarkombivater @typeVarKomArtikel, null
				END

			END;
			IF(EXISTS(SELECT * FROM DELETED))
			BEGIN
				-- Lagerbestand pro Lager aktualisieren
				DECLARE @TYPE_spUpdateLagerbestandProLager AS TYPE_spUpdateLagerbestandProLager;
				INSERT INTO @TYPE_spUpdateLagerbestandProLager(kArtikel, kWarenlager)
					SELECT kArtikel, kWarenlager
						FROM INSERTED
						CROSS JOIN dbo.tWarenlager;
				EXEC dbo.spUpdateLagerbestandProLager @TYPE_spUpdateLagerbestandProLager;

			END

			IF(@IsVater = 0) -- Falls stücklsite Vater, brauch sie nicht als Komponente gecheckt werden
			BEGIN

				DELETE FROM @typeArtikel;
			    INSERT INTO @typeArtikel (kArtikel)
				SELECT kArtikel AS 'kArtikel'
				    FROM
				    (
					    SELECT kArtikel FROM INSERTED
					    UNION
					    SELECT kArtikel FROM DELETED
				    ) AS U1
				    WHERE kArtikel = U1.kArtikel;

			    INSERT INTO @typeSlArtikel (kArtikel)
				SELECT kArtikel FROM @typeArtikel


			    EXEC dbo.spUpdateLagerbestand @typeArtikel;
			    IF CONTEXT_INFO() <> 0x5009 OR CONTEXT_INFO() IS NULL
			    BEGIN
				    EXEC dbo.spAktualisiereStueckliste @typeSlArtikel;
			    END
			END;

			UPDATE dbo.tArtikel
				SET tArtikel.cLagerAktiv = vererbteKomponentenwerte.cLagerAktiv,
					tArtikel.cLagerKleinerNull = vererbteKomponentenwerte.cLagerKleinerNull,
					tArtikel.cTeilbar = vererbteKomponentenwerte.cTeilbar
			FROM dbo.tArtikel
			JOIN
			(
				--
				-- Zu setzende Werte aus für Stücklisten aus allen Komponenten ermitteln die betroffen sind.
				--
				SELECT	tStueckliste.kStueckliste,
						MAX(ISNULL(tartikel.cLagerAktiv, 'N')) AS cLagerAktiv,
						MIN(CASE ISNULL(tartikel.cLagerAktiv, 'N') WHEN 'N' THEN 'Y' ELSE ISNULL(tartikel.cLagerKleinerNull, 'N') END ) AS cLagerKleinerNull,
						MIN(ISNULL(tartikel.cTeilbar, 'N')) AS cTeilbar
				FROM dbo.tArtikel
				JOIN dbo.tStueckliste ON tArtikel.kArtikel = tStueckliste.kArtikel
				JOIN
				(
					--
					-- Stücklisten ermitteln in denen der aktuelle Artikel eine Komponente ist
					--
					SELECT dbo.tStueckliste.kStueckliste
					FROM dbo.tStueckliste
					JOIN INSERTED ON tStueckliste.kArtikel = INSERTED.kArtikel
					GROUP BY dbo.tStueckliste.kStueckliste
				) AS aktualisierteStuecklisten ON dbo.tStueckliste.kStueckliste = aktualisierteStuecklisten.kStueckliste
				GROUP BY tStueckliste.kStueckliste
			) AS vererbteKomponentenwerte ON tArtikel.kStueckliste = vererbteKomponentenwerte.kStueckliste
			WHERE	tArtikel.cLagerAktiv <> vererbteKomponentenwerte.cLagerAktiv
					OR tArtikel.cLagerKleinerNull <> vererbteKomponentenwerte.cLagerKleinerNull
					OR tArtikel.cTeilbar <> vererbteKomponentenwerte.cTeilbar

			--
			-- Vaterartikel (Varkombi) aktualisieren
			--
			UPDATE Vaterartikel WITH(ROWLOCK)
					SET Vaterartikel.cLagerAktiv = ISNULL(Kindartikel.cLagerAktiv, 'N')
				FROM dbo.tartikel AS Vaterartikel WITH(ROWLOCK)
				JOIN
				(
					SELECT dbo.tartikel.kVaterArtikel,
						ISNULL(MAX(ISNULL(dbo.tartikel.cLagerAktiv, 'N')), 'N') AS cLagerAktiv
					FROM dbo.tartikel WITH(NOLOCK)
					JOIN INSERTED ON dbo.tartikel.kVaterArtikel = INSERTED.kVaterArtikel
					GROUP BY dbo.tartikel.kVaterArtikel
				) AS Kindartikel ON Vaterartikel.kArtikel = Kindartikel.kVaterArtikel
				JOIN INSERTED ON Vaterartikel.kArtikel = INSERTED.kVaterArtikel
				LEFT JOIN DELETED ON INSERTED.kArtikel = DELETED.kArtikel
				WHERE INSERTED.kVaterArtikel > 0 
					AND (INSERTED.cLageraktiv <> ISNULL(DELETED.cLagerAktiv, 'X')
					 OR (INSERTED.kVaterArtikel <> DELETED.kVaterArtikel))
		END


		--
		-- Wenn ein neuer Artikel angelegt wird, wird ein Eintrag in tWarenlagerplatzartikel mit Menge 0 auf den Dummy Warenlagerplatz gemacht.
		--
		INSERT INTO dbo.tWarenLagerPlatzArtikel(kWarenLagerPlatz, kArtikel)
			SELECT dbo.tWarenLagerPlatz.kWarenLagerPlatz, INSERTED.kArtikel
				FROM INSERTED 
				JOIN dbo.tWarenLagerPlatz ON dbo.tWarenLagerPlatz.kWarenLagerPlatzTyp = 10 
												AND dbo.tWarenLagerPlatz.cKommentar LIKE 'Dummy Lagerplatz%'
				WHERE INSERTED.kArtikel NOT IN (SELECT DELETED.kArtikel FROM DELETED)
					AND INSERTED.cLagerVariation != 'Y'
					AND INSERTED.cAktiv = 'Y'

	--
	-- Aktualisiert die Spalte tArtikelspeicher (Version 20)
	--
		IF UPDATE(cArtNr) OR UPDATE(cBarcode) OR UPDATE(cHan) OR UPDATE(cUPC) OR UPDATE(cISBN) OR UPDATE(cASIN) OR UPDATE(cJfpid)
		BEGIN

	 		DELETE dbo.tArtikelSpeicher WITH(ROWLOCK) 
			FROM dbo.tArtikelSpeicher WITH(ROWLOCK)
			JOIN INSERTED ON INSERTED.kArtikel = tArtikelSpeicher.kArtikel;
	

	          ---
			--- Beachten: Die Artikel IDs werden getrimt. 
			---
			WITH Alle AS 
			(
					SELECT LTRIM(RTRIM(INSERTED.cArtNr)) AS Nummer, INSERTED.kArtikel, 0 AS Art , CASE WHEN dbo.tOptions.cValue = '1' THEN 1 ELSE 0 END AS nAktiv
						FROM INSERTED 
						LEFT JOIN dbo.tOptions WITH(NOLOCK) ON dbo.tOptions.cKey = 'ArtikelEigenschaft Artikelnummer'
						WHERE INSERTED.cArtNr IS NOT NULL 
						AND INSERTED.cArtNr <> '' 
							
				UNION ALL
					SELECT LTRIM(RTRIM(INSERTED.cBarcode)) AS Nummer, INSERTED.kArtikel, 1 AS Art , CASE WHEN dbo.tOptions.cValue = '1' THEN 1 ELSE 0 END AS nAktiv
						FROM INSERTED 
						LEFT JOIN dbo.tOptions WITH(NOLOCK) ON dbo.tOptions.cKey = 'ArtikelEigenschaft EAN'
						WHERE INSERTED.cBarcode IS NOT NULL 
							AND INSERTED.cBarcode <> '' 
				UNION ALL
					SELECT  LTRIM(RTRIM(INSERTED.cHAN)) AS Nummer, INSERTED.kArtikel, 2 AS Art , CASE WHEN dbo.tOptions.cValue = '1' THEN 1 ELSE 0 END AS nAktiv
						FROM INSERTED 
						LEFT JOIN dbo.tOptions WITH(NOLOCK) ON dbo.tOptions.cKey = 'ArtikelEigenschaft HAN'
						WHERE INSERTED.cHAN IS NOT NULL 
							AND INSERTED.cHAN <> '' 
				UNION ALL
					SELECT  LTRIM(RTRIM(INSERTED.cUPC)) AS Nummer, INSERTED.kArtikel, 3 AS Art , CASE WHEN dbo.tOptions.cValue = '1' THEN 1 ELSE 0 END AS nAktiv
						FROM INSERTED 
						LEFT JOIN dbo.tOptions WITH(NOLOCK) ON dbo.tOptions.cKey = 'ArtikelEigenschaft UPC'
						WHERE INSERTED.cUPC IS NOT NULL 
							AND INSERTED.cUPC <> '' 
				UNION ALL
					SELECT  LTRIM(RTRIM(INSERTED.cISBN)) AS Nummer, INSERTED.kArtikel, 4 AS Art , CASE WHEN dbo.tOptions.cValue = '1' THEN 1 ELSE 0 END AS nAktiv
						FROM INSERTED 
						LEFT JOIN dbo.tOptions WITH(NOLOCK) ON dbo.tOptions.cKey = 'ArtikelEigenschaft ISBN'
						WHERE INSERTED.cISBN IS NOT NULL 
							AND INSERTED.cISBN <> '' 
				UNION ALL
					SELECT  LTRIM(RTRIM(INSERTED.cAmazonFNSKU)) AS Nummer, INSERTED.kArtikel, 10 AS Art , CASE WHEN dbo.tOptions.cValue = '1' THEN 1 ELSE 0 END AS nAktiv
						FROM INSERTED 
						LEFT JOIN dbo.tOptions WITH(NOLOCK) ON dbo.tOptions.cKey = 'ArtikelEigenschaft FNSKU'
						WHERE INSERTED.cAmazonFNSKU IS NOT NULL 
							AND INSERTED.cAmazonFNSKU <> '' 
			    UNION ALL
					SELECT  LTRIM(RTRIM(INSERTED.cJfpid)) AS Nummer, INSERTED.kArtikel, 11 AS Art , CASE WHEN dbo.tOptions.cValue = '1' THEN 1 ELSE 0 END AS nAktiv
						FROM INSERTED 
						LEFT JOIN dbo.tOptions WITH(NOLOCK) ON dbo.tOptions.cKey = 'ArtikelEigenschaft JTLFPID'
						WHERE INSERTED.cJfpid IS NOT NULL 
							AND INSERTED.cJfpid <> '' 
				UNION ALL
					SELECT DISTINCT LTRIM(RTRIM(tGebinde.cEAN)) AS Nummer, dbo.tGebinde.kArtikel, 6 AS Art , CASE WHEN dbo.tOptions.cValue = '1' THEN 1 ELSE 0 END AS nAktiv
						FROM dbo.tGebinde 
						JOIN INSERTED ON INSERTED.kArtikel = dbo.tGebinde.kArtikel 
						LEFT JOIN dbo.tOptions WITH(NOLOCK) ON dbo.tOptions.cKey = 'ArtikelEigenschaft GebindeEAN'
						WHERE dbo.tGebinde.cEAN IS NOT NULL 
							AND dbo.tGebinde.cEAN <> '' 
			     UNION ALL
					SELECT DISTINCT LTRIM(RTRIM(tGebinde.cUPC)) AS Nummer, dbo.tGebinde.kArtikel, 9 AS Art , CASE WHEN dbo.tOptions.cValue = '1' THEN 1 ELSE 0 END AS nAktiv
						FROM dbo.tGebinde 
						JOIN INSERTED ON INSERTED.kArtikel = dbo.tGebinde.kArtikel 
						LEFT JOIN dbo.tOptions WITH(NOLOCK) ON dbo.tOptions.cKey = 'ArtikelEigenschaft GebindeUPC'
						WHERE dbo.tGebinde.cUPC IS NOT NULL 
							AND dbo.tGebinde.cUPC <> '' 
				UNION ALL
					SELECT  LTRIM(RTRIM(INSERTED.cASIN)) AS Nummer, INSERTED.kArtikel, 7 AS Art , CASE WHEN dbo.tOptions.cValue = '1' THEN 1 ELSE 0 END AS nAktiv
						FROM INSERTED 
						LEFT JOIN dbo.tOptions WITH(NOLOCK) ON dbo.tOptions.cKey = 'ArtikelEigenschaft ASIN'
						WHERE INSERTED.cASIN IS NOT NULL 
							AND INSERTED.cASIN <> '' 
				UNION ALL
					SELECT DISTINCT LTRIM(RTRIM(tLiefArtikel.cLiefArtNr)) AS Nummer, dbo.tLiefArtikel.tArtikel_kArtikel, 8 AS Art , CASE WHEN dbo.tOptions.cValue = '1' THEN 1 ELSE 0 END AS nAktiv
						FROM dbo.tLiefArtikel
						JOIN INSERTED ON INSERTED.kArtikel = dbo.tLiefArtikel.tArtikel_kArtikel 
						LEFT JOIN dbo.tOptions WITH(NOLOCK) ON dbo.tOptions.cKey = 'ArtikelEigenschaft LieferantenArtNummer'
					WHERE dbo.tLiefArtikel.cLiefArtNr IS NOT NULL 
						AND dbo.tLiefArtikel.cLiefArtNr <> '' 

				UNION ALL

				    SELECT LTRIM(RTRIM(dbo.tArtikelBeschreibung.cName)) AS Nummer, dbo.tArtikelBeschreibung.kArtikel, 5 AS Art , CASE WHEN dbo.tOptions.cValue = '1' THEN 1 ELSE 0 END AS nAktiv
						FROM dbo.tArtikelBeschreibung
						JOIN INSERTED ON INSERTED.kArtikel = dbo.tArtikelBeschreibung.kArtikel 
						LEFT JOIN dbo.tOptions WITH(NOLOCK) ON dbo.tOptions.cKey = 'ArtikelEigenschaft Artikelname'
						JOIN tSpracheUsed ON dbo.tArtikelBeschreibung.kSprache = tSpracheUsed.kSprache AND tSpracheUsed.nStandard = 1  
					WHERE dbo.tArtikelBeschreibung.cName IS NOT NULL 
					AND dbo.tArtikelBeschreibung.kPlattform = 1
					AND dbo.tArtikelBeschreibung.cName <> '' 
			)
			INSERT INTO dbo.tArtikelSpeicher WITH(ROWLOCK) (kArtikel,cNummer,nID,nAktiv)
				SELECT DISTINCT Alle.kArtikel, Alle.Nummer, Alle.Art ,Alle.nAktiv
					FROM Alle
    
		END
		DECLARE @Positionen AS XML
		SET @Positionen = (
			SELECT dbo.tReserviert.kKey, dbo.tReserviert.kPlattform AS nPlattform 
				FROM dbo.tReserviert WITH (NOLOCK)
				JOIN INSERTED ON dbo.tReserviert.kArtikel = INSERTED.kArtikel
				JOIN DELETED ON INSERTED.kArtikel = DELETED.kArtikel
				WHERE INSERTED.cLagerAktiv <> DELETED.cLagerAktiv
			FOR XML PATH('Keys'), TYPE
		)
		EXEC dbo.spReservierungAktualisieren @Positionen

		--
		-- nLiefertageWennAusverkauft setzten
		--
		IF(EXISTS(SELECT INSERTED.kArtikel FROM INSERTED WHERE INSERTED.nAutomatischeLiefertageberechnung = 1))
		BEGIN
			UPDATE dbo.tArtikel 
				SET dbo.tArtikel.nLiefertageWennAusverkauft = dbo.tliefartikel.nLieferzeit
				FROM dbo.tArtikel
				JOIN dbo.tliefartikel ON dbo.tArtikel.kArtikel = dbo.tliefartikel.tArtikel_kArtikel
				JOIN (
					SELECT INSERTED.kArtikel
						FROM INSERTED
						JOIN DELETED ON INSERTED.kArtikel = DELETED.kArtikel
					UNION
				    SELECT INSERTED.kArtikel
						FROM INSERTED 
						WHERE NOT EXISTS(SELECT DELETED.kArtikel FROM DELETED)
				) AS Result ON Result.kArtikel = dbo.tArtikel.kArtikel
				WHERE dbo.tArtikel.nAutomatischeLiefertageberechnung = 1 
					AND dbo.tliefartikel.nStandard = 1
	   END
END
go

