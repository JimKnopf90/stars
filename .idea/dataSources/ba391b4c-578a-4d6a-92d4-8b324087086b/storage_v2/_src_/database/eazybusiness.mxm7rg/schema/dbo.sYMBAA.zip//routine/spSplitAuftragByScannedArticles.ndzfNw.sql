--- 
--- spSplitAuftragByScannedArticles
---

CREATE PROCEDURE [dbo].[spSplitAuftragByScannedArticles]
	--
	-- Copyright (c) 2012-2017 by JTL Software GmbH
	-- Datum: $Date$
	-- Version: $Rev$
	--
	@kBestellung INT,
	@kBenutzer INT,
	@kPickliste INT,
	@nRetError  INT OUT
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;



     --
     -- Die Prozedur bezieht sich auf die Artikel Tabelle aus Eazyshipping tWMSPackItem. Und splittet anhand dieser die enthaltene Menge von der Bestellung ab.
     -- Zudem wird die Pickliste mit gesplittet und die Verknüpfungen zur abgesplitteten Bestellung erneuert.
     --
    DECLARE @CreatedTransaction INT;
	DECLARE @nRet INT;
	DECLARE @kBestellungNewOrder INT;
	DECLARE @kTempPickliste INT;
	DECLARE @kLieferschein INT;
	DECLARE @text varchar(1000);  
	DECLARE @MaxMenge DECIMAL(28,5);
	DECLARE @kWMSPackItem INT;
	DECLARE @kArtikel INT;
	DECLARE @fMenge DECIMAL(28,5);
	DECLARE @kBestellposNeu INT;
	DECLARE @kBestellposAlt INT;
	DECLARE @fMengeAlt DECIMAL(28,5);		   
	DECLARE @kNewBestellpos INT;
	DECLARE @kNewPickPos INT;
	DECLARE @kPickPosToSplitt INT;
	DECLARE @fAnzahlPickPosToSplitt INT;
	DECLARE @kPickposAktuell  INT;
	DECLARE @fAnzahlPickposAktuell DECIMAL(28,14);
	DECLARE @kArtikelPickposAktuell INT;
	DECLARE @kBestellPosOld INT;
	DECLARE @kArtikelOld INT;
	DECLARE @nAnzahlOld DECIMAL(28,14);
	DECLARE @kBestellungNow INT;
	DECLARE @TempPickPos INT;
	DECLARE @kWarenlager INT;
	DECLARE @kBestellStueckliste INT;
	DECLARE @TempMenge DECIMAL(28,14);
	DECLARE @Temp_BestellPosAlt TABLE(kBestellPos INT,kArtikel INT,fMenge DECIMAL(28,14),kBestellStueckliste INT);
	DECLARE @Temp_BestellPosNeu TABLE(kBestellPos INT,kArtikel INT,fMenge DECIMAL(28,14));
	DECLARE @Temp_BestellPosNeuForSplit TABLE(kBestellPos INT,kArtikel INT,fMenge DECIMAL(28,14),kBestellstueckliste INT);
	
	DECLARE cur_GetWMSPackItems CURSOR LOCAL FAST_FORWARD FOR   
	SELECT dbo.tWMSPackItem.kWMSPackItem,dbo.tWMSPackItem.kArtikel,ROUND(dbo.tWMSPackItem.fMenge , 4) AS fMenge,dbo.tWMSPackItem.kBestellStueckliste
	FROM dbo.tWMSPackItem WITH(NOLOCK)
	WHERE dbo.tWMSPackItem.kBestellung = @kBestellung
	AND dbo.tWMSPackItem.kPickliste = @kPickliste;

	-- START TRANSACTION
	IF (@@TRANCOUNT = 0)
	BEGIN
	   SET @CreatedTransaction = 1;
	   BEGIN TRANSACTION
	END;
	ELSE
	BEGIN
		SET @CreatedTransaction = 0;
		SAVE TRANSACTION Savepoint0;
	END;
		
	BEGIN TRY    
		SET @nRet = 0;
		SET @kBestellungNewOrder = 0;
	
	
	     --
	     -- Erzeugen eines Lieferscheins mit den gescannten Artikeln aus dem Eazyshipping
	     --
	
		-- Die alten Bestellpositionen Speichern
		INSERT INTO @Temp_BestellPosAlt(kBestellPos,kArtikel,fMenge,kBestellStueckliste)
		SELECT dbo.tBestellpos.kBestellPos,dbo.tBestellpos.tArtikel_kArtikel,dbo.tBestellpos.nAnzahl, dbo.tBestellpos.kBestellStueckliste
		FROM dbo.tBestellpos
		JOIN dbo.vWMSArtikel Artikel ON Artikel.kArtikel = dbo.tBestellpos.tArtikel_kArtikel
		JOIN dbo.tPicklistePos ON dbo.tPicklistePos.kBestellPos = dbo.tbestellpos.kBestellPos
		WHERE dbo.tBestellpos.tBestellung_kBestellung = @kBestellung
		AND dbo.tBestellpos.kBestellStueckliste = 0
		AND dbo.tPicklistePos.kPickliste = @kPickliste;
		
		-- Über alle Artikel aus eazyshipping
		OPEN cur_GetWMSPackItems    
		FETCH NEXT FROM cur_GetWMSPackItems INTO  @kWMSPackItem,@kArtikel,@fMenge,@kBestellStueckliste

		WHILE (@@FETCH_STATUS = 0  and @nRet >= 0)
		BEGIN  
		
			-- Die Menge aus Eazyshipping muß in den Bestellpos gesucht werden, die gefundenen Bestellpos werden temporät zwischengespeichert in @Temp_BestellPosNeu
			WHILE (@fMenge > 0  and @nRet >= 0)
			BEGIN  
				SET @kBestellposNeu = null;
				SET @kBestellposAlt = null;
		  
				SELECT TOP 1 @kBestellposAlt = kBestellPos , @fMengeAlt = fMenge
				FROM @Temp_BestellPosAlt
				WHERE kArtikel = @kArtikel
				AND fMenge > 0
				ORDER BY  CASE WHEN kBestellStueckliste = @kBestellStueckliste THEN 0 ELSE 1 END,  
				          CASE WHEN fMenge > @fMenge THEN 1 ELSE 0 END,fMenge DESC;
		    	
				IF((@fMengeAlt - @fMenge) < 0.0001 AND (@fMengeAlt - @fMenge > 0))
				SET @fMenge = @fMengeAlt;

				IF(@kBestellposAlt is null OR @fMengeAlt = 0)
				BEGIN
					SET @nRet = -203000201; -- Fehler
				END
				ELSE
				BEGIN
		    
					SET @MaxMenge = CASE WHEN @fMenge >= @fMengeAlt THEN @fMengeAlt ELSE @fMenge END;
					SET @fMenge = @fMenge - @MaxMenge;
		    
					SELECT @kBestellposNeu = kBestellPos
					FROM @Temp_BestellPosNeu
					WHERE kBestellPos = @kBestellposAlt;
    		    
    					-- Die neuen Bestellpositionen entweder anlagen oder erhöhen
					IF(@kBestellposNeu is not null) 
					BEGIN 
    		      
						UPDATE @Temp_BestellPosNeu
						SET fMenge = fMenge + @MaxMenge
						WHERE kBestellPos = @kBestellposNeu;
    		      
    				END
					ELSE
					BEGIN
    		    
						INSERT INTO @Temp_BestellPosNeu (kBestellPos,kArtikel,fMenge) 
						VALUES (@kBestellposAlt,@kArtikel,@MaxMenge);
    		    
					END
    		    
					UPDATE @Temp_BestellPosAlt
					SET fMenge = fMenge - @MaxMenge
					WHERE kBestellPos = @kBestellposAlt;

				END
			END
			FETCH NEXT FROM cur_GetWMSPackItems INTO  @kWMSPackItem,@kArtikel,@fMenge,@kBestellStueckliste
		END
		CLOSE cur_GetWMSPackItems
		DEALLOCATE cur_GetWMSPackItems 



       INSERT INTO @Temp_BestellPosNeuForSplit
	  SELECT tBestellPos.kBestellPos AS kBestellpos,tBestellPos.tArtikel_kArtikel,
	  (tBestellPos.nAnzahl - ISNULL(vGeliefert.fAnzahlGeliefert,0)) - ISNULL(NewBestellPos.fMenge,0) AS fAnzahlNeu,dbo.tbestellpos.kBestellStueckliste
	  FROM tBestellPos
	  LEFT JOIN @Temp_BestellPosNeu AS NewBestellPos ON NewBestellPos.kBestellPos = tBestellPos.kBestellPos
	  LEFT JOIN ( SELECT kBestellPos, SUM(fAnzahl) as fAnzahlGeliefert 
				FROM dbo.tLieferscheinPos WITH(NOLOCK) GROUP BY kBestellPos) vGeliefert on vGeliefert.kBestellPos = dbo.tBestellPos.kBestellPos
	  WHERE tBestellPos.tBestellung_kBestellung = @kBestellung
	  AND tBestellPos.kBestellPos IS NOT NULL

	  GROUP BY  tBestellPos.kBestellPos,tBestellPos.nAnzahl,NewBestellPos.fMenge,vGeliefert.fAnzahlGeliefert,tBestellPos.tArtikel_kArtikel,dbo.tbestellpos.kBestellStueckliste
	  HAVING tBestellPos.nAnzahl - ISNULL(NewBestellPos.fMenge,0) > 0


	  -- StücklistenVäter rein
	  INSERT INTO @Temp_BestellPosNeuForSplit(kBestellPos,kArtikel,fMenge)
	  SELECT tbestellpos.kBestellStueckliste,Vater.tArtikel_kArtikel, (( cast (MAX(ISNULL(t1.fAnzahlNeu,0.0))AS DECIMAL) / SUM( cast (ISNULL(tbestellpos.nAnzahl,0.0) AS DECIMAL)  )) * Vater.nAnzahl) AS fMengeGesammt
	  FROM tbestellpos
	  JOIN tBestellpos AS Vater ON Vater.kBestellPos = tbestellpos.kBestellStueckliste
	  LEFT JOIN (SELECT BestNeu.kBestellStueckliste,SUM(cast (ISNULL(BestNeu.fMenge,0.0)AS DECIMAL)) fAnzahlNeu
	  		    FROM @Temp_BestellPosNeuForSplit BestNeu
	  		    WHERE BestNeu.kBestellPos != BestNeu.kBestellStueckliste
	  		    and BestNeu.kBestellStueckliste > 0
	  		    group by BestNeu.kBestellStueckliste) AS t1 ON  t1.kBestellStueckliste = tbestellpos.kBestellStueckliste
	  WHERE tbestellpos.kBestellPos != tbestellpos.kBestellStueckliste
	  and tbestellpos.kBestellStueckliste > 0
	  and tbestellpos.tBestellung_kBestellung = @kBestellung
	  group by Vater.tArtikel_kArtikel,tbestellpos.kBestellStueckliste,Vater.nAnzahl
	  HAVING MAX(t1.fAnzahlNeu) > 0;

	  
	    -- Alle Artikel die abgesplittet werden sollen
	   DECLARE @xSplitBestellPosition AS XML;
	   
	   SET @xSplitBestellPosition = (
	   SELECT PosNeu.kBestellPos AS kBestellpos,  PosNeu.fMenge AS fAnzahlNeu
	   FROM @Temp_BestellPosNeuForSplit AS PosNeu
	   FOR XML PATH ('Bestellpos'), TYPE);


	   EXEC Auftrag.spSplitAuftrag
				@xSplitBestellPositionen = @xSplitBestellPosition, @kBenutzer = @kBenutzer;


        SELECT TOP 1 @kBestellungNewOrder = kBestellung
	   FROM tBestellung
	   WHERE kSplitBestellung = @kBestellung
	   ORDER BY kBestellung DESC;

	   SELECT @kWarenlager = kWarenlager
	   FROM tPickliste
	   WHERE tPickliste.kPickliste = @kPickliste
	   
	   EXEC dbo.spSplitPicklisteByAuftrag  @kBestellung,@kBestellungNewOrder,@kWarenlager,@kPickliste;         
       


	    IF (@nRet = 0)
		BEGIN
			IF(@CreatedTransaction = 1)
				COMMIT;
		END
		ELSE
		BEGIN
			IF(@CreatedTransaction = 1)
				ROLLBACK TRANSACTION;
			ELSE
				ROLLBACK TRANSACTION Savepoint0;
		END;

	   SET @nRetError = @nRet;
	END TRY  
	  
	BEGIN CATCH
		SET @nRetError = -203000105; -- unbekannter Fehler
		--SET @text = ERROR_MESSAGE();

		IF(@CreatedTransaction = 1)
		    ROLLBACK TRANSACTION;
		ELSE
		    ROLLBACK TRANSACTION Savepoint0;

	DECLARE @ErrorMessage NVARCHAR(4000);
    DECLARE @ErrorSeverity INT;
    DECLARE @ErrorState INT;

    SELECT 
        @ErrorMessage = ERROR_MESSAGE(),
        @ErrorSeverity = ERROR_SEVERITY(),
        @ErrorState = ERROR_STATE();

    RAISERROR (@ErrorMessage, -- Message text.
               @ErrorSeverity, -- Severity.
               @ErrorState -- State.
               );


	END CATCH
go

