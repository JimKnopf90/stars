CREATE TRIGGER tgr_ebay_transaction_INSUPDEL
ON dbo.ebay_transaction
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
	IF(CONTEXT_INFO() IN (0x5107, 0x5108, 0x5109))
	BEGIN
		RETURN;
	END
	ROLLBACK;
	RAISERROR(N'Die Tabelle ebay_transaction kann nur über die SPs spEbayTransactionAendern, spEbayTransactionAnlegen und spEbayTransactionLoeschen geändert werden.', 15,1);
END
go

