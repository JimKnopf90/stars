

	CREATE PROCEDURE unicorn2_spInheritPicturesFromShopToShop @kShopIdFrom INT, @kShopIdTo INT, @kPlattformTo INT 
    AS
		DECLARE @kShopIdFromLocal INT
		DECLARE @kShopIdToLocal INT
		DECLARE @kPlattformToLocal INT
		DECLARE @kBild INT
		DECLARE @kArtikel INT
		DECLARE @nNr INT
		DECLARE @nInet TINYINT
		DECLARE @cBildname VARCHAR
		DECLARE @kEbayUser INT

		SET @kShopIdFromLocal = @kShopIdFrom
		SET @kShopIdToLocal = @kShopIdTo
		SET @kPlattformToLocal = @kPlattformTo

		IF NOT EXISTS(SELECT * FROM tShop WHERE tShop.kShop = @kShopIdFrom)
		BEGIN
			RAISERROR('Der Quellshop existiert nicht', 16, 16)
			RETURN
		END
		IF NOT EXISTS(SELECT * FROM tShop WHERE tShop.kShop = @kShopIdTo )
		BEGIN
			RAISERROR('Der Zielshop existiert nicht', 16, 16)
			RETURN
		END
		IF NOT EXISTS(SELECT * FROM tPlattform WHERE tPlattform.nPlattform = @kPlattformTo )
		BEGIN
			RAISERROR('Die Plattform existiert nicht', 16, 16)
			RETURN
		END
		IF (@kShopIdFrom = @kShopIdTo)
		BEGIN
			RAISERROR('Quellshop und Zielshop dÃ¼rfen nicht identisch sein!', 16, 16)
			RETURN
		END		

		DELETE FROM tArtikelbildPlattform WHERE tArtikelbildPlattform.kShop = @kShopIdTo	
		DECLARE bild CURSOR READ_ONLY FAST_FORWARD FOR SELECT tArtikelbildPlattform.kBild, tArtikelbildPlattform.kArtikel, tArtikelbildPlattform.nNr, tArtikelbildPlattform.nInet, tArtikelbildPlattform.cBildname, tArtikelbildPlattform.kEbayUser FROM tArtikelbildPlattform WHERE tArtikelbildPlattform.kShop = @kShopIdFrom

		OPEN bild 
		FETCH NEXT FROM bild INTO @kBild, @kArtikel, @nNr, @nInet, @cBildname, @kEbayUser   

			WHILE (@@FETCH_STATUS = 0) 						
				BEGIN            
			
					INSERT INTO tArtikelbildPlattform (kBild, kArtikel, kPlattform, kShop, nNr, nInet, cBildname, kEbayUser) VALUES (@kBild, @kArtikel, @kPlattformTo, @kShopIdTo, @nNr, @nInet, @cBildname, @kEbayUser); 	
			                                              		
				FETCH NEXT FROM bild INTO @kBild, @kArtikel, @nNr, @nInet, @cBildname, @kEbayUser 	        
				END 				            
			
		CLOSE bild
		DEALLOCATE bild
  go

