--- 
--- spShopWurzelKategoriesetzen
---

CREATE PROCEDURE [dbo].[spShopWurzelKategoriesetzen]
	@kShop AS INT,
	@kWurzelkategorie AS INT
AS
BEGIN

	--
	-- Wurzelkategorie und Shop müssen > 0 sein
	--
	IF(@kShop = 0 OR @kWurzelkategorie = 0)
	BEGIN
		RETURN;
	END

	--
	-- Ungültige Kategoriezuweisung (auf z.B. gelöschte Kategorie) entfernen.
	--
	UPDATE dbo.tShop 
		SET kKategorie = 0
	FROM dbo.tShop
	LEFT JOIN dbo.tKategorie ON dbo.tKategorie.kKategorie = tShop.kKategorie
	WHERE	dbo.tKategorie.kKategorie IS NULL 
			AND dbo.tKategorie.kKategorie > 0
			AND dbo.tShop.kShop = @kShop;

	--
	-- Wurzelkategorie in tShop setzen wenn noch nicht passiert
	--
	IF(NOT EXISTS(SELECT TOP 1 kShop 
				FROM dbo.tShop
				WHERE	dbo.tShop.kShop = @kShop
						AND dbo.tShop.kKategorie = @kWurzelkategorie)
	  )
	BEGIN
		UPDATE dbo.tShop
			SET dbo.tShop.kKategorie = @kWurzelkategorie
		WHERE dbo.tShop.kShop = @kShop;
	END

	--
	-- Alle tArtikelshop Einträge löschen die nicht Teil der Wurzelkategorie sind
	--
	DELETE dbo.tArtikelShop
	FROM dbo.tArtikelShop
	LEFT JOIN 
	(
		SELECT dbo.tKategorieArtikel.kArtikel
		FROM dbo.ifKategoriebaum(@kWurzelkategorie) AS Wurzelkategorien
		JOIN dbo.tKategorieArtikel ON Wurzelkategorien.kKategorie = dbo.tKategorieArtikel.kKategorie
		GROUP BY dbo.tKategorieArtikel.kArtikel
		UNION ALL
		-- VarkombiKinder beziehen sich auf die Kategorie vom Vater
		SELECT dbo.tArtikel.kArtikel
		FROM dbo.tArtikel
		JOIN 
		(
			SELECT dbo.tKategorieArtikel.kArtikel
			FROM dbo.ifKategoriebaum(@kWurzelkategorie) AS Wurzelkategorien
			JOIN dbo.tKategorieArtikel ON Wurzelkategorien.kKategorie = dbo.tKategorieArtikel.kKategorie			
			GROUP BY dbo.tKategorieArtikel.kArtikel
		) AS WurzelArtikelVater ON dbo.tArtikel.kVaterArtikel = WurzelArtikelVater.kArtikel

	) AS WurzelArtikel ON dbo.tArtikelShop.kArtikel = WurzelArtikel.kArtikel
	WHERE	WurzelArtikel.kARtikel IS NULL
			AND dbo.tArtikelShop.kShop = @kShop;

	--
	-- Alle Kategorieshop Einträge löschen die nicht Teil der Wurzelkategorie sind
	--
	DELETE dbo.tKategorieShop
	FROM dbo.tKategorieShop
	LEFT JOIN dbo.ifKategoriebaum(@kWurzelkategorie) AS Wurzelkategorien ON dbo.tKategorieShop.kKategorie = Wurzelkategorien.kKategorie
	WHERE	(Wurzelkategorien.kKategorie IS NULL OR Wurzelkategorien.kKategorie = @kWurzelkategorie)
			AND dbo.tKategorieShop.kShop = @kShop;

END
go

