CREATE TRIGGER [dbo].[jtlActionValidator_tVersandArt]
	--
	-- Copyright (c) 2012-2017 by JTL Software GmbH
	-- Datum: $Date$
	-- Version: $Rev$
	-- Autor: PN
	--
	ON [dbo].[tversandart]
	AFTER DELETE
	AS
	SET NOCOUNT ON;
	SET ANSI_NULLS ON;
	SET ANSI_NULL_DFLT_ON ON;
	SET ANSI_PADDING ON;
	SET CONCAT_NULL_YIELDS_NULL ON;
	SET XACT_ABORT OFF;
	BEGIN

		--
		-- tVersandschnittstellenKonfiguration entfernen
		--
			DELETE dbo.tVersandschnittstellenKonfiguration WITH(ROWLOCK)
			FROM dbo.tVersandschnittstellenKonfiguration WITH(ROWLOCK)
			JOIN DELETED ON dbo.tVersandschnittstellenKonfiguration.kVersandArt = DELETED.kVersandArt
			
			DELETE dbo.tAmazonShippingDruckereinstellungen WITH(ROWLOCK)
			FROM dbo.tAmazonShippingDruckereinstellungen WITH(ROWLOCK)
			JOIN DELETED ON dbo.tAmazonShippingDruckereinstellungen.kVersandArt = DELETED.kVersandArt
			
	
	END
go

