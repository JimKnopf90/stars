--- 
--- spBoxenAnBestellungZuseisen
---

CREATE PROCEDURE [dbo].[spBoxenAnBestellungZuseisen]
    --
    -- Copyright (c) 2012-2017 by JTL Software GmbH
    -- Datum: $Date$
    -- Version: $Rev$
    -- Autor: PN
    --
    @kBestellung INT,
    @kBenutzer INT,
    @kLhm INT,
    @kRet INT OUTPUT
AS
BEGIN
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;

  DECLARE @kLhmStatus INT
  DECLARE @nStatus INT
  DECLARE @kBestellungInLHM INT
  DECLARE @kBestellungInLHMNeu INT
  
  BEGIN TRANSACTION


	   SELECT @kLhmStatus = dbo.tLHMStatus.kLHMStatus, @nStatus = dbo.tLHMStatus.nStatus, @kBestellungInLHM = dbo.tLHMStatus.kBestellung
	   FROM dbo.tlhm
	   JOIN dbo.tLHMStatus ON dbo.tLHMStatus.kLHMStatus = dbo.tlhm.kLHMStatus
	   WHERE dbo.tlhm.kLHM = @kLhm;

	   IF(@kBestellungInLHM = 0 AND @nStatus = 10)
	   BEGIN

		  INSERT INTO dbo.tLHMStatus
		  (
			 dbo.tLHMStatus.kLHM,
			 dbo.tLHMStatus.nStatus,
			 dbo.tLHMStatus.dZeitstempel,
			 dbo.tLHMStatus.kBestellung
		  )
		  VALUES
		  (
			 @kLhm, -- kLHM - int
			 20, -- nStatus - int
			 GETDATE(), -- dZeitstempel - datetime
			 @kBestellung -- kBestellung - int
		  );

		  SET @kBestellungInLHMNeu = SCOPE_IDENTITY();

		  UPDATE dbo.tLHM 
		  SET kLHMStatus = @kBestellungInLHMNeu
		  WHERE KLHM = @kLhm;


		  SET @kRet = 0;

	   END;
	   ELSE
	   BEGIN
	       SET @kRet = -1;
	   END;

	   COMMIT;

END;
go

