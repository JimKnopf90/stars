CREATE TRIGGER [dbo].[tgr_tEingangsrechnungZahlung_INSUPDEL]  
-- 
-- Copyrigt (C) 2012 JTL-Software-GmbH  
-- Datum: $Date$
-- Version: $Rev$
--  
ON [dbo].[tEingangsrechnungZahlung]  
AFTER INSERT, UPDATE, DELETE  
AS   
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;  
BEGIN TRANSACTION 
	DECLARE @kEingangsrechnung BIGINT  
	SET @kEingangsrechnung = 0  
	 	  
	DECLARE c CURSOR LOCAL FAST_FORWARD FOR  
		SELECT U1.kEingangsrechnung FROM 
		(  
			SELECT deleted.kEingangsrechnung FROM deleted  
			UNION  
			SELECT inserted.kEingangsrechnung FROM inserted  
		) AS U1   
	  
	OPEN c  
	FETCH NEXT FROM c INTO @kEingangsrechnung  
	  
	WHILE (@@FETCH_STATUS = 0)  
	BEGIN  
		EXEC spEingangsrechnungStatusSetzen @kEingangsrechnung  
		FETCH NEXT FROM c INTO @kEingangsrechnung  
	END  
COMMIT
go

