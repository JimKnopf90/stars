CREATE TRIGGER [dbo].[tgr_tlagerbestand_Connector_DELETE]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: FB
--
ON [dbo].[tlagerbestand]
AFTER DELETE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN

	--Überprüfen ob Trigger gefüllt aufgerufen wird
	IF((SELECT COUNT(1) DELETED) = 0)
	BEGIN 
		RETURN;
	END

	DECLARE @Komplett AS INT;
	--DECLARE @Preis AS INT;
	DECLARE @Bestand AS INT;

	SET @Komplett = 1;
	--SET @Preis = 2;
	SET @Bestand = 4;

	--
	-- Artikel vollständig zu Webshops senden, wenn Änderungen vorgenommen wurden
	--
	DECLARE @Exists INT;
	SET @Exists = 0;
	SELECT @Exists = COUNT(1) 
			  FROM dbo.tArtikelShop WITH (NOLOCK)
			  JOIN DELETED ON dbo.tArtikelShop.kArtikel = DELETED.kArtikel
			  WHERE ((dbo.tArtikelShop.nAktion & @Bestand = 0
				 AND dbo.tArtikelShop.nAktion & @Komplett = 0)
				 OR dbo.tArtikelShop.nInBearbeitung = 1);
	IF(@Exists > 0)
	BEGIN
		UPDATE dbo.tArtikelShop
			SET dbo.tArtikelShop.nAktion = dbo.tArtikelShop.nAktion | @Bestand,
				dbo.tArtikelShop.cInet = 'Y',
				dbo.tArtikelShop.nInBearbeitung = 0
		FROM dbo.tArtikelShop
		JOIN DELETED ON dbo.tArtikelShop.kArtikel = DELETED.kArtikel
		WHERE	(dbo.tArtikelShop.nAktion & @Bestand = 0
				AND dbo.tArtikelShop.nAktion & @Komplett = 0)
				OR dbo.tArtikelShop.nInBearbeitung = 1;
	END
END
go

