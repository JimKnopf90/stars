CREATE TRIGGER [dbo].[jtlActionValidator_tartikel]  
--     
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--    
ON [dbo].[tArtikel]  
AFTER DELETE 
AS  
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN 

	--
	--Überprüfen ob Trigger mit Inhalt aufgerufen wird
	--
	IF((SELECT COUNT(1) FROM DELETED) = 0)
	BEGIN
		RETURN;
	END;

	--
	-- tWarenLagerPlatzArtikel aufräumen
	--
	DELETE dbo.tWarenLagerPlatzArtikel
	FROM dbo.tWarenLagerPlatzArtikel
	JOIN DELETED ON DELETED.kArtikel = dbo.tWarenLagerPlatzArtikel.kArtikel;

	--
	-- tArtikelBeschreibung aufräumen
	--
	DELETE dbo.tArtikelBeschreibung
	FROM dbo.tArtikelBeschreibung
	JOIN DELETED ON DELETED.kArtikel = dbo.tArtikelBeschreibung.kArtikel;

	--
	-- nIstVater auf 0 setzen wenn alle Kinder gelöscht wurden
	--
	UPDATE dbo.tArtikel
	SET dbo.tArtikel.nIstVater = 0 
	WHERE dbo.tArtikel.kArtikel IN
	(
		SELECT dbo.tArtikel.kArtikel
		FROM dbo.tArtikel
		JOIN DELETED ON dbo.tArtikel.kArtikel = DELETED.kVaterartikel
		LEFT JOIN dbo.tArtikel AS Kinder ON dbo.tArtikel.kArtikel = Kinder.kVaterArtikel
		WHERE dbo.tArtikel.nIstVater > 0 
			AND Kinder.kArtikel IS NULL 
		GROUP BY dbo.tArtikel.kArtikel
	);

	--
	-- tArtikelSpeicher aufräumen
	--
	DELETE dbo.tArtikelSpeicher
	FROM dbo.tArtikelSpeicher
	JOIN DELETED ON DELETED.kArtikel = dbo.tArtikelSpeicher.kArtikel;
		
	--
	-- tArtikelAttribute aufräumen
	--
	DELETE dbo.tArtikelAttribut
	FROM dbo.tArtikelAttribut
	JOIN DELETED ON dbo.tArtikelAttribut.kArtikel = DELETED.kArtikel;

	--
	-- tArtikelbildPlattform aufräumen
	--
	DELETE dbo.tArtikelbildPlattform
	FROM dbo.tArtikelbildPlattform
	JOIN DELETED ON dbo.tArtikelbildPlattform.kArtikel = DELETED.kArtikel;

	--
	-- tartikeldownload aufräumen
	--
	DELETE dbo.tartikeldownload
	FROM dbo.tartikeldownload
	JOIN DELETED ON dbo.tartikeldownload.kArtikel = DELETED.kArtikel;

	--
	-- tArtikelEinkaufsliste aufräumen
	--
	DELETE tArtikelEinkaufsliste
	FROM tArtikelEinkaufsliste
	JOIN DELETED ON tArtikelEinkaufsliste.kArtikel = DELETED.kArtikel;

	--
	-- tArtikelHistory aufräumen
	--
	DELETE dbo.tArtikelHistory
	FROM dbo.tArtikelHistory
	JOIN DELETED ON dbo.tArtikelHistory.kArtikel = DELETED.kArtikel;

	--
	-- tartikelkonfiggruppe aufräumen
	--
	DELETE dbo.tartikelkonfiggruppe
	FROM dbo.tartikelkonfiggruppe
	JOIN DELETED ON dbo.tartikelkonfiggruppe.kArtikel = DELETED.kArtikel;

	--
	-- tArtikelLagerOrt aufräumen
	--
	DELETE dbo.tArtikelLagerOrt
	FROM dbo.tArtikelLagerOrt
	JOIN DELETED ON dbo.tArtikelLagerOrt.kArtikel = DELETED.kArtikel;

	--
	-- tArtikelMerkmal aufräumen
	--
	DELETE dbo.tArtikelMerkmal
	FROM dbo.tArtikelMerkmal
	JOIN DELETED ON dbo.tArtikelMerkmal.kArtikel = DELETED.kArtikel;

	--
	-- tArtikelRankingGlobal aufräumen
	--
	DELETE dbo.tArtikelRankingGlobal
	FROM dbo.tArtikelRankingGlobal
	JOIN DELETED ON dbo.tArtikelRankingGlobal.kArtikel = DELETED.kArtikel;

	--
	-- tArtikelRankingZeitraum aufräumen
	--
	DELETE dbo.tArtikelRankingZeitraum
	FROM dbo.tArtikelRankingZeitraum
	JOIN DELETED ON dbo.tArtikelRankingZeitraum.kArtikel = DELETED.kArtikel;

	--
	-- tArtikelSichtbarkeit aufräumen
	--
	DELETE dbo.tArtikelSichtbarkeit
	FROM dbo.tArtikelSichtbarkeit
	JOIN DELETED ON dbo.tArtikelSichtbarkeit.kArtikel = DELETED.kArtikel;

	--
	-- tArtikelSonderpreis aufräumen
	--
	DELETE dbo.tArtikelSonderpreis
	FROM dbo.tArtikelSonderpreis
	JOIN DELETED ON dbo.tArtikelSonderpreis.kArtikel = DELETED.kArtikel;

	--
	-- tArtikelSperre aufräumen
	--
	DELETE dbo.tArtikelSperre
	FROM dbo.tArtikelSperre
	JOIN DELETED ON dbo.tArtikelSperre.kArtikel = DELETED.kArtikel;

	--
	-- tArtikelUpload aufräumen
	--
	DELETE dbo.tArtikelUpload
	FROM dbo.tArtikelUpload
	JOIN DELETED ON dbo.tArtikelUpload.kArtikel = DELETED.kArtikel;

	--
	-- tattribut aufräumen
	--
	DELETE dbo.tartikelattribut
	FROM dbo.tartikelattribut
	JOIN DELETED ON dbo.tartikelattribut.kArtikel = DELETED.kArtikel;

	--
	-- tbestelleigenschaft aufräumen
	--
	UPDATE dbo.tbestelleigenschaft
	SET dbo.tbestelleigenschaft.kArtikel = 0
	FROM dbo.tbestelleigenschaft
	JOIN DELETED ON dbo.tbestelleigenschaft.kArtikel = DELETED.kArtikel;


	-- Erst,mal raus bis das XML weg ist
	--
	-- tbestellpos aufräumen
	--
	--DECLARE @xBestellpos AS XML;
	--SET @xBestellpos = (
	--	SELECT dbo.tbestellpos.kBestellpos,	0 AS kArtikel, dbo.tbestellpos.tBestellung_kBestellung AS kBestellung, 
	--			dbo.tbestellpos.fVKPreis, dbo.tbestellpos.fMwSt, dbo.tbestellpos.nAnzahl, dbo.tbestellpos.fRabatt,
	--			dbo.tbestellpos.cString, dbo.tbestellpos.fVKNetto, dbo.tbestellpos.cArtNr, 0 AS nType, dbo.tbestellpos.cHinweis, 
	--			dbo.tbestellpos.nHatUpload, dbo.tbestellpos.cUnique, dbo.tbestellpos.kKonfigitem, dbo.tbestellpos.nDropshipping, 
	--			dbo.tbestellpos.fEKNetto, dbo.tbestellpos.cOrderItemId, dbo.tbestellpos.cItemID, dbo.tbestellpos.cTransactionID, 
	--			dbo.tbestellpos.kAmazonBestellungPos, dbo.tbestellpos.nSort, dbo.tbestellpos.kBestellStueckliste, dbo.tbestellpos.cStringStandard
	--		FROM dbo.tbestellpos
	--		JOIN DELETED ON dbo.tbestellpos.tArtikel_kArtikel = DELETED.kArtikel
	--		FOR XML PATH('Bestellpos'), TYPE
	--	);
	--EXEC dbo.spBestellposAendern @xBestellpos = @xBestellpos;	


	--
	-- Solang wir noch XML als parameter nutzen machen wir das erstmal so, der XML weg frisst hier zu viel performance (Faktor 20)
	--
	----------------------------------------------------------------
	DECLARE @OldContextInfo VARBINARY(128)
	IF(CONTEXT_INFO() IS NOT NULL)
	BEGIN
	  SET @OldContextInfo = CONTEXT_INFO()
	END;
	ELSE
	BEGIN
	  SET @OldContextInfo = 0x0
	END;

	SET CONTEXT_INFO 0x5098
	UPDATE dbo.tBestellpos 
		SET tArtikel_kArtikel = 0,
			nType = 0
	WHERE  dbo.tBestellpos.tArtikel_kArtikel IN (SELECT DELETED.kArtikel FROM DELETED)
	SET CONTEXT_INFO @OldContextInfo
	---------------------------------------------------------------
			
	UPDATE dbo.tRMRetourePos 
	SET kArtikel = 0
	WHERE  dbo.tRMRetourePos.kArtikel IN (SELECT DELETED.kArtikel FROM DELETED);	

	DELETE dbo.tArtikelZustand
	WHERE  dbo.tArtikelZustand.kHauptartikel IN (SELECT DELETED.kArtikel FROM DELETED);
	
	DELETE dbo.tArtikelZustand
	WHERE dbo.tArtikelZustand.kZustandArtikel IN (SELECT DELETED.kArtikel FROM DELETED);

    --
	-- teigenschaft aufräumen
	--
	DELETE dbo.teigenschaft
	FROM dbo.teigenschaft
	JOIN DELETED ON dbo.teigenschaft.kArtikel = DELETED.kArtikel;

	--
	-- tEingangsrechnungPos aufräumen
	--
	UPDATE dbo.tEingangsrechnungPos
	SET dbo.tEingangsrechnungPos.kArtikel = 0,
		dbo.tEingangsrechnungPos.nPosTyp = 0        
	FROM dbo.tEingangsrechnungPos
	JOIN DELETED ON dbo.tEingangsrechnungPos.kArtikel = DELETED.kArtikel;

	--
	-- tGebinde aufräumen
	--
	DELETE dbo.tGebinde
	FROM dbo.tGebinde
	JOIN DELETED ON dbo.tGebinde.kArtikel = DELETED.kArtikel;

	--
	-- tgutschrifteigenschaft aufräumen
	--
	UPDATE dbo.tgutschrifteigenschaft
	SET dbo.tgutschrifteigenschaft.kArtikel = 0
	FROM dbo.tgutschrifteigenschaft
	JOIN DELETED ON dbo.tgutschrifteigenschaft.kArtikel = DELETED.kArtikel;

	--
	-- tgutschriftpos aufräumen
	--
	DECLARE @xGutschriftpos AS XML;
	SET @xGutschriftpos = (
		SELECT dbo.tgutschriftpos.kGutschriftPos, 0 AS kArtikel, dbo.tgutschriftpos.tGutschrift_kGutschrift AS kGutschrift, 
				dbo.tgutschriftpos.fVKPreis, dbo.tgutschriftpos.fMwSt, dbo.tgutschriftpos.nAnzahl, dbo.tgutschriftpos.fRabatt, 
				dbo.tgutschriftpos.cString, dbo.tgutschriftpos.fVKNetto, dbo.tgutschriftpos.cArtNr, dbo.tgutschriftpos.nLager, 
				dbo.tgutschriftpos.kBestellPos, dbo.tgutschriftpos.kGutschriftStueckliste
			FROM dbo.tgutschriftpos
			JOIN DELETED ON dbo.tgutschriftpos.tArtikel_kArtikel = DELETED.kArtikel
			FOR XML PATH('Gutschriftpos'), TYPE
		);
	EXEC Gutschrift.spGutschriftposAendern @xGutschriftPos = @xGutschriftpos;

	--
	-- tInventur aufräumen
	--
	DELETE dbo.tInventur
	FROM dbo.tInventur
	JOIN DELETED ON dbo.tInventur.kArtikel = DELETED.kArtikel;

	--
	-- tintervallpos aufräumen
	--
	DELETE dbo.tintervallpos
	FROM dbo.tintervallpos
	JOIN DELETED ON dbo.tintervallpos.kArtikel = DELETED.kArtikel;

	--
	-- tkategorieartikel aufräumen
	--
	DELETE dbo.tkategorieartikel
	FROM dbo.tkategorieartikel
	JOIN DELETED ON dbo.tkategorieartikel.kArtikel = DELETED.kArtikel;

	--
	-- Amazon-Angebote beenden
	--
	UPDATE dbo.pf_amazon_angebot_ext
		SET  dbo.pf_amazon_angebot_ext.nMaxBestand = 0
	FROM dbo.pf_amazon_angebot_ext
	JOIN DELETED ON DELETED.cArtNr = dbo.pf_amazon_angebot_ext.cSellerSKU;

	--
	-- tkonfigitem aufräumen
	--
	DELETE dbo.tkonfigitem
	FROM dbo.tkonfigitem
	JOIN DELETED ON dbo.tkonfigitem.kArtikel = DELETED.kArtikel;

	--
	-- tlagerartikel aufräumen
	--
	DELETE dbo.tlagerartikel
	FROM dbo.tlagerartikel
	JOIN DELETED ON dbo.tlagerartikel.kArtikel = DELETED.kArtikel;

	--
	-- tliefartikel aufräumen
	--
	DELETE dbo.tliefartikel
	FROM dbo.tliefartikel
	JOIN DELETED ON dbo.tliefartikel.tArtikel_kArtikel = DELETED.kArtikel;

	--
	-- tLieferantenBestellungPos aufräumen
	--
	DECLARE @xLieferantenBestellungPos AS XML;
	SET @xLieferantenBestellungPos = (
		SELECT dbo.tLieferantenBestellungPos.kLieferantenBestellungPos  AS kLieferantenbestellungPos, dbo.tLieferantenBestellungPos.kLieferantenBestellung AS kLieferantenbestellung, 
				0 AS kArtikel, dbo.tLieferantenBestellungPos.cArtNr, dbo.tLieferantenBestellungPos.cLieferantenArtNr, 
				dbo.tLieferantenBestellungPos.cName, dbo.tLieferantenBestellungPos.cLieferantenBezeichnung,
				dbo.tLieferantenBestellungPos.fUST, dbo.tLieferantenBestellungPos.fMenge, dbo.tLieferantenBestellungPos.cHinweis, 
				dbo.tLieferantenBestellungPos.fEKNetto, dbo.tLieferantenBestellungPos.nPosTyp, dbo.tLieferantenBestellungPos.cNameLieferant, 
				dbo.tLieferantenBestellungPos.nLiefertage, dbo.tLieferantenBestellungPos.dLieferdatum, dbo.tLieferantenBestellungPos.nSort,
				dbo.tLieferantenBestellungPos.kLieferscheinPos, dbo.tLieferantenBestellungPos.fMengeGeliefert, 
				dbo.tLieferantenBestellungPos.cVPEEinheit, dbo.tLieferantenBestellungPos.nVPEMenge
			FROM dbo.tLieferantenBestellungPos
			JOIN DELETED ON dbo.tLieferantenBestellungPos.kArtikel = DELETED.kArtikel
			FOR XML PATH('LieferantenbestellungPos'), TYPE
	);
	EXEC Lieferantenbestellung.spLieferantenBestellungPosBearbeiten @xLieferantenbestellungPos = @xLieferantenBestellungPos;

	--
	-- tMedienDatei aufräumen
	--
	DELETE dbo.tMedienDatei
	FROM dbo.tMedienDatei
	JOIN DELETED ON dbo.tMedienDatei.kArtikel = DELETED.kArtikel;

	--
	-- tPicklistePos aufräumen
	--
	DELETE dbo.tPicklistePos
	FROM dbo.tPicklistePos
	JOIN DELETED ON dbo.tPicklistePos.kArtikel = DELETED.kArtikel;

	--
	-- tPreis aufräumen
	--
	DELETE dbo.tPreis
	FROM dbo.tPreis
	JOIN DELETED ON dbo.tPreis.kArtikel = DELETED.kArtikel;

	--
	-- tStueckliste aufräumen (Komponenten)
	--
	DELETE dbo.tStueckliste
	FROM dbo.tStueckliste
	JOIN DELETED ON dbo.tStueckliste.kArtikel = DELETED.kArtikel;

	--
	-- tStueckliste aufräumen (Stücklisten selbst)
	--
	DELETE dbo.tStueckliste
	FROM dbo.tStueckliste
	JOIN DELETED ON dbo.tStueckliste.kStueckliste = DELETED.kStueckliste;

	--
	-- tWarenlagerArtikelOptionen aufräumen
	--
	DELETE dbo.tWarenlagerArtikelOptionen
	FROM dbo.tWarenlagerArtikelOptionen
	JOIN DELETED ON dbo.tWarenlagerArtikelOptionen.kArtikel = DELETED.kArtikel;

	--
	-- tWarenLagerAusgang aufräumen
	--
	SET CONTEXT_INFO 0x6001;

	DELETE dbo.tWarenLagerAusgang
	FROM dbo.tWarenLagerAusgang
	JOIN DELETED ON dbo.tWarenLagerAusgang.kArtikel = DELETED.kArtikel;

	--
	-- tWarenLagerEingang aufräumen
	--
     DELETE dbo.tWarenLagerEingang
	FROM dbo.tWarenLagerEingang
	JOIN DELETED ON dbo.tWarenLagerEingang.kArtikel = DELETED.kArtikel;

	SET CONTEXT_INFO 0x000;

	--
	-- tXSell aufräumen
	--
	DELETE dbo.tXSell
	FROM dbo.tXSell
	JOIN DELETED ON dbo.tXSell.kArtikel = DELETED.kArtikel;
	
	DELETE dbo.tXSell
	FROM dbo.tXSell
	JOIN DELETED ON dbo.tXSell.kXSellArtikel = DELETED.kArtikel;

	UPDATE dbo.tArtikel
	SET dbo.tArtikel.nIstVater = 0
	FROM dbo.tArtikel
	JOIN DELETED ON dbo.tArtikel.kArtikel = DELETED.kVaterArtikel
	LEFT JOIN dbo.tArtikel AS KindArtikel ON dbo.tArtikel.kArtikel = KindArtikel.kVaterArtikel
	WHERE dbo.tArtikel.kArtikel = DELETED.kVaterArtikel
		AND KindArtikel.kArtikel IS NULL;

	--
	-- Shopzuordnungen der Kinder löschen (das muss sein, da der Trigger sich selbst nicht nochmal aufruft)
	--
	DELETE dbo.tArtikelShop
	FROM dbo.tArtikelShop
	JOIN dbo.tArtikel AS Kinder ON dbo.tArtikelShop.kArtikel = Kinder.kArtikel
							AND Kinder.kEigenschaftKombi > 0
	JOIN DELETED AS Vater ON Kinder.kVaterArtikel = Vater.kArtikel
							AND Vater.nIstVater = 1

	--
	-- Varkombi Kinder löschen
	--      
	DELETE dbo.tArtikel
	FROM dbo.tArtikel 
	JOIN DELETED ON dbo.tArtikel.kVaterArtikel = DELETED.kArtikel;

	IF EXISTS (SELECT * FROM DELETED WHERE DELETED.kEigenschaftKombi > 0)
	BEGIN

	    --
	    -- Varkombi Kinder löschen
	    --    
	    DELETE dbo.tEigenschaftKombiWert
	    FROM dbo.tEigenschaftKombiWert
	    JOIN DELETED ON dbo.tEigenschaftKombiWert.kEigenschaftKombi = DELETED.kEigenschaftKombi;

	END;

	--
	-- eBay-Angebotsvorlagen löschen
	--
	DELETE dbo.ebay_item
	FROM dbo.ebay_item
	JOIN DELETED ON dbo.ebay_item.kArtikel = DELETED.kArtikel 
				AND dbo.ebay_item.Type = 'V'
				AND dbo.ebay_item.Status < 3
				AND dbo.ebay_item.Sent = 'N'
				AND dbo.ebay_item.kPlanung = 0;

	DELETE dbo.tQueue
	FROM dbo.tQueue
	JOIN
	(
		SELECT DELETED.kHersteller, dbo.tArtikelShop.kShop
		FROM DELETED
		JOIN dbo.tArtikelShop ON DELETED.kArtikel = dbo.tArtikelShop.kArtikel
		JOIN dbo.tShopKonfiguration ON dbo.tArtikelShop.kShop = dbo.tShopKonfiguration.kShop
								AND dbo.tShopKonfiguration.nHerstellerGefiltertSenden = 1
		LEFT JOIN (
			SELECT dbo.tHersteller.kHersteller, dbo.tArtikelShop.kShop, COUNT(1) AS Anzahl
				FROM tArtikel
				JOIN dbo.tHersteller ON dbo.tArtikel.kHersteller = dbo.tHersteller.kHersteller
				JOIN dbo.tArtikelShop ON dbo.tArtikel.kArtikel = dbo.tArtikelShop.kArtikel
				GROUP BY dbo.tArtikel.kArtikel, dbo.tHersteller.kHersteller, dbo.tArtikelShop.kShop
		) AS Result ON Result.kHersteller = DELETED.kHersteller
					AND dbo.tArtikelShop.kShop = Result.kShop
		WHERE ISNULL(Anzahl, 0) = 0
	) AS Items ON dbo.tQueue.kWert = Items.kHersteller
			AND dbo.tQueue.cName = 'tHersteller'
			AND dbo.tQueue.kShop = Items.kShop
			AND dbo.tQueue.nAction = 1

	INSERT INTO dbo.tQueue(kWert, kShop, cName, kPlattform, nAction)
	SELECT DELETED.kHersteller, dbo.tArtikelShop.kShop, 'tHersteller', 2, 2
	FROM DELETED
	JOIN dbo.tArtikelShop ON DELETED.kArtikel = dbo.tArtikelShop.kArtikel
	JOIN dbo.tShopKonfiguration ON dbo.tArtikelShop.kShop = dbo.tShopKonfiguration.kShop
							AND dbo.tShopKonfiguration.nHerstellerGefiltertSenden = 1
	LEFT JOIN (
		SELECT dbo.tHersteller.kHersteller, dbo.tArtikelShop.kShop, COUNT(1) AS Anzahl
			FROM tArtikel
			JOIN dbo.tHersteller ON dbo.tArtikel.kHersteller = dbo.tHersteller.kHersteller
			JOIN dbo.tArtikelShop ON dbo.tArtikel.kArtikel = dbo.tArtikelShop.kArtikel
			GROUP BY dbo.tArtikel.kArtikel, dbo.tHersteller.kHersteller, dbo.tArtikelShop.kShop
	) AS Result ON Result.kHersteller = DELETED.kHersteller
				AND dbo.tArtikelShop.kShop = Result.kShop
	WHERE DELETED.kHersteller > 0 AND ISNULL(Anzahl, 0) = 0
	GROUP BY DELETED.kHersteller, dbo.tArtikelShop.kShop

	--
	-- tArtikelShop aufräumen
	--
	DELETE dbo.tArtikelShop
	FROM dbo.tArtikelShop
	JOIN DELETED ON dbo.tArtikelShop.kArtikel = DELETED.kArtikel;

	--
	-- tlagerbestand aufräumen
	--
	DELETE dbo.tlagerbestand
	FROM dbo.tlagerbestand
	JOIN DELETED ON DELETED.kArtikel = dbo.tlagerbestand.kArtikel;

	-- Vaterartikel , Stücklisten Väter und Alle die gelöscht wurden aktualisieren
	DECLARE @typeArtikel AS TYPE_spUpdateLagerbestand;

	INSERT INTO @typeArtikel (kArtikel)
	SELECT DISTINCT t1.kArtikel 
	FROM
			( SELECT kVaterArtikel AS kArtikel
			  FROM DELETED 
			  UNION 
			  SELECT tArtikel.kArtikel AS kArtikel
			  FROM tStueckliste
			  JOIN tArtikel ON tArtikel.kStueckliste = tStueckliste.kStueckliste
			  WHERE tStueckliste.kArtikel in (SELECT DELETED.kArtikel FROM DELETED)) AS t1
									
	EXEC spUpdateLagerbestand @typeArtikel;


	 -- Alle Bestellpos mit dem Artikel und Alle StücklistenVäter von ihm
	 DECLARE @Positionen AS XML
	 SET @Positionen = (
	    
		SELECT t2.kKey AS kKey, 1 AS nPlattform 
		FROM 
		(SELECT dbo.tReserviert.kKey AS kKey
		FROM dbo.tReserviert
		JOIN DELETED ON DELETED.kArtikel = tReserviert.kArtikel
		WHERE dbo.tReserviert.kPlattform = 1
		UNION
		SELECT dbo.tBestellpos.kBestellPos AS kKey
		FROM tBestellpos
		WHERE tBestellpos.kBestellPos IN (
								SELECT bp2.kBestellStueckliste
								FROM dbo.tBestellpos AS bp2
								JOIN tReserviert ON tReserviert.kKey = bp2.kBestellStueckliste AND dbo.tReserviert.kPlattform = 1
								JOIN DELETED ON DELETED.kArtikel = tBestellpos.tArtikel_kArtikel
								WHERE bp2.kBestellStueckliste > 0
								AND  bp2.kBestellStueckliste !=  bp2.kBestellPos
								)) AS t2
	FOR XML PATH('Keys'), TYPE
	);


    EXEC dbo.spReservierungAktualisieren @Positionen;


	--
	-- Connector - Falls Varkombi-Kind gelöscht wurde, müssen die verbliebenen Kinder nochmals zum Shop gesendet werden
	--
	IF(
		EXISTS(
		SELECT *
		FROM DELETED
		WHERE DELETED.kEigenschaftKombi > 0)
		)
	BEGIN
		UPDATE dbo.tArtikelShop
			SET dbo.tArtikelShop.cInet = 'Y',
				dbo.tArtikelShop.nAktion = 1
		FROM DELETED AS DeletedKind
		JOIN dbo.tArtikel AS RestlicheKinder ON DeletedKind.kVaterArtikel = RestlicheKinder.kVaterArtikel
		JOIN dbo.tArtikelShop ON RestlicheKinder.kArtikel = dbo.tArtikelShop.kArtikel
		WHERE DeletedKind.kEigenschaftKombi > 0;
	END;
END;
go

