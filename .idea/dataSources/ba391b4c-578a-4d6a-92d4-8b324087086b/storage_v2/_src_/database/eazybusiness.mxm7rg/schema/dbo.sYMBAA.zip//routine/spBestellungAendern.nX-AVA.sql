--- 
--- spBestellungAendern
---

CREATE PROCEDURE [dbo].[spBestellungAendern]
	@xBestellung XML = NULL,
	@kBestellung INT = NULL,
	@kRechnung INT = NULL,
	@kBenutzer INT = NULL,
	@kAdresse INT = NULL,
	@kText INT = NULL,
	@kKunde INT = NULL,
	@cBestellNr VARCHAR(40) = NULL,
	@cType CHAR(1) = NULL,
	@cAnmerkung VARCHAR(4500) = NULL,
	@dErstellt DATETIME = NULL,
	@nZahlungsziel TINYINT = NULL,
	@kVersandArt INT = NULL,
	@fVersandBruttoPreis DECIMAL(28,14) = NULL,
	@fRabatt DECIMAL(28,14) = NULL,
	@kInetBestellung INT = NULL,
	@cVersandInfo VARCHAR(255) = NULL,
	@dVersandt DATETIME = NULL,
	@cIdentCode VARCHAR(255) = NULL,
	@cBeschreibung CHAR(1) = NULL,
	@cInet CHAR(1) = NULL,
	@dLieferdatum DATETIME = NULL,
	@kBestellHinweis INT = NULL,
	@cErloeskonto VARCHAR(64) = NULL,
	@cWaehrung VARCHAR(20) = NULL,
	@fFaktor DECIMAL(28,14) = NULL,
	@kShop INT = NULL,
	@kFirma INT = NULL,
	@kLogistik INT = NULL,
	@nPlatform TINYINT = NULL,
	@kSprache INT = NULL,
	@fGutschein DECIMAL(28,14) = NULL,
	@dGedruckt DATETIME = NULL,
	@dMailVersandt DATETIME = NULL,
	@cInetBestellnr VARCHAR(50) = NULL,
	@kZahlungsArt INT = NULL,
	@kLieferAdresse INT = NULL,
	@kRechnungsAdresse INT = NULL,
	@nIGL TINYINT = NULL,
	@nUStFrei TINYINT = NULL,
	@cStatus VARCHAR(255) = NULL,
	@dVersandMail DATETIME = NULL,
	@dZahlungsMail DATETIME = NULL,
	@cUserName VARCHAR(255) = NULL,
	@cVerwendungszweck VARCHAR(255) = NULL,
	@fSkonto DECIMAL(28,14) = NULL,
	@kColor INT = NULL,
	@nStorno TINYINT = NULL,
	@cModulID VARCHAR(255) = NULL,
	@nZahlungsTyp INT = NULL,
	@nHatUpload INT = NULL,
	@fZusatzGewicht DECIMAL(28,14) = NULL,
	@nKomplettAusgeliefert TINYINT = NULL,
	@dBezahlt DATETIME = NULL,
	@kSplitBestellung INT = NULL,
	@cPUIZahlungsdaten VARCHAR(MAX) = NULL,
	@nPrio INT = NULL,
	@cVersandlandISO VARCHAR(5) = NULL,
	@cUstId VARCHAR(25) = NULL,
	@nPremium TINYINT = NULL,
	@kRueckhalteGrund INT = NULL,
	@cJfoid VARCHAR(100) = NULL,
	@kFulfillmentLieferant INT = NULL,
	@cKundenauftragsnummer VARCHAR(255) = NULL,
	@nIstExterneRechnung BIT = NULL
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
DECLARE @ErrorMessage NVARCHAR(4000);
DECLARE @ErrorSeverity INT;
DECLARE @ErrorState INT;
DECLARE @retry INT;
SET @retry = 5;
WHILE @retry > 0
BEGIN
	SET CONTEXT_INFO 0x5104;
	BEGIN TRY
		BEGIN TRANSACTION
			IF(OBJECT_ID('tempdb..#Bestellung') IS NOT NULL)
			BEGIN
				DROP TABLE #Bestellung;
			END
			CREATE TABLE #Bestellung(kBestellung INT, kRechnung INT, kBenutzer INT, kAdresse INT, kText INT, kKunde INT,
									cBestellNr VARCHAR(40), cType CHAR(1), cAnmerkung VARCHAR(4500), dErstellt DATETIME,
									nZahlungsziel TINYINT, kVersandArt INT, fVersandBruttoPreis DECIMAL(28,14), fRabatt DECIMAL(28,14),
									kInetBestellung INT, cVersandInfo VARCHAR(255), dVersandt DATETIME, cIdentCode VARCHAR(255),
									cBeschreibung CHAR(1), cInet CHAR(1), dLieferdatum DATETIME, kBestellHinweis INT,
									cErloeskonto VARCHAR(64), cWaehrung VARCHAR(20), fFaktor DECIMAL(28,14), kShop INT,
									kFirma INT, kLogistik INT, nPlatform TINYINT, kSprache INT, fGutschein DECIMAL(28,14),
									dGedruckt DATETIME, dMailVersandt DATETIME, cInetBestellnr VARCHAR(50), kZahlungsArt INT,
									kLieferAdresse INT, kRechnungsAdresse INT, nIGL TINYINT, nUStFrei TINYINT, cStatus VARCHAR(255),
									dVersandMail DATETIME, dZahlungsMail DATETIME, cUserName VARCHAR(255), cVerwendungszweck VARCHAR(255),
									fSkonto DECIMAL(28,14), kColor INT, nStorno TINYINT, cModulID VARCHAR(255), nZahlungsTyp INT,
									nHatUpload INT, fZusatzGewicht DECIMAL(28,14), nKomplettAusgeliefert TINYINT, dBezahlt DATETIME,
									kSplitBestellung INT, cPUIZahlungsdaten VARCHAR(MAX), nPrio INT,
									cVersandlandISO VARCHAR(5), cUstId VARCHAR(25),
									nChangeKomplettAusgeliefert TINYINT, nChangeStorno TINYINT, nChangeType TINYINT, nChangeWert TINYINT,
									nChangeBezahlt TINYINT, nChangeVersandart TINYINT, nPremium TINYINT, cVersandlandWaehrung VARCHAR(20), 
									fVersandlandFaktor DECIMAL(28,14), kRueckhalteGrund INT, cKundenauftragsnummer VARCHAR(250), nIstExterneRechnung BIT,
									cJfoid VARCHAR(100), kFulfillmentLieferant INT);
			IF(@xBestellung IS NOT NULL)
			BEGIN
				INSERT INTO #Bestellung(kBestellung, kRechnung, kBenutzer, kAdresse, kText, kKunde, cBestellNr, cType, cAnmerkung,
										dErstellt, nZahlungsziel, kVersandArt, fVersandBruttoPreis, fRabatt, kInetBestellung,
										cVersandInfo, dVersandt, cIdentCode, cBeschreibung, cInet, dLieferdatum, kBestellHinweis,
										cErloeskonto, cWaehrung, fFaktor, kShop, kFirma, kLogistik, nPlatform, kSprache, fGutschein,
										dGedruckt, dMailVersandt, cInetBestellnr, kZahlungsArt, kLieferAdresse, kRechnungsAdresse,
										nIGL, nUStFrei, cStatus, dVersandMail, dZahlungsMail, cUserName, cVerwendungszweck,
										fSkonto, kColor, nStorno, cModulID, nZahlungsTyp, nHatUpload, fZusatzGewicht, nKomplettAusgeliefert,
										dBezahlt, kSplitBestellung, cPUIZahlungsdaten, nPrio, cVersandlandISO, cUstId,nChangeKomplettAusgeliefert, 
										nChangeStorno, nChangeType, nChangeWert, nChangeBezahlt, nChangeVersandart, nPremium, cVersandlandWaehrung,
										fVersandlandFaktor, kRueckhalteGrund, cKundenauftragsnummer, nIstExterneRechnung, cJfoid, kFulfillmentLieferant)
					SELECT	Bestellung.ID.value('kBestellung[1]', 'INT'),
							Bestellung.ID.value('kRechnung[1]', 'INT'),
							Bestellung.ID.value('kBenutzer[1]', 'INT'),
							Bestellung.ID.value('kAdresse[1]', 'INT'),
							Bestellung.ID.value('kText[1]', 'INT'),
							Bestellung.ID.value('kKunde[1]', 'INT'),
							Bestellung.ID.value('cBestellNr[1]', 'VARCHAR(50)'),
							Bestellung.ID.value('cType[1]', 'CHAR(1)'),
							Bestellung.ID.value('cAnmerkung[1]', 'VARCHAR(4500)'),
							Bestellung.ID.value('dErstellt[1]', 'DATETIME'),
							Bestellung.ID.value('nZahlungsziel[1]', 'TINYINT'),
							Bestellung.ID.value('kVersandArt[1]', 'INT'),
							Bestellung.ID.value('fVersandBruttoPreis[1]', 'DECIMAL(28,14)'),
							Bestellung.ID.value('fRabatt[1]', 'DECIMAL(28,14)'),
							Bestellung.ID.value('kInetBestellung[1]', 'INT'),
							Bestellung.ID.value('cVersandInfo[1]', 'VARCHAR(255)'),
							Bestellung.ID.value('dVersandt[1]', 'DATETIME'),
							Bestellung.ID.value('cIdentCode[1]', 'VARCHAR(255)'),
							Bestellung.ID.value('cBeschreibung[1]', 'CHAR(1)'),
							Bestellung.ID.value('cInet[1]', 'CHAR(1)'),
							Bestellung.ID.value('dLieferdatum[1]', 'DATETIME'),
							Bestellung.ID.value('kBestellHinweis[1]', 'INT'),
							Bestellung.ID.value('cErloeskonto[1]', 'VARCHAR(64)'),
							CASE WHEN Bestellung.ID.value('cWaehrung[1]', 'VARCHAR(20)') IS NULL OR Bestellung.ID.value('cWaehrung[1]', 'VARCHAR(20)') = ''
								THEN dbo.tWaehrung.cEAMapping
								ELSE Bestellung.ID.value('cWaehrung[1]', 'VARCHAR(20)')
							END,
							Bestellung.ID.value('fFaktor[1]', 'DECIMAL(28,14)'),
							Bestellung.ID.value('kShop[1]', 'INT'),
							Bestellung.ID.value('kFirma[1]', 'INT'),
							Bestellung.ID.value('kLogistik[1]', 'INT'),
							Bestellung.ID.value('nPlatform[1]', 'TINYINT'),
							Bestellung.ID.value('kSprache[1]', 'INT'),
							Bestellung.ID.value('fGutschein[1]', 'DECIMAL(28,14)'),
							Bestellung.ID.value('dGedruckt[1]', 'DATETIME'),
							Bestellung.ID.value('dMailVersandt[1]', 'DATETIME'),
							Bestellung.ID.value('cInetBestellNr[1]', 'VARCHAR(50)'),
							Bestellung.ID.value('kZahlungsArt[1]', 'INT'),
							Bestellung.ID.value('kLieferAdresse[1]', 'INT'),
							Bestellung.ID.value('kRechnungsAdresse[1]', 'INT'),
							Bestellung.ID.value('nIGL[1]', 'TINYINT'),
							Bestellung.ID.value('nUStFrei[1]', 'TINYINT'),
							Bestellung.ID.value('cStatus[1]', 'VARCHAR(255)'),
							Bestellung.ID.value('dVersandMail[1]', 'DATETIME'),
							Bestellung.ID.value('dZahlungsMail[1]', 'DATETIME'),
							Bestellung.ID.value('cUserName[1]', 'VARCHAR(255)'),
							Bestellung.ID.value('cVerwendungszweck[1]', 'VARCHAR(255)'),
							Bestellung.ID.value('fSkonto[1]', 'DECIMAL(28,14)'),
							Bestellung.ID.value('kColor[1]', 'INT'),
							Bestellung.ID.value('nStorno[1]', 'TINYINT'),
							Bestellung.ID.value('cModulID[1]', 'VARCHAR(255)'),
							Bestellung.ID.value('nZahlungsTyp[1]', 'INT'),
							Bestellung.ID.value('nHatUpload[1]', 'INT'),
							Bestellung.ID.value('fZusatzGewicht[1]', 'DECIMAL(28,14)'),
							CASE WHEN Bestellung.ID.value('nKomplettAusgeliefert[1]', 'TINYINT') > 1
								THEN CASE WHEN Bestellung.ID.value('nKomplettAusgeliefert[1]', 'TINYINT') = 2
										THEN 2
										ELSE Bestellung.ID.value('nKomplettAusgeliefert[1]', 'TINYINT') - 10
									END
								ELSE dbo.tbestellung.nKomplettAusgeliefert
							END,
							Bestellung.ID.value('dBezahlt[1]', 'DATETIME'),
							Bestellung.ID.value('kSplitBestellung[1]', 'INT'),
							Bestellung.ID.value('cPUIZahlungsdaten[1]', 'VARCHAR(MAX)'),
							Bestellung.ID.value('nPrio[1]', 'INT'),
							CASE WHEN Bestellung.ID.value('cVersandlandISO[1]', 'VARCHAR(5)') IS NULL OR Bestellung.ID.value('cVersandlandISO[1]', 'VARCHAR(5)') = ''
								THEN dbo.tbestellung.cVersandlandISO
								ELSE Bestellung.ID.value('cVersandlandISO[1]', 'VARCHAR(5)')
							END,
							CASE WHEN Bestellung.ID.value('cUstId[1]', 'VARCHAR(25)') IS NULL OR Bestellung.ID.value('cUstId[1]', 'VARCHAR(25)') = ''
								THEN dbo.tbestellung.cUstId
								ELSE Bestellung.ID.value('cUstId[1]', 'VARCHAR(25)')
							END,
							CASE WHEN dbo.tbestellung.nKomplettAusgeliefert <> Bestellung.ID.value('nKomplettAusgeliefert[1]', 'TINYINT')
								THEN 1
								ELSE 0
							END,
							CASE WHEN dbo.tbestellung.nStorno <> Bestellung.ID.value('nStorno[1]', 'TINYINT')
								THEN 1
								ELSE 0
							END,
							CASE WHEN dbo.tbestellung.cType <> Bestellung.ID.value('cType[1]', 'CHAR(1)')
								THEN 1
								ELSE 0
							END,
							CASE WHEN dbo.tbestellung.cWaehrung <> Bestellung.ID.value('cWaehrung[1]', 'VARCHAR(20)')
									OR dbo.tbestellung.fRabatt <> Bestellung.ID.value('fRabatt[1]', 'DECIMAL(28,14)')
									OR dbo.tbestellung.fGutschein <> Bestellung.ID.value('fGutschein[1]', 'DECIMAL(28,14)')
									OR dbo.tbestellung.fVersandBruttoPreis <> Bestellung.ID.value('fVersandBruttoPreis[1]', 'DECIMAL(28,14)')
									OR dbo.tbestellung.fSkonto <> Bestellung.ID.value('fSkonto[1]', 'DECIMAL(28,14)')
									OR dbo.tbestellung.fFaktor <> Bestellung.ID.value('fFaktor[1]', 'DECIMAL(28,14)')
								THEN 1
								ELSE 0
							END,
							CASE WHEN dbo.tbestellung.dBezahlt <> Bestellung.ID.value('dBezahlt[1]', 'DATETIME')
								THEN 1
								ELSE 0
							END,
							CASE WHEN dbo.tbestellung.tVersandArt_kVersandArt <> Bestellung.ID.value('kVersandart[1]', 'INT')
								THEN 1
								ELSE 0
							END,
							Bestellung.ID.value('nPremium[1]', 'TINYINT'),
							dbo.tland.cWaehrung,
							WaehrungVersandland.fFaktor,							
							Bestellung.ID.value('kRueckhalteGrund[1]', 'INT'),
							Bestellung.ID.value('cKundenauftragsnummer[1]', 'VARCHAR(250)'),
							Bestellung.ID.value('nIstExterneRechnung[1]', 'BIT'),
							Bestellung.ID.value('cJfoid[1]', 'VARCHAR(100)'),
							Bestellung.ID.value('kFulfillmentLieferant[1]', 'INT')
						FROM @xBestellung.nodes('Bestellung') AS Bestellung(ID)
						JOIN dbo.tbestellung ON dbo.tbestellung.kBestellung = Bestellung.ID.value('kBestellung[1]', 'INT')
						JOIN dbo.tWaehrung ON dbo.twaehrung.nStandard = 1
						JOIN dbo.tland ON dbo.tland.cIso = Bestellung.ID.value('cVersandlandISO[1]', 'VARCHAR(5)')
						JOIN dbo.tWaehrung AS WaehrungVersandLand ON WaehrungVersandland.cEAMapping = dbo.tland.cWaehrung;
			END
			ELSE
			BEGIN
				DECLARE @nChangeKomplettAusgeliefert TINYINT;
				DECLARE @nChangeStorno TINYINT;
				DECLARE @nChangeType TINYINT;
				DECLARE @nChangeWert TINYINT;
				DECLARE @nChangeBezahlt TINYINT;
				DECLARE @nChangeVersandart INT;
				SELECT @nChangeKomplettAusgeliefert = CASE WHEN @nKomplettAusgeliefert <> nKomplettAusgeliefert
															THEN 1
															ELSE 0
														END,
						@nChangeStorno = CASE WHEN @nStorno <> nStorno
											THEN 1
											ELSE 0
										END,
						@nChangeType = CASE WHEN @cType <> cType
										THEN 1
										ELSE 0
									END,
						@nChangeWert = CASE WHEN @cWaehrung <> cWaehrung
											OR @fRabatt <> fRabatt
											OR @fGutschein <> fGutschein
											OR @fVersandBruttoPreis <> fVersandBruttoPreis
											OR @fSkonto <> fSkonto
											OR @fFaktor <> fFaktor
										THEN 1
										ELSE 0
									END,
						@nChangeBezahlt = CASE WHEN @dBezahlt <> dBezahlt
											THEN 1
											ELSE 0
										END,
						@nChangeVersandart = CASE WHEN @kVersandArt <> tVersandart_kVersandArt
												THEN 1
												ELSE 0
											END,
						@nKomplettAusgeliefert = CASE WHEN @nKomplettAusgeliefert = 2
													THEN 2
													ELSE dbo.tbestellung.nKomplettAusgeliefert
												END,
						@cVersandlandISO = 	CASE WHEN @cVersandlandISO IS NULL OR @cVersandlandISO = ''
										THEN dbo.tbestellung.cVersandlandISO
										ELSE @cVersandlandISO
									END,
						@cUstId = CASE WHEN @cUstId IS NULL OR @cUstId = ''
									THEN dbo.tbestellung.cUstId
									ELSE @cUstId
								END																		
					FROM dbo.tbestellung 
					WHERE dbo.tbestellung.kBestellung = @kBestellung;
				DECLARE @cVersandlandWaehrung VARCHAR(20);
				SELECT @cVersandlandWaehrung = dbo.tland.cWaehrung
					FROM dbo.tland
					WHERE dbo.tland.cISO = @cVersandlandISO;
				DECLARE @fVersandlandFaktor DECIMAL(28,14);
				SELECT @fVersandlandFaktor = dbo.tWaehrung.fFaktor
					FROM dbo.tWaehrung 
					WHERE dbo.tWaehrung.cEAMapping = @cVersandlandWaehrung;
				SELECT @cWaehrung = dbo.tWaehrung.cEAMapping
				FROM dbo.tWaehrung
				WHERE nStandard = 1
					AND @cWaehrung IS NULL OR @cWaehrung = '';
				INSERT INTO #Bestellung(kBestellung, kRechnung, kBenutzer, kAdresse, kText, kKunde, cBestellNr, cType, cAnmerkung,
										dErstellt, nZahlungsziel, kVersandArt, fVersandBruttoPreis, fRabatt, kInetBestellung,
										cVersandInfo, dVersandt, cIdentCode, cBeschreibung, cInet, dLieferdatum, kBestellHinweis,
										cErloeskonto, cWaehrung, fFaktor, kShop, kFirma, kLogistik, nPlatform, kSprache, fGutschein, 
										dGedruckt, dMailVersandt, cInetBestellnr, kZahlungsArt, kLieferAdresse, kRechnungsAdresse,
										nIGL, nUStFrei, cStatus, dVersandMail, dZahlungsMail, cUserName, cVerwendungszweck,
										fSkonto, kColor, nStorno, cModulID, nZahlungsTyp, nHatUpload, fZusatzGewicht,
										nKomplettAusgeliefert, dBezahlt, kSplitBestellung, cPUIZahlungsdaten, nPrio,
										cVersandlandISO, cUstId,nChangeKomplettAusgeliefert, nChangeStorno, nChangeType, nChangeWert, 
										nChangeBezahlt, nChangeVersandart, nPremium, cVersandlandWaehrung, fVersandlandFaktor, 
										kRueckhalteGrund, cKundenauftragsnummer, nIstExterneRechnung, cJfoid, kFulfillmentLieferant)
					VALUES(@kBestellung, @kRechnung, @kBenutzer, @kAdresse, @kText, @kKunde, @cBestellNr, @cType, @cAnmerkung,
							@dErstellt, @nZahlungsziel, @kVersandArt, @fVersandBruttoPreis, @fRabatt, @kInetBestellung, 
							@cVersandInfo, @dVersandt, @cIdentCode, @cBeschreibung, @cInet, @dLieferdatum, @kBestellHinweis,
							@cErloeskonto, @cWaehrung, @fFaktor, @kShop, @kFirma, @kLogistik, @nPlatform, @kSprache, @fGutschein,
							@dGedruckt, @dMailVersandt, @cInetBestellnr, @kZahlungsArt, @kLieferAdresse, @kRechnungsAdresse,
							@nIGL, @nUStFrei, @cStatus, @dVersandMail, @dZahlungsMail, @cUserName, @cVerwendungszweck,
							@fSkonto, @kColor, @nStorno, @cModulID, @nZahlungsTyp, @nHatUpload, @fZusatzGewicht, 
							@nKomplettAusgeliefert, @dBezahlt, @kSplitBestellung, @cPUIZahlungsdaten, @nPrio,
							@cVersandlandISO, @cUstId,@nChangeKomplettAusgeliefert, @nChangeStorno, @nChangeType, @nChangeWert, 
							@nChangeBezahlt, @nChangeVersandart, @nPremium, @cVersandlandWaehrung, @fVersandlandFaktor, 
							@kRueckhalteGrund, @cKundenauftragsnummer, @nIstExterneRechnung, @cJfoid, @kFulfillmentLieferant);				
			END
			UPDATE dbo.tbestellung
				SET	tRechnung_kRechnung = ISNULL(dbo.trechnung.kRechnung, 0),
					tBenutzer_kBenutzer = #Bestellung.kBenutzer,
					tAdresse_kAdresse = #Bestellung.kAdresse,
					tText_kText = CASE WHEN #Bestellung.kText < 0 THEN 0 ELSE #Bestellung.kText END,
					tKunde_kKunde = #Bestellung.kKunde,
					cBestellNr = #Bestellung.cBestellNr,
					cType = #Bestellung.cType,
					cAnmerkung = #Bestellung.cAnmerkung,
					dErstellt = #Bestellung.dErstellt,
					nZahlungsziel = #Bestellung.nZahlungsziel,
					tVersandArt_kVersandArt = #Bestellung.kVersandArt,
					fVersandBruttoPreis = #Bestellung.fVersandBruttoPreis,
					fRabatt = #Bestellung.fRabatt,
					kInetBestellung = #Bestellung.kInetBestellung,
					cVersandInfo = #Bestellung.cVersandInfo,
					dVersandt = #Bestellung.dVersandt,
					cIdentCode = #Bestellung.cIdentCode,
					cBeschreibung = #Bestellung.cBeschreibung,
					cInet = #Bestellung.cInet,
					dLieferdatum = #Bestellung.dLieferdatum,
					kBestellHinweis = #Bestellung.kBestellHinweis,
					cErloeskonto = #Bestellung.cErloeskonto,
					cWaehrung = #Bestellung.cWaehrung,
					fFaktor = CASE WHEN #Bestellung.fFaktor < 0 THEN 0 ELSE #Bestellung.fFaktor END,
					kShop = #Bestellung.kShop,
					kFirma = #Bestellung.kFirma,
					kLogistik = #Bestellung.kLogistik,
					nPlatform = #Bestellung.nPlatform,
					kSprache = #Bestellung.kSprache,
					fGutschein = #Bestellung.fGutschein,
					dGedruckt = #Bestellung.dGedruckt,
					dMailVersandt = #Bestellung.dMailVersandt,
					cInetBestellNr = #Bestellung.cInetBestellnr,
					kZahlungsArt = #Bestellung.kZahlungsArt,
					kLieferAdresse = #Bestellung.kLieferAdresse,
					kRechnungsAdresse = #Bestellung.kRechnungsAdresse,
					nIGL = #Bestellung.nIGL,
					nUStFrei = #Bestellung.nUStFrei,
					cStatus = #Bestellung.cStatus,
					dVersandMail = #Bestellung.dVersandMail,
					dZahlungsMail = #Bestellung.dZahlungsMail,
					cUserName = #Bestellung.cUserName,
					cVerwendungszweck = #Bestellung.cVerwendungszweck,
					fSkonto = #Bestellung.fSkonto,
					kColor = CASE WHEN #Bestellung.kColor < 0 THEN 0 ELSE #Bestellung.kColor END,
					nStorno = #Bestellung.nStorno,
					cModulID = #Bestellung.cModulID,
					nZahlungsTyp = #Bestellung.nZahlungsTyp,
					nHatUpload = #Bestellung.nHatUpload,
					fZusatzGewicht = #Bestellung.fZusatzGewicht,
					nKomplettAusgeliefert = #Bestellung.nKomplettAusgeliefert,
					dBezahlt = #Bestellung.dBezahlt,
					kSplitBestellung = #Bestellung.kSplitBestellung,
					cPUIZahlungsdaten = #Bestellung.cPUIZahlungsdaten,
					nPrio = #Bestellung.nPrio,
					cVersandlandISO = #Bestellung.cVersandlandISO,
					cUstId = #Bestellung.cUstId,
					nPremium = #Bestellung.nPremium,
					fVersandlandWaehrungFaktor = #Bestellung.fVersandlandFaktor,
					cVersandlandWaehrung = #Bestellung.cVersandlandWaehrung,
					kRueckhalteGrund = #Bestellung.kRueckhalteGrund,
					cKundenauftragsnummer = #Bestellung.cKundenauftragsnummer,
					nIstExterneRechnung = #Bestellung.nIstExterneRechnung,
					cJfoid = #Bestellung.cJfoid,
					kFulfillmentLieferant = #Bestellung.kFulfillmentLieferant
				FROM #Bestellung 
				LEFT JOIN dbo.trechnung ON #Bestellung.kBestellung = dbo.trechnung.tBestellung_kBestellung
				WHERE #Bestellung.kBestellung = dbo.tBestellung.kBestellung;
	
				IF(EXISTS(SELECT * FROM #Bestellung WHERE #Bestellung.nChangeKomplettAusgeliefert = 1))
				BEGIN
					DELETE dbo.tBestellungWMSFreigabe
						FROM dbo.tBestellungWMSFreigabe 
						WHERE dbo.tBestellungWMSFreigabe.kBestellung 
							IN(SELECT kBestellung 
								FROM #Bestellung 
								WHERE #Bestellung.nChangeKomplettAusgeliefert = 1
									AND #Bestellung.nKomplettAusgeliefert > 0);
				END
				IF(EXISTS(SELECT * FROM #Bestellung WHERE #Bestellung.nChangeStorno = 1))
				BEGIN
					UPDATE dbo.tBestellung
						SET nKomplettAusgeliefert = 0
						FROM dbo.tBestellung 
						JOIN #Bestellung ON #Bestellung.kBestellung = dbo.tBestellung.kBestellung
						WHERE #Bestellung.nChangeStorno = 1;
				END
				IF(EXISTS(SELECT * FROM #Bestellung WHERE #Bestellung.nChangeStorno = 1 
								OR #Bestellung.nChangeKomplettAusgeliefert = 1 OR #Bestellung.nChangeType = 1
								))
				BEGIN
					UPDATE dbo.tlagerbestand
						SET fInAuftraegen = fInAuftraegen - Reservierung.fAnzahl,
							fVerfuegbar = fVerfuegbar + CASE WHEN dbo.tlagerbestand.nLagerAktiv = 1
															THEN Reservierung.fAnzahl
															ELSE 0
														END
						FROM dbo.tlagerbestand
						JOIN (SELECT kArtikel, SUM(fAnzahl) AS fAnzahl
									FROM dbo.tReserviert
									JOIN #Bestellung ON #Bestellung.kBestellung = dbo.tReserviert.kBestellung
									WHERE #Bestellung.nStorno = 1
									GROUP BY kArtikel
						) AS Reservierung ON Reservierung.kArtikel = dbo.tlagerbestand.kArtikel;

					DELETE FROM dbo.tReserviert 
						FROM dbo.tReserviert 
						JOIN #Bestellung ON #Bestellung.kBestellung = dbo.tReserviert.kBestellung
						WHERE #Bestellung.nStorno = 1;
					DECLARE @xPositionen AS XML;
					SET @xPositionen = (
						SELECT kBestellpos AS kKey, 1 AS nPlattform 
							FROM dbo.tbestellpos 
							WHERE dbo.tbestellpos.tBestellung_kBestellung IN (
								SELECT #Bestellung.kBestellung
									FROM #Bestellung 
									WHERE (#Bestellung.nChangeStorno = 1
										OR #Bestellung.nChangeKomplettAusgeliefert = 1
										OR #Bestellung.nChangeType = 1) AND #Bestellung.nStorno = 0)
						FOR XML PATH('Keys'), TYPE
					);
					EXEC dbo.spReservierungAktualisieren @xPositionen;
					IF(EXISTS(SELECT * FROM #Bestellung WHERE nChangeKomplettAusgeliefert = 1 OR nStorno = 1))
					BEGIN
						DECLARE @typeArtikel AS TYPE_spUpdateLagerbestand;
						INSERT INTO @typeArtikel(kArtikel)
							SELECT dbo.tBestellpos.tArtikel_kArtikel AS kArtikel
								FROM dbo.tBestellpos
								WHERE dbo.tbestellpos.tBestellung_kBestellung IN (
									SELECT #Bestellung.kBestellung
										FROM #Bestellung
										WHERE #Bestellung.nChangeKomplettAusgeliefert = 1 
											OR #Bestellung.nStorno = 1);
						EXEC dbo.spUpdateLagerbestand @typeArtikel;
					END
				END

				IF(EXISTS(SELECT * FROM #Bestellung 
								WHERE #Bestellung.nChangeWert = 1
									OR #Bestellung.nChangeType = 1
									OR #Bestellung.nChangeStorno = 1
									))
				BEGIN
					DECLARE @xBestellungen XML;
					SET @xBestellungen = (
						SELECT kBestellung
							FROM #Bestellung
							WHERE #Bestellung.nChangeWert = 1
								OR #Bestellung.nChangeType = 1
								OR #Bestellung.nChangeStorno = 1
							FOR XML PATH('Bestellung'), TYPE
						);
				END

				IF(EXISTS(SELECT * FROM #Bestellung 
							WHERE #Bestellung.nChangeBezahlt = 1))
				BEGIN
					UPDATE dbo.trechnung
						SET cBezahlt = CASE WHEN #Bestellung.dBezahlt IS NULL
											THEN 'N'
											ELSE 'Y'
										END
						FROM dbo.trechnung 
						JOIN #Bestellung ON #Bestellung.kRechnung = dbo.trechnung.kRechnung;
					IF(EXISTS(SELECT * FROM dbo.tWarenLager WHERE dbo.tWarenLager.nLagerplatzVerwaltung > 0))
					BEGIN 
						DECLARE @kLHM INT;
						DECLARE cBestellung CURSOR LOCAL FAST_FORWARD FOR  
							SELECT tLHM.kLHM
								FROM #Bestellung
								JOIN dbo.tZahlung ON tZahlung.kBestellung = #Bestellung.kBestellung
								JOIN dbo.tZahlungsart ON dbo.tZahlungsart.kZahlungsart = dbo.tZahlung.kZahlungsart
								JOIN dbo.tLHMStatus ON dbo.tLHMStatus.kBestellung = #Bestellung.kBestellung
								JOIN dbo.tLHM ON dbo.tLHM.kLHMStatus = dbo.tLHMStatus.kLHMStatus
								WHERE dbo.tLHMStatus.nstatus = 20
								AND dbo.tZahlungsart.nAusliefernVorZahlung = 0
								AND #Bestellung.dBezahlt IS NOT NULL
								AND #Bestellung.nChangeBezahlt = 1;
						OPEN cBestellung    
						FETCH NEXT FROM cBestellung INTO @kLHM
						WHILE @@FETCH_STATUS = 0    
						BEGIN   
							EXEC spVersandBoxPruefen @kLHM = @kLHM

							FETCH NEXT FROM cBestellung INTO @kLHM
						END;  	
						CLOSE cBestellung;  
						DEALLOCATE cBestellung;
					END
				END
				IF(EXISTS(SELECT * FROM #Bestellung WHERE #Bestellung.nChangeVersandart = 1))
				BEGIN
					UPDATE dbo.tbestellung
							SET tVersandArt_kVersandArt = tMainVersandArt.kVersandArt
						FROM dbo.tbestellung 
						JOIN dbo.tversandart ON dbo.tbestellung.tVersandArt_kVersandArt = dbo.tversandart.kVersandArt						
												AND dbo.tversandart.kMainVersandart > 0
						JOIN dbo.tversandart AS tMainVersandArt ON tMainVersandArt.kVersandart = dbo.tversandart.kMainVersandart
						JOIN #Bestellung ON #Bestellung.kBestellung = dbo.tbestellung.kBestellung;

						-- Prio der Bestellung, auf Prio der Versandart setzten
						UPDATE dbo.tbestellung
							SET dbo.tbestellung.nPrio =  dbo.tversandart.nPrioritaet
						FROM dbo.tbestellung 
						JOIN dbo.tversandart ON dbo.tbestellung.tVersandArt_kVersandArt = dbo.tversandart.kVersandArt						
						JOIN #Bestellung ON #Bestellung.kBestellung = dbo.tbestellung.kBestellung;


				END
				IF(@xBestellungen IS NOT NULL)
				BEGIN
					EXEC dbo.spBestellungEckdatenAktualisieren @xBestellungen;
				END
			SET @retry = -1;
			SET CONTEXT_INFO 0x0;
		COMMIT
	END TRY
	BEGIN CATCH
	IF(ERROR_NUMBER() = 1205)
			BEGIN
				SET @retry = @retry - 1;
				ROLLBACK;
				IF(@retry = 0)
				BEGIN
					SELECT @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
					RAISERROR (	@ErrorMessage, 
								@ErrorSeverity,
								@ErrorState
					);
					SET CONTEXT_INFO 0x0;
					RETURN;
				END
				WAITFOR DELAY '00:00:00:5';
			END
			ELSE 
			BEGIN
				SET @retry = -1;
				SELECT @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
				ROLLBACK;
				RAISERROR (	@ErrorMessage, 
							@ErrorSeverity,
							@ErrorState
				);
				SET CONTEXT_INFO 0x0;
				RETURN;
			END
	END CATCH
	SET CONTEXT_INFO 0x0;	
END
go

