--- 
--- spBestellungenZusammenfassen
---

CREATE PROCEDURE [dbo].[spBestellungenZusammenfassen]
-- 
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Create date:	07.08.2014
-- Version: $Rev$
-- Datum: $Date$
-- Author:		GJ
-- Description:	Fasst zwei Bestellungen zusammen
-- 
@kBestellung1 INT , 
@kBestellung2 INT
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
DECLARE @ContextInfoOld VARBINARY(128);
IF  CONTEXT_INFO() IS NULL
SET @ContextInfoOld = 0x0
ELSE
SET @ContextInfoOld = CONTEXT_INFO();
--
--Variablen
--
DECLARE
   @nTestWert INT;
DECLARE
   @cError VARCHAR( 250 );

--
-- Initialisierung
--

SET @nTestWert = 0;
SET @cError = '';	

--
-- Prüfen, ob es die beiden Bestellungen gibt
--
SELECT * INTO #BeideBestellungen
  FROM tBestellung WITH ( NOLOCK )
  WHERE kBestellung IN( @kBestellung1 , @kBestellung2 );

SELECT @nTestWert = COUNT( 1 )
  FROM #BeideBestellungen;

IF @nTestWert = 0
    BEGIN
        SET @cError = 'Bestellungen_Nicht_Vorhanden';
        RAISERROR( @cError , 11 , 1 );
        RETURN -1;
    END;
IF @nTestWert = 1
    BEGIN
        IF( SELECT kBestellung
              FROM #BeideBestellungen ) = @kBestellung1
            BEGIN
                SET @cError = 'Bestellung2_Nicht_Vorhanden';
            END;
        ELSE
            BEGIN
                SET @cError = 'Bestellung1_Nicht_Vorhanden';
            END;
        RAISERROR( @cError , 11 , 1 );
        RETURN -1;
    END;


IF(0 < (
SELECT count(*)
  FROM tBestellung WITH ( NOLOCK )
  WHERE kBestellung IN( @kBestellung1 , @kBestellung2 )
  AND nPlatform IN (51,52,53,54,55,56,57)))
  BEGIN

      SET @cError = 'Amazonaufträge können nicht zusammengeführt werden.';
	 RAISERROR( @cError , 11 , 1 );
  END;

IF(0 < (
SELECT count(*)
  FROM dbo.tRMRetoure WITH ( NOLOCK )
  WHERE kBestellung IN( @kBestellung1 , @kBestellung2 )))
  BEGIN

      SET @cError = 'Umtauschaufträge dürfen nicht zusammengeführt werden.';
	 RAISERROR( @cError , 11 , 1 );
  END;

IF(0 < (
SELECT count(*)
  FROM dbo.tBestellung WITH ( NOLOCK )
  WHERE kBestellung IN( @kBestellung1 , @kBestellung2 )
  AND nStorno > 0))
  BEGIN

      SET @cError = 'Stornierte Aufträge können nicht zusammengeführt werden.';
	 RAISERROR( @cError , 11 , 1 );
  END;


IF(0 < (
  SELECT count(*)
  FROM tbestellpos
  JOIN tPicklistePos ON tPicklistePos.kBestellPos = tbestellpos.kBestellPos
  WHERE tbestellpos.tBestellung_kBestellung IN( @kBestellung1 , @kBestellung2 )
  AND tPicklistePos.nStatus < 40) )
  BEGIN

      SET @cError = 'Es gibt noch nicht abgeschlossene Picklisten für mindestens einen der Aufträge.';
	 RAISERROR( @cError , 11 , 1 );
  END;


IF(0 < (
SELECT count(*)
  FROM tBestellung WITH ( NOLOCK )
  WHERE kBestellung IN( @kBestellung1 , @kBestellung2 )
  AND  cModulID IN   ('za_billpay_jtl','za_ebay_rechnungskauf','za_paypal_pui_jtl','za_billpay_invoice_jtl','za_billpay_direct_debit_jtl','za_billpay_rate_payment_jtl','za_billpay_paylater_jtl'))
   )
  BEGIN
      SET @cError = 'Aufträge mit der Zahlungsart Billpay, Paypal- oder eBay-Rechnungskauf können nicht zusammengeführt werden.';
	 RAISERROR( @cError , 11 , 1 );
  END;
  
  
--
-- Beide Bestellungen gefunden
--

SELECT * INTO #Bestellung1
  FROM #BeideBestellungen
  WHERE kBestellung = @kBestellung1;
SELECT * INTO #Bestellung2
  FROM #BeideBestellungen
  WHERE kBestellung = @kBestellung2;


--
-- Prüfen, ob Bestellung 2 eine Bestellung der Zusammenfassbaren Bestellungen von Bestellung 1 ist. Dazu wird die inline function ifZusammenfassbareAuftraege verwendet.
-- TODO: Für genauere Fehlermeldungen müssten hier die Bedingungen, ob zwei Bestellungen zusammengefasst werden können einzeln geprüft werden
--
SELECT @nTestWert = COUNT( 1 )
  FROM dbo.ifZusammenfassbareAuftraege( @kBestellung1 )
  WHERE kBestellung = @kBestellung2;

IF @nTestWert = 0
    BEGIN
        SET @cError = 'Die Aufträge dürfen nicht zusammengeführt werden.';
        RAISERROR( @cError , -- Message text.
        11 , -- Severity.
        1 -- State.
        );
        RETURN -1;
    END;
ELSE
    BEGIN
        BEGIN TRY
            --
            -- MAX(nSort) der Positionen der ersten Bestellung holen um die Sortierung weiterzuführen
            --
            DECLARE
               @nMaxSortVonBestellung1 INT;

            SELECT @nMaxSortVonBestellung1 = MAX( nSort )
              FROM dbo.tbestellpos WITH ( NOLOCK )
              WHERE tBestellung_kBestellung = @kBestellung1;

            BEGIN TRANSACTION;

		  --
            -- tBestellung_kBestellung der Bestellung2 auf kBestellung von Bestellung1 ändern
            --
		  DECLARE @xBestellPos AS XML;
				SET @xBestellPos = (
					SELECT kBestellpos,tArtikel_kArtikel AS  kArtikel,@kBestellung1 AS kBestellung, fVKPreis, fMwSt, nAnzahl, fRabatt, cString, fVKNetto, cArtNr,
						  nType, cHinweis, nHatUpload, cUnique, kKonfigitem, nDropshipping, fEKNetto, cOrderItemId, cItemID,
						  cTransactionID, kAmazonBestellungPos,  @nMaxSortVonBestellung1 + nSort AS nSort, kBestellStueckliste
					FROM tbestellpos 
				     WHERE tBestellung_kBestellung = @kBestellung2
						FOR XML PATH('Bestellpos'), TYPE
					);

		  EXEC spBestellposAendern
			  @xBestellpos = @xBestellPos;

            --
            -- Mögliche Zahlung von Bestellung 2 auf Bestellung 1 umbiegen
            --
            UPDATE tZahlung
            SET kBestellung = @kBestellung1
              WHERE kBestellung = @kBestellung2;
		 
            --
            -- Bestellhinweis von Bestellung 2 an Bestellhinweis von Bestellung 1 hängen
            --


            DECLARE
               @fZusatzGewicht2 REAL;
            DECLARE
               @fGutschein2 REAL;
            DECLARE
               @kBestellHinweis1 INT;
            DECLARE
               @kBestellHinweis2 INT;
            DECLARE
               @cAnmerkung VARCHAR( 4500 );
            DECLARE
               @cAnmerkung1 VARCHAR( 4500 );
            DECLARE
               @cAnmerkung2 VARCHAR( 4500 );
            DECLARE
               @crlf CHAR( 2 );
            DECLARE
               @nHatUpload2 INT;
            DECLARE
               @kInetBestellung1 INT;
            DECLARE
               @kInetBestellung2 INT;
            DECLARE
               @kShop1 INT;
            DECLARE
               @kShop2 INT;
            DECLARE
               @nPlatform1 INT;
            DECLARE
               @nPlatform2 INT;

            SET @crlf = CHAR( 13 ) + CHAR( 10 );



            SELECT @kBestellHinweis1 = #Bestellung1.kBestellHinweis , 
                   @cAnmerkung1 = ISNULL( #Bestellung1.cAnmerkung , '' ) , 
                   @kInetBestellung1 = #Bestellung1.kInetBestellung , 
                   @kShop1 = #Bestellung1.kShop , 
                   @nPlatform1 = #Bestellung1.nPlatform
              FROM #Bestellung1;
            SELECT @kBestellHinweis2 = #Bestellung2.kBestellHinweis , 
                   @cAnmerkung2 = ISNULL( #Bestellung2.cAnmerkung , '' ) , 
                   @fZusatzGewicht2 = #Bestellung2.fZusatzGewicht , 
                   @fGutschein2 = #Bestellung2.fGutschein , 
                   @nHatUpload2 = ISNULL( #Bestellung2.nHatUpload , 0 ) , 
                   @kInetBestellung2 = #Bestellung2.kInetBestellung , 
                   @nPlatform2 = #Bestellung2.nPlatform,
			    @kShop2 = dbo.#Bestellung2.kShop
              FROM #Bestellung2;

			--
			-- Ebay Transaction korrigieren
			--
			SET CONTEXT_INFO 0x5107;
			UPDATE dbo.ebay_transaction
				SET kBestellung = @kBestellung1
				FROM dbo.ebay_transaction 
				WHERE kBestellung = @kBestellung2;
			SET CONTEXT_INFO @ContextInfoOld;


            --
            -- Anmerkungen zusammenfassen
            --
            IF NOT @cAnmerkung1 = ''
            OR NOT @cAnmerkung2 = ''
                BEGIN
                    --
                    -- Es gibt mindestens eine Anmerkung
                    --
                    IF @cAnmerkung1 = ''
                        --
                        -- Anmerkung 1 ist es nicht, also Anmerkung 2
                        --
                        BEGIN
                            SET @cAnmerkung = @cAnmerkung2;
                        END;
                    ELSE
                        BEGIN
                            SET @cAnmerkung = @cAnmerkung1;
                            IF NOT @cAnmerkung2 = ''
                                BEGIN
                                    SET @cAnmerkung = @cAnmerkung + @crlf + @cAnmerkung2;
                                END;
                        END;
					SET CONTEXT_INFO 0x5021
                    UPDATE tBestellung
                    SET cAnmerkung = @cAnmerkung
                      WHERE kBestellung = @kBestellung1;
					SET CONTEXT_INFO @ContextInfoOld;
                END;
		  
            --
            -- Gibt es an einer Bestellung einen Hinweis
            --
            IF @kBestellHinweis1 > 0
            OR @kBestellHinweis2 > 0
                BEGIN
                    DECLARE
                       @cText VARCHAR( MAX );
                    DECLARE
                       @kBestellHinweis INT;
                    SET @kBestellHinweis = 0;


                    DECLARE
                       @cText2 VARCHAR( MAX );

                    IF @kBestellHinweis1 > 0
                        BEGIN

                            SELECT @cText = cText
                              FROM tBestellHinweis
                              WHERE kBestellHinweis = @kBestellHinweis1;
                            --
                            -- Bestellung 1 hatte einen Hinweis, also wird hier der Hinweis neu gesetzt
                            --
                            SET @kBestellHinweis = @kBestellHinweis1;
                        END;

                    IF @kBestellHinweis2 > 0
                        BEGIN
                            SELECT @cText2 = cText
                              FROM tBestellHinweis
                              WHERE kBestellHinweis = @kBestellHinweis2;

                            IF @kBestellHinweis = 0
                                BEGIN
                                    SET @kBestellHinweis = @kBestellHinweis1;
                                    --
                                    -- Da Bestellung 1 keinen Hinweis hatte, bekommt Bestellung 1 kBestellHinweis von Bestellung 2
                                    --
									SET CONTEXT_INFO  0x5021
                                    UPDATE tBestellung
                                    SET kBestellHinweis = kBestellHinweis
                                      WHERE kBestellung = @kBestellung1;
                                    SET @cText = @cText2;
									SET CONTEXT_INFO @ContextInfoOld;
                                END;
                            ELSE
                                BEGIN
                                    --
                                    -- Beide Hinweise zusammenfassen
                                    --                                   
                                    SET @cText = @cText + @crlf + @cText2;
                                END;
                        END;

                    UPDATE tBestellHinweis
                    SET cText = @cText
                      WHERE kBestellHinweis = @kBestellHinweis;
                END;

            IF @fZusatzGewicht2 > 0
            OR NOT @fGutschein2 = 0
            OR @nHatUpload2 > 0
                BEGIN
					SET CONTEXT_INFO 0x5021
                    UPDATE tBestellung
                    SET fZusatzGewicht = fZusatzGewicht + @fZusatzGewicht2 , 
                        fGutschein = fGutschein + @fGutschein2 , 
                        nHatUpload = CASE
                                     WHEN @nHatUpload2 = 1 THEN @nHatUpload2
                                         ELSE nHatUpload
                                     END
                      WHERE kBestellung = @kBestellung1;
					SET CONTEXT_INFO @ContextInfoOld;
                END;

            --
            -- WebShop Bestellung (falls vorhanden) updaten für Bestellung 1
            --
            IF @kInetBestellung1 > 0
                BEGIN
                    INSERT INTO tQueue( kShop , 
                                        kPlattform , 
                                        cName , 
                                        kWert , 
                                        nAction , 
                                        kOption1 , 
                                        kOption2 )
                    VALUES( @kShop1 , 
                            0 , 
                            'tBestellung' , 
                            @kBestellung1 , 
                            1 , 
                            -- nAction - QUEUE_ACTION_ADD
                            0 , 
                            0 );
                END;

            --
            -- WebShop Bestellung (falls vorhanden) löschen für Bestellung 2
            --
            IF @kInetBestellung2 > 0
                BEGIN
                    INSERT INTO tQueue( kShop , 
                                        kPlattform , 
                                        cName , 
                                        kWert , 
                                        nAction , 
                                        kOption1 , 
                                        kOption2 )
                    VALUES( @kShop2 , 
                            @nPlatform2 , 
                            'tBestellung' , 
                            @kInetBestellung2 , 
                            2 , 
                            -- nAction - QUEUE_ACTION_DEL
                            0 , 
                            0 );
                END;




		  --
		  -- Abgeschloßene Pickpositionen zusammenführen 
		  --
		  UPDATE tPicklistePos
		  SET kBestellung = @kBestellung1
		  WHERE kBestellung = @kBestellung2
		  AND tPicklistePos.nStatus >= 40;


			--
			-- Lieferscheine umbiegen
			--
			UPDATE dbo.tLieferschein
			SET dbo.tLieferschein.kBestellung = @kBestellung1
			WHERE dbo.tLieferschein.kBestellung = @kBestellung2;
		  
            --
            -- BestellungAttribute von Bestellung 2, die es nicht in Bestellung 1 gibt, umbiegen
            --
            UPDATE tBestellungAttribute
            SET kBestellung = @kBestellung1
              WHERE kBestellung = @kBestellung2
                AND NOT cName IN( SELECT cName
                                    FROM tBestellungAttribute
                                    WHERE kBestellung = @kBestellung1 );
		  --
		  -- Restliche Attribute von Bestellung 2 löschen
		  --
		  DELETE FROM tBestellungAttribute 
			 WHERE kBestellung = @kBestellung2


		  --
		  -- Bestellung 2 in tBestellungAlt archivieren
		  --
            INSERT INTO tBestellungAlt
            SELECT @kBestellung2 AS kBestellungAlt , 
                   @kBestellung1 kBestellungNeu , 
                   cBestellNr , 
                   dErstellt , 
                   kInetBestellung , 
                   cVersandInfo , 
                   dVersandt , 
                   cIdentCode , 
                   dLieferDatum , 
                   kBestellHinweis , 
                   kShop , 
                   kLogistik , 
                   nPlatform , 
                   fGutschein , 
                   cInetBestellNr , 
                   cStatus
              FROM #Bestellung2;

            --
            -- Bestellung 2 löschen
            --
		   EXEC dbo.spBestellungLoeschen	@kBestellung = @kBestellung2

			--
			-- Zielbestellung für den Abgleich aktivieren
			--
			SET CONTEXT_INFO  0x5021
			UPDATE dbo.tBestellung
				SET tBestellung.cInet = 'Y'
			WHERE tBestellung.kBestellung = @kBestellung1
				AND tBestellung.kShop > 0;
			SET CONTEXT_INFO @ContextInfoOld;
            COMMIT;
        END TRY
        BEGIN CATCH		  
            --
            -- SQL Fehler wurde geCATCHt
            --

            ROLLBACK;

            DECLARE
               @ErrorMessage NVARCHAR( 4000 );
            DECLARE
               @ErrorSeverity INT;
            DECLARE
               @ErrorState INT;

            SELECT @ErrorMessage = ERROR_MESSAGE( ) , 
                   @ErrorSeverity = ERROR_SEVERITY( ) , 
                   @ErrorState = ERROR_STATE( );

            RAISERROR( @ErrorMessage , -- Message text.
            @ErrorSeverity , -- Severity.
            @ErrorState -- State.
            );
        END CATCH;

    END;
go

