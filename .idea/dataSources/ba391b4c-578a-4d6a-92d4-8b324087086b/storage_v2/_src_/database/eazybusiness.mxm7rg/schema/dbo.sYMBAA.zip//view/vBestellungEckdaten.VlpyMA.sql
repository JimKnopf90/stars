CREATE VIEW [dbo].[vBestellungEckdaten] AS  SELECT * FROM tBestellungEckDaten
go

