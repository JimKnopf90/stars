CREATE TRIGGER [dbo].[tgr_tFirma_UPDATE]    
--      
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP
--        
ON [dbo].[tFirma]    
AFTER UPDATE    
AS    
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;

IF UPDATE(cLandISO)
BEGIN
        UPDATE dbo.tSteuerzone
            SET dbo.tSteuerzone.cLandISO = landISONeu.cLandIso
        FROM dbo.tSteuerzone
        JOIN
        (
            --
            -- Erster Eintrag in cLandIso aller aktualisieren Datensätze in tFirma, 
            -- die keine individuellen Steuereinstellungen haben und somit auf global zurückfallen.
            --
            SELECT TOP(1) 0 AS kFirma, INSERTED.cLandIso AS cLandIso
            FROM INSERTED
            LEFT JOIN
            (
                --
                -- Alle Firmen zu denen bereits eine individuelle Steuereinstellung hinterlegt ist
                --
                SELECT kFirma
                FROM dbo.tSteuerzone
                WHERE dbo.tSteuerzone.kFirma > 0
                GROUP BY dbo.tSteuerzone.kFirma
            ) AS individuelleSteuereinstellungen ON INSERTED.kFirma = individuelleSteuereinstellungen.kFirma
            WHERE individuelleSteuereinstellungen.kFirma IS NULL
        ) AS landISONeu ON dbo.tSteuerzone.kFirma = landISONeu.kFirma
        WHERE dbo.tSteuerzone.cLandISO <> landISONeu.cLandIso;
END
go

