-- 
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: GJ
CREATE VIEW dbo.vGlobaleTexte AS 

SELECT DISTINCT WawiAttributSprache.kWawiAttribut , 
                   WawiAttributSprache.cWertVarchar , 
                   REPLACE( REPLACE( AttributSprache.cName , ' ' , '_' ) , '#' , '_' )AS cName , 
                   REPLACE( REPLACE( Attribut.cGruppeName , ' ' , '_' ) , '#' , '_' )AS cGruppeName , 
                   AlleSprachen.cNameDeu , 
                   Attribut.kAttribut , 
                   Attribut.cBeschreibung
   FROM
        dbo.tAttributSprache AS AttributSprache
       JOIN tAttribut AS Attribut ON Attribut.kAttribut = AttributSprache.kAttribut
                                  AND Attribut.nBezugstyp = 2
        JOIN tSpracheUsed AS SpracheUsed ON (SpracheUsed.kSprache = AttributSprache.kSprache
                                        AND SpracheUsed.nStandard = 1) OR AttributSprache.kSprache = 0
        JOIN tSpracheUsed AS AlleSprachen ON 1 = 1
        JOIN tWawiAttribut AS WawiAttribut ON WawiAttribut.kAttribut = Attribut.kAttribut
        LEFT JOIN tWawiAttributSprache AS WawiAttributSprache ON WawiAttributSprache.kSprache = AlleSprachen.kSprache
                                                             AND WawiAttributSprache.kWawiAttribut = WawiAttribut.kWawiAttribut;
go

