--- 
--- spWarenlagerAnlegen
---

CREATE PROCEDURE dbo.spWarenlagerAnlegen
	@cName VARCHAR(255),
	@cKuerzel VARCHAR(255),
	@cLagerTyp VARCHAR(255),
	@cBeschreibung VARCHAR(255),
	@cStrasse VARCHAR(255),
	@cPLZ VARCHAR(255),
	@cOrt VARCHAR(255),
	@cLand VARCHAR(255),
	@cAnsprechpartnerAnrede VARCHAR(255),
	@cAnsprechpartnerVorname VARCHAR(255),
	@cAnsprechpartnerName VARCHAR(255),
	@cAnsprechpartnerTel VARCHAR(255),
	@cAnsprechpartnerFax VARCHAR(255),
	@cAnsprechpartnerEMail VARCHAR(255),
	@cAnsprechpartnerAbteilung VARCHAR(255),
	@cBundesland VARCHAR(100),
	@kFirma INT,
	@kUser INT,
	@nFulfillment INT,
	@nLagerplatzVerwaltung INT,
	@nAuslieferungsPrio INT,
	@nPackStationAktiv INT,
	@cDimension1Name VARCHAR(255),
	@cDimension1Trennzeichen VARCHAR(1),
	@nDimension1Laenge INT,
	@nDimension1Typ INT,
	@cDimension2Name VARCHAR(255),
	@cDimension2Trennzeichen VARCHAR(1),
	@nDimension2Laenge INT,
	@nDimension2Typ INT,
	@cDimension3Name VARCHAR(255),
	@cDimension3Trennzeichen VARCHAR(1),
	@nDimension3Laenge INT,
	@nDimension3Typ INT,
	@cDimension4Name VARCHAR(255),
	@cDimension4Trennzeichen VARCHAR(1),
	@nDimension4Laenge INT,
	@nDimension4Typ INT,
	@cDimension5Name VARCHAR(255),
	@cDimension5Trennzeichen VARCHAR(1),
	@nDimension5Laenge INT,
	@nDimension5Typ INT,
	@cEmpfaengerFirma VARCHAR(255),
	@kQuellLager INT,
	@kZielLager INT,
	@nAktiv INT,
	@cJfwid VARCHAR(50), 
	@kWarenlager INT OUTPUT
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
DECLARE @errorMessage NVARCHAR(4000);
DECLARE @errorSeverity INT;
DECLARE @errorState INT;
DECLARE @retry INT;
SET @retry = 5;
WHILE @retry > 0
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION
			DECLARE @nFulfillmentDienstleister INT
			INSERT INTO dbo.tWarenLager(cName, cKuerzel, cLagerTyp, cBeschreibung, cStrasse, cPLZ, cOrt, cLand, cAnsprechpartnerAnrede, cAnsprechpartnerVorname,
										cAnsprechpartnerName, cAnsprechpartnerTel, cAnsprechpartnerFax, cAnsprechpartnerEMail, cAnsprechpartnerAbteilung,
										cBundesland, kFirma, kUser, nFulfillment, nLagerplatzVerwaltung, nAuslieferungsPrio, nPackStationAktiv, cDimension1Name,
										cDimension1Trennzeichen, nDimension1Laenge, nDimension1Typ, cDimension2Name, cDimension2Trennzeichen, nDimension2Laenge,
										nDimension2Typ, cDimension3Name, cDimension3Trennzeichen, nDimension3Laenge, nDimension3Typ, cDimension4Name,
										cDimension4Trennzeichen, nDimension4Laenge, nDimension4Typ, cDimension5Name, cDimension5Trennzeichen, nDimension5Laenge,
										nDimension5Typ, cEmpfaengerFirma, kQuellLager, kZielLager, nAktiv, cJfwid)
				    VALUES(@cName, @cKuerzel, @cLagerTyp, @cBeschreibung, @cStrasse, @cPLZ, @cOrt, @cLand, @cAnsprechpartnerAnrede, @cAnsprechpartnerVorname, 
							@cAnsprechpartnerName, @cAnsprechpartnerTel, @cAnsprechpartnerFax, @cAnsprechpartnerEmail, @cAnsprechpartnerAbteilung, @cBundesland,
							@kFirma, @kUser, @nFulfillment, @nLagerplatzVerwaltung, @nAuslieferungsPrio, @nPackStationAktiv, @cDimension1Name, @cDimension1Trennzeichen,
							@nDimension1Laenge, @nDimension1Typ, @cDimension2Name, @cDimension2Trennzeichen, @nDimension2Laenge, @nDimension2Typ, @cDimension3Name,
							@cDimension3Trennzeichen, @nDimension3Laenge, @nDimension3Typ, @cDimension4Name, @cDimension4Trennzeichen, @nDimension4Laenge,
							@nDimension4Typ, @cDimension5Name, @cDimension5Trennzeichen, @nDimension5Laenge, @nDimension5Typ, @cEmpfaengerFirma, @kQuellLager,
							@kZielLager, @nAktiv, @cJfwid);
			SET @kWarenlager = SCOPE_IDENTITY();
			DECLARE @WARENLAGER_FULFILLMENTDIENSTLEISTER_UNBEKANNT AS INT = 0;
			DECLARE @WARENLAGER_FULFILLMENTDIENSTLEISTER_AMAZON AS INT = 1;
			DECLARE @WARENLAGER_FULFILLMENTDIENSTLEISTER_JTL AS INT = 2;
			SELECT @nFulfillmentDienstleister = CASE WHEN @nFulfillment = 2
														THEN @WARENLAGER_FULFILLMENTDIENSTLEISTER_AMAZON
													WHEN @nFulfillment = 3
														THEN @WARENLAGER_FULFILLMENTDIENSTLEISTER_JTL
													ELSE @WARENLAGER_FULFILLMENTDIENSTLEISTER_UNBEKANNT
											    END;
			IF(@nLagerplatzVerwaltung = 1)
			BEGIN
				--
				-- Warenlagerplatz anlegen bei nicht WMS-Lager
				--
				INSERT INTO dbo.tWarenLagerPlatz(kWarenLager, fGewichtMax, cKommentar, fLaenge, fBreite, fHoehe, nSort, cName, kWarenLagerPlatzTyp, nStatus,
												dWmsInventurDatum, kWmsInventur, nPreInvStatus, nInvGezaehlt, nGesperrt)
					VALUES(@kWarenlager, 0.0, '', 0, 0, 0, 0,@cName, 0, 0, 0, 0, 0, 0, 0);
			END	
			IF @nFulfillmentDienstleister > 0
			BEGIN
				--
				-- Fulfillment-Dienstleister zu Fulfillmentlager anlegen
				--
				INSERT INTO dbo.tWarenlagerFulfillmentDienstleister(kWarenLager, kFulfillmentDienstleister, nDruckLieferschein, nFaxLieferschein, nMailLieferschein,
																	nDruckFF, nFaxFF, nMailFF, kFormularLieferschein, kFormularFulfillmentAuftrag)
					VALUES(@kWarenLager, @nFulfillmentDienstleister, 0, 0, 0, 0, 0, 0, 0, 0);
			END	
			--
			-- tlagerbestandProLagerLagerartikel mit allen Lager-Artikeln für Bestandsberechnung füllen
			--
			INSERT INTO dbo.tlagerbestandProLagerLagerartikel
				SELECT Artikel.kArtikel, @kWarenlager AS kWarenLager, 0 AS fBestand
				    FROM dbo.tArtikel AS Artikel
				    WHERE Artikel.cLagerAktiv = 'Y'
						AND Artikel.kStueckliste = 0
						AND Artikel.nIstVater = 0;				  
			SET @retry = -1;
		COMMIT
	END TRY
	BEGIN CATCH
		IF ERROR_NUMBER() = 1205
		BEGIN
			SET @retry = @retry - 1;
			ROLLBACK;
			IF @retry = 0
			BEGIN
				SELECT @errorMessage = ERROR_MESSAGE(),@errorSeverity = ERROR_SEVERITY(),@errorState = ERROR_STATE();
				RAISERROR(@errorMessage,@errorSeverity,@errorState);
				RETURN;
			END
			WAITFOR DELAY '00:00:00:5';
		END
		ELSE
		BEGIN
			SET @retry = -1;
			SELECT @errorMessage = ERROR_MESSAGE(),@errorSeverity = ERROR_SEVERITY(),@errorState = ERROR_STATE();
			ROLLBACK;
			RAISERROR(@errorMessage,@errorSeverity,@errorState);
			RETURN;
		END
	END CATCH
END
go

