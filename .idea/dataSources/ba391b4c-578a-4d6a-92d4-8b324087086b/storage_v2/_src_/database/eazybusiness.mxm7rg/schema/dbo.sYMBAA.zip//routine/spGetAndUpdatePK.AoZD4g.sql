--- 
--- spGetAndUpdatePK
---

CREATE PROC [dbo].[spGetAndUpdatePK] 	
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--
@cName VARCHAR(255),
@kId INT = NULL OUTPUT
AS 
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN TRANSACTION 	

	DECLARE @res INT 	
	EXEC @res = sp_getapplock @Resource = @cName,@LockMode ='Exclusive', @LockOwner ='Transaction', @LockTimeout = 500, @DbPrincipal = 'public' 	

	IF @res NOT IN (0, 1) 	
	BEGIN 	
	     SET @kId = 0;
		SELECT 0 AS nummer 	
	END 	
	ELSE 	
	BEGIN 		
	     SET @kId = (
		  SELECT nummer 
		  FROM tpk WITH(NOLOCK) 
		  WHERE cName = @cName
		)
		
		SELECT @kId AS nummer		

		UPDATE tpk WITH(ROWLOCK) 
			SET nummer = nummer + 1, dChanged = CONVERT(varchar(10), GETDATE(), 126) 
		WHERE cName=@cName 		

		EXEC sp_releaseapplock @Resource = @cName, @DbPrincipal ='public', @LockOwner = 'Transaction' 	
	END 

COMMIT
go

