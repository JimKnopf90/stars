CREATE TRIGGER [dbo].[tgr_tXSellGruppe_INSUPDEL]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--
ON [dbo].[tXSellGruppe]
AFTER INSERT, UPDATE, DELETE
AS
SET CONCAT_NULL_YIELDS_NULL ON;
SET ANSI_WARNINGS ON;
SET ANSI_PADDING ON;
SET NOCOUNT ON;
BEGIN
	--Überprüfen ob Trigger gefüllt aufgerufen wird
	IF((SELECT COUNT(1) FROM INSERTED FULL JOIN DELETED ON INSERTED.kXSellGruppe = DELETED.kXSellGruppe) = 0)
	BEGIN
		RETURN
	END

	INSERT INTO dbo.tGlobalsQueue(kShop, nType, cName, kKey, dTimeStamp)
	SELECT dbo.tShop.kShop, 1, 'tXSellGruppe', INSERTED.kXSellGruppe, GETDATE()
	FROM INSERTED
	JOIN dbo.tSpracheUsed ON INSERTED.kSprache = dbo.tSpracheUsed.kSprache
		AND dbo.tSpracheUsed.nStandard = 1
	LEFT JOIN DELETED ON INSERTED.kXSellGruppe = DELETED.kXSellGruppe
	CROSS JOIN dbo.tShop
	WHERE DELETED.kXSellGruppe IS NULL;

	INSERT INTO dbo.tGlobalsQueue(kShop, nType, cName, kKey, dTimeStamp)
	SELECT dbo.tShop.kShop, 1, 'tXSellGruppe', INSERTED.kXSellGruppe, GETDATE()
	FROM INSERTED
	JOIN dbo.tSpracheUsed ON INSERTED.kSprache = dbo.tSpracheUsed.kSprache
		AND dbo.tSpracheUsed.nStandard = 1
	JOIN DELETED ON INSERTED.kXSellGruppe = DELETED.kXSellGruppe
	CROSS JOIN dbo.tShop
	WHERE DELETED.cName <> INSERTED.cName
		OR DELETED.cBeschreibung <> INSERTED.cBeschreibung;

	INSERT INTO dbo.tGlobalsQueue(kShop, nType, cName, kKey, dTimeStamp)
	SELECT dbo.tShop.kShop, 2, 'tXSellGruppe', DELETED.kXSellGruppe, GETDATE()
	FROM DELETED
	JOIN dbo.tSpracheUsed ON DELETED.kSprache = dbo.tSpracheUsed.kSprache
		AND dbo.tSpracheUsed.nStandard = 1
	LEFT JOIN INSERTED ON DELETED.kXSellGruppe = INSERTED.kXSellGruppe
	CROSS JOIN dbo.tShop
	WHERE INSERTED.kXSellGruppe IS NULL;
END
go

