
    CREATE PROCEDURE unicorn2_spMissingChanged
    AS
	    SET DEADLOCK_PRIORITY LOW
        INSERT INTO unicorn2_tChangeCache (cStatus, cType, kWawiId, dChangedDate)
        SELECT 'Add' AS cStatus, 'Artikel' AS cType, kWawiId, GETDATE() AS dChangedDate
        FROM unicorn2_vNotExistingArtikel WITH (NOLOCK)
        WHERE kWawiId NOT IN (SELECT kWawiId FROM unicorn2_tChangeCache WITH (NOLOCK))
    go

