CREATE VIEW [dbo].[vBestellLieferInfoProLager] AS  
SELECT  
	vBestellposLieferInfoProLager.kBestellung,   
	vBestellposLieferInfoProLager.kWarenlager, 
	-- Bildet die Summen über vBestellposLieferInfoProLager, dort stehen genauere Erklärungen zur Berechnung   
	SUM(ISNULL(vBestellposLieferInfoProLager.nAnzahlAuszuliefern,0)) AS nAnzahlAuszuliefern,   
	SUM(ISNULL(vBestellposLieferInfoProLager.nAnzahlGeliefert,0)) AS nAnzahlGeliefert,   
	SUM(ISNULL(vBestellposLieferInfoProLager.nAnzahlVerfuegbar,0)) AS nAnzahlVerfuegbar,   
	SUM(ISNULL(CASE WHEN vBestellposLieferInfoProLager.nAnzahlFehlbestand > 0 THEN vBestellposLieferInfoProLager.nAnzahlFehlbestand ELSE 0 END ,0)) AS nAnzahlFehlbestand,   
	CASE   
	-- Status 10 (Vollständig Lieferbar):  nAnzahlFehlbestand = 0   
	WHEN SUM(ISNULL(CASE WHEN vBestellposLieferInfoProLager.nAnzahlFehlbestand > 0 THEN vBestellposLieferInfoProLager.nAnzahlFehlbestand ELSE 0 END ,0)) = 0 THEN 10   
	-- Status 20 (Nicht Lieferbar): nAnzahlAuszuliefern <= nAnzahlFehlbestand   
	WHEN SUM(ISNULL(vBestellposLieferInfoProLager.nAnzahlAuszuliefern,0)) <= SUM(ISNULL(vBestellposLieferInfoProLager.nAnzahlFehlbestand,0)) THEN 20   
	-- Status 30 (Teilweise Lieferbar): nAnzahlFehlbestand > 0 AND nAnzahlFehlbestand < nAnzahlAuszuliefern   
	ELSE 30   
	END AS nStatus   
FROM   
	vBestellposLieferInfoProLager   
GROUP BY vBestellposLieferInfoProLager.kBestellung, vBestellposLieferInfoProLager.kWarenlager
go

