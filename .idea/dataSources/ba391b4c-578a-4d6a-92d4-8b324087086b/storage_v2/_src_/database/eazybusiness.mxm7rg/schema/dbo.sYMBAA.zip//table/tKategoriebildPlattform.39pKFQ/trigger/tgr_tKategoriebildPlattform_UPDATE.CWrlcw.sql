CREATE TRIGGER [dbo].[tgr_tKategoriebildPlattform_UPDATE]  
--     
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Author: Markus Hütz
--    
ON [dbo].[tKategoriebildPlattform]  
AFTER UPDATE
AS  
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
    --
    -- Überprüfen ob Trigger gefüllt aufgerufen wird
    --
    IF NOT EXISTS(SELECT INSERTED.kKategoriebildPlattform FROM INSERTED FULL JOIN DELETED ON INSERTED.kKategoriebildPlattform = DELETED.kKategoriebildPlattform)
    BEGIN
	   RETURN;
    END;

    --
    -- Wenn kBild nicht gleich ist es ein neues Bild und muss übertragen werden
    --
    UPDATE dbo.tKategoriebildPlattform
    SET dbo.tKategoriebildPlattform.nInet = 1
    FROM dbo.tKategoriebildPlattform
    JOIN DELETED ON DELETED.kKategoriebildPlattform = dbo.tKategoriebildPlattform.kKategoriebildPlattform
    JOIN INSERTED ON INSERTED.kKategoriebildPlattform = dbo.tKategoriebildPlattform.kKategoriebildPlattform
    WHERE DELETED.kBild != INSERTED.kBild OR DELETED.nNr != INSERTED.nNr

	--
	-- nInet auf 0 setzen wenn Kategorie gar nicht für Shop aktiv
	--
	UPDATE dbo.tKategoriebildPlattform
		SET dbo.tKategoriebildPlattform.nInet = 0
	FROM dbo.tKategoriebildPlattform
	JOIN INSERTED ON dbo.tKategoriebildPlattform.kKategoriebildPlattform = INSERTED.kKategoriebildPlattform
	LEFT JOIN dbo.tKategorieShop ON INSERTED.kKategorie = dbo.tKategorieShop.kKategorie
		AND INSERTED.kShop = dbo.tKategorieShop.kShop
	WHERE	dbo.tKategorieShop.kKategorie IS NULL
			AND INSERTED.nInet = 1;

    --
    -- tBild aufräumen
    --
    DECLARE @Bilder AS TYPE_spBildLoeschenWennNichtVerwendet;

    INSERT INTO @Bilder (kBild)
    SELECT DELETED.kBild 
	FROM DELETED
	LEFT JOIN INSERTED ON DELETED.kBild != INSERTED.kBild
	WHERE DELETED.kPlattform = 1
	GROUP BY DELETED.kBild;

    EXEC dbo.spBildLoeschenWennNichtVerwendet @Bilder;
END
go

