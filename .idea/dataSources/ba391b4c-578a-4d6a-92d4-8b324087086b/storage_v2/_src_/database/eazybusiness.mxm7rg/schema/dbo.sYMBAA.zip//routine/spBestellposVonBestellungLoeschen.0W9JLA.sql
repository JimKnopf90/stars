--- 
--- spBestellposVonBestellungLoeschen
---

CREATE PROCEDURE [dbo].[spBestellposVonBestellungLoeschen]
	@xBestellung XML = NULL,
	@kBestellung INT = NULL
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
DECLARE @ErrorMessage NVARCHAR(4000);
DECLARE @ErrorSeverity INT;
DECLARE @ErrorState INT;
DECLARE @retry INT;
SET @retry = 5;
WHILE @retry > 0
BEGIN
	SET CONTEXT_INFO 0x0;
	BEGIN TRY
		BEGIN TRANSACTION
			IF(OBJECT_ID('tempdb..#Bestellung') IS NOT NULL)
			BEGIN
				DROP TABLE #Bestellung;
			END
			CREATE TABLE #Bestellung (kBestellung INT);
			IF(@xBestellung IS NOT NULL)
			BEGIN
				INSERT INTO #Bestellung(kBestellung)
					SELECT Bestellung.ID.value('kBestellung[1]', 'INT')
						FROM @xBestellung.nodes('Bestellung') AS Bestellung(ID);
			END
			ELSE
			BEGIN
				INSERT INTO #Bestellung(kBestellung)
					VALUES(@kBestellung);
			END
			DECLARE @xBestellpos XML;
			SET @xBestellpos = (
				SELECT dbo.tbestellpos.kBestellPos
					FROM #Bestellung
					JOIN dbo.tbestellpos ON dbo.tbestellpos.tBestellung_kBestellung = #Bestellung.kBestellung
					FOR XML PATH('Bestellpos'), TYPE
				);
			IF(@xBestellpos IS NOT NULL)
			BEGIN
				EXEC dbo.spBestellposLoeschen @xBestellpos;
			END			
			SET @retry = -1;
			SET CONTEXT_INFO 0x0;
		COMMIT
	END TRY
	BEGIN CATCH
	IF(ERROR_NUMBER() = 1205)
			BEGIN
				SET @retry = @retry - 1;
				ROLLBACK;
				WAITFOR DELAY '00:00:00:5';
			END
			ELSE 
			BEGIN
				SET @retry = -1;
				SELECT @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
				ROLLBACK;
				RAISERROR (	@ErrorMessage, 
							@ErrorSeverity,
							@ErrorState
				);
				SET CONTEXT_INFO 0x0;
				RETURN;
			END
	END CATCH
	SET CONTEXT_INFO 0x0;	
END
go

