CREATE TRIGGER [dbo].[tgr_tGebinde_DELETE]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--
ON [dbo].[tGebinde]
AFTER DELETE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN TRANSACTION 
	
    DELETE tArtikelSpeicher WITH(ROWLOCK) FROM tArtikelSpeicher WITH(ROWLOCK)
	JOIN deleted ON deleted.kArtikel = tArtikelSpeicher.kArtikel and deleted.cEAN = tArtikelSpeicher.cNummer
	WHERE tArtikelSpeicher.nID IN (6,9) 
		
COMMIT
go

