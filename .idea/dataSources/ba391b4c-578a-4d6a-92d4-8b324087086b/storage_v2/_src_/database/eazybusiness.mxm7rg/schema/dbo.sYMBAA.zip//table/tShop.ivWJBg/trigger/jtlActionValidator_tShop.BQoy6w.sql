CREATE TRIGGER [dbo].[jtlActionValidator_tShop]  
--     
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--    
ON [dbo].[tShop]  
AFTER DELETE 
AS  
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN 
	--
	--Überprüfen ob Trigger mit Inhalt aufgerufen wird
	--
	IF((SELECT COUNT(1) FROM DELETED) = 0)
	BEGIN
		RETURN;
	END;

	--
	-- tArtikelAttribut aufräumen
	--
	DELETE dbo.tArtikelAttribut
	FROM dbo.tArtikelAttribut
	JOIN DELETED ON DELETED.kShop = dbo.tArtikelAttribut.kShop;

	--
	-- tArtikelBeschreibung aufräumen
	--
	DELETE dbo.tArtikelBeschreibung
	FROM dbo.tArtikelBeschreibung
	JOIN DELETED ON DELETED.kShop = dbo.tArtikelBeschreibung.kShop;

	--
	-- tArtikelbildPlattform aufräumen
	--
	DELETE dbo.tArtikelbildPlattform
	FROM dbo.tArtikelbildPlattform
	JOIN DELETED ON DELETED.kShop = dbo.tArtikelbildPlattform.kShop;

	--
	-- tArtikelRankingGlobal aufräumen
	--
	DELETE dbo.tArtikelRankingGlobal
	FROM dbo.tArtikelRankingGlobal
	JOIN DELETED ON DELETED.kShop = dbo.tArtikelRankingGlobal.kShop;

	--
	-- tArtikelRankingZeitraum aufräumen
	--
	DELETE dbo.tArtikelRankingZeitraum
	FROM dbo.tArtikelRankingZeitraum
	JOIN DELETED ON DELETED.kShop = dbo.tArtikelRankingZeitraum.kShop;

	--
	-- tArtikelShop aufräumen
	--
	DELETE dbo.tArtikelShop
	FROM dbo.tArtikelShop
	JOIN DELETED ON DELETED.kShop = dbo.tArtikelShop.kShop;

	--
	-- tArtikelSichtbarkeit aufräumen
	--
	DELETE dbo.tArtikelSichtbarkeit
	FROM dbo.tArtikelSichtbarkeit
	JOIN DELETED ON DELETED.kShop = dbo.tArtikelSichtbarkeit.kShop;

	--
	-- tAttributShop aufräumen
	--
	DELETE dbo.tAttributShop
	FROM dbo.tAttributShop
	JOIN DELETED ON DELETED.kShop = dbo.tAttributShop.kShop;

	--
	-- tbestellung aufräumen
	--
	UPDATE dbo.tbestellung
		SET dbo.tbestellung.kShop = 0
	FROM dbo.tbestellung
	JOIN DELETED ON DELETED.kShop = dbo.tbestellung.kShop;

	--
	-- tDownloadShop aufräumen
	--
	DELETE dbo.tDownloadShop
	FROM dbo.tDownloadShop
	JOIN DELETED ON DELETED.kShop = dbo.tDownloadShop.kShop;

	--
	-- tEigenschaftSichtbarkeit aufräumen
	--
	DELETE dbo.tEigenschaftSichtbarkeit
	FROM dbo.tEigenschaftSichtbarkeit
	JOIN DELETED ON DELETED.kShop = dbo.tEigenschaftSichtbarkeit.kShop;


     --
	-- tbestellungAlt aufräumen
	--
	UPDATE dbo.tbestellungAlt
	SET dbo.tbestellungAlt.kShop = 0
	FROM dbo.tbestellungAlt
	JOIN DELETED ON DELETED.kShop = dbo.tbestellungAlt.kShop;


     --
	-- tEigenschaftWertAufpreis aufräumen
	--
	DELETE dbo.tEigenschaftWertAufpreis
	FROM dbo.tEigenschaftWertAufpreis
	JOIN DELETED ON DELETED.kShop = dbo.tEigenschaftWertAufpreis.kShop;
	 

	--
	-- tEigenschaftWertSichtbarkeit aufräumen
	--
	DELETE dbo.tEigenschaftWertSichtbarkeit
	FROM dbo.tEigenschaftWertSichtbarkeit
	JOIN DELETED ON DELETED.kShop = dbo.tEigenschaftWertSichtbarkeit.kShop;

	 
     --
	-- tGlobalsQueue  aufräumen
	--
	DELETE dbo.tGlobalsQueue 
	FROM dbo.tGlobalsQueue 
	JOIN DELETED ON DELETED.kShop = dbo.tGlobalsQueue.kShop;


	--
	-- tGutschein  aufräumen
	--
	UPDATE dbo.tGutschein 
	SET dbo.tGutschein.kShop = 0
	FROM dbo.tGutschein 
	JOIN DELETED ON DELETED.kShop = dbo.tGutschein.kShop;

	--
	-- tHerstellerBildPlattform   aufräumen
	--
	DELETE dbo.tHerstellerBildPlattform  
	FROM dbo.tHerstellerBildPlattform  
	JOIN DELETED ON DELETED.kShop = dbo.tHerstellerBildPlattform.kShop;

	--
	-- tinetadress  aufräumen
	--
	DELETE dbo.tinetadress  
	FROM dbo.tinetadress  
	JOIN DELETED ON DELETED.kShop = dbo.tinetadress.kShop;

	--
	-- tInetAdresseShop  aufräumen
	--
	DELETE dbo.tInetAdresseShop  
	FROM dbo.tInetAdresseShop  
	JOIN DELETED ON DELETED.kShop = dbo.tInetAdresseShop.kShop;


	--
	-- tinetbestellpos  aufräumen
	--
	DELETE dbo.tinetbestellpos
	FROM dbo.tinetbestellpos  
	JOIN DELETED ON DELETED.kShop = dbo.tinetbestellpos.kShop;

	--
	-- tinetbestellposeigenschaft   aufräumen
	--
	DELETE dbo.tinetbestellposeigenschaft
	FROM dbo.tinetbestellposeigenschaft   
	JOIN DELETED ON DELETED.kShop = dbo.tinetbestellposeigenschaft.kShop;


	--
	-- tinetbestellung  aufräumen
	--
	DELETE dbo.tinetbestellung  
	FROM dbo.tinetbestellung  
	JOIN DELETED ON DELETED.kShop = dbo.tinetbestellung.kShop;

	--
	-- tShopKundenGruppe aufräumen
	--
	DELETE dbo.tShopKundenGruppe  
	FROM dbo.tShopKundenGruppe  
	JOIN DELETED ON DELETED.kShop = dbo.tShopKundenGruppe.kWebShop;

	--
	-- tShopSprache aufräumen
	--
	DELETE dbo.tShopSprache  
	FROM dbo.tShopSprache  
	JOIN DELETED ON DELETED.kShop = dbo.tShopSprache.kWebShop;

	--
	-- tinetkunde   aufräumen
	--
	DELETE dbo.tinetkunde   
	FROM dbo.tinetkunde   
	JOIN DELETED ON DELETED.kShop = dbo.tinetkunde.kShop;


	--
	-- tInetKundenAttribute   aufräumen
	--
	DELETE dbo.tInetKundenAttribute   
	FROM dbo.tInetKundenAttribute   
	JOIN DELETED ON DELETED.kShop = dbo.tInetKundenAttribute.kShop;


	--
	-- tInetKundeShop   aufräumen
	--
	DELETE dbo.tInetKundeShop   
	FROM dbo.tInetKundeShop   
	JOIN DELETED ON DELETED.kShop = dbo.tInetKundeShop.kShop;


	--
	-- tInetShopZahlung   aufräumen
	--
	DELETE dbo.tInetShopZahlung   
	FROM dbo.tInetShopZahlung   
	JOIN DELETED ON DELETED.kShop = dbo.tInetShopZahlung.kShop;


	--
	-- tinetzahlungsinfo   aufräumen
	--
	DELETE dbo.tinetzahlungsinfo   
	FROM dbo.tinetzahlungsinfo   
	JOIN DELETED ON DELETED.kShop = dbo.tinetzahlungsinfo.kShop;


	--
	-- tKategorieAttribut   aufräumen
	--
	DELETE dbo.tKategorieAttribut   
	FROM dbo.tKategorieAttribut   
	JOIN DELETED ON DELETED.kShop = dbo.tKategorieAttribut.kShop;


	--
	-- tKategoriebildPlattform   aufräumen
	--
	DELETE dbo.tKategoriebildPlattform   
	FROM dbo.tKategoriebildPlattform   
	JOIN DELETED ON DELETED.kShop = dbo.tKategoriebildPlattform.kShop;


	--
	-- tKategorieRabatt   aufräumen
	--
	DELETE dbo.tKategorieRabatt   
	FROM dbo.tKategorieRabatt   
	JOIN DELETED ON DELETED.kShop = dbo.tKategorieRabatt.kShop;

	--
	-- tKategorieShop   aufräumen
	--
	DELETE dbo.tKategorieShop    
	FROM dbo.tKategorieShop    
	JOIN DELETED ON DELETED.kShop = dbo.tKategorieShop.kShop;

	--
	-- tKategorieSichtbarkeit    aufräumen
	--
	DELETE dbo.tKategorieSichtbarkeit    
	FROM dbo.tKategorieSichtbarkeit    
	JOIN DELETED ON DELETED.kShop = dbo.tKategorieSichtbarkeit.kShop;

	--
	-- tKategorieSichtbarkeit    aufräumen
	--
	DELETE dbo.tKategorieSprache    
	FROM dbo.tKategorieSprache    
	JOIN DELETED ON DELETED.kShop = dbo.tKategorieSprache.kShop;

	--
	-- tkonfigitempreis     aufräumen
	--
	DELETE dbo.tkonfigitempreis     
	FROM dbo.tkonfigitempreis     
	JOIN DELETED ON DELETED.kShop = dbo.tkonfigitempreis.kShop;

	
	--
	-- tkonfigshop   aufräumen
	--
	DELETE dbo.tkonfigshop    
	FROM dbo.tkonfigshop    
	JOIN DELETED ON DELETED.kShop = dbo.tkonfigshop.kShop;

	--
	-- tKundenRankingGlobal   aufräumen
	--
	DELETE dbo.tKundenRankingGlobal   
	FROM dbo.tKundenRankingGlobal   
	JOIN DELETED ON DELETED.kShop = dbo.tKundenRankingGlobal.kShop;

	--
	-- tKundenRankingZeitraum   aufräumen
	--
	DELETE dbo.tKundenRankingZeitraum   
	FROM dbo.tKundenRankingZeitraum   
	JOIN DELETED ON DELETED.kShop = dbo.tKundenRankingZeitraum.kShop;

	--
	-- tMedienDateiShop   aufräumen
	--
	DELETE dbo.tMedienDateiShop   
	FROM dbo.tMedienDateiShop   
	JOIN DELETED ON DELETED.kShop = dbo.tMedienDateiShop.kShop;

	--
	-- tMedienDir   aufräumen
	--
	DELETE dbo.tMedienDir   
	FROM dbo.tMedienDir   
	JOIN DELETED ON DELETED.kShop = dbo.tMedienDir.kShop;

	--
	-- tMedienFile   aufräumen
	--
	DELETE dbo.tMedienFile   
	FROM dbo.tMedienFile   
	JOIN DELETED ON DELETED.kShop = dbo.tMedienFile.kShop;

	--
	-- tMerkmalBildPlattform   aufräumen
	--
	DELETE dbo.tMerkmalBildPlattform   
	FROM dbo.tMerkmalBildPlattform   
	JOIN DELETED ON DELETED.kShop = dbo.tMerkmalBildPlattform.kShop;

	--
	-- tMerkmalwertBildPlattform   aufräumen
	--
	DELETE dbo.tMerkmalwertBildPlattform   
	FROM dbo.tMerkmalwertBildPlattform   
	JOIN DELETED ON DELETED.kShop = dbo.tMerkmalwertBildPlattform.kShop;

	--
	-- tPicVersand   aufräumen
	--
	DELETE dbo.tPicVersand   
	FROM dbo.tPicVersand   
	JOIN DELETED ON DELETED.kShop = dbo.tPicVersand.kShop;

	--
	-- tPreis   aufräumen
	--
	DELETE dbo.tPreis   
	FROM dbo.tPreis   
	JOIN DELETED ON DELETED.kShop = dbo.tPreis.kShop;

	--
	-- tPreiskalkulationSetting   aufräumen
	--
	DELETE dbo.tPreiskalkulationSetting   
	FROM dbo.tPreiskalkulationSetting   
	JOIN DELETED ON DELETED.kShop = dbo.tPreiskalkulationSetting.kShop;

	--
	-- tQueue aufräumen
	--
	DELETE dbo.tQueue    
	FROM dbo.tQueue    
	JOIN DELETED ON DELETED.kShop = dbo.tQueue.kShop;

	--
	-- tSonderpreise   aufräumen
	--
	DELETE dbo.tSonderpreise   
	FROM dbo.tSonderpreise   
	JOIN DELETED ON DELETED.kShop = dbo.tSonderpreise.kShop;

	--
	-- tVerfuegbarkeitsAnfrage   aufräumen
	--
	DELETE dbo.tVerfuegbarkeitsAnfrage   
	FROM dbo.tVerfuegbarkeitsAnfrage   
	JOIN DELETED ON DELETED.kShop = dbo.tVerfuegbarkeitsAnfrage.kShop;

	--
	-- Connector-Tabellen aufräumen
	--
	DELETE dbo.tShopKonfiguration
	FROM dbo.tShopKonfiguration
	JOIN DELETED ON DELETED.kShop = dbo.tShopKonfiguration.kShop;

	DELETE dbo.tShopConnectorFunktion
	FROM dbo.tShopConnectorFunktion
	JOIN DELETED ON DELETED.kShop = dbo.tShopConnectorFunktion.kShop;

	DELETE dbo.tShopConnectorSynchronisierung
	FROM dbo.tShopConnectorSynchronisierung
	JOIN DELETED ON DELETED.kShop = dbo.tShopConnectorSynchronisierung.kShop;

	DELETE dbo.tShopMappingKundengruppe
	FROM dbo.tShopMappingKundengruppe
	JOIN DELETED ON DELETED.kShop = dbo.tShopMappingKundengruppe.kShop;

END;
go

