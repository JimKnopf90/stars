CREATE TRIGGER [dbo].[tgr_tartikelkonfigruppe_DELETE]
--      
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MK
--        
ON [dbo].[tartikelkonfiggruppe]  
AFTER DELETE
AS    
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
    IF((SELECT COUNT(1) FROM DELETED) = 0) 
    BEGIN
	   RETURN;
    END;

	UPDATE tArtikelShop
	SET tArtikelShop.cInet = 'Y', tArtikelShop.nAktion = 1
	FROM tArtikelShop
	JOIN DELETED ON tArtikelShop.kArtikel = DELETED.kArtikel;
END;
go

