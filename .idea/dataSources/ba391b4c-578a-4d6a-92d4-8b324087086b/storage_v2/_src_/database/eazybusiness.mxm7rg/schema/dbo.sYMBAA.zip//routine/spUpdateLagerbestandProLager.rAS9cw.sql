--- 
--- spUpdateLagerbestandProLager
---

CREATE PROCEDURE [dbo].[spUpdateLagerbestandProLager]
	@TYPE_spUpdateLagerbestandProLager TYPE_spUpdateLagerbestandProLager READONLY
AS
BEGIN
	IF(OBJECT_ID('tempdb..#ArtikelWarenlager') IS NOT NULL)
	BEGIN
		DROP TABLE #ArtikelWarenlager;
	END
	CREATE TABLE #ArtikelWarenlager (kArtikel INT, kWarenlager INT);
	INSERT INTO #ArtikelWarenlager(kArtikel, kWarenlager)
		SELECT kArtikel, kWarenlager
			FROM @TYPE_spUPdateLagerbestandProLager;
	UPDATE dbo.tlagerbestandProlagerLagerartikel
		SET fBestand = ISNULL(Result.Summe,0)
		FROM dbo.tlagerbestandProLagerLagerartikel
		JOIN #ArtikelWarenlager ON #ArtikelWarenlager.kArtikel = dbo.tlagerbestandProLagerLagerartikel.kArtikel
								AND #ArtikelWarenlager.kWarenlager = dbo.tlagerbestandProLagerLagerartikel.kWarenlager
		LEFT JOIN (SELECT SUM(dbo.tWarenlagerEingang.fAnzahlAktuell) AS Summe, dbo.tWarenLagerEingang.kArtikel, dbo.tWarenlagerPlatz.kWarenLager
				FROM dbo.tWarenLagerEingang
				JOIN dbo.tWarenlagerPlatz ON dbo.tWarenLagerEingang.kWarenLagerPlatz = dbo.tWarenlagerPlatz.kWarenLagerPlatz
				WHERE dbo.tWarenLagerEingang.fAnzahlAktuell > 0.0
				GROUP BY dbo.tWarenLagerEingang.kArtikel, dbo.tWarenlagerPlatz.kWarenLager
			)AS Result ON Result.kArtikel = #ArtikelWarenlager.kArtikel
						AND Result.kWarenLager = #ArtikelWarenlager.kWarenlager;
END
go

