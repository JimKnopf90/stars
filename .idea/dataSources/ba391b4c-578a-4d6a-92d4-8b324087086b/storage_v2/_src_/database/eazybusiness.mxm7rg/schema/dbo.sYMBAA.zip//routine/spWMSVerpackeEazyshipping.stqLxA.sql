--- 
--- spWMSVerpackeEazyshipping
---

CREATE PROCEDURE [dbo].[spWMSVerpackeEazyshipping]
@kPickliste INT,         -- Die Pickliste über die der Prozess läuft
@kBenutzer INT,         -- Der Benutzer der den Vorgang ausführt
@kBestellung INT,         -- Bestellung die gepickt wird
@dTimestamp DATETIME,     -- Die Zeit wann gebucht wurde
@kWarenlager INT,		 -- Warenlager auf dem wir arbeiten
@cLieferscheinNr VARCHAR(255),
@nVerpackModus INT,	      -- 0 = Standard, 1 = SplittAuftrag, 2 = Packtisch
@cKommentar VARCHAR(MAX),
@nRet INT OUT
	
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Author PN    

-- Funktion: Mit dieser Procedur werden alle Artikel aus den zuvor gefüllten tWMSPacktitem Tabelle gepickt.
	
AS
BEGIN TRAN T0;
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
	DECLARE @kArtikel INT;
	DECLARE @kWMSPackItem INT;
	DECLARE @fMenge DECIMAL(28,14);
	DECLARE @cChargenNr VARCHAR(255);
	DECLARE @cMHD VARCHAR(255);
	DECLARE @cSerNo VARCHAR(255);
	DECLARE @fDataMenge	DECIMAL(28,14);
	DECLARE @kLieferschein INT;
	DECLARE @kPicklistePos INT;
	DECLARE @kLieferscheinPos INT;
	DECLARE @fAnzahlAktuell DECIMAL(28,14);
	DECLARE @kWarenLagerEingang INT;
	DECLARE @kLagerArtikel INT;
	DECLARE @kLieferscheinPosSerNo INT;
	DECLARE @kBestellPosSerNo INT;
	DECLARE @kLagerArtikelkLieferscheinPos INT;
	DECLARE @temp_SerNoBestellpos TABLE(kBestellPos INT,kArtikel INT, nMengeMax INT, nMengeIS INT);
	DECLARE @kWarenLagerPlatzWLE INT;
	DECLARE @kIsPicklistePos INT;
	DECLARE @kIsLieferscheinPos INT;
	DECLARE @IsNowDate DATETIME;
	DECLARE @InBoxCount INT;
	DECLARE @kBestellungNewOrder INT;
	DECLARE @PickPosErrorCount INT;
	DECLARE @nBuchungsArt INT;

     DECLARE cur_GetWMSPackItems CURSOR LOCAL FAST_FORWARD FOR
	SELECT dbo.tWMSPackItem.kWMSPackItem,dbo.tWMSPackItem.kArtikel,ROUND(dbo.tWMSPackItem.fMenge , 4) AS fMenge
	FROM dbo.tWMSPackItem WITH(NOLOCK)
	WHERE dbo.tWMSPackItem.kBestellung = @kBestellung
	AND  dbo.tWMSPackItem.kPickliste = @kPickliste
	AND  dbo.tWMSPackItem.kArtikel > 0
	AND  dbo.tWMSPackItem.kBestellpos = 0;
	
			

	BEGIN TRY
	 
		SET @IsNowDate = GETDATE();
		SET @nRet = 0;


		-- 130 WMS Warenausgang, 20 = Warenausgang
		SELECT @nBuchungsArt = CASE WHEN tWarenlager.nLagerplatzVerwaltung > 0 THEN 130 ELSE 20 END
		FROM dbo.tWarenlager 
		WHERE tWarenlager.kWarenLager = @kWarenlager;
			
		SET CONTEXT_INFO 0x5087; -- Während wir verpacken soll der Bestand nicht durch Trigger aktualisiert werden. Das machen wir am Ende der SP manuell.
		

		-- Auftrag anhand der PackItems Splitten
		IF(@nVerpackModus = 1)
		BEGIN
		
		    EXEC dbo.spSplitAuftragByScannedArticles
					@kBestellung = @kBestellung,
					@kBenutzer = @kBenutzer,
					@kPickliste = @kPickliste,
					@nRetError = @nRet OUTPUT;
		END;
		
		IF(@nVerpackModus = 2)
		BEGIN
		
		    EXEC dbo.spCreateLieferscheinFromPackArtikel
				@kBestellung     = @kBestellung,
				@kBenutzer          = @kBenutzer,
				@kPickliste = @kPickliste,
				@cLieferscheinNr = @cLieferscheinNr,
				@kRetLieferschein  = @kLieferschein OUTPUT,
				@nRetError       = @nRet OUTPUT;		
			 
	     END;

		ELSE

		BEGIN
		    IF(@nRet >= 0)
		    BEGIN

		  
			    SET CONTEXT_INFO 0x5087; -- Während wir verpacken soll der Bestand nicht durch Trigger aktualisiert werden. Das machen wir am Ende der SP manuell.



			    EXEC  Versand.spLieferscheinErstellen 
					   @xLieferschein= null,
					   @kBestellung = @kBestellung,
					   @kBenutzer = @kBenutzer,
					   @cLieferscheinNr = @cLieferscheinNr,
					   @cHinweis= '',
					   @dMailVersand = null,
					   @dGedruckt = null,
					   @nFulfillment = 0,
					   @kLieferantenBestellung = null,
					   @kSessionId = null,
					   @kLieferschein = @kLieferschein OUTPUT;


				 IF (@kLieferschein > 0)
				 BEGIN

				    	DECLARE @LieferscheinPositionen AS XML
					SET @LieferscheinPositionen = (
						   SELECT 0 AS kLieferscheinPos, @kLieferschein AS kLieferschein,tBestellPos.kBestellPos AS kBestellPos, tBestellPos.nAnzahl - ISNULL(vGeliefert.fAnzahlGeliefert,0) - ISNULL(tGutschriftPos.nAnzahl,0) AS fAnzahl, '' AS cHinweis
						   FROM dbo.tbestellpos WITH(NOLOCK) 
						   LEFT JOIN Versand.vBestellPosLieferInfo ON Versand.vBestellPosLieferInfo.kBestellPos = tbestellpos.kBestellPos
						   LEFT JOIN ( SELECT kBestellPos, SUM(fAnzahl) as fAnzahlGeliefert 
				    					FROM dbo.tLieferscheinPos WITH(NOLOCK) GROUP BY kBestellPos) vGeliefert on vGeliefert.kBestellPos = dbo.tBEstellPos.kBestellPos
						   LEFT JOIN tGutschriftPos ON tGutschriftPos.kBestellPos = dbo.tbestellpos.kBestellPos
						   WHERE dbo.tbestellpos.tBestellung_kBestellung = @kBestellung 
						   AND ((Versand.vBestellPosLieferInfo.kBestellPos IS NOT NULL OR tbestellpos.kBestellPos = tbestellpos.kBestellStueckliste) AND (tbestellpos.nType IN (0,1,11)) OR (tbestellpos.nType NOT IN (0,1,11)))
						   AND (dbo.tBestellPos.nAnzahl - ISNULL(vGeliefert.fAnzahlGeliefert,0)) > 0
					FOR XML PATH('LieferscheinPos'), TYPE );



					EXEC [Versand].[spLieferscheinPosErstellen]
									@xLieferscheinPos = @LieferscheinPositionen,
									@kLieferschein = null,
									@kBestellPos = null,
									@fAnzahl  = null,
									@cHinweis  = null,
									@kLieferscheinPos = null;

				END;

		    END;
		    ELSE
		      SET @nRet = -203009001;
  
		END;


        --
		-- PicklistenPositionen buchen, evtl. splitten oder Warenlagereingänge tauschen. 
		--
		OPEN cur_GetWMSPackItems    
		FETCH NEXT FROM cur_GetWMSPackItems INTO  @kWMSPackItem,@kArtikel,@fMenge

		WHILE (@@FETCH_STATUS = 0  and @nRet >= 0)
		BEGIN  
			DECLARE cur_GetWMSPackItemData CURSOR LOCAL FAST_FORWARD FOR  
			SELECT dbo.tWMSPackItemData.cChargenNr,(CONVERT(VARCHAR,dbo.tWMSPackItemData.dMHD, 104)) cMHD,dbo.tWMSPackItemData.cSerNo, dbo.tWMSPackItemData.fMenge 
				FROM dbo.tWMSPackItemData WITH(NOLOCK) 
				WHERE dbo.tWMSPackItemData.kWMSPackItem = @kWMSPackItem
				AND (LEN(dbo.tWMSPackItemData.cChargenNr) > 0 
				    OR LEN(dbo.tWMSPackItemData.dMHD) > 0);

			OPEN cur_GetWMSPackItemData    
			FETCH NEXT FROM cur_GetWMSPackItemData INTO  @cChargenNr,@cMHD,@cSerNo,@fDataMenge
			WHILE (@@FETCH_STATUS = 0  and @nRet >= 0)
			BEGIN  
				IF(LEN(@cChargenNr) > 0  OR LEN(@cMHD) > 0)
				BEGIN
		  
				EXEC dbo.spPicklisteInBox
					  @kPickliste    = @kPickliste,
					  @kArtikel      = @kArtikel,
					  @cMhd          = @cMHD,
					  @cCharge       = @cChargenNr,
					  @nMenge        = @fDataMenge,
					  @kBestellung   = @kBestellung,
					  @kBenutzer     = @kBenutzer,
					  @kLhm          = 0,
					  @kWarenlagerPlatz = 0,
					  @nPickPosStatus  = 30,
					  @kLieferschein = @kLieferschein,
					  @nRet       = @nRet OUTPUT;
				END
				SET @fMenge = @fMenge - @fDataMenge
				FETCH NEXT FROM cur_GetWMSPackItemData INTO  @cChargenNr,@cMHD,@cSerNo,@fDataMenge
			END
			CLOSE cur_GetWMSPackItemData 
			DEALLOCATE cur_GetWMSPackItemData	   
			IF(@fMenge > 0)
			BEGIN
				EXEC  dbo.spPicklisteInBox
					  @kPickliste    = @kPickliste,
					  @kArtikel      = @kArtikel,
					  @cMhd          = null,
					  @cCharge       = null,
					  @nMenge        = @fMenge,
					  @kBestellung   = @kBestellung,
					  @kBenutzer     = @kBenutzer,
					  @kLhm          = 0,
					  @kWarenlagerPlatz = 0,
					  @nPickPosStatus  = 30,
					  @kLieferschein = @kLieferschein,
					  @nRet       = @nRet OUTPUT;
			END
			FETCH NEXT FROM cur_GetWMSPackItems INTO  @kWMSPackItem,@kArtikel,@fMenge
		END
		CLOSE cur_GetWMSPackItems
		DEALLOCATE cur_GetWMSPackItems 
		
		
		IF(@nRet >= 0)
		BEGIN

		    IF(@kLieferschein = 0)
		      RAISERROR(N'Es wurde kein Lieferschein erstellt. Verpacken abgebrochen.', 15,1);

			--
			-- SerNos ausbuchen
			--
			INSERT INTO @temp_SerNoBestellpos (kBestellPos ,kArtikel , nMengeMax , nMengeIS)
			   SELECT dbo.tbestellpos.kBestellPos,dbo.tbestellpos.tArtikel_kArtikel,dbo.tbestellpos.nAnzahl,0
			   FROM dbo.tbestellpos WITH(NOLOCK) 
			   JOIN dbo.tArtikel WITH(NOLOCK) on dbo.tArtikel.kArtikel = dbo.tbestellpos.tArtikel_kArtikel
			   WHERE dbo.tbestellpos.tBestellung_kBestellung = @kBestellung
			   AND dbo.tArtikel.cLagerArtikel = 'Y';
		  
			DECLARE cur_GetWMSPackItemDataSerNo CURSOR LOCAL FAST_FORWARD FOR  
			SELECT dbo.tWMSPackItem.kArtikel, dbo.tWMSPackItemData.cSerNo, dbo.tWMSPackItemData.fMenge 
				FROM dbo.tWMSPackItem WITH(NOLOCK) 
				JOIN dbo.tWMSPackItemData WITH(NOLOCK) ON dbo.tWMSPackItemData.kWMSPackItem = dbo.tWMSPackItem.kWMSPackItem
				WHERE dbo.tWMSPackItem.kBestellung = @kBestellung
				AND LEN(dbo.tWMSPackItemData.cSerNo) > 0;
	   
			OPEN cur_GetWMSPackItemDataSerNo    
			FETCH NEXT FROM cur_GetWMSPackItemDataSerNo INTO  @kArtikel,@cSerNo,@fDataMenge
			WHILE (@@FETCH_STATUS = 0  and @nRet >= 0)
			BEGIN  
				-- Ersten gültigen Lagerartikel holen
				SELECT TOP(1) @kLagerArtikel = dbo.tLagerArtikel.kLagerArtikel , @kLagerArtikelkLieferscheinPos = dbo.tLagerArtikel.kLieferscheinPos
					FROM dbo.tLagerArtikel WITH(NOLOCK) 
					WHERE kArtikel = @kArtikel
					AND kWarenlager = @kWarenlager
					AND ISNULL(kLieferscheinPos,0) IN (0,999999999)
					ORDER BY CASE WHEN cSeriennr = @cSerNo 
								THEN 0 
								ELSE 1 
							END,
							CASE WHEN cSeriennr = '#$KEINE$#' 
								THEN 0 
								ELSE 1 
							END, 
							kLieferscheinPos;

				-- Bestellpos zum Artikel holen
				SELECT TOP(1) @kBestellPosSerNo = tbestellpos.kBestellPos, @kLieferscheinPosSerNo = tLieferscheinPos.kLieferscheinPos
					FROM dbo.tbestellpos WITH(NOLOCK) 
					JOIN dbo.tLieferscheinPos WITH(NOLOCK) ON dbo.tLieferscheinPos.kBestellPos = dbo.tbestellpos.kBestellPos
					WHERE dbo.tbestellpos.tBestellung_kBestellung = @kBestellung
					AND dbo.tbestellpos.tArtikel_kArtikel = @kArtikel
					AND dbo.tbestellpos.kBestellPos IN (
                                                              SELECT snb.kBestellPos 
												  FROM @temp_SerNoBestellpos snb   --Keine schon erfassten bestellpos
											       WHERE snb.nMengeIS < snb.nMengeMax
                                                            );
	
				-- SerNo Ausbuchen
				UPDATE dbo.tLagerArtikel WITH(ROWLOCK) 
				SET dbo.tLagerArtikel.kLieferscheinPos = @kLieferscheinPosSerNo,dbo.tLagerArtikel.cSeriennr = @cSerNo,dbo.tLagerArtikel.kBestellPos = @kBestellPosSerNo
				WHERE dbo.tLagerArtikel.kLagerArtikel = @kLagerArtikel;	    
				
				-- Alte SerNo reservierungen löschen
				UPDATE dbo.tLagerArtikel WITH(ROWLOCK)
				SET dbo.tLagerArtikel.kBestellPos = 0
				WHERE dbo.tLagerArtikel.kLagerArtikel != @kLagerArtikel AND dbo.tLagerArtikel.kBestellPos = @kBestellPosSerNo AND dbo.tLagerArtikel.kLieferscheinPos = 0;


                    -- Bestellpos die eben gebucht wurde merken
				UPDATE @temp_SerNoBestellpos 
				SET nMengeIS = nMengeIS + 1
				WHERE kBestellPos = @kBestellPosSerNo;
	   
				FETCH NEXT FROM cur_GetWMSPackItemDataSerNo 
                    INTO  @kArtikel,@cSerNo,@fDataMenge;
			END	   
			CLOSE cur_GetWMSPackItemDataSerNo;
			DEALLOCATE cur_GetWMSPackItemDataSerNo; 
			
			--
		    -- Buche Bestände
			--
			SET CONTEXT_INFO 0x5087;
		    EXEC dbo.spWMSBestandUndPicklisteBuchen
				@kBestellung = @kBestellung,
				@kPickliste = @kPickliste,
				@kPlattform = 1,
				@kBenutzer = @kBenutzer,
				@cKommentar = @cKommentar,   
				@kLieferschein = @kLieferschein,
				@kBuchungsart = @nBuchungsArt;



			--
			-- Picklistenstatus ändern
			--
			DECLARE @kBestellstuecklistePacktisch INT;
			DECLARE @kBestellPosPacktisch INT
			DECLARE cur_GetPackFensterPos CURSOR LOCAL FAST_FORWARD FOR  
			SELECT dbo.tPicklistepos.kPicklistePos,dbo.tLieferscheinPos.kLieferscheinPos,dbo.tbestellpos.kBestellstueckliste, dbo.tbestellpos.kBestellPos
		    FROM dbo.tPicklistepos WITH(NOLOCK) 
			JOIN dbo.tbestellpos WITH(NOLOCK) ON dbo.tbestellpos.kBestellPos = dbo.tPicklistePos.kBestellPos
		    JOIN dbo.tLieferscheinPos WITH(NOLOCK) ON dbo.tLieferscheinPos.kBestellPos = dbo.tbestellpos.kBestellPos
		    WHERE dbo.tPicklistepos.kBestellung = @kBestellung 
			AND  (dbo.tPicklistepos.kWarenLagerEingang = 0 OR EXISTS (SELECT teigenschaft.kArtikel FROM teigenschaft WHERE  dbo.tbestellpos.tartikel_kArtikel = teigenschaft.kArtikel AND teigenschaft.cAktiv = 'Y'))
			AND dbo.tPicklistepos.kPickliste = @kPickliste
		    GROUP BY dbo.tPicklistepos.kPicklistePos,dbo.tLieferscheinPos.kLieferscheinPos,dbo.tbestellpos.kBestellstueckliste, dbo.tbestellpos.kBestellPos
			ORDER BY CASE WHEN dbo.tbestellpos.kBestellstueckliste = dbo.tbestellpos.kBestellPos AND dbo.tbestellpos.kBestellstueckliste > 0 THEN 1 ELSE 0 END;
                  
                  
			OPEN cur_GetPackFensterPos    
			FETCH NEXT FROM cur_GetPackFensterPos INTO  @kIsPicklistePos,@kIsLieferscheinPos,@kBestellstuecklistePacktisch,@kBestellPosPacktisch
			WHILE (@@FETCH_STATUS = 0)
			BEGIN  	 
                 
				DECLARE @OffeneStuecklistenKinder INT = 0;
			    IF(@kBestellstuecklistePacktisch = @kBestellPosPacktisch AND @kBestellstuecklistePacktisch > 0)
				BEGIN

					SELECT @OffeneStuecklistenKinder = count(*) 
					FROM dbo.tPicklistePos
					JOIN dbo.tBestellPos ON dbo.tBestellPos.kBestellPos = dbo.tPicklistePos.kBestellPos
					WHERE dbo.tBestellPos.kBestellstueckliste = @kBestellstuecklistePacktisch
					AND dbo.tBestellPos.kBestellPos != dbo.tBestellPos.kBestellstueckliste
					AND dbo.tPicklistePos.nStatus < 40;

				END;

				IF(@OffeneStuecklistenKinder = 0)
				BEGIN

					UPDATE dbo.tPicklistePos
					SET kLieferscheinPos = @kIsLieferscheinPos
					WHERE dbo.tPicklistePos.kPicklistePos = @kIsPicklistePos;     
	   
	   				EXEC dbo.spPicklisteposStatusAendern @kPicklistePos = @kIsPicklistePos, @nNewStatus = 40, @kBenutzer = @kBenutzer,@dTimestamp = @IsNowDate
				END;

			    FETCH NEXT FROM cur_GetPackFensterPos INTO  @kIsPicklistePos,@kIsLieferscheinPos,@kBestellstuecklistePacktisch,@kBestellPosPacktisch;
			END	   
			CLOSE cur_GetPackFensterPos
			DEALLOCATE cur_GetPackFensterPos	   
		END
    
		DELETE FROM dbo.tWMSPackItemData  WITH(ROWLOCK) 
		WHERE dbo.tWMSPackItemData.kWMSPackItem IN (
                                                     SELECT kWMSPackItem 
										   FROM dbo.tWMSPackItem WITH(NOLOCK)
									   	   WHERE dbo.tWMSPackItem.kBestellung = @kBestellung
										   AND dbo.tWMSPackItem.kPickliste = @kPickliste
                                                     );
    
		DELETE FROM dbo.tWMSPackItem WITH(ROWLOCK) 
		WHERE dbo.tWMSPackItem.kBestellung = @kBestellung
		AND dbo.tWMSPackItem.kPickliste = @kPickliste;


		SET CONTEXT_INFO 0x0000; --Sperre Bestandsupdate Trigger wieder freigeben


		--
		-- Plausibilitäts Prüfungen. Im Fehlerfall alles reverten.
		--

		SELECT @InBoxCount = COUNT(*) 
		FROM dbo.tPicklistePos
		JOIN dbo.tBestellpos ON dbo.tBestellpos.kBestellPos = dbo.tPicklistePos.kBestellPos
		WHERE dbo.tPicklistePos.kPickliste = @kPickliste
		AND dbo.tPicklistePos.nStatus = 30
		AND dbo.tBestellpos.tBestellung_kBestellung = @kBestellung;

		IF(@InBoxCount > 0)
		BEGIN
		  SET @nRet =  -203508701;
		END;

		SELECT @PickPosErrorCount = COUNT(*) 
		FROM dbo.tLieferscheinPos
		JOIN dbo.tPicklistePos ON dbo.tPicklistePos.kBestellPos = dbo.tLieferscheinPos.kBestellPos  
		CROSS JOIN ( SELECT COUNT(*) AS PicklistenAnzahl
				    FROM tPicklistePos
				    WHERE tPicklistePos.kBestellung = @kBestellung
				    AND tPicklistePos.nStatus < 40
					AND tPicklistePos.kPickliste != @kPickliste) AS PicklistenCheck
		WHERE dbo.tLieferscheinPos.kLieferschein = @kLieferschein
		AND dbo.tPicklistePos.nStatus <= 30
		AND @nVerpackModus = 0
		AND PicklistenCheck.PicklistenAnzahl = 0;
		
		IF(@PickPosErrorCount > 0)
		BEGIN

		   INSERT INTO dbo.tLog (dDatum, kBenutzer, cLog,  nTyp,  nVorgang )
		   SELECT getdate(), @kBenutzer, 'Pickpos:' + CAST(tPicklistePos.kPicklistePos AS VARCHAR) +  '  Bestellpos:' + CAST(tBestellpos.kBestellPos AS VARCHAR),  14,  9 
		   FROM dbo.tLieferscheinPos
		   JOIN dbo.tBestellpos ON dbo.tBestellpos.kBestellPos = tLieferscheinPos.kBestellPos   
		   JOIN dbo.tPicklistePos ON dbo.tPicklistePos.kBestellPos = dbo.tBestellpos.kBestellPos
		   WHERE dbo.tLieferscheinPos.kLieferscheinPos = @kLieferschein
		   AND dbo.tPicklistePos.nStatus <= 30;   

		   DECLARE @ErrorText AS VARCHAR(520);
		   SET @ErrorText = N'Es konnten nicht alle (' + CAST(@PickPosErrorCount AS VARCHAR) +   ') Pickpositionen verpackt werden. Verpacken abgebrochen.';
		   RAISERROR(@ErrorText, 15,1);

		END;



		IF(@nRet < 0)  -- Bei einen Fehler im prozess, gesammter rollback
		BEGIN 
			ROLLBACK TRAN T0;
			SELECT @nRet;
		END
		ELSE
		BEGIN
		   

		    --
		    -- Wir aktualisieren den Bestand den wir gebucht haben
		    --
		    DECLARE @Positionen AS XML
		    SET @Positionen = (
				SELECT dbo.tBestellpos.kBestellPos AS kKey, 1 AS nPlattform
				    FROM dbo.tBestellpos
				    JOIN dbo.tpicklistepos ON dbo.tpicklistepos.kBestellPos = dbo.tBestellpos.kBestellPos
				    WHERE dbo.tBestellpos.tBestellung_kBestellung = @kBestellung    
				    AND dbo.tpicklistepos.kPickliste = @kPickliste    
			 FOR XML PATH('Keys'), TYPE
			 );


		    EXEC dbo.spReservierungAktualisieren @Positionen;
		    EXEC dbo.spBestellungEckdatenAktualisieren    @kBestellung =  @kBestellung;

		   COMMIT TRAN T0; -- Alles gut

		END;

	END TRY
	BEGIN CATCH

		
	    DECLARE @ErrorMessage VARCHAR(4000)
	    SET @ErrorMessage = N'DB-Error: (' + CAST(ERROR_NUMBER() AS VARCHAR) + ' - ' +  CAST(ERROR_SEVERITY() AS VARCHAR) + ' - ' + CAST(ERROR_STATE() AS VARCHAR) + ' ) ' + ' Zeile:' + CAST(ERROR_LINE() AS VARCHAR) + ' - SP: ' +  ISNULL(ERROR_PROCEDURE(), 'none') + ' - Text: ' + ERROR_MESSAGE();
		
	    INSERT INTO dbo.tLog
	    (dDatum, kBenutzer, cLog,  nTyp,  nVorgang )
	    VALUES
	    (GETDATE(),  @kBenutzer,   @ErrorMessage,   14,  9);

 	    SET @nRet = -203009999;
	    SELECT -203009999; -- unbekannter Fehler

	    BEGIN TRY
	      ROLLBACK TRAN T0;
	    END TRY
	    BEGIN Catch

	      SET @nRet = -203009999;
	      SELECT -203009999; -- unbekannter Fehler

	      INSERT INTO dbo.tLog
	      (dDatum, kBenutzer, cLog,  nTyp,  nVorgang )
	      VALUES
		  (GETDATE(),  @kBenutzer,   @ErrorMessage,   14,  9);
	    END CATCH;
	
	    INSERT INTO dbo.tLog
	    (dDatum, kBenutzer, cLog,  nTyp,  nVorgang )
	    VALUES
	    (GETDATE(),  @kBenutzer,   @ErrorMessage,   14,  9);
	END CATCH
go

