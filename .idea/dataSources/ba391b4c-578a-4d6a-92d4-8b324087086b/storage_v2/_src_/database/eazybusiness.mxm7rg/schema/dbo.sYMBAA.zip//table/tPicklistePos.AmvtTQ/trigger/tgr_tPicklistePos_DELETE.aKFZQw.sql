CREATE TRIGGER [dbo].[tgr_tPicklistePos_DELETE]
ON [dbo].[tPicklistePos]
AFTER DELETE
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--
AS 
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN TRANSACTION
	DECLARE @kPickliste INT;
	DECLARE @nStatus INT;
	DECLARE @kPicklisteStatus INT;

	IF EXISTS(SELECT 1 FROM DELETED)
	BEGIN
		SET CONTEXT_INFO 0x5095;
		UPDATE tWarenLagerEingang
		SET fAnzahlReserviertPickpos = (SELECT ISNULL(SUM(fAnzahl),0)
										FROM tPicklistePos
										WHERE tPicklistePos.nStatus < 40
										AND tPicklistePos.kWarenLagerEingang = tWarenLagerEingang.kWarenLagerEingang)
		WHERE kWarenLagerEingang IN (SELECT kWarenLagerEingang FROM DELETED)
		SET CONTEXT_INFO 0x000;

		--
		--Hiermit wird sichergestellt, dass aus Versandboxen wieder freigegeben werden, wenn die letzte Position einer Pickpos gelöscht wird
		--
		UPDATE tlhmstatus 
		SET kbestellung = 0, nStatus = 10
		WHERE klhmstatus IN (
			SELECT tlhmstatus.klhmstatus FROM tlhmstatus
			JOIN tlhm on tlhm.klhmstatus = tlhmstatus.klhmstatus
			WHERE kBestellung IS NOT NULL
				AND kBestellung > 0
  				AND kLhmTyp = 4
				AND NOT EXISTS (SELECT *
			  					FROM twarenlagereingang
								WHERE twarenlagereingang.fanzahlaktuell > 0
								AND twarenlagereingang.klhm = tlhm.klhm)
				AND NOT EXISTS (SELECT *
								FROM tpicklistepos 
								JOIN tBestellpos ON tPicklistePos.kBestellPos = tBestellpos.kBestellPos
								WHERE tBestellPos.tBestellung_kBestellung = tlhmstatus.kBestellung
								AND tpicklistepos.nStatus <= 20)) --Es müssen nur die Positionen beachtet werden, die auf dem Weg zu einer Box sind  --Es müssen nur die Positionen beachtet werden, die auf dem Weg zu einer Box sind
						
		DELETE tPickliste WITH (ROWLOCK)
		FROM tPickliste WITH (ROWLOCK)
		JOIN deleted ON tPickliste.kPickliste = deleted.kPickliste
		LEFT JOIN tPicklistePos ON tPickliste.kPickliste = tPicklistePos.kPickliste
		WHERE tPicklistePos.kPickliste IS NULL

		
	    IF(object_id('tempdb..#NewStatus') IS NOT NULL)
	    BEGIN
	        DROP TABLE #NewStatus;
	    END
         CREATE TABLE #NewStatus (kPicklisteStatus INT NOT NULL, kPickliste INT NOT NULL, nStatus INT NOT NULL);


	    --
	    -- Setzt den PicklisteStatus anhand der PicklistePosStatus
	    -- 
	    INSERT INTO dbo.tPicklisteStatus
		(
			dbo.tPicklisteStatus.kPickliste,
			dbo.tPicklisteStatus.kBenutzer,
			dbo.tPicklisteStatus.dZeitstempel,
			dbo.tPicklisteStatus.nStatus
		)
		OUTPUT INSERTED.kPicklisteStatus, INSERTED.kPickliste, INSERTED.nStatus INTO #NewStatus
		SELECT
			dbo.tPickliste.kPickliste,
			PicklistePosStatus.kBenutzer AS kBenutzer,
			GETDATE(),
			CASE 
				WHEN (PicklistePosStatus.nMinStatus = 10) AND (PicklistePosStatus.nMaxStatus > 10) THEN 11
				ELSE PicklistePosStatus.nMinStatus
			END 		
		FROM dbo.tPickliste
		JOIN tPicklisteStatus ON dbo.tPicklisteStatus.kPicklisteStatus = dbo.tPickliste.kPicklisteStatus
		JOIN (
			SELECT 
				dbo.tPicklistePos.kPickliste,MAX(dbo.tPicklistePosStatus.kBenutzer) AS kBenutzer,
				MAX(ISNULL(dbo.tPicklistePosStatus.nStatus, 0)) AS  nMaxStatus,
				MIN(ISNULL(dbo.tPicklistePosStatus.nStatus, 0)) AS nMinStatus
			FROM dbo.tPicklistePosStatus 
			JOIN dbo.tPicklistePos ON dbo.tPicklistePos.kPicklistePosStatus = tPicklistePosStatus.kPicklistePosStatus
			JOIN DELETED ON DELETED.kPickliste = dbo.tPicklistePos.kPickliste
			GROUP BY dbo.tPicklistePos.kPickliste
		) AS PicklistePosStatus ON PicklistePosStatus.kPickliste = dbo.tPickliste.kPickliste
		WHERE CASE 
			 WHEN (PicklistePosStatus.nMinStatus = 10) AND (PicklistePosStatus.nMaxStatus > 10) THEN 11
			 ELSE PicklistePosStatus.nMinStatus
			 END <> dbo.tPicklisteStatus.nStatus;


	     -- Tabelle tPickliste muß den gleichen status wie der tPicklisteStatus haben
		UPDATE dbo.tPickliste
		SET  dbo.tPickliste.nStatus = #NewStatus.nStatus,
			dbo.tPickliste.kPicklisteStatus = #NewStatus.kPicklisteStatus
		FROM dbo.tPickliste
		JOIN #NewStatus ON #NewStatus.kPickliste = dbo.tPickliste.kPickliste;

		DROP TABLE #NewStatus;

		-- reservierte Seriennummern wieder freigeben
		UPDATE dbo.tlagerartikel
		SET
			dbo.tlagerartikel.kPicklistePos = 0,
			dbo.tlagerartikel.kBestellPos = 0
		FROM dbo.tlagerartikel
		JOIN DELETED ON DELETED.kPicklistePos = dbo.tlagerartikel.kPicklistePos
		WHERE dbo.tlagerartikel.kLieferscheinPos = 0
	END
 COMMIT
go

