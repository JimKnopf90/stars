--- 
--- spDelConstraint
---

CREATE PROCEDURE [dbo].[spDelConstraint] 
@cTabelle VARCHAR(255), 
@cSpalte  VARCHAR(255) 
AS  
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN 
	DECLARE @cName VARCHAR(512) 
	SELECT @cName = cstr.name FROM sys.tables AS tbl  WITH(NOLOCK) 
		INNER JOIN sys.all_columns AS clmns ON clmns.object_id=tbl.object_id 
		INNER JOIN sys.default_constraints AS cstr ON cstr.object_id=clmns.default_object_id 
		WHERE clmns.name=@cSpalte
			AND(
				tbl.name=@cTabelle 
				AND SCHEMA_NAME(tbl.schema_id)=N'dbo'
				) 
	--Wenn vorhanden Constraint loeschen 
	IF(@cName IS NOT NULL AND LEN(@cName)>0) 
	BEGIN 
		DECLARE @tsql NVARCHAR(2048) 
		SET @tsql = 'ALTER TABLE '+@cTabelle+' DROP CONSTRAINT '+@cName 
		EXEC sp_executesql @tsql 
	END 
END
go

