CREATE TRIGGER [dbo].[jtlActionValidator_tUmlagerung]  
--     
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--    
ON [dbo].[tUmlagerung]  
AFTER DELETE 
AS  
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN 

	--
	--Überprüfen ob Trigger mit Inhalt aufgerufen wird
	--
		IF((SELECT COUNT(1) FROM DELETED) = 0)
		BEGIN
			RETURN
		END

	--
	-- tBestellung aufräumen
	--
	DECLARE @xBestellung XML;
	SELECT @xBestellung = (
			SELECT tBestellung.kBestellung AS kBestellung
			FROM tBestellung 
			JOIN DELETED ON DELETED.kBestellung = tBestellung.kBestellung 
			FOR XML PATH('Bestellung'), TYPE
		);


    EXEC [dbo].[spBestellungLoeschen]
	@xBestellung = @xBestellung;


	--
	-- tLieferantenBestellung aufräumen
	--
	DECLARE @xLieferantenbestellung XML;
			SELECT @xLieferantenbestellung = (
					SELECT tLieferantenBestellung.kLieferantenBestellung AS Lieferantenbestellung
					FROM tLieferantenBestellung WITH(ROWLOCK)
					JOIN DELETED ON DELETED.kLieferantenBestellung = tLieferantenBestellung.kLieferantenBestellung	
				    FOR XML PATH('Lieferantenbestellung'), TYPE
				);


	EXEC [Lieferantenbestellung].[spLieferantenBestellungLoeschen]
	@xLieferantenbestellung = @xLieferantenbestellung;

	
																			 
END
go

