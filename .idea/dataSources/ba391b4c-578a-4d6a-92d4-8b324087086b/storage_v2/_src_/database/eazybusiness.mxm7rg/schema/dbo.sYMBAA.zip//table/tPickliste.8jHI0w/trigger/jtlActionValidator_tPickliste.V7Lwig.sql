--
-- CleanUp-Trigger für das Löschen von Picklisten
--
CREATE TRIGGER [dbo].[jtlActionValidator_tPickliste]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MaikS
--
ON [dbo].[tPickliste]
AFTER DELETE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
  IF EXISTS(SELECT 1 FROM DELETED)
  BEGIN
	--
	-- tPicklisteStatus  entfernen
	--					
		DELETE tPicklisteStatus   WITH(ROWLOCK)
		FROM tPicklisteStatus   WITH(ROWLOCK)
		JOIN DELETED ON tPicklisteStatus.kPickliste = DELETED.kPickliste
						
	--
	-- tPicklisteVorlage  entfernen
	--
		DELETE tPicklisteVorlage   WITH(ROWLOCK)
		FROM tPicklisteVorlage   WITH(ROWLOCK)
		JOIN DELETED ON tPicklisteVorlage.kPickliste = DELETED.kPickliste
		
	--
	-- tBestellungPicklisteLock  entfernen
	--
		DELETE tBestellungPicklisteLock   WITH(ROWLOCK)
		FROM tBestellungPicklisteLock   WITH(ROWLOCK)
		JOIN DELETED ON tBestellungPicklisteLock.kPickliste = DELETED.kPickliste
		
	--
	-- tPicklistePos entfernen
	--
		DELETE tPicklistePos  WITH(ROWLOCK)
		FROM tPicklistePos  WITH(ROWLOCK)
		JOIN DELETED ON tPicklistePos.kPickliste = DELETED.kPickliste
  END		
END
go

