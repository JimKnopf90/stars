--- 
--- spBestellposAendern
---

CREATE PROCEDURE [dbo].[spBestellposAendern]
	@xBestellpos AS XML = NULL,
	@kBestellpos INT = NULL,
	@kArtikel INT = NULL,
	@kBestellung INT = NULL,
	@fVKPreis DECIMAL(28,14) = NULL,
	@fMwSt DECIMAL(28,14) = NULL,
	@nAnzahl DECIMAL(28,14) = NULL,
	@fRabatt DECIMAL(28,14) = NULL,
	@cString VARCHAR(255) = NULL,
	@fVKNetto DECIMAL(28,14) = NULL,
	@cArtNr VARCHAR(100) = NULL,
	@nType TINYINT = NULL,
	@cHinweis VARCHAR(2000) = NULL,
	@nHatUpload INT = NULL,
	@cUnique VARCHAR(30) = NULL,
	@kKonfigitem INT = NULL,
	@nDropshipping TINYINT = NULL,
	@fEkNetto DECIMAL(28,14) = NULL,
	@cOrderItemId VARCHAR(255) = NULL,
	@cItemId VARCHAR(255) = NULL,
	@cTransactionID VARCHAR(255) = NULL,
	@kAmazonBestellungPos INT = NULL,
	@nSort INT = NULL,
	@kBestellStueckliste INT = NULL, 
	@cStringStandard VARCHAR(255) = NULL,
	@nEckDatenNichtAktualisieren INT = 0,
	@cEinheit VARCHAR(255) = NULL
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
DECLARE @ErrorMessage NVARCHAR(4000);
DECLARE @ErrorSeverity INT;
DECLARE @ErrorState INT;
DECLARE @retry INT;
SET @retry = 5;
WHILE @retry > 0
BEGIN
	SET CONTEXT_INFO 0x5098;
	BEGIN TRY
		BEGIN TRANSACTION
			IF(OBJECT_ID('tempdb..#Bestellpos') IS NOT NULL)
			BEGIN
				DROP TABLE #Bestellpos;
			END
			CREATE TABLE #Bestellpos(
				kBestellpos INT,
				kArtikel INT,
				kBestellung INT,
				fVKPreis DECIMAL(28,14),
				fMwSt DECIMAL(28,14),
				nAnzahl DECIMAL(28,14),
				fRabatt DECIMAL(28,14),
				cString VARCHAR(255),
				fVKNetto DECIMAL(28,14),
				cArtNr VARCHAR(100),
				nType TINYINT, 
				cHinweis VARCHAR(2000),
				nHatUpload INT,
				cUnique VARCHAR(30),
				kKonfigitem INT,
				nDropshipping TINYINT,
				fEKNetto DECIMAL(28,14),
				cOrderItemId VARCHAR(255),
				cItemID VARCHAR(255),
				cTransactionID VARCHAR(255),
				kAmazonBestellungPos INT,
				nSort INT,
				kBestellStueckliste INT,
				cStringStandard VARCHAR(255),
				nBestandAenderung INT,
				nEckdatenAenderung INT,
				nArtikelAenderung INT,
				cEinheit VARCHAR(255)
			);	
			IF(@xBestellpos IS NOT NULL)
			BEGIN
				INSERT INTO #Bestellpos(kBestellpos, kArtikel, kBestellung, fVKPreis, fMwSt, nAnzahl, fRabatt, cString, fVKNetto, cArtNr,
										nType, cHinweis, nHatUpload, cUnique, kKonfigitem, nDropshipping, fEKNetto, cOrderItemId, cItemID,
										cTransactionID, kAmazonBestellungPos, nSort, kBestellStueckliste, cStringStandard, nBestandAenderung, 
										nEckdatenAenderung, nArtikelAenderung, cEinheit)
					SELECT Bestellpos.ID.value('kBestellpos[1]', 'INT'),
							Bestellpos.ID.value('kArtikel[1]', 'INT'),
							Bestellpos.ID.value('kBestellung[1]', 'INT'),
							Bestellpos.ID.value('fVKPreis[1]', 'DECIMAL(28,14)'),
							Bestellpos.ID.value('fMwSt[1]', 'DECIMAL(28,14)'),
							ROUND(Bestellpos.ID.value('nAnzahl[1]', 'DECIMAL(28,14)'),4),
							Bestellpos.ID.value('fRabatt[1]', 'DECIMAL(28,14)'),
							Bestellpos.ID.value('cString[1]', 'VARCHAR(255)'),
							Bestellpos.ID.value('fVKNetto[1]', 'DECIMAL(28,14)'),
							Bestellpos.ID.value('cArtNr[1]', 'VARCHAR(100)'),
							Bestellpos.ID.value('nType[1]', 'TINYINT'),
							Bestellpos.ID.value('cHinweis[1]', 'VARCHAR(2000)'),
							Bestellpos.ID.value('nHatUpload[1]', 'INT'),
							Bestellpos.ID.value('cUnique[1]', 'VARCHAR(30)'),
							Bestellpos.ID.value('kKonfigitem[1]', 'INT'),
							Bestellpos.ID.value('nDropshipping[1]', 'TINYINT'),
							Bestellpos.ID.value('fEKNetto[1]', 'DECIMAL(28,14)'),
							Bestellpos.ID.value('cOrderItemId[1]', 'VARCHAR(255)'),
							Bestellpos.ID.value('cItemID[1]', 'VARCHAR(255)'),
							Bestellpos.ID.value('cTransactionID[1]', 'VARCHAR(255)'),
							Bestellpos.ID.value('kAmazonBestellungPos[1]', 'INT'),
							Bestellpos.ID.value('nSort[1]', 'INT'),
							Bestellpos.ID.value('kBestellStueckliste[1]', 'INT'),
							Bestellpos.ID.value('cStringStandard[1]', 'VARCHAR(255)'),
							CASE WHEN ((dbo.tbestellpos.tBestellung_kBestellung <> Bestellpos.ID.value('kBestellung[1]', 'INT')) 
									OR (dbo.tbestellpos.nAnzahl <> Bestellpos.ID.value('nAnzahl[1]', 'DECIMAL(28,14)'))
									OR (dbo.tbestellpos.tArtikel_kArtikel <> Bestellpos.ID.value('kArtikel[1]', 'INT')))
									AND dbo.tBestellung.cType IN ('B', 'U')
								THEN 1
								ELSE 0
							END,
							CASE WHEN ((dbo.tbestellpos.fVkPreis <> Bestellpos.ID.value('fVKPreis[1]', 'DECIMAL(28,14)')) 
									OR (dbo.tbestellpos.fMwSt <> Bestellpos.ID.value('fMwSt[1]', 'DECIMAL(28,14)'))
									OR (dbo.tbestellpos.fRabatt <> Bestellpos.ID.value('fRabatt[1]', 'DECIMAL(28,14)')))
									AND dbo.tBestellung.cType IN ('B', 'U')
								THEN 1
								ELSE 0
							END,
							CASE WHEN (dbo.tbestellpos.tArtikel_kArtikel <> Bestellpos.ID.value('kArtikel[1]', 'INT'))
								THEN 1
								ELSE 0
							END,
							CASE WHEN (Bestellpos.ID.value('cEinheit[1]', 'VARCHAR(255)') IS NOT NULL)
								THEN Bestellpos.ID.value('cEinheit[1]', 'VARCHAR(255)')
								ELSE CASE WHEN dbo.tbestellpos.cEinheit IS NOT NULL
											THEN dbo.tbestellpos.cEinheit
											ELSE (SELECT dbo.tEinheitSprache.cName
													FROM dbo.tBestellung
													JOIN dbo.tArtikel ON dbo.tArtikel.kArtikel = @kArtikel
													JOIN dbo.tEinheitSprache ON dbo.tArtikel.kVerkaufsEinheit = dbo.tEinheitSprache.kEinheit
														AND dbo.tEinheitSprache.kSprache = dbo.tBestellung.kSprache
													WHERE	dbo.tBestellung.kBestellung = Bestellpos.ID.value('kBestellung[1]', 'INT'))
									END
							END
						FROM @xBestellpos.nodes('/Bestellpos') AS Bestellpos(ID)
						JOIN dbo.tbestellpos ON Bestellpos.ID.value('kBestellpos[1]', 'INT') = dbo.tbestellpos.kBestellpos
						JOIN dbo.tbestellung ON dbo.tbestellpos.tBestellung_kBestellung = dbo.tbestellung.kBestellung;

			END
			ELSE
			BEGIN

				-- Wir runden auf 4 nachkommastellen
		    	SET @nAnzahl = ROUND(@nAnzahl,4);

				DECLARE @nBestandAenderung INT;
				DECLARE @nEckdatenAenderung INT;
				DECLARE @nArtikelAenderung INT;
				SELECT @nBestandAenderung = CASE WHEN dbo.tbestellpos.tBestellung_kBestellung <> @kBestellung 
													OR dbo.tbestellpos.nAnzahl <> @nAnzahl
												THEN 1
												ELSE 0
											END,
						@nEckdatenAenderung = CASE WHEN (dbo.tbestellpos.fVkPreis <> @fVkPreis) 
													OR (dbo.tbestellpos.fMwSt <> @fMwSt)
													OR (dbo.tbestellpos.fRabatt <> @fRabatt)
												THEN 1
												ELSE 0
											END,
						@nArtikelAenderung = CASE WHEN dbo.tbestellpos.tArtikel_kArtikel <> @kArtikel
												THEN 1
												ELSE 0
											END
					FROM dbo.tbestellpos 
					WHERE dbo.tbestellpos.kBestellPos = @kBestellpos;
				IF(@cEinheit IS NULL)
				BEGIN
					IF(EXISTS(SELECT * FROM dbo.tbestellpos WHERE dbo.tbestellpos.kBestellPos = @kBestellpos))
					BEGIN
						SELECT @cEinheit = cEinheit FROM dbo.tbestellpos WHERE dbo.tbestellpos.kBestellpos = @kBestellpos
					END
					ELSE
					BEGIN
						SELECT dbo.tEinheitSprache.cName
							FROM dbo.tBestellung
							JOIN dbo.tArtikel ON dbo.tArtikel.kArtikel = @kArtikel
							JOIN dbo.tEinheitSprache ON dbo.tArtikel.kVerkaufsEinheit = dbo.tEinheitSprache.kEinheit
								AND dbo.tEinheitSprache.kSprache = dbo.tBestellung.kSprache
							WHERE	dbo.tBestellung.kBestellung = @kBestellung
					END
				END
				INSERT INTO #Bestellpos(kBestellpos, kArtikel, kBestellung, fVKPreis, fMwSt, nAnzahl, fRabatt, cString, fVKNetto, cArtNr,
										nType, cHinweis, nHatUpload, cUnique, kKonfigitem, nDropshipping, fEKNetto, cOrderItemId, cItemID,
										cTransactionID, kAmazonBestellungPos, nSort, kBestellStueckliste, cStringStandard, nBestandAenderung, nEckdatenAenderung, nArtikelAenderung, cEinheit)
					VALUES (@kBestellpos, @kArtikel, @kBestellung, @fVKPreis, @fMwSt, @nAnzahl, @fRabatt, @cString, @fVKNetto, @cArtNr, 
							@nType, @cHinweis, @nHatUpload, @cUnique, @kKonfigitem, @nDropshipping, @fEkNetto, @cOrderItemId, @cItemID,
							@cTransactionID, @kAmazonBestellungPos, @nSort, @kBestellStueckliste, @cStringStandard, @nBestandAenderung, @nEckdatenAenderung, @nArtikelAenderung, @cEinheit);
			END
			IF(EXISTS(SELECT * 
						FROM dbo.tBestellung
						JOIN #Bestellpos ON #Bestellpos.kBestellung = tBestellung.kBestellung
						WHERE tBestellung.nIstExterneRechnung = 1))
			BEGIN
				RAISERROR('Diese Bestellung darf nicht geändert werden.', 18,10);
				ROLLBACK;
				RETURN;
			END

			DECLARE @typeArtikel AS TYPE_spUpdateLagerbestand;

			INSERT INTO @typeArtikel (kArtikel)
				SELECT kArtikel
					FROM #Bestellpos
					WHERE #Bestellpos.nArtikelAenderung = 1
				UNION ALL
				SELECT dbo.tbestellpos.tArtikel_kArtikel AS kArtikel
					FROM #Bestellpos
					JOIN dbo.tbestellpos ON #Bestellpos.kBestellpos = dbo.tbestellpos.kBestellPos
					WHERE #Bestellpos.nArtikelAenderung = 1
			UPDATE dbo.tbestellpos
				SET tArtikel_kArtikel = #Bestellpos.kArtikel,
					tBestellung_kBestellung = #Bestellpos.kBestellung,
					fVKPreis = #Bestellpos.fVKPreis,
					fMwSt = #Bestellpos.fMwSt,
					nAnzahl = #Bestellpos.nAnzahl,
					fRabatt = #Bestellpos.fRabatt,
					cString = #Bestellpos.cString,
					fVKNetto = #Bestellpos.fVKNetto,
					cArtNr = #Bestellpos.cArtNr,
					nType = #Bestellpos.nType,
					cHinweis = #Bestellpos.cHinweis,
					nHatUpload = #Bestellpos.nHatUpload,
					cUnique = #Bestellpos.cUnique,
					kKonfigitem = #Bestellpos.kKonfigitem,
					nDropshipping = #Bestellpos.nDropshipping,
					fEKNetto = CASE WHEN #Bestellpos.kBestellStueckliste > 0 AND #Bestellpos.kBestellStueckliste <> #Bestellpos.kBestellpos THEN 0.0 ELSE #Bestellpos.fEKNetto END,					
					cOrderItemId = #Bestellpos.cOrderItemId,
					cItemID = #Bestellpos.cItemID,
					cTransactionID = #Bestellpos.cTransactionID,
					kAmazonBestellungPos = #Bestellpos.kAmazonBestellungPos,
					nSort = #Bestellpos.nSort,
					kBestellStueckliste = #Bestellpos.kBestellStueckliste,
					cStringStandard = #Bestellpos.cStringStandard,
					cEinheit = #Bestellpos.cEinheit
					FROM dbo.tbestellpos 
					JOIN #Bestellpos ON dbo.tbestellpos.kBestellPos = #Bestellpos.kBestellpos;
										
			IF(EXISTS(SELECT *
						FROM #Bestellpos
						WHERE #Bestellpos.nBestandAenderung =  1
						OR #Bestellpos.nArtikelAenderung = 1))
			BEGIN
				-- nKomplettausgeliefert ändern wenn sich die Anzahl erhöht
				DECLARE @xBestellung AS XML;
				SET @xBestellung = (
					SELECT dbo.tbestellung.kBestellung AS kBestellung,
							0 AS nKomplettAusgeliefert
						FROM dbo.tbestellung 
						JOIN #Bestellpos ON #Bestellpos.kBestellung = dbo.tbestellung.kBestellung
						WHERE (#Bestellpos.nBestandAenderung =  1) AND dbo.tbestellung.nKomplettAusgeliefert = 1
						FOR XML PATH('BestellungKomplettAusgeliefert'), TYPE
					);
				EXEC Auftrag.spBestellungKomplettAusgeliefert @xBestellungStorno = @xBestellung, 
				    @kBestellung = NULL;
				IF(EXISTS(SELECT * FROM #Bestellpos WHERE nArtikelAenderung = 1))
				BEGIN
					DELETE FROM dbo.tReserviert
						FROM dbo.tReserviert
						JOIN #Bestellpos ON #Bestellpos.kBestellpos = dbo.tReserviert.kKey
							AND dbo.tReserviert.kPlattform = 1
						WHERE #Bestellpos.nArtikelAenderung = 1;

					EXEC dbo.spUpdateLagerbestand @typeArtikel;

				END
				DECLARE @xPositionen AS XML;
				SET @xPositionen = (
					SELECT #Bestellpos.kBestellpos AS kKey, 1 AS nPlattform
						FROM #Bestellpos 
						WHERE #Bestellpos.nBestandAenderung =  1 
							OR #Bestellpos.nArtikelAenderung = 1
				   FOR XML PATH('Keys'), TYPE
				);
				IF(@xPositionen IS NOT NULL AND @nEckDatenNichtAktualisieren = 0)
				BEGIN
					EXEC dbo.spReservierungAktualisieren @xPositionen;
				END
			END
			IF(EXISTS(SELECT *
						FROM #Bestellpos
						WHERE #Bestellpos.nEckdatenAenderung =  1 OR #Bestellpos.nBestandAenderung = 1)) 
			BEGIN
				DECLARE @xBestellungen AS XML;
				SET @xBestellungen = (
					SELECT #Bestellpos.kBestellung
						FROM #Bestellpos 
						WHERE #Bestellpos.nBestandAenderung = 1
							OR #Bestellpos.nEckdatenAenderung = 1
						FOR XML PATH('Bestellung'), TYPE
					);
				IF(@xBestellungen IS NOT NULL AND @nEckDatenNichtAktualisieren = 0)
				BEGIN
					EXEC dbo.spBestellungEckdatenAktualisieren @xBestellungen;
				END
			END
			SET @retry = -1;
			SET CONTEXT_INFO 0x0;
		COMMIT
	END TRY
	BEGIN CATCH
	IF(ERROR_NUMBER() = 1205)
			BEGIN
				SET @retry = @retry - 1;
				ROLLBACK;
				IF(@retry = 0)
				BEGIN
					SELECT @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
					RAISERROR (	@ErrorMessage, 
								@ErrorSeverity,
								@ErrorState
					);
					SET CONTEXT_INFO 0x0;
					RETURN;
				END
				WAITFOR DELAY '00:00:00:5';
			END
			ELSE 
			BEGIN
				SET @retry = -1;
				SELECT @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
				ROLLBACK;
				RAISERROR (	@ErrorMessage, 
							@ErrorSeverity,
							@ErrorState
				);
				SET CONTEXT_INFO 0x0;
				RETURN;
			END
	END CATCH
	SET CONTEXT_INFO 0x0;
END
go

