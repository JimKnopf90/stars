CREATE TRIGGER [dbo].[tgr_tPicklistePos_INSERT]     
--  
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP/FB
-- 
ON [dbo].[tPicklistePos]     
AFTER INSERT  
AS 
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF; 
BEGIN 
	IF(EXISTS(SELECT * FROM INSERTED WHERE INSERTED.kWarenLagerEingang > 0)) 	  
	BEGIN
		SET CONTEXT_INFO 0x5093;
		UPDATE dbo.tWarenLagerEingang WITH(ROWLOCK)  
			SET fAnzahlReserviertPickpos =  
				(
					SELECT SUM(ISNULL(dbo.tPicklistePos.fAnzahl,0))   
					FROM dbo.tPicklistePos WITH(NOLOCK)
					WHERE ISNULL(dbo.tPicklistePos.nStatus, 0) < 40  
					AND	dbo.tPicklistePos.kWarenLagerEingang = dbo.tWarenLagerEingang.kWarenLagerEingang
				)   
		FROM dbo.tWarenLagerEingang WITH(ROWLOCK)
		JOIN INSERTED ON dbo.tWarenLagerEingang.kWarenLagerEingang = INSERTED.kWarenLagerEingang;
		SET CONTEXT_INFO 0x000;
	END
	
END
go

