--- 
--- spGetNextKundenNr
---

CREATE PROC [dbo].[spGetNextKundenNr] 
AS 
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN TRANSACTION 	
    DECLARE @err INT 	
    DECLARE @iKundenNr INT
    DECLARE @cKundenNr VARCHAR(30) 	
    DECLARE @Heute smalldatetime 	
    SET @Heute = GetDate()     	
    DECLARE @PRE VARCHAR(10)     	
    DECLARE @POST VARCHAR(10) 	
    SET @err = 0 	
    DECLARE @res INT 	
    EXEC @res = sp_getapplock @Resource = 'tLfdnrKunde',@LockMode ='Exclusive', @LockOwner ='Transaction', @LockTimeout = 500, @DbPrincipal = 'public' 	
	   if @res NOT IN (0, 1) 	
	   BEGIN 		
		  SET @iKundenNr = ''         
		  SET @err = 1 	
	   END  	
	   ELSE 	
	   BEGIN 		
		  SET @iKundenNr = (SELECT nNummer FROM tLfdnrKunde WITH(NOLOCK)) 		
		  UPDATE tLfdnrKunde WITH(ROWLOCK) SET nNummer=nNummer+1 		
		  EXEC sp_releaseapplock @Resource = 'tLfdnrKunde',@DbPrincipal ='public', @LockOwner = 'Transaction' 
	   END     IF (@err = 0)     
	   BEGIN       
		  SET @PRE = ISNULL((SELECT sKPre FROM tAnfangsnr WITH(NOLOCK)),'');       
		  SET @POST = ISNULL((SELECT sKPost FROM tAnfangsnr WITH(NOLOCK)),'');       
		  SET @cKundenNr = (SELECT CONVERT(VARCHAR(30),@iKundenNr) )       
		  SET @cKundenNr = (SELECT (@PRE + @cKundenNr + @POST));       
		  SET @cKundenNr = (SELECT REPLACE(@cKundenNr,'<K>',Datepart(Week, @Heute)));       
		  SET @cKundenNr = (SELECT REPLACE(@cKundenNr,'<J>',Datepart(Year, @Heute)));       
		  SET @cKundenNr = (SELECT REPLACE(@cKundenNr,'<M>',REPLACE(STR( Datepart(Month, @Heute),2),' ',0) ));       
		  SET @cKundenNr = (SELECT REPLACE(@cKundenNr,'<T>',REPLACE(STR( Datepart(Day, @Heute),2),' ',0) ));     
		  END   
	   SELECT @cKundenNr 
COMMIT
go

