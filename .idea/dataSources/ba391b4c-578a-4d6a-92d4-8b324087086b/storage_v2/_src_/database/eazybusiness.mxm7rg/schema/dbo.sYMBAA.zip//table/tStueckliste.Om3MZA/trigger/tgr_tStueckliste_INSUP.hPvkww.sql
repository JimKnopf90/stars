CREATE TRIGGER [dbo].[tgr_tStueckliste_INSUP]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP
--    	
ON [dbo].[tStueckliste]
AFTER INSERT, UPDATE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
	DECLARE @Komplett AS INT;

	SET @Komplett = 1;

	--Überprüfen ob Trigger gefüllt ist
	IF((SELECT COUNT(1) FROM INSERTED FULL JOIN DELETED ON INSERTED.kStueckliste = DELETED.kStueckliste) = 0)
	BEGIN
		RETURN;
	END;

	DECLARE @typeSlArtikel AS TYPE_spAktualisiereStueckliste;
	DECLARE @typeArtikel AS TYPE_spUpdateLagerbestand;

	INSERT INTO @typeArtikel (kArtikel)
	SELECT dbo.tArtikel.kArtikel
	FROM INSERTED 
	JOIN dbo.tArtikel ON INSERTED.kStueckliste = dbo.tArtikel.kStueckliste;


	INSERT INTO @typeSlArtikel (kArtikel)
	SELECT kArtikel
	FROM @typeArtikel 
	
	EXEC dbo.spUpdateLagerbestand @typeArtikel;
	IF CONTEXT_INFO() <> 0x5009 OR CONTEXT_INFO() IS NULL
	BEGIN
	   EXEC dbo.spAktualisiereStueckliste @typeSlArtikel;
     END;
	

	--
	-- Stückliste im Shop aktualisieren
	--
	UPDATE dbo.tArtikelShop
		SET dbo.tArtikelShop.nAktion = dbo.tArtikelShop.nAktion | @Komplett,
			dbo.tArtikelShop.cInet = 'Y',
			dbo.tArtikelShop.nInBearbeitung = 0
	FROM dbo.tArtikelShop
	JOIN dbo.tArtikel ON dbo.tArtikel.kArtikel = dbo.tArtikelShop.kArtikel
	JOIN DELETED ON dbo.tartikel.kStueckliste = DELETED.kStueckliste
	WHERE dbo.tArtikelShop.cInet = 'N'
	   OR dbo.tArtikelShop.nAktion & @Komplett = 0
	   OR dbo.tArtikelShop.nInBearbeitung = 1;
END;
go

