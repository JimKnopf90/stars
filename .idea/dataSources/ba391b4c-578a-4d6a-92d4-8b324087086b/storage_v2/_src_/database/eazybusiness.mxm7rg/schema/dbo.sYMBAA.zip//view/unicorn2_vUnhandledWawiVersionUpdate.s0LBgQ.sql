
    CREATE VIEW unicorn2_vUnhandledWawiVersionUpdate 
    AS
        SELECT 
			cVersion, dInstallationDate
		FROM unicorn2_tWawiVersionHistory
		WHERE unicorn2_tWawiVersionHistory.bHandled IS NULL OR unicorn2_tWawiVersionHistory.bHandled = 0;
    go

