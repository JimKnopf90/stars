CREATE TRIGGER [dbo].[tgr_tKundenGruppeSprache_Connector]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP
--
ON [dbo].[tKundenGruppeSprache]
AFTER UPDATE, INSERT
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN

	--Überprüfen ob Trigger gefüllt aufgerufen wird
	IF((SELECT COUNT(1) 
		FROM INSERTED
		JOIN dbo.tShopKundenGruppe ON dbo.tShopKundenGruppe.kKundenGruppe = INSERTED.kKundenGruppe) = 0)
	BEGIN 
		RETURN;
	END;

	INSERT INTO dbo.tGlobalsQueue (kShop, nType, cName, kKey)
	SELECT dbo.tShopKundenGruppe.kWebShop, 1, 'tKundengruppe', 0
	FROM dbo.tShopKundenGruppe
	JOIN INSERTED ON dbo.tShopKundenGruppe.kKundenGruppe = INSERTED.kKundenGruppe
	GROUP BY dbo.tShopKundenGruppe.kWebShop;

END
go

