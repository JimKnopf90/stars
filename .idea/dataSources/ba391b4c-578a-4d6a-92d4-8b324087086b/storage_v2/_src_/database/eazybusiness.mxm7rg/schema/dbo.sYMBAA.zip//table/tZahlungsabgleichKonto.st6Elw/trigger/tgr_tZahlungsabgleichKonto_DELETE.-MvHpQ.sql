CREATE TRIGGER [dbo].[tgr_tZahlungsabgleichKonto_DELETE]  
ON [dbo].[tZahlungsabgleichKonto]  
AFTER DELETE
AS  
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
    IF((SELECT COUNT(1) FROM DELETED) = 0) 
    BEGIN
	   RETURN;
    END;

    DELETE dbo.tZahlungsabgleichKontoLog
    FROM dbo.tZahlungsabgleichKontoLog
    JOIN DELETED ON DELETED.kZahlungsabgleichKonto = dbo.tZahlungsabgleichKontoLog.kZahlungsabgleichKonto
    WHERE dbo.tZahlungsabgleichKontoLog.kZahlungsabgleichKonto = DELETED.kZahlungsabgleichKonto;
END
go

