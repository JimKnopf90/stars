CREATE TRIGGER [dbo].[tgr_pf_amazon_bestellung_INSUPDEL]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--
ON [dbo].[pf_amazon_bestellung]
AFTER INSERT, UPDATE, DELETE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN

	--
	--Überprüfen ob Trigger mit Inhalt aufgerufen wird
	--
		IF((SELECT COUNT(1) FROM INSERTED FULL JOIN DELETED ON INSERTED.kAmazonBestellung = DELETED.kAmazonBEstellung) = 0)
		BEGIN
			RETURN
		END

	--
	-- Reservierungen aktualisieren
	--
	IF(UPDATE(cOrderStatus) OR UPDATE(nStatus) OR UPDATE(nDeleted))
	BEGIN
		DECLARE @typeArtikel AS TYPE_spUpdateLagerbestand;

		INSERT INTO @typeArtikel (kArtikel)
		SELECT DISTINCT dbo.tReserviert.kArtikel 
		FROM dbo.pf_amazon_bestellungpos
		JOIN dbo.tReserviert ON dbo.tReserviert.kKey = dbo.pf_amazon_bestellungpos.kAmazonBestellungPos
							AND dbo.tReserviert.kPlattform = 3
		JOIN INSERTED ON dbo.pf_amazon_bestellungpos.kAmazonBestellung = INSERTED.kAmazonBestellung		
		WHERE kKey = dbo.pf_amazon_bestellungpos.kAmazonBestellungPos AND INSERTED.nDeleted > 0;

		DELETE dbo.tReserviert 
		FROM dbo.pf_amazon_bestellungpos
		JOIN INSERTED ON dbo.pf_amazon_bestellungpos.kAmazonBestellung = INSERTED.kAmazonBestellung		
		WHERE kPlattform = 3 AND kKey = dbo.pf_amazon_bestellungpos.kAmazonBestellungPos AND INSERTED.nDeleted > 0;
		
		EXEC dbo.spUpdateLagerbestand @typeArtikel;		
	END
END
go

