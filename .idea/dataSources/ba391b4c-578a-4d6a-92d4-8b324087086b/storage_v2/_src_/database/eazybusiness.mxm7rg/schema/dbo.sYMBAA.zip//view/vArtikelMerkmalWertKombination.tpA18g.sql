CREATE VIEW [dbo].[vArtikelMerkmalWertKombination]

AS

	SELECT
		ArtikelMerkmal.kArtikel
	,	Merkmal.kMerkmal
	,	Merkmal.nVerwendungszweck
	,	Wert.kMerkmalWert
	,	MerkmalSprache.cName
	,	MerkmalSprache.kSprache
	,	Sprache.cNameDeu AS cSprache
	,	WertSprache.cWert
	,	WertSprache.cSeo
	,	WertSprache.cMetaTitle
	,	WertSprache.cMetaKeywords
	,	WertSprache.cMetaDescription
	,	WertSprache.cBeschreibung

	,	MerkmalBildDaten.bBild AS bMerkmalBild
	,	MerkmalBildDaten.bVorschauBild AS bMerkmalVorschauBild
	,	WertBildDaten.bBild AS bWertBild
	,	WertBildDaten.bVorschauBild AS bWertVorschauBild
	,	CASE 	WHEN Sprache.nStandard = 1
		AND isnull(MerkmalBild.kPlattform,1) = 1
		AND isnull(MerkmalBild.kShop,0) = 0
		AND isnull(MerkmalBild.nInet,0) = 0 THEN 1
											ELSE 0 END AS nStandard
	,	isnull(MerkmalBild.kPlattform , 0) AS kPlattform
	,	ROW_NUMBER() OVER ( ORDER BY

	('1' + REPLICATE( '0' , 4 - LEN( CAST( Merkmal.nSort AS VARCHAR( 10 )))) + CAST( Merkmal.nSort AS VARCHAR( 10 ))) +
	('1' + REPLICATE( '0' , 4 - LEN( CAST( Wert.nSort AS VARCHAR( 10 )))) + CAST( Wert.nSort AS VARCHAR( 10 ))) +
	WertSprache.cWert
	) AS nSort
	FROM
					dbo.tArtikelMerkmal				 AS ArtikelMerkmal	
		JOIN		dbo.tMerkmal					 AS Merkmal			 	ON Merkmal.kMerkmal = ArtikelMerkmal.kMerkmal
		JOIN		dbo.tMerkmalSprache				 AS MerkmalSprache	 	ON MerkmalSprache.kMerkmal = ArtikelMerkmal.kMerkmal
		JOIN		dbo.tMerkmalWert				 AS Wert			 	ON Wert.kMerkmal = Merkmal.kMerkmal
			AND Wert.kMerkmalWert = ArtikelMerkmal.kMerkmalWert
		JOIN		dbo.tMerkmalWertSprache			 AS WertSprache		 	ON WertSprache.kMerkmalWert = Wert.kMerkmalWert
			AND WertSprache.kSprache = MerkmalSprache.kSprache
		LEFT JOIN	dbo.tMerkmalBildPlattform		 AS MerkmalBild		 	ON MerkmalBild.kMerkmal = Merkmal.kMerkmal AND MerkmalBild.kShop = 0
		LEFT JOIN	dbo.tMerkmalwertBildPlattform	 AS WertBild		 	ON WertBild.kMerkmalwert = Wert.kMerkmalWert  AND WertBild.kShop = 0
			AND (WertBild.kPlattform = MerkmalBild.kPlattform OR MerkmalBild.kPlattform IS NULL)
			AND (WertBild.kShop = MerkmalBild.kShop OR MerkmalBild.kShop IS NULL)
			AND (WertBild.nInet = MerkmalBild.nInet OR MerkmalBild.nInet IS NULL)
		LEFT JOIN	dbo.tBild						 AS MerkmalBildDaten 	ON MerkmalBildDaten.kBild = MerkmalBild.kBild
		LEFT JOIN	dbo.tBild						 AS WertBildDaten	 	ON WertBildDaten.kBild = WertBild.kBild
		JOIN		dbo.tSpracheUsed				 AS Sprache			 	ON Sprache.kSprache = MerkmalSprache.kSprache;
go

