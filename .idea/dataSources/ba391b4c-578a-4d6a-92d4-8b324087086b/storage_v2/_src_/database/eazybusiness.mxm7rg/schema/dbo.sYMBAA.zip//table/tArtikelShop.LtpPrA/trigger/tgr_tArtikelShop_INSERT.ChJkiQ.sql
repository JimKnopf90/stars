CREATE TRIGGER [dbo].[tgr_tArtikelShop_INSERT]
ON [dbo].[tArtikelShop]
AFTER INSERT
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN

	INSERT INTO dbo.tMerkmalBildPlattform (kMerkmal, kBild, kPlattform, kShop, nInet)
	SELECT dbo.tArtikelMerkmal.kMerkmal, StandardBild.kBild, 2, INSERTED.kShop, 1
	FROM INSERTED
	JOIN dbo.tArtikelMerkmal ON INSERTED.kArtikel = dbo.tArtikelMerkmal.kArtikel
	JOIN dbo.tMerkmalBildPlattform AS StandardBild ON StandardBild.kMerkmal = dbo.tArtikelMerkmal.kMerkmal
												AND (StandardBild.kShop IS NULL OR StandardBild.kShop = 0)
	LEFT JOIN dbo.tMerkmalBildPlattform ON dbo.tArtikelMerkmal.kMerkmal = dbo.tMerkmalBildPlattform.kMerkmal
									AND INSERTED.kShop = dbo.tMerkmalBildPlattform.kShop
	WHERE dbo.tMerkmalBildPlattform.kShop IS NULL
	GROUP BY dbo.tArtikelMerkmal.kMerkmal, INSERTED.kShop, dbo.tMerkmalBildPlattform.kBild, dbo.tMerkmalBildPlattform.kShop, StandardBild.kBild;

	INSERT INTO dbo.tMerkmalwertBildPlattform (kMerkmalwert, kBild, kPlattform, kShop, nInet)
	SELECT dbo.tArtikelMerkmal.kMerkmalWert, StandardBild.kBild, 2, INSERTED.kShop, 1
	FROM INSERTED
	JOIN dbo.tArtikelMerkmal ON INSERTED.kArtikel = dbo.tArtikelMerkmal.kArtikel
	JOIN dbo.tMerkmalwertBildPlattform AS StandardBild ON StandardBild.kMerkmalwert = dbo.tArtikelMerkmal.kMerkmalWert
													AND (StandardBild.kShop IS NULL OR StandardBild.kShop = 0)
	LEFT JOIN dbo.tMerkmalwertBildPlattform ON dbo.tArtikelMerkmal.kMerkmalWert = dbo.tMerkmalwertBildPlattform.kMerkmalwert
									AND INSERTED.kShop = dbo.tMerkmalwertBildPlattform.kShop
	WHERE dbo.tMerkmalwertBildPlattform.kShop IS NULL
	GROUP BY dbo.tArtikelMerkmal.kMerkmalWert, INSERTED.kShop, dbo.tMerkmalwertBildPlattform.kBild, dbo.tMerkmalwertBildPlattform.kShop, StandardBild.kBild;

    ---
    --- tEigenschaftWertPict fuellen
    ---
    DECLARE @tpk int;
    SET @tpk = (SELECT tpk.nummer FROM tpk WHERE tpk.cName = 'tEigenschaftWertPict');

    INSERT INTO tEigenschaftWertPict (kEigenschaftWertPict, kEigenschaftWert, kBild, nInet, kPlattform, kShop)
    SELECT @tpk + ROW_NUMBER() OVER (ORDER BY INSERTED.kArtikel) AS kEigenschaftWertPict , dbo.teigenschaftwert.kEigenschaftWert, StandardBild.kBild, 1 AS nInet, 2 AS kPlattform, INSERTED.kShop
    FROM INSERTED
    JOIN dbo.teigenschaft ON INSERTED.kArtikel = dbo.teigenschaft.kArtikel
    JOIN dbo.teigenschaftwert ON dbo.teigenschaftwert.kEigenschaft = dbo.teigenschaft.kEigenschaft
    JOIN dbo.tEigenschaftWertPict AS StandardBild ON StandardBild.kEigenschaftWert = dbo.teigenschaftwert.kEigenschaftWert
		AND ISNULL(StandardBild.kPlattform, 0) IN (1, 0);

    UPDATE tpk
    SET
        nummer = (ISNULL((SELECT MAX(ISNULL(kEigenschaftWertPict,0)) FROM tEigenschaftWertPict), 0) + 1),
        dChanged = (SELECT CONVERT(VARCHAR(10),GETDATE(),121))
    WHERE cName = 'tEigenschaftWertPict';
END
go

