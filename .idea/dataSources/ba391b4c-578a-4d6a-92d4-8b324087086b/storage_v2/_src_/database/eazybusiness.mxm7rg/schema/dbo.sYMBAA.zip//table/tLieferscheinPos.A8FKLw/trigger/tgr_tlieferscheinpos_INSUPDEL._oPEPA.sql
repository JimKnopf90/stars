CREATE TRIGGER [dbo].[tgr_tlieferscheinpos_INSUPDEL]
ON [dbo].[tLieferscheinPos]
AFTER INSERT, UPDATE, DELETE
AS 
BEGIN
	IF(CONTEXT_INFO() IN (0x5115, 0x5116))
	BEGIN
		RETURN;
	END
	IF(UPDATE(fAnzahl) OR UPDATE(kBestellpos))
	BEGIN
		ROLLBACK;
		RAISERROR(N'Die Tabelle dbo.tlieferscheinpos kann nur über die SPs spLieferscheinPosErstellen und spLieferscheinPosLoeschen bearbeitet werden.', 15,1);
	END
END
go

