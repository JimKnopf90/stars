
    CREATE PROCEDURE unicorn2_spSetSpecificArticleShopInactive @kShop INT, @kArtikel INT, @kBenutzer INT
    AS
        DECLARE @kShopLocal INT
			SET @kShopLocal = @kShop
		DECLARE @kArtikelLocal INT
			SET @kArtikelLocal = @kArtikel
        DECLARE @kBenutzerLocal INT
            SET @kBenutzerLocal = @kBenutzer

		SET DEADLOCK_PRIORITY LOW

        BEGIN TRY
		    ALTER TABLE eazybusiness.dbo.tArtikelShop DISABLE TRIGGER tgr_tArtikelShop_Connector_DELETE
		    DELETE FROM eazybusiness.dbo.tArtikelShop WHERE kShop = @kShopLocal AND kArtikel = @kArtikelLocal
		    ALTER TABLE eazybusiness.dbo.tArtikelShop ENABLE TRIGGER tgr_tArtikelShop_Connector_DELETE

		    DELETE FROM eazybusiness.dbo.tQueue WHERE kShop = @kShopLocal AND cName = 'tArtikel' AND kWert = @kArtikelLocal

		    INSERT INTO
			    eazybusiness.dbo.tQueue
		    WITH (ROWLOCK)
			    (kShop, kPlattform, cName, kWert, nAction, kOption1, kOption2, nInBearbeitung)
		    VALUES
			    (@kShopLocal, 140, 'tArtikel', @kArtikelLocal, 2, null, null, 0)

            INSERT INTO eazybusiness.dbo.unicorn2_tShopDeletedArtikel WITH (ROWLOCK) (kWawiId, kShopId, dDeletionDate) VALUES (@kArtikelLocal, @kShopLocal, GETDATE())

        END TRY
        BEGIN CATCH
        END CATCH
		INSERT INTO
			eazybusiness.dbo.tLog
			(dDatum, kBenutzer, cLog,  nTyp,  nVorgang )
		VALUES
			(GETDATE(),  @kBenutzerLocal,  'unicorn 2: Artikel (kArtikel: ' + CAST(@kArtikelLocal AS VARCHAR(10)) + ') aus Shop (kShop: ' + CAST(@kShopLocal AS VARCHAR(10)) + ') entfernt', 1,  2)
    go

