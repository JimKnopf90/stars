--- 
--- spBereinigenVorlagenAngebote
---

CREATE PROCEDURE [dbo].[spBereinigenVorlagenAngebote]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: GJ
--
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
    DELETE FROM ebay_alienitem
    WHERE Status = 88;

    DELETE FROM ebay_item
    WHERE Status = 88;

    DELETE FROM ebay_item
    WHERE kArtikel NOT IN( SELECT kArtikel
                           FROM tArtikel )
	  AND kArtikel > 0;

    DELETE FROM ebay_attributSetArray
    WHERE kItem NOT IN( SELECT kItem
                        FROM ebay_item );

    DELETE FROM ebay_attributSetArray
    WHERE kItem NOT IN( SELECT kItem
                        FROM ebay_item );
   

    DELETE FROM ebay_data_htmltemplatetagcontent
    WHERE kEbayItem NOT IN( SELECT kItem
                            FROM ebay_item );

    DELETE FROM ebay_InternationalShippingServiceOption
    WHERE kItem NOT IN( SELECT kItem
                        FROM ebay_item );

    DELETE FROM ebay_item2kombi
    WHERE kItem NOT IN( SELECT kItem
                        FROM ebay_item );

    DELETE FROM ebay_item2xsell
    WHERE kEbayItem NOT IN( SELECT kItem
                            FROM ebay_item );

    DELETE FROM ebay_planung
    WHERE kItem NOT IN( SELECT kItem
                        FROM ebay_item );

    DELETE FROM ebay_ShippingServiceOptions
    WHERE kItem NOT IN( SELECT kItem
                        FROM ebay_item );

    DELETE FROM ebay_ShippingServiceOptions
    WHERE kItem NOT IN( SELECT kItem
                        FROM ebay_item );
END;
go

