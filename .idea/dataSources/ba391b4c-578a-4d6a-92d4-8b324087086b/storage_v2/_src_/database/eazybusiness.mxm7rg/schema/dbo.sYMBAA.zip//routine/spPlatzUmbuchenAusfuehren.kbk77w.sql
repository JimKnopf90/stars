--- 
--- spPlatzUmbuchenAusfuehren
---

CREATE PROCEDURE [dbo].[spPlatzUmbuchenAusfuehren] 
	@kWarenlagerEingang INT, 
	@fAnzahl DECIMAL(28,14), 
	@kWarenlagerPlatzNeu INT,
	@kLHM INT,
	@kBuchungsart INT, -- Falls null wird die des quell WEs genommen
	@callerIsPickliste BIT, -- 1: Pickpos betroffen, 0: keine Pickpos betroffen
	@kBenutzer INT,
	@cKommentar VARCHAR(255),
	@kWarenlagerEingangNeu INT OUTPUT
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
	SET CONTEXT_INFO 0x5092;
	DECLARE @kWarenlagerPlatzAlt INT;
	DECLARE @kSessionID INT;
	DECLARE @kLHMAlt INT;
	DECLARE @kArtikel INT;
	SELECT @kWarenlagerPlatzAlt = dbo.tWarenLagerEingang.kWarenLagerPlatz,
			@kSessionID = dbo.tWarenLagerEingang.kSessionID,
			@kLHMAlt = dbo.tWarenLagerEingang.kLHM,
			@kArtikel = dbo.tWarenLagerEingang.kArtikel
		FROM dbo.tWarenLagerEingang 
		WHERE dbo.tWarenLagerEingang.kWarenLagerEingang = @kWarenlagerEingang
	-- Muss Eingang gesplittet werden: 
	IF((SELECT dbo.twarenlagereingang.fAnzahl 
				FROM dbo.twarenlagereingang
				WHERE dbo.twarenlagereingang.kWarenLagerEingang = @kWarenlagerEingang) <> @fAnzahl
				)
	BEGIN
		INSERT INTO dbo.tWarenLagerEingang
		(
		    kArtikel,
		    kWarenLagerPlatz,
		    kLieferantenBestellungPos,
		    kBenutzer,
		    fAnzahl,
		    fEKEinzel,
		    cLieferscheinNr,
		    cChargenNr,
		    dMHD,
		    dErstellt,
		    dGeliefertAM,
		    cKommentar,
		    kGutschriftPos,
		    kWarenLagerAusgang,
		    kLHM,
		    fAnzahlAktuell,
		    fAnzahlReserviertPickpos,
		    kSessionID,
		    kWarenLagerEingang_Ursprung,
		    kBuchungsart
		)
		SELECT dbo.tWarenLagerEingang.kArtikel,
				@kWarenlagerplatzNeu,
				dbo.tWarenLagerEingang.kLieferantenBestellungPos,
				dbo.tWarenLagerEingang.kBenutzer,
				@fAnzahl,
				dbo.tWarenLagerEingang.fEKEinzel,
				dbo.tWarenLagerEingang.cLieferscheinNr,
				dbo.tWarenLagerEingang.cChargenNr,
				dbo.tWarenLagerEingang.dMHD,
				dbo.tWarenLagerEingang.dErstellt,
				dbo.tWarenLagerEingang.dGeliefertAM,
				dbo.tWarenLagerEingang.cKommentar,
				dbo.tWarenLagerEingang.kGutschriftPos,
				dbo.tWarenLagerEingang.kWarenLagerAusgang,
				@kLHM,
				@fAnzahl,
				CASE WHEN @callerIsPickliste = 1
					THEN @fAnzahl
					ELSE 0.0
				END,
				dbo.tWarenLagerEingang.kSessionID,
				CASE WHEN dbo.tWarenLagerEingang.kWarenLagerEingang_Ursprung IS NULL OR dbo.tWarenLagerEingang.kWarenLagerEingang = 0 
					THEN @kWarenlagerEingang
					ELSE dbo.tWarenLagerEingang.kWarenLagerEingang
				END,
				CASE WHEN @kBuchungsart IS NULL THEN dbo.tWarenLagerEingang.kBuchungsart ELSE @kBuchungsart END
			FROM dbo.tWarenLagerEingang
			WHERE dbo.tWarenLagerEingang.kWarenLagerEingang = @kWarenlagerEingang;
		SELECT @kWarenlagerEingangNeu = SCOPE_IDENTITY();
		UPDATE dbo.tWarenLagerEingang
			SET fAnzahl = fAnzahl - @fAnzahl,
				fAnzahlAktuell = fAnzahlAktuell - @fAnzahl,
				fAnzahlReserviertPickpos = CASE WHEN @callerIsPickliste = 1
												THEN fAnzahlReserviertPickpos - @fAnzahl
												ELSE fAnzahlReserviertPickpos
											END
			WHERE kWarenLagerEingang = @kWarenlagerEingang;
	END
	-- Kein Warenlagereingangssplit notwendig
	ELSE
	BEGIN
		UPDATE dbo.tWarenLagerEingang
			SET kWarenLagerPlatz = @kWarenlagerPlatzNeu,
				kLHM = @kLHM
			WHERE kWarenLagerEingang = @kWarenlagerEingang;	   
		SET @kWarenlagerEingangNeu  = @kWarenlagerEingang;
	END		
	-- Bestand anpassen wenn WarenlagerPlatz nGesperrt = 1
	IF(EXISTS(SELECT * FROM dbo.tWarenlagerplatz WHERE (dbo.tWarenlagerplatz.kWarenLagerPlatz = @kWarenlagerPlatzNeu OR tWarenlagerplatz.kWarenLagerPlatz = @kWarenlagerPlatzAlt)
													AND dbo.tWarenlagerplatz.nGesperrt = 1))
	BEGIN
		DECLARE @typeArtikel AS TYPE_spUpdateLagerbestand;

		INSERT INTO @typeArtikel (kArtikel)
		SELECT @kArtikel;

		EXEC spUpdateLagerbestand @typeArtikel;
	END
	-- Warenlagereinganghistorie schreiben
	INSERT INTO dbo.tWarenLagerEingangHistorie
	(
	    kWarenLagerEingang,
	    kWarenLagerPlatzStart,
	    kWarenLagerPlatzZiel,
	    dZeitstempel,
	    kBenutzer,
	    cKommentar,
	    kBuchungsArt,
	    kSessionID,
	    fAnzahl,
	    kLHMStart,
	    kLHMZiel
	)
	VALUES
	(
		@kWarenlagerEingangNeu,
		@kWarenlagerPlatzAlt,
		@kWarenlagerPLatzNeu,
		GETDATE(),
		@kBenutzer,
		@cKommentar,
		@kBuchungsart, 
		@kSessionID,
		@fAnzahl,
		@kLHMAlt,
		@kLHM
	)
	-- Warenlagerplatzartikel schreiben
	INSERT INTO dbo.tWarenLagerPlatzArtikel(kWarenLagerPlatz, kArtikel)
		SELECT @kWarenlagerPlatzNeu, @kArtikel
			WHERE NOT EXISTS(SELECT * FROM dbo.tWarenLagerPlatzArtikel 
								WHERE dbo.tWarenLagerPlatzArtikel.kArtikel = @kArtikel
									AND dbo.tWarenLagerPlatzArtikel.kWarenLagerPlatz = @kWarenlagerPlatzNeu);
	SET CONTEXT_INFO 0x000;
	RETURN;
END
go

