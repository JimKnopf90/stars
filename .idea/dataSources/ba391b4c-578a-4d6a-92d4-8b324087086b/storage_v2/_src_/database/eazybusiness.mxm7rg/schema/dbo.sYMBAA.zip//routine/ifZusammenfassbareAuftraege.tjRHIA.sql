CREATE FUNCTION [dbo].[ifZusammenfassbareAuftraege]( @kBestellung INT )
-- 
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Author:		GJ
-- Description:	Gibt für eine Bestellung die zu dieser Zusammenfassbaren Bestellungen zurück
-- 
RETURNS @resultTable TABLE( kBestellung BIGINT NOT NULL, 
                            tRechnung_kRechnung BIGINT NULL, 
                            tBenutzer_kBenutzer BIGINT NOT NULL, 
                            tAdresse_kAdresse BIGINT NULL, 
                            tText_kText BIGINT NOT NULL, 
                            tKunde_kKunde BIGINT NOT NULL, 
                            cBestellNr VARCHAR( 40 )NULL, 
                            cType CHAR( 1 )NULL, 
                            cAnmerkung VARCHAR( 4500 )NULL, 
                            dErstellt DATETIME NULL, 
                            nZahlungsziel TINYINT NULL, 
                            tVersandArt_kVersandArt BIGINT NULL, 
                            fVersandBruttoPreis DECIMAL(28,14) NULL, 
                            fRabatt DECIMAL(28,14) NULL, 
                            kInetBestellung BIGINT NULL, 
                            cVersandInfo VARCHAR( 255 )NULL, 
                            dVersandt DATETIME NULL, 
                            cIdentCode VARCHAR( 255 )NULL, 
                            cBeschreibung CHAR( 1 )NULL, 
                            cInet CHAR( 1 )NULL, 
                            dLieferdatum DATETIME NULL, 
                            kBestellHinweis INT NULL, 
                            cErloeskonto VARCHAR( 64 )NULL, 
                            cWaehrung VARCHAR( 20 )NULL, 
                            fFaktor DECIMAL(28,14) NOT NULL, 
                            kShop INT NULL, 
                            kFirma INT NOT NULL, 
                            kLogistik INT NULL, 
                            nPlatform TINYINT NOT NULL, 
                            kSprache INT NOT NULL, 
                            fGutschein DECIMAL(28,14) NULL, 
                            dGedruckt DATETIME NULL, 
                            dMailVersandt DATETIME NULL, 
                            cInetBestellNr VARCHAR( 50 )NULL, 
                            kZahlungsArt INT NULL, 
                            kLieferAdresse BIGINT NULL, 
                            kRechnungsAdresse BIGINT NULL, 
                            nIGL TINYINT NULL, 
                            nUStFrei TINYINT NULL, 
                            cStatus VARCHAR( 255 )NULL, 
                            dVersandMail DATETIME NULL, 
                            dZahlungsMail DATETIME NULL, 
                            cUserName VARCHAR( 255 )NULL, 
                            cVerwendungszweck VARCHAR( 255 )NULL, 
                            fSkonto DECIMAL(28,14) NULL, 
                            kColor INT NULL, 
                            nStorno TINYINT NULL, 
                            cModulID VARCHAR( 255 )NULL, 
                            nZahlungsTyp INT NULL, 
                            nHatUpload INT NULL, 
                            fZusatzGewicht DECIMAL(28,14) NULL, 
                            nKomplettAusgeliefert TINYINT NOT NULL, 
                            dBezahlt DATETIME NULL, 
                            kSplitBestellung BIGINT NULL, 
                            kRueckhalteGrund INT NULL, 
                            cPUIZahlungsdaten VARCHAR( MAX ))
AS
BEGIN
    DECLARE @kKunde AS INT;
    DECLARE @kZahlungsArt AS INT;
    DECLARE @kLieferAdresse AS INT;
    DECLARE @kRechnungsAdresse AS INT;
    DECLARE @kVersandArt AS INT;
    DECLARE @kFirma AS INT;
    DECLARE @cWaehrung AS VARCHAR(20); 

    --
    -- Erstmal die Stammdaten der übergebenen Bestellung holen
    --
    SELECT @kKunde = Bestellung.tKunde_kKunde, 
           @kZahlungsArt = Bestellung.kZahlungsArt, 
           @kLieferAdresse = Bestellung.kLieferAdresse, 
           @kRechnungsAdresse = Bestellung.kRechnungsAdresse, 
           @kVersandArt = Bestellung.tVersandArt_kVersandArt, 
           @kFirma = Bestellung.kFirma,
		 @cWaehrung = Bestellung.cWaehrung
    FROM dbo.tBestellung AS Bestellung
	LEFT JOIN dbo.tRueckhalteGrund AS Rueckhaltegrund ON Rueckhaltegrund.kRueckhalteGrund = Bestellung.kRueckhalteGrund
    WHERE Bestellung.kBestellung = @kBestellung
      AND Bestellung.cType = 'B'
      AND Bestellung.nStorno = 0
      AND Bestellung.tRechnung_kRechnung = 0
      AND Bestellung.cModulID NOT IN 
	 ('za_ebay_rechnungskauf','za_billpay_jtl','za_paypal_pui_jtl','za_billpay_invoice_jtl','za_billpay_direct_debit_jtl','za_billpay_rate_payment_jtl','za_billpay_paylater_jtl')
      AND ISNULL( Rueckhaltegrund.nZusammenfassbar , 1) = 1;
	  
    INSERT INTO @resultTable
    SELECT 
		 Bestellung.kBestellung, 
           Bestellung.tRechnung_kRechnung, 
           Bestellung.tBenutzer_kBenutzer, 
           Bestellung.tAdresse_kAdresse, 
           Bestellung.tText_kText, 
           Bestellung.tKunde_kKunde, 
           Bestellung.cBestellNr, 
           Bestellung.cType, 
           Bestellung.cAnmerkung, 
           Bestellung.dErstellt, 
           Bestellung.nZahlungsziel, 
           Bestellung.tVersandArt_kVersandArt, 
           Bestellung.fVersandBruttoPreis, 
           Bestellung.fRabatt, 
           Bestellung.kInetBestellung, 
           Bestellung.cVersandInfo, 
           Bestellung.dVersandt, 
           Bestellung.cIdentCode, 
           Bestellung.cBeschreibung, 
           Bestellung.cInet, 
           Bestellung.dLieferdatum, 
           Bestellung.kBestellHinweis, 
           Bestellung.cErloeskonto, 
           Bestellung.cWaehrung, 
           Bestellung.fFaktor, 
           Bestellung.kShop, 
           Bestellung.kFirma, 
           Bestellung.kLogistik, 
           Bestellung.nPlatform, 
           Bestellung.kSprache, 
           Bestellung.fGutschein, 
           Bestellung.dGedruckt, 
           Bestellung.dMailVersandt, 
           Bestellung.cInetBestellNr, 
           Bestellung.kZahlungsArt, 
           Bestellung.kLieferAdresse, 
           Bestellung.kRechnungsAdresse, 
           Bestellung.nIGL, 
           Bestellung.nUStFrei, 
           Bestellung.cStatus, 
           Bestellung.dVersandMail, 
           Bestellung.dZahlungsMail, 
           Bestellung.cUserName, 
           Bestellung.cVerwendungszweck, 
           Bestellung.fSkonto, 
           Bestellung.kColor, 
           Bestellung.nStorno, 
           Bestellung.cModulID, 
           Bestellung.nZahlungsTyp, 
           Bestellung.nHatUpload, 
           Bestellung.fZusatzGewicht, 
           Bestellung.nKomplettAusgeliefert, 
           Bestellung.dBezahlt, 
           Bestellung.kSplitBestellung, 
           Bestellung.kRueckhalteGrund, 
           Bestellung.cPUIZahlungsdaten
    FROM
         dbo.tBestellung AS Bestellung
         JOIN dbo.tlieferadresse AS Lieferadresse1 ON Lieferadresse1.kLieferAdresse = @kLieferAdresse
         JOIN dbo.tlieferadresse AS Lieferadresse2 ON Lieferadresse2.kLieferAdresse = Bestellung.kLieferAdresse
         JOIN dbo.trechnungsadresse AS Rechnungsadresse1 ON Rechnungsadresse1.kRechnungsAdresse = @kRechnungsAdresse
         JOIN dbo.trechnungsadresse AS Rechnungsadresse2 ON Rechnungsadresse2.kRechnungsAdresse = Bestellung.kRechnungsAdresse
         LEFT JOIN dbo.tPicklistePos AS PicklistePos ON PicklistePos.kBestellung = Bestellung.kBestellung
                                                     OR PicklistePos.kBestellung = @kBestellung
         LEFT JOIN dbo.tRMRetoure ON dbo.tRMRetoure.kBestellung = Bestellung.kBestellung
		 LEFT JOIN dbo.tRueckhalteGrund AS Rueckhaltegrund ON Rueckhaltegrund.kRueckhalteGrund = Bestellung.kRueckhalteGrund
    WHERE Bestellung.tKunde_kKunde = @kKunde 
      --AND Bestellung.tVersandArt_kVersandArt = @kVersandArt 
      AND Bestellung.kFirma = @kFirma 
      AND Bestellung.kBestellung <> @kBestellung
	  AND Bestellung.cWaehrung = @cWaehrung
      AND Bestellung.cType = 'B'
      AND Bestellung.nStorno = 0 
      AND Bestellung.tRechnung_kRechnung = 0
	  AND dbo.tRMRetoure.kBestellung IS NULL
      AND NOT ISNULL(Bestellung.cModulID, '') in ('za_ebay_rechnungskauf', 'za_billpay_jtl', 'za_paypal_pui_jtl', 'za_billpay_invoice_jtl', 'za_billpay_direct_debit_jtl', 'za_billpay_rate_payment_jtl', 'za_billpay_paylater_jtl')	
      AND ISNULL( Rueckhaltegrund.nZusammenfassbar , 1) = 1
      --AND ISNULL(Lieferadresse1.cFirma, '') = ISNULL(Lieferadresse2.cFirma, '')
      --AND ISNULL(Lieferadresse1.cVorname, '') = ISNULL(Lieferadresse2.cVorname, '')
      --AND ISNULL(Lieferadresse1.cName, '') = ISNULL(Lieferadresse2.cName, '')
      --AND ISNULL(Lieferadresse1.cStrasse, '') = ISNULL(Lieferadresse2.cStrasse, '')
      --AND ISNULL(Lieferadresse1.cPLZ, '') = ISNULL(Lieferadresse2.cPLZ, '')
      --AND ISNULL(Lieferadresse1.cOrt, '') = ISNULL(Lieferadresse2.cOrt, '')
      AND ISNULL(Rechnungsadresse1.cFirma, '') = ISNULL(Rechnungsadresse2.cFirma, '')
      AND ISNULL(Rechnungsadresse1.cVorname, '') = ISNULL(Rechnungsadresse2.cVorname, '')
      AND ISNULL(Rechnungsadresse1.cName, '') = ISNULL(Rechnungsadresse2.cName, '')
      AND ISNULL(Rechnungsadresse1.cStrasse, '') = ISNULL(Rechnungsadresse2.cStrasse, '')
      AND ISNULL(Rechnungsadresse1.cPLZ, '') = ISNULL(Rechnungsadresse2.cPLZ, '')
      AND ISNULL(Rechnungsadresse1.cOrt, '') = ISNULL(Rechnungsadresse2.cOrt, '')
      AND (PicklistePos.kPicklistePos IS NULL OR PicklistePos.nStatus >= 40);
    RETURN;
END;
go

