--- 
--- spBereinigenInaktiveLieferanten
---

CREATE PROCEDURE [dbo].[spBereinigenInaktiveLieferanten]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: GJ
--
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
    DELETE FROM dbo.tlieferant
    WHERE tlieferant.cAktiv = 'N';

    DELETE FROM dbo.tliefartikel
    WHERE tliefartikel.tLieferant_kLieferant NOT IN( SELECT tlieferant.kLieferant
                                                     FROM dbo.tlieferant );
END;
go

