--- 
--- spOptimiereDatenbank
---

CREATE PROC [dbo].[spOptimiereDatenbank]
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP/AC/MS
AS
BEGIN
    SET NOCOUNT ON;
	SET ANSI_NULLS ON;
	SET ANSI_NULL_DFLT_ON ON;
	SET ANSI_PADDING ON;
	SET CONCAT_NULL_YIELDS_NULL ON;
	SET XACT_ABORT OFF;
    
    DECLARE @Databasename VARCHAR(200);
    SELECT @Databasename = DB_NAME(); 

    --
    -- Indizies der Tabellen neuerstellen um die Fragmentierung der Indizies zu beheben
    --

    DECLARE @TableName VARCHAR(255);
    DECLARE @sql NVARCHAR(500);
    DECLARE @fillfactor INT;
    SET @fillfactor = 80;
    DECLARE TableCursor CURSOR FOR
	   SELECT '[' + OBJECT_SCHEMA_NAME(object_id) + '].[' + name + ']' AS TableName
	   FROM [sys].[tables];
    OPEN TableCursor;
    FETCH NEXT FROM [TableCursor] INTO @TableName;
    WHILE @@FETCH_STATUS = 0
    BEGIN
	    SET @sql = 'ALTER INDEX ALL ON ' + @TableName + ' REBUILD WITH (FILLFACTOR = ' + CONVERT(VARCHAR(3),@fillfactor) + ')';
	    PRINT @sql;
	    EXEC (@sql);
	    FETCH NEXT FROM TableCursor INTO @TableName;
    END;
    CLOSE TableCursor;
    DEALLOCATE TableCursor;

    DELETE dbo.toptions WHERE cKey = 'letzte Index Defragmentierung';

    BEGIN TRY
       EXEC sp_updatestats;
	END TRY
	BEGIN CATCH
       EXEC sp_MSforeachtable 'UPDATE STATISTICS ?';
	END CATCH

    INSERT INTO dbo.toptions (cKey, cValue)
	   SELECT 'letzte Index Defragmentierung', CONVERT(VARCHAR, GETDATE());

    --
    -- Datensätze mit fehlenden Verknüpfungen aufräumen
    --

    DELETE FROM dbo.tArtikelShop 
	   WHERE dbo.tArtikelShop.kArtikel NOT IN (SELECT dbo.tArtikel.kArtikel FROM dbo.tArtikel);

    DELETE FROM dbo.tArtikelSichtbarkeit 
	   WHERE dbo.tArtikelSichtbarkeit.kArtikel NOT IN (SELECT dbo.tArtikel.kArtikel FROM dbo.tArtikel);

    DELETE FROM dbo.tKategorieShop 
	   WHERE dbo.tKategorieShop.kKategorie NOT IN (SELECT dbo.tKategorie.kKategorie FROM dbo.tKategorie);

    DELETE FROM dbo.tMerkmalbildPlattform 
	   WHERE dbo.tMerkmalbildPlattform.kMerkmal NOT IN (SELECT dbo.tMerkmal.kMerkmal FROM dbo.tMerkmal);

    DELETE FROM dbo.tMerkmalwertBildPlattform
	   WHERE dbo.tMerkmalwertBildPlattform.kMerkmalWert NOT IN (SELECT dbo.tMerkmalWert.kMerkmalWert FROM dbo.tMerkmalWert);

    DELETE FROM dbo.ebay_item 
	   WHERE dbo.ebay_item.kArtikel NOT IN (SELECT dbo.tArtikel.kArtikel FROM dbo.tArtikel);

    DELETE FROM dbo.ebay_attributSetArray 
	   WHERE dbo.ebay_attributSetArray.kItem NOT IN (SELECT dbo.ebay_item.kItem FROM dbo.ebay_item);

    DELETE FROM dbo.ebay_attributSetArray 
	   WHERE dbo.ebay_attributSetArray.kItem NOT IN (SELECT dbo.ebay_item.kItem FROM dbo.ebay_item);

    DELETE FROM dbo.ebay_data_htmltemplatetagcontent 
	   WHERE dbo.ebay_data_htmltemplatetagcontent.kEbayItem NOT IN (SELECT dbo.ebay_item.kItem FROM dbo.ebay_item);

    DELETE FROM dbo.ebay_InternationalShippingServiceOption 
	   WHERE dbo.ebay_InternationalShippingServiceOption.kItem NOT IN (SELECT dbo.ebay_item.kItem FROM dbo.ebay_item);

    DELETE FROM dbo.ebay_item2kombi 
	   WHERE dbo.ebay_item2kombi.kItem NOT IN (SELECT dbo.ebay_item.kItem FROM dbo.ebay_item);

    DELETE FROM dbo.ebay_item2xsell 
	   WHERE dbo.ebay_item2xsell.kEbayItem NOT IN (SELECT dbo.ebay_item.kItem FROM dbo.ebay_item);

    DELETE FROM dbo.ebay_planung 
	   WHERE dbo.ebay_planung.kItem NOT IN (SELECT dbo.ebay_item.kItem FROM dbo.ebay_item);

    DELETE FROM dbo.ebay_ShippingServiceOptions 
	   WHERE dbo.ebay_ShippingServiceOptions.kItem NOT IN (SELECT dbo.ebay_item.kItem FROM dbo.ebay_item);

    DELETE FROM dbo.teigenschaft 
	   WHERE dbo.teigenschaft.cAktiv='N';

    DELETE FROM dbo.teigenschaftKombiWert 
	   WHERE dbo.teigenschaftKombiWert.kEigenschaft NOT IN (SELECT dbo.teigenschaft.kEigenschaft FROM dbo.teigenschaft)

    DELETE FROM dbo.tEigenschaftSichtbarkeit 
	   WHERE dbo.tEigenschaftSichtbarkeit.kEigenschaft NOT IN (SELECT dbo.teigenschaft.kEigenschaft FROM dbo.teigenschaft);

    DELETE FROM dbo.tEigenschaftSprache 
	   WHERE dbo.tEigenschaftSprache.kEigenschaft NOT IN (SELECT dbo.teigenschaft.kEigenschaft FROM dbo.teigenschaft);

    DELETE FROM dbo.tEigenschaftWertAbhaengigkeit 
	   WHERE dbo.tEigenschaftWertAbhaengigkeit.kEigenschaftWert NOT IN (SELECT dbo.teigenschaftwert.kEigenschaftWert FROM dbo.teigenschaftwert);

    DELETE FROM dbo.tEigenschaftWertAufpreis 
	   WHERE dbo.tEigenschaftWertAufpreis.kEigenschaftWert NOT IN (SELECT dbo.teigenschaftwert.kEigenschaftWert FROM dbo.teigenschaftwert);

    DELETE FROM dbo.tEigenschaftWertSichtbarkeit 
	   WHERE dbo.tEigenschaftWertSichtbarkeit.kEigenschaftWert NOT IN (SELECT dbo.teigenschaftwert.kEigenschaftWert FROM dbo.teigenschaftwert);

    DELETE FROM dbo.tEigenschaftWertSprache 
	   WHERE dbo.tEigenschaftWertSprache.kEigenschaftWert NOT IN (SELECT dbo.teigenschaftwert.kEigenschaftWert FROM dbo.teigenschaftwert);

    DELETE FROM dbo.tliefartikel 
	   WHERE dbo.tliefartikel.tLieferant_kLieferant NOT IN (SELECT dbo.tlieferant.kLieferant FROM dbo.tlieferant);

    DELETE FROM dbo.tLieferantenBestellungPos 
	   WHERE dbo.tLieferantenBestellungPos.kLieferantenBestellung NOT IN (SELECT dbo.tLieferantenBestellung.kLieferantenBestellung FROM dbo.tLieferantenBestellung);

    DELETE FROM dbo.tLieferscheinPos 
	   WHERE dbo.tLieferscheinPos.kLieferschein NOT IN (SELECT dbo.tLieferschein.kLieferschein FROM dbo.tLieferschein);

    DELETE FROM dbo.tWarenlagerEingang 
	   WHERE dbo.tWarenlagerEingang.kWarenlagerPlatz NOT IN (SELECT dbo.tWarenlagerPlatz.kWarenlagerPlatz FROM dbo.tWarenlagerPlatz);

    DELETE FROM dbo.tWarenlagerPlatz 
	   WHERE dbo.tWarenlagerPlatz.kWarenlager NOT IN (SELECT dbo.tWarenlager.kWarenlager FROM dbo.tWarenlager);

    DELETE FROM dbo.tLHM  
	   WHERE dbo.tLHM.kWarenlager NOT IN (SELECT dbo.tWarenlager.kWarenlager FROM dbo.tWarenlager);

    DELETE FROM dbo.tWarenLagerOptionen 
	   WHERE dbo.tWarenLagerOptionen.kWarenlager NOT IN (SELECT dbo.tWarenlager.kWarenlager FROM dbo.tWarenlager);

    DELETE FROM dbo.tWarenlagerArtikelOptionen 
	   WHERE dbo.tWarenlagerArtikelOptionen.kWarenlager NOT IN (SELECT dbo.tWarenlager.kWarenlager FROM dbo.tWarenlager);

    DELETE FROM dbo.tWarenLagerOptionen 
    WHERE dbo.tWarenLagerOptionen.kWarenlager NOT IN (SELECT dbo.tWarenlager.kWarenlager FROM dbo.tWarenlager);

    DELETE FROM dbo.tWarenLagerPlatzArtikel 
	   WHERE dbo.tWarenLagerPlatzArtikel.kWarenlagerPlatz NOT IN (SELECT dbo.tWarenlagerPlatz.kWarenlagerPlatz FROM dbo.tWarenlagerPlatz);

    DELETE FROM dbo.tWmsInventurlog 
	   WHERE dbo.tWmsInventurlog.kWmsInventur NOT IN (SELECT dbo.tWmsInventurlog.kWmsInventur FROM dbo.tWmsInventurlog);

    DELETE FROM dbo.tWarenLagerEingangHistorie 
	   WHERE dbo.tWarenLagerEingangHistorie.kWarenLagerEingang NOT IN (SELECT dbo.tWarenLagerEingang.kWarenLagerEingang FROM dbo.tWarenLagerEingang);

    --
    -- Logdatei der Datenbank verkleinern und die Maximalgröße auf 1 MB festlegen
    --
	DECLARE @LogFile VARCHAR(255);
	SELECT TOP(1) @LogFile = sys.database_files.name 
		FROM sys.database_files 
		WHERE sys.database_files.type = 1
    EXEC('ALTER DATABASE ' + @Databasename + ' SET RECOVERY SIMPLE');
	DBCC SHRINKFILE (@LogFile, 1);
	EXEC('ALTER DATABASE ' + @Databasename + ' SET RECOVERY FULL');
END
go

