CREATE FUNCTION [dbo].[ifGetNetPrice] (@kArtikel AS INT, @kKunde AS INT, @kKundengruppe AS INT, @kShop AS INT, @fAnzahl AS INT)
RETURNS TABLE
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP
-- Beschreibung:	Dient zur Ermittlung eines eindeutigen Preises für einen Artikel.
--					Parameter dürfen nicht NULL sein sondern statt dessen 0.
--
AS

RETURN
(
	SELECT	CASE 
				WHEN CONVERT(DECIMAL(28,15), ISNULL(Sonderpreis.fNettoPreis, ISNULL(AbweichenderVK.fNettoPreis, dbo.tArtikel.fVKNetto))) > CONVERT(DECIMAL(28,15), ISNULL(AbweichenderVK.fNettoPreis, dbo.tArtikel.fVKNetto))
				THEN CONVERT(DECIMAL(28,15), ISNULL(AbweichenderVK.fNettoPreis, tArtikel.fVKNetto))
				ELSE CONVERT(DECIMAL(28,15), ISNULL(Sonderpreis.fNettoPreis, ISNULL(AbweichenderVK.fNettoPreis, dbo.tArtikel.fVKNetto)))
			END AS dNettoPreis,			
			CASE 
				WHEN ISNULL(AbweichenderVK.kundenindividuell, 0) > 0 
				THEN 0.0 
				ELSE CONVERT(DECIMAL(28,15), CASE WHEN Sonderpreis.fNettoPreis IS NULL THEN ISNULL(Rabatt.fRabatt, 0.0) ELSE 0.0 END) 
			END AS dRabatt
		FROM dbo.tArtikel
		LEFT JOIN 
		(
			SELECT TOP(1)	BesterVK.kArtikel AS kArtikel,
							BesterVK.fNettoPreis AS fNettoPreis,
							BesterVK.kundenindividuell AS kundenindividuell
			FROM
			(
				--
				-- Abweichenden VK Netto ermitteln für Kundengruppe
				--
					SELECT TOP(1)	dbo.tPreis.kArtikel AS kArtikel,
									dbo.tPreisDetail.fNettoPreis AS fNettoPreis,
									0 AS kundenindividuell
					FROM dbo.tPreis
					JOIN dbo.tPreisDetail ON dbo.tPreis.kPreis = dbo.tPreisDetail.kPreis
						AND dbo.tPreisDetail.nAnzahlAb <= @fAnzahl
					WHERE	dbo.tPreis.kKundenGruppe = @kKundengruppe
								AND dbo.tPreis.kKunde = 0
								AND dbo.tPreis.kShop = @kShop
								AND dbo.tPreis.kArtikel = @kArtikel
					ORDER BY dbo.tPreisDetail.nAnzahlAb DESC
				UNION ALL
				--
				-- Abweichenden VK Netto ermitteln für Kunden
				--
					SELECT TOP(1)	dbo.tPreis.kArtikel AS kArtikel,
									dbo.tPreisDetail.fNettoPreis AS fNettoPreis,
									1 AS kundenindividuell
					FROM dbo.tPreis WITH(NOLOCK)
					JOIN dbo.tPreisDetail WITH(NOLOCK) ON dbo.tPreis.kPreis = dbo.tPreisDetail.kPreis
						AND dbo.tPreisDetail.nAnzahlAb <= @fAnzahl
					WHERE	dbo.tPreis.kKunde = @kKunde
								AND dbo.tPreis.kKundenGruppe = 0
								AND dbo.tPreis.kShop = @kShop
								AND dbo.tPreis.kArtikel = @kArtikel
					ORDER BY dbo.tPreisDetail.nAnzahlAb DESC
			) AS BesterVK
			ORDER BY BesterVK.fNettoPreis ASC
		) AS AbweichenderVK ON dbo.tArtikel.kArtikel = AbweichenderVK.kArtikel
		LEFT JOIN
		(
			--
			-- Ermitteln von Sonderpreisen.
			-- Sonderpreise werden nicht mehr rabattiert.
			--
				SELECT TOP(1)	dbo.tArtikelSonderpreis.kArtikel AS kArtikel,
								CONVERT(DECIMAL(28,15), ISNULL(dbo.tSonderpreise.fNettoPreis, 0.0)) AS fNettoPreis
				FROM dbo.tArtikelSonderpreis WITH(NOLOCK)
				JOIN dbo.tSonderpreise WITH(NOLOCK) ON dbo.tArtikelSonderpreis.kArtikelSonderpreis = dbo.tSonderpreise.kArtikelSonderpreis
					AND dbo.tSonderpreise.kKundenGruppe = CASE WHEN dbo.tSonderpreise.kKundenGruppe = 0 THEN 0 ELSE @kKundengruppe END
					AND dbo.tSonderpreise.kShop = CASE WHEN dbo.tSonderpreise.kShop = 0 THEN 0 ELSE @kShop END
				JOIN dbo.tlagerbestand WITH(NOLOCK) ON dbo.tArtikelSonderpreis.kArtikel = dbo.tlagerbestand.kArtikel
				JOIN dbo.tArtikel WITH(NOLOCK) ON dbo.tlagerbestand.kArtikel = dbo.tArtikel.kArtikel
				WHERE 	dbo.tSonderpreise.fNettopreis IS NOT NULL
						AND dbo.tArtikelSonderpreis.kArtikel = @kArtikel
						AND dbo.tArtikelSonderpreis.nAktiv = 1
						-- Zeiten abschneiden
						AND CONVERT(INT, CONVERT(VARCHAR, dbo.tArtikelSonderpreis.dStart, 112)) <= CONVERT(INT, CONVERT(VARCHAR, GETDATE(), 112))
						AND CONVERT(INT, CONVERT(VARCHAR, ISNULL(dbo.tArtikelSonderpreis.dEnde, GETDATE()), 112)) >= CONVERT(INT, CONVERT(VARCHAR, GETDATE(), 112))												
						AND (dbo.tArtikelSonderpreis.nIstAnzahl = 0 OR CASE WHEN dbo.tArtikel.cLagerAktiv = 'Y' THEN ISNULL(CONVERT(DECIMAL, nAnzahl), -1) ELSE -1 END < dbo.tlagerbestand.fVerfuegbar)
				ORDER BY dbo.tSonderpreise.fNettoPreis ASC
		) AS Sonderpreis ON dbo.tArtikel.kArtikel = Sonderpreis.kArtikel
		LEFT JOIN
		(
			--
			-- Ermittlung des größstmöglichen Rabatt aller Rabatte
			--
				SELECT TOP(1)	@kArtikel AS kArtikel,
								ISNULL(AlleRabatte.fRabatt, 0.0) AS fRabatt
				FROM
				(
					--
					-- Ermittlung des Kundenrabatts
					--
						SELECT TOP(1)	CONVERT(DECIMAL(28,15), dbo.tKunde.fRabatt) AS fRabatt
						FROM dbo.tKunde WITH(NOLOCK)
						WHERE	dbo.tKunde.kKunde = @kKunde
								AND dbo.tKunde.kKunde > 0
								AND ISNULL(dbo.tKunde.fRabatt, 0.0) != 0.0
						UNION ALL
					--
					-- Ermittlung des Kundengruppenrabatts
					--
						SELECT TOP(1)	CONVERT(DECIMAL(28,15), dbo.tKundenGruppe.fRabatt) AS fRabatt
						FROM dbo.tKundenGruppe WITH(NOLOCK)
						WHERE	dbo.tKundenGruppe.kKundenGruppe = @kKundengruppe
								AND dbo.tKundenGruppe.kKundenGruppe > 0
								AND ISNULL(dbo.tKundenGruppe.fRabatt, 0.0) != 0.0
						UNION ALL
					--
					-- Ermittlung des Kategorierabatts
					--
						SELECT CONVERT(DECIMAL(28,15), dbo.tKategorieRabatt.fRabatt) AS fRabatt
						FROM dbo.tkategorieartikel WITH(NOLOCK)
						JOIN dbo.tKategorieRabatt WITH(NOLOCK) ON dbo.tkategorieartikel.kKategorie = dbo.tKategorieRabatt.kKategorie
							AND dbo.tKategorieRabatt.kKundenGruppe = @kKundengruppe
							AND dbo.tKategorieRabatt.kShop = @kShop
						JOIN 
						(
							SELECT	CASE WHEN dbo.tArtikel.kVaterArtikel > 0 
										THEN kVaterArtikel 
										ELSE kArtikel
									END AS kArtikel
							FROM dbo.tArtikel
							WHERE dbo.tArtikel.kArtikel = @kArtikel
						) AS artikel ON dbo.tkategorieartikel.kArtikel = artikel.kArtikel
						WHERE	ISNULL(tKategorieRabatt.fRabatt, 0.0) != 0.0
				) AS AlleRabatte
				ORDER BY AlleRabatte.fRabatt DESC
		) AS Rabatt ON dbo.tArtikel.kArtikel = Rabatt.kArtikel
		WHERE dbo.tArtikel.kArtikel = @kArtikel
)
go

