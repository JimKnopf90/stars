CREATE TRIGGER [dbo].[jtlActionValidator_teigenschaftwert]  
--     
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--    
ON [dbo].[teigenschaftwert]  
AFTER DELETE 
AS  
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN 

	--
	--Überprüfen ob Trigger mit Inhalt aufgerufen wird
	--
		IF((SELECT COUNT(1) FROM DELETED) = 0)
		BEGIN
			RETURN
		END

	--
	-- tEigenschaftWertAbhaengigkeit aufräumen
	--
		DELETE tEigenschaftWertAbhaengigkeit WITH(ROWLOCK)
		FROM tEigenschaftWertAbhaengigkeit WITH(ROWLOCK)
		JOIN DELETED ON tEigenschaftWertAbhaengigkeit.kEigenschaftWert = DELETED.kEigenschaftWert
	--
	-- tEigenschaftWertAufpreis aufräumen
	--
		DELETE tEigenschaftWertAufpreis WITH(ROWLOCK)
		FROM tEigenschaftWertAufpreis WITH(ROWLOCK)
		JOIN DELETED ON tEigenschaftWertAufpreis.kEigenschaftWert = DELETED.kEigenschaftWert
	--
	-- tEigenschaftWertPict aufräumen
	--
		DELETE tEigenschaftWertPict WITH(ROWLOCK)
		FROM tEigenschaftWertPict WITH(ROWLOCK)
		JOIN DELETED ON tEigenschaftWertPict.kEigenschaftWert = DELETED.kEigenschaftWert
	--
	-- tEigenschaftWertSichtbarkeit aufräumen
	--
		DELETE tEigenschaftWertSichtbarkeit WITH(ROWLOCK)
		FROM tEigenschaftWertSichtbarkeit WITH(ROWLOCK)
		JOIN DELETED ON tEigenschaftWertSichtbarkeit.kEigenschaftWert = DELETED.kEigenschaftWert
	--
	-- tEigenschaftWertSprache aufräumen
	--
		DELETE tEigenschaftWertSprache WITH(ROWLOCK)
		FROM tEigenschaftWertSprache WITH(ROWLOCK)
		JOIN DELETED ON tEigenschaftWertSprache.kEigenschaftWert = DELETED.kEigenschaftWert
END
go

