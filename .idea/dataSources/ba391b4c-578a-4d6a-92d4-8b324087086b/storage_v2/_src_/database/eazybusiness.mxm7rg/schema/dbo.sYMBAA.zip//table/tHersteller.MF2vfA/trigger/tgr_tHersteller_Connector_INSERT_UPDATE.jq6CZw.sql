CREATE TRIGGER [dbo].[tgr_tHersteller_Connector_INSERT_UPDATE]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: PN/MP
--
ON [dbo].[tHersteller]
AFTER INSERT, UPDATE
AS 
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN

	DELETE dbo.tQueue
	FROM dbo.tQueue
	JOIN INSERTED ON dbo.tQueue.kWert = INSERTED.kHersteller
	WHERE dbo.tQueue.cName = 'tHersteller';

	INSERT INTO tQueue(kShop, kPlattform, cName, kWert, nAction)	 
	SELECT dbo.tShop.kShop, 2, 'tHersteller' AS cName, INSERTED.kHersteller, 1
	FROM INSERTED
	CROSS JOIN dbo.tShop;

END
go

