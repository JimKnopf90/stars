
    CREATE VIEW unicorn2_vNotExistingArtikel 
    AS
        SELECT kArtikel AS kWawiId
        FROM tartikel WITH (NOLOCK) 
        WHERE kVaterArtikel = 0 AND kArtikel NOT IN (SELECT kWawiId FROM unicorn2_tExistingArtikel) AND cAktiv = 'Y'
    go

