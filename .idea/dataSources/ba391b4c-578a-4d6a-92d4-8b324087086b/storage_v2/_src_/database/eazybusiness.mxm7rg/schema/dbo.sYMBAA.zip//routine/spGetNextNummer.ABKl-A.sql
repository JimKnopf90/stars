--- 
--- spGetNextNummer
---

CREATE PROCEDURE [dbo].[spGetNextNummer]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP
--
	@cName VARCHAR(100),
	@kFirma BIGINT,
	@nNoUpdate TINYINT,
	@cNeueNummer VARCHAR(30) = NULL OUTPUT
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;

DECLARE @ErrorMessage NVARCHAR(4000);
DECLARE @ErrorSeverity INT;
DECLARE @ErrorState INT;
DECLARE @retry INT;
SET @retry = 5;
WHILE @retry > 0
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION
			DECLARE @err INT
			DECLARE @iNeueNummer BIGINT
			DECLARE @Heute smalldatetime
			DECLARE @PRE varchar(10)
			DECLARE @POST varchar(10)
			DECLARE @res INT
			DECLARE @cSQL AS NVARCHAR(1000)
			DECLARE @cSQLREPLACED AS NVARCHAR(1000)
			DECLARE @CountTable AS TABLE(nCounter INT)
			DECLARE @cTable AS VARCHAR(100)
			DECLARE @cColumn AS VARCHAR(100)
	
			SET @err = 0
			SET @Heute = GetDate()
			SET @cNeueNummer = '1'
			SET @cTable = (SELECT TOP 1 ISNULL(cTable, '') FROM tLaufendeNummern WITH(NOLOCK) WHERE cName = @cName)
			SET @cColumn = (SELECT TOP 1 ISNULL(cColumn, '') FROM tLaufendeNummern WITH(NOLOCK) WHERE cName = @cName)

			SET @cSQL = 'SELECT COUNT(*) FROM ' + @cTable + ' WITH(NOLOCK) WHERE ' + @cColumn + ' = ''#LAUFENDENUMMER#'''

			EXEC @res = sp_getapplock @Resource = 'tLaufendeNummern', @LockMode ='Exclusive', @LockOwner ='Session', @LockTimeout = 500, @DbPrincipal = 'public' 	

			IF @res NOT IN (0, 1)
			BEGIN
				SET @cNeueNummer = ''
				SET @err = 1
			END
			ELSE
			BEGIN
				WHILE ((SELECT ISNULL(MAX(ISNULL(nCounter, 0)), 0) FROM @CountTable) > 0 OR @cNeueNummer = '1')
				BEGIN
					IF EXISTS(SELECT nNummer FROM tLaufendeNummern WITH(NOLOCK) WHERE tLaufendeNummern.cName = @cName AND tLaufendeNummern.kFirma = @kFirma)
					BEGIN
						SET @iNeueNummer = (SELECT nNummer FROM tLaufendeNummern WITH(NOLOCK) WHERE tLaufendeNummern.cName = @cName AND tLaufendeNummern.kFirma = @kFirma)
						IF(@nNoUpdate = 0)
						BEGIN
							UPDATE tLaufendeNummern WITH(ROWLOCK) SET nNummer = nNummer + 1 WHERE tLaufendeNummern.cName = @cName AND tLaufendeNummern.kFirma = @kFirma
						END
		
						SET @PRE = ISNULL((SELECT tLaufendeNummern.cPrefix FROM tLaufendeNummern WITH(NOLOCK) WHERE tLaufendeNummern.cName = @cName AND tLaufendeNummern.kFirma = @kFirma), '');
						SET @POST = ISNULL((SELECT tLaufendeNummern.cSuffix FROM tLaufendeNummern WITH(NOLOCK) WHERE tLaufendeNummern.cName = @cName AND tLaufendeNummern.kFirma = @kFirma), '');
						SET @cNeueNummer = (SELECT CONVERT(VARCHAR(30), @iNeueNummer))
						SET @cNeueNummer = (SELECT (@PRE + @cNeueNummer + @POST));
						SET @cNeueNummer = (SELECT REPLACE(@cNeueNummer, '<K>', REPLACE(STR(DATEPART(ISOWK, @Heute), 2), ' ', 0)));
						SET @cNeueNummer = (SELECT REPLACE(@cNeueNummer, '<J>', DATEPART(YEAR, @Heute)));
						SET @cNeueNummer = (SELECT REPLACE(@cNeueNummer, '<M>', REPLACE(STR(DATEPART(MONTH, @Heute), 2), ' ', 0)));
						SET @cNeueNummer = (SELECT REPLACE(@cNeueNummer, '<T>', REPLACE(STR(DATEPART(DAY, @Heute), 2), ' ', 0)));
					END
					ELSE
					BEGIN
						IF EXISTS(SELECT nNummer FROM tLaufendeNummern WITH(NOLOCK) WHERE tLaufendeNummern.cName = @cName AND tLaufendeNummern.kFirma = 0)
						BEGIN
							SET @iNeueNummer = (SELECT nNummer FROM tLaufendeNummern WITH(NOLOCK) WHERE tLaufendeNummern.cName = @cName AND tLaufendeNummern.kFirma = 0)
							IF(@nNoUpdate = 0)
							BEGIN
								UPDATE tLaufendeNummern WITH(ROWLOCK) SET nNummer = nNummer + 1 WHERE tLaufendeNummern.cName = @cName AND tLaufendeNummern.kFirma = 0
							END
			
							SET @PRE = ISNULL((SELECT tLaufendeNummern.cPrefix FROM tLaufendeNummern WITH(NOLOCK) WHERE tLaufendeNummern.cName = @cName AND tLaufendeNummern.kFirma = 0), '');
							SET @POST = ISNULL((SELECT tLaufendeNummern.cSuffix FROM tLaufendeNummern WITH(NOLOCK) WHERE tLaufendeNummern.cName = @cName AND tLaufendeNummern.kFirma = 0), '');
							SET @cNeueNummer = (SELECT CONVERT(VARCHAR(30), @iNeueNummer))
							SET @cNeueNummer = (SELECT (@PRE + @cNeueNummer + @POST));
							SET @cNeueNummer = (SELECT REPLACE(@cNeueNummer, '<K>', REPLACE(STR(DATEPART(ISOWK, @Heute), 2), ' ', 0)));
							SET @cNeueNummer = (SELECT REPLACE(@cNeueNummer, '<J>', DATEPART(YEAR, @Heute)));
							SET @cNeueNummer = (SELECT REPLACE(@cNeueNummer, '<M>', REPLACE(STR(DATEPART(MONTH, @Heute), 2), ' ', 0)));
							SET @cNeueNummer = (SELECT REPLACE(@cNeueNummer, '<T>', REPLACE(STR(DATEPART(DAY, @Heute), 2), ' ', 0)));
						END
					END

					IF(@nNoUpdate = 1)
					BEGIN
						SELECT @cNeueNummer
						BREAK
					END
					ELSE
					BEGIN
						DELETE @CountTable
						SET @cSQLREPLACED = REPLACE(@cSQL, '#LAUFENDENUMMER#', @cNeueNummer)
						INSERT INTO @CountTable(nCounter) EXEC sp_executesql @cSQLREPLACED
					END

				END
			END
	
			EXEC sp_releaseapplock @Resource = 'tLaufendeNummern', @DbPrincipal ='public', @LockOwner = 'Session'
			SELECT @cNeueNummer
			SET @retry = 0;
		COMMIT
	END TRY
	BEGIN CATCH
		SET @retry = @retry - 1;
		ROLLBACK;
		IF(@retry = 0)
		BEGIN
			SELECT @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
			RAISERROR (	@ErrorMessage, 
						@ErrorSeverity,
						@ErrorState
			);
			RETURN;
		END
		WAITFOR DELAY '00:00:00:5';
	END CATCH
END
go

