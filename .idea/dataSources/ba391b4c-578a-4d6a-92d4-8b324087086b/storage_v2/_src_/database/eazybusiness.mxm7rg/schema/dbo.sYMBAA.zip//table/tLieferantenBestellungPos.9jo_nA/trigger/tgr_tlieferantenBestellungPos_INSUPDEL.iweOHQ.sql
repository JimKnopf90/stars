CREATE TRIGGER [dbo].[tgr_tlieferantenBestellungPos_INSUPDEL]
ON [dbo].[tLieferantenBestellungPos]
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
	IF(CONTEXT_INFO() IN (0x5123, 0x5124, 0x5125, 0x5129))
	BEGIN
		RETURN;
	END
	ROLLBACK;
	RAISERROR(N'Die Tabelle tlieferantenBestellungPos kann nur über die SPs spLieferantenBestellungPosBearbeiten, spLieferantenBestellungPosErstellen und spLieferantenBestellungPosLoeschen bearbeitet werden.', 15,1);
END
go

