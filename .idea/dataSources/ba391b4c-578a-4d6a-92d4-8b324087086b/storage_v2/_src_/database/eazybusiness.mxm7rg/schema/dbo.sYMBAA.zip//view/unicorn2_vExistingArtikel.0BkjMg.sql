
    CREATE VIEW unicorn2_vExistingArtikel 
    AS
        SELECT kWawiId 
        FROM unicorn2_tExistingArtikel WITH (NOLOCK) 
        WHERE kWawiId NOT IN (SELECT kartikel FROM tartikel WITH (NOLOCK) WHERE kVaterArtikel = 0 AND cAktiv = 'Y')
    go

