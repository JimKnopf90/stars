CREATE TRIGGER [dbo].[tgr_tliefartikel_DELETE]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--
ON [dbo].[tliefartikel]
AFTER DELETE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
	--Überprüfen ob Trigger mit Inhalt gefüllt wird
	IF NOT EXISTS(SELECT * FROM DELETED)
	BEGIN
		RETURN;
	END;


     IF((SELECT COUNT(1) FROM DELETED 
	WHERE DELETED.tArtikel_kArtikel > 0 AND LEN(DELETED.cLiefArtNr) > 0) > 0)
	BEGIN
		  ---- Wir löschen alle LiefArtNr zuordnungen und legen sie neu an, weil Artikel können die gleiche liefArtNr von mehreren Lieferanten haben.
		  DELETE dbo.tArtikelSpeicher WITH(ROWLOCK) 
		  FROM dbo.tArtikelSpeicher WITH(ROWLOCK)
		  JOIN DELETED ON DELETED.tArtikel_kArtikel = dbo.tArtikelSpeicher.kArtikel
		  WHERE dbo.tArtikelSpeicher.nID = 8;

		  INSERT INTO dbo.tArtikelSpeicher WITH(ROWLOCK) (cNummer,kArtikel,nID,nAktiv)
		  SELECT DISTINCT LTRIM(RTRIM(tLiefArtikel.cLiefArtNr)) AS Nummer, dbo.tLiefArtikel.tArtikel_kArtikel, 8 AS Art ,1 AS nAktiv 
			  FROM dbo.tLiefArtikel 
			  JOIN tArtikel ON tArtikel.kArtikel = dbo.tLiefArtikel.tArtikel_kArtikel  
			  JOIN DELETED ON DELETED.tArtikel_kArtikel = dbo.tArtikel.kArtikel
			  WHERE dbo.tLiefArtikel.cLiefArtNr IS NOT NULL  
			  AND dbo.tLiefArtikel.cLiefArtNr <> '' ;

	END;

	DECLARE @typeArtikel AS TYPE_spUpdateLagerbestand;

	INSERT INTO @typeArtikel (kArtikel)
	SELECT DISTINCT kArtikel 
	FROM
	(
		SELECT tArtikel_kArtikel AS kArtikel 
			FROM DELETED
			GROUP BY DELETED.tArtikel_kArtikel
	) AS U1
	WHERE kArtikel = U1.kArtikel;

	EXEC spUpdateLagerBestand @typeArtikel;

	--
	-- tLiefartikelPreis löschen
	--
	DELETE dbo.tLiefArtikelPreis
		FROM dbo.tLiefArtikelPreis
		JOIN DELETED ON dbo.tLiefArtikelPreis.kLiefArtikel = DELETED.kLiefArtikel;
END;
go

