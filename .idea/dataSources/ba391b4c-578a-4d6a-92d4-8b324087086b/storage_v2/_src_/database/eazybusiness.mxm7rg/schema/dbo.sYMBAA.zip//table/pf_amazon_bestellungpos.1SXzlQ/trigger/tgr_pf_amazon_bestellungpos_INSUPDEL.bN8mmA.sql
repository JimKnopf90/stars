CREATE TRIGGER [dbo].[tgr_pf_amazon_bestellungpos_INSUPDEL]
ON [dbo].[pf_amazon_bestellungpos]
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
	IF(CONTEXT_INFO() IN (0x5101, 0x5102,0x5103))
	BEGIN
    	RETURN;
    END
	ROLLBACK;
	RAISERROR(N'Die Tabelle dbo.pf_amazon_bestellungpos kann nur über die SPs spAmazonPosAendern, spAmazonPosAnlegen und spAmazonPosLoeschen geändert werden.', 15,1);
END
go

