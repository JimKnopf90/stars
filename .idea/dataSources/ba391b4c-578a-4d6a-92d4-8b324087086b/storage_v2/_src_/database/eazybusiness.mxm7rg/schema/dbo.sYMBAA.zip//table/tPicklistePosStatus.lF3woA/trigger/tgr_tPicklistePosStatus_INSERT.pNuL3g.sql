CREATE TRIGGER [dbo].[tgr_tPicklistePosStatus_INSERT]   
--   
-- Aktualisiert den Status in tPicklistePos und tPickliste  
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: SB
--  
ON [dbo].[tPicklistePosStatus]   
AFTER INSERT  
AS   
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN 

	IF(CONTEXT_INFO() IN(0x5022))
	BEGIN
		RETURN;
	END;

	DECLARE @kPickliste INT;
	DECLARE @nStatus INT;
	DECLARE @kPicklisteStatus INT;
	DECLARE @kBenutzer INT;

	    -- Der Trigger kann nur von einem Update aufgerufen werden - deshalb sind alle kBenutzer identisch
	    SET @kBenutzer = (SELECT TOP 1 kBenutzer FROM INSERTED);



	    -- tPicklistePos.kPicklistePosStatus setzen
	    UPDATE dbo.tPicklistePos
		SET dbo.tPicklistePos.kPicklistePosStatus = INSERTED.kPicklistePosStatus, 
			nStatus = INSERTED.nStatus
		FROM dbo.tPicklistePos
		JOIN INSERTED ON INSERTED.kPicklistePos = dbo.tPicklistePos.kPicklistePos;



	    -- tPicklisteStatus schreiben falls sich der Status geändert hat	
	    INSERT INTO dbo.tPicklisteStatus (kPickliste, kBenutzer, dZeitstempel, nStatus) 
		SELECT 
			dbo.tPickliste.kPickliste AS kPickliste,
			@kBenutzer AS kBenutzer, 
			GETDATE() AS dZeitstempel,
			CASE 
				WHEN MIN(ISNULL(dbo.tPicklistePos.nStatus, 0)) = 10 AND MAX(ISNULL(dbo.tPicklistePos.nStatus, 0)) > 10 THEN 11
				ELSE MIN(ISNULL(dbo.tPicklistePos.nStatus, 0)) 
			END AS nStatus
		FROM dbo.tPickliste	WITH (NOLOCK)
		JOIN dbo.tPicklistePos WITH (NOLOCK) ON dbo.tPicklistePos.kPickliste = dbo.tPickliste.kPickliste
		WHERE dbo.tPickliste.kPickliste IN (
			SELECT DISTINCT dbo.tPicklistePos.kPickliste
			FROM dbo.tPicklistePos WITH (NOLOCK)
			JOIN INSERTED ON INSERTED.kPicklistePos = dbo.tPicklistePos.kPicklistePos
		) 
		GROUP BY dbo.tPickliste.kPickliste, dbo.tPickliste.nStatus
		HAVING dbo.tPickliste.nStatus != CASE 
		WHEN MIN(ISNULL(dbo.tPicklistePos.nStatus, 0)) = 10 AND MAX(ISNULL(dbo.tPicklistePos.nStatus, 0)) > 10 THEN 11
		ELSE MIN(ISNULL(dbo.tPicklistePos.nStatus, 0)) END;

											
		UPDATE dbo.tPickliste
		SET nStatus = AktStatus.nStatus,
				kPicklisteStatus = AktStatus.kPicklisteStatus,
				kPicklisteStatusAngelegt = ISNULL(dbo.tPickliste.kPicklisteStatusAngelegt, AktStatus.kPicklisteStatus)
		FROM dbo.tPickliste
		JOIN (SELECT dbo.tPicklisteStatus.kPickliste, MAX(dbo.tPicklisteStatus.nStatus) AS nStatus, MAX(dbo.tPicklisteStatus.kPicklisteStatus) AS kPicklisteStatus
		      FROM dbo.tPicklisteStatus
			  JOIN dbo.tPicklistePos ON dbo.tPicklistePos.kPickliste = dbo.tPicklisteStatus.kPickliste
			  JOIN INSERTED ON INSERTED.kPicklistePos = dbo.tPicklistePos.kPicklistePos
		      WHERE NOT EXISTS (SELECT * FROM dbo.tPicklisteStatus t2
								WHERE t2.kPickliste = tPicklisteStatus.kPickliste
								  AND t2.kPicklisteStatus > tPicklisteStatus.kPicklisteStatus)
		GROUP BY dbo.tPicklisteStatus.kPickliste) AS AktStatus ON AktStatus.kPickliste = tPickliste.kPickliste
		   

END;
go

