--- 
--- spCreateLieferscheinFromPackArtikel
---

CREATE PROCEDURE [dbo].[spCreateLieferscheinFromPackArtikel]
	--
	-- Copyright (c) 2012-2017 by JTL Software GmbH
	-- Datum: $Date$
	-- Version: $Rev$
	--
	@kBestellung INT,
	@kBenutzer INT,
	@kPickliste INT,
	@cLieferscheinNr VARCHAR(255),
	@kRetLieferschein  INT OUT,
	@nRetError  INT OUT
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;

	DECLARE @nRet INT;
	DECLARE @kBestellungNewOrder INT;
	DECLARE @kLieferschein INT;
	DECLARE @MaxMenge DECIMAL(28,14);
	DECLARE @kWMSPackItem INT;
	DECLARE @kArtikel INT;
	DECLARE @fMenge DECIMAL(28,14);
	DECLARE @kBestellposNeu INT;
	DECLARE @kBestellposAlt INT;
	DECLARE @fMengeAlt DECIMAL(28,14);
    DECLARE @IsNowDate DATETIME;
	DECLARE @kBestellpos INT;	 
	DECLARE @kBestellstuecklisteNeu INT;  
	DECLARE @kBestellStueckliste INT;

	DECLARE @Temp_BestellPosAlt TABLE(kBestellPos INT,kArtikel INT,fMenge DECIMAL(28,14),kBestellstueckliste INT);
	DECLARE @Temp_BestellPosNeu TABLE(kBestellPos INT,kArtikel INT,fMenge DECIMAL(28,14),kBestellstueckliste INT);
	
	DECLARE cur_GetWMSPackItems CURSOR LOCAL FAST_FORWARD FOR   
	SELECT dbo.tWMSPackItem.kWMSPackItem,dbo.tWMSPackItem.kArtikel,dbo.tWMSPackItem.fMenge,dbo.tWMSPackItem.kBestellpos,dbo.tWMSPackItem.kBestellStueckliste
	FROM dbo.tWMSPackItem WITH(NOLOCK)
	WHERE dbo.tWMSPackItem.kBestellung = @kBestellung
	AND dbo.tWMSPackItem.kPickliste = @kPickliste;

BEGIN


		SET @nRet = 0;
		SET @kBestellungNewOrder = 0;
		SET @IsNowDate = GETDATE();
	
	
	     --
	     -- Erzeugen eines Lieferscheins mit den gescannten Artikeln aus dem Eazyshipping
	     --
	
		-- Die alten Bestellpositionen Speichern
		INSERT INTO @Temp_BestellPosAlt(kBestellPos,kArtikel,fMenge,kBestellstueckliste)
		SELECT DISTINCT dbo.tBestellpos.kBestellPos,dbo.tBestellpos.tArtikel_kArtikel, (dbo.tBestellpos.nAnzahl - ISNULL(LieferscheinPos.fAnzahl,0)) AS nAnzahl,dbo.tBestellpos.kBestellStueckliste
		FROM dbo.tBestellpos
		JOIN tArtikel ON tArtikel.kArtikel = dbo.tBestellpos.tArtikel_kArtikel
		JOIN dbo.tPicklistePos ON dbo.tPicklistePos.kBestellPos = dbo.tbestellpos.kBestellPos
		LEFT JOIN (SELECT tLieferscheinPos.kBestellPos, SUM(tLieferscheinPos.fAnzahl) fAnzahl 
			            FROM tLieferscheinPos
						JOIN tLieferschein ON tLieferschein.kLieferschein = tLieferscheinPos.kLieferschein
						GROUP BY tLieferscheinPos.kBestellPos ) AS LieferscheinPos ON LieferscheinPos.kBestellPos = dbo.tBestellPos.kBestellPos
		WHERE dbo.tBestellpos.tBestellung_kBestellung = @kBestellung
		AND dbo.tPicklistePos.kPickliste = @kPickliste
		AND dbo.tPicklistePos.nStatus < 30
		AND (LieferscheinPos.kBestellPos IS NULL OR dbo.tBestellpos.nAnzahl > LieferscheinPos.fAnzahl)
		ORDER by dbo.tBestellpos.kBestellPos
				
		-- Über alle Artikel aus eazyshipping
		OPEN cur_GetWMSPackItems    
		FETCH NEXT FROM cur_GetWMSPackItems INTO  @kWMSPackItem,@kArtikel,@fMenge,@kBestellpos,@kBestellStueckliste

		WHILE (@@FETCH_STATUS = 0  and @nRet >= 0)
		BEGIN  
		
			--Wenn Bestellpos vorhanden, dann ist es eine FreiPos. Einfach komplett übernehmen.
		    IF(@fMenge > 0  AND @nRet >= 0 AND @kBestellpos > 0)
			BEGIN
		 
				 -- Freipos kann auch in stückliste seinm bzw. stücklisten können auch NUR aus freipos bestehen
				 SELECT @kBestellstuecklisteNeu =   kBestellstueckliste
				 FROM tbestellpos 
				 WHERE kbestellpos = @kBestellpos;

				 INSERT INTO @Temp_BestellPosNeu (kBestellPos,kArtikel,fMenge,kBestellstueckliste) 
				 VALUES (@kBestellpos,@kArtikel,@fMenge,@kBestellstuecklisteNeu);

		    END;
			ELSE
			BEGIN
			    -- Die Menge aus Eazyshipping muß in den Bestellpos gesucht werden, die gefundenen Bestellpos werden temporät zwischengespeichert in @Temp_BestellPosNeu
			    WHILE (@fMenge > 0  AND @nRet >= 0)
			    BEGIN  
				    SET @kBestellposNeu = null;
				    SET @kBestellposAlt = null;
		  
				    SELECT TOP 1 @kBestellposAlt = kBestellPos , @fMengeAlt = fMenge,@kBestellstuecklisteNeu = kBestellstueckliste
				    FROM @Temp_BestellPosAlt
				    WHERE kArtikel = @kArtikel
				    AND fMenge > 0
					ORDER BY  CASE WHEN kBestellStueckliste = @kBestellStueckliste THEN 0 ELSE 1 END,  
				              CASE WHEN fMenge > @fMenge THEN 1 ELSE 0 END,
							  fMenge DESC,
							  kBestellPos ASC;

					IF((@fMengeAlt - @fMenge) < 0.0001 AND (@fMengeAlt - @fMenge > 0))
						SET @fMenge = @fMengeAlt;
		    
				    IF(@kBestellposAlt is null OR @fMengeAlt = 0)
				    BEGIN
					    SET @nRet = -203000201; -- Fehler
				    END
				    ELSE
				    BEGIN
		    
					    SET @MaxMenge = CASE WHEN @fMenge >= @fMengeAlt THEN @fMengeAlt ELSE @fMenge END;
					    SET @fMenge = @fMenge - @MaxMenge;
		    
					    SELECT @kBestellposNeu = kBestellPos 
					    FROM @Temp_BestellPosNeu
					    WHERE kBestellPos = @kBestellposAlt;
    		    
    					    -- Die neuen Bestellpositionen entweder anlagen oder erhöhen
					    IF(@kBestellposNeu is not null) 
					    BEGIN 
    		      
						    UPDATE @Temp_BestellPosNeu
						    SET fMenge = fMenge + @MaxMenge
						    WHERE kBestellPos = @kBestellposNeu;
    		      
    					    END
					    ELSE
					    BEGIN
    		    
						    INSERT INTO @Temp_BestellPosNeu (kBestellPos,kArtikel,fMenge,kBestellstueckliste) 
						    VALUES (@kBestellposAlt,@kArtikel,@MaxMenge,@kBestellstuecklisteNeu);
    		    
					    END
    		    
					    UPDATE @Temp_BestellPosAlt
					    SET fMenge = fMenge - @MaxMenge
					    WHERE kBestellPos = @kBestellposAlt;

				    END
			    END
			END

			FETCH NEXT FROM cur_GetWMSPackItems INTO  @kWMSPackItem,@kArtikel,@fMenge,@kBestellpos,@kBestellStueckliste
		END
		CLOSE cur_GetWMSPackItems;
		DEALLOCATE cur_GetWMSPackItems;

		-- StücklistenVäter per Hand reinmachen, das kommt raus sobald wir die mit in Stücklisten anlegen
		INSERT INTO @Temp_BestellPosNeu(kBestellPos,kArtikel,fMenge)
		SELECT tbestellpos.kBestellStueckliste,Vater.tArtikel_kArtikel, ((MAX(ISNULL(t1.fAnzahlNeu,0.0)) / SUM(ISNULL(tbestellpos.nAnzahl,0.0))) * Vater.nAnzahl) AS fMengeGesammt
		FROM tbestellpos
		JOIN tBestellpos AS Vater ON Vater.kBestellPos = tbestellpos.kBestellStueckliste
		LEFT JOIN (SELECT BestNeu.kBestellStueckliste,SUM(ISNULL(BestNeu.fMenge,0.0)) fAnzahlNeu
				    FROM @Temp_BestellPosNeu BestNeu
				    WHERE BestNeu.kBestellPos != BestNeu.kBestellStueckliste
				    and BestNeu.kBestellStueckliste > 0
				    group by BestNeu.kBestellStueckliste) AS t1 ON  t1.kBestellStueckliste = tbestellpos.kBestellStueckliste
		WHERE tbestellpos.kBestellPos != tbestellpos.kBestellStueckliste
		and tbestellpos.kBestellStueckliste > 0
		and tbestellpos.tBestellung_kBestellung = @kBestellung
		group by Vater.tArtikel_kArtikel,tbestellpos.kBestellStueckliste,Vater.nAnzahl
		HAVING MAX(t1.fAnzahlNeu) > 0;



		IF(@nRet >= 0)
		BEGIN

		   EXEC  Versand.spLieferscheinErstellen 
					   @xLieferschein= null,
					   @kBestellung = @kBestellung,
					   @kBenutzer = @kBenutzer,
					   @cLieferscheinNr = @cLieferscheinNr,
					   @cHinweis= '',
					   @dMailVersand = null,
					   @dGedruckt = null,
					   @nFulfillment = 0,
					   @kLieferantenBestellung = null,
					   @kSessionId = null,
					   @kLieferschein = @kRetLieferschein OUTPUT;


		   IF (@kRetLieferschein > 0)
		   BEGIN

			 DECLARE @LieferscheinPositionen AS XML
			 SET @LieferscheinPositionen = (
				    SELECT 0 AS kLieferscheinPos, @kRetLieferschein AS kLieferschein,BestellPos.kbestellpos AS kBestellPos, SUM(ISNULL(BestellPos.fMenge,0.0)) AS fAnzahl, '' AS cHinweis
				    FROM @Temp_BestellPosNeu BestellPos
		              GROUP BY BestellPos.kbestellpos
			 FOR XML PATH('LieferscheinPos'), TYPE );

			 EXEC [Versand].[spLieferscheinPosErstellen]
							 @xLieferscheinPos = @LieferscheinPositionen,
							 @kLieferschein = null,
							 @kBestellPos = null,
							 @fAnzahl  = null,
							 @cHinweis  = null,
							 @kLieferscheinPos = null;

	        END;
		   ELSE
		     SET @nRet = -1;

	     END;

		SET @nRetError = @nRet;

END;
go

