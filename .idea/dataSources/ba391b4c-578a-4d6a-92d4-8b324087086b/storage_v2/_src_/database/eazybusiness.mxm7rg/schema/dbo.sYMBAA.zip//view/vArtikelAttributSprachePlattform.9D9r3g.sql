CREATE VIEW [dbo].[vArtikelAttributSprachePlattform]
AS
SELECT 
dbo.tAttributShop.kAttribut,
	ArtikelAttribute.kArtikel,
	dbo.tAttributShop.kShop,
	ISNULL(SpezialAttribut.kArtikelAttribut, DefaultAttribut.kArtikelAttribut) AS kArtikelAttribut
FROM dbo.tAttributShop
JOIN (
	SELECT DISTINCT kArtikel, kAttribut FROM dbo.tArtikelAttribut
) AS ArtikelAttribute ON ArtikelAttribute.kAttribut = dbo.tAttributShop.kAttribut
LEFT JOIN dbo.tArtikelAttribut AS SpezialAttribut ON SpezialAttribut.kAttribut = dbo.tAttributShop.kAttribut AND SpezialAttribut.kShop = dbo.tAttributShop.kShop AND SpezialAttribut.kArtikel = ArtikelAttribute.kArtikel
LEFT JOIN dbo.tArtikelAttribut AS DefaultAttribut ON DefaultAttribut.kAttribut = dbo.tAttributShop.kAttribut AND DefaultAttribut.kShop = 0 AND DefaultAttribut.kArtikel = ArtikelAttribute.kArtikel
UNION (
	SELECT
		dbo.tArtikelAttribut.kAttribut,
		dbo.tArtikelAttribut.kArtikel,
		dbo.tShop.kShop,
		dbo.tArtikelAttribut.kArtikelAttribut
	FROM dbo.tArtikelAttribut
	JOIN dbo.tShop ON 1=1
	JOIN dbo.tAttribut ON dbo.tAttribut.kAttribut = dbo.tArtikelAttribut.kAttribut
	WHERE dbo.tArtikelAttribut.kShop = 0 AND dbo.tAttribut.nIstFreifeld = 1
)
go

