--- 
--- spOptimieren
---

CREATE PROCEDURE [dbo].[spOptimieren]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: GJ
--
AS
BEGIN
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
    --
    -- Indizies der Tabellen neuerstellen um die Fragmentierung der Indizies zu beheben
    --

    DECLARE @TableName VARCHAR(255);
    DECLARE @sql NVARCHAR(500);
    DECLARE @fillfactor INT;
    SET @fillfactor = 80;
    DECLARE TableCursor CURSOR FOR
	   SELECT '[' + OBJECT_SCHEMA_NAME(object_id) + '].[' + name + ']' AS TableName
	   FROM [sys].[tables];
    OPEN TableCursor;
    FETCH NEXT FROM [TableCursor] INTO @TableName;
    WHILE @@FETCH_STATUS = 0
    BEGIN
	    SET @sql = 'ALTER INDEX ALL ON ' + @TableName + ' REBUILD WITH (FILLFACTOR = ' + CONVERT(VARCHAR(3),@fillfactor) + ')';
	    EXEC (@sql);
	    FETCH NEXT FROM TableCursor INTO @TableName;
    END;
    CLOSE TableCursor;
    DEALLOCATE TableCursor;

    DELETE dbo.toptions
    WHERE toptions.cKey = 'letzte Index Defragmentierung';
    
	BEGIN TRY
       EXEC sp_updatestats;
	END TRY
	BEGIN CATCH
       EXEC sp_MSforeachtable 'UPDATE STATISTICS ?';
	END CATCH

    INSERT INTO dbo.toptions( cKey , 
                              cValue )
    SELECT 'letzte Index Defragmentierung' , 
           CONVERT( VARCHAR , GETDATE( ));

END;
go

