CREATE TRIGGER [dbo].[tgr_tKategorieShop_UPDATE]
ON [dbo].[tKategorieShop]
AFTER UPDATE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN

	IF(UPDATE(cInet))
	BEGIN
		UPDATE dbo.tKategorieShop 
			SET dbo.tKategorieShop.nInBearbeitung = 0
		FROM dbo.tKategorieShop
		JOIN INSERTED ON dbo.tKategorieShop.kKategorie = INSERTED.kKategorie
			AND dbo.tKategorieShop.kShop = INSERTED.kShop;	
	END
END
go

