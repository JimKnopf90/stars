
    CREATE PROCEDURE unicorn2_spFinishMultiWithRetry @kWawiIdList VARCHAR(MAX), @kShopId INT
    AS
        BEGIN

    		    DECLARE @kWawiIdListLocal VARCHAR(MAX)
				DECLARE @kShopIdLocal INT

    		    DECLARE @kRetry TINYINT
    		    DECLARE @kErrorNumber INT
    		    DECLARE @kErrorLine INT
    		    DECLARE @kErrorMessage VARCHAR(2000)
    		    

    		    SET @kWawiIdListLocal = @kWawiIdList
				SET @kShopIdLocal = @kShopId

    		    SET @kRetry = 9
    		    SET @kErrorNumber = 0
    		    SET @kErrorLine = 0
    		    SET @kErrorMessage = 'unknown'
    		    
    		    WHILE @kRetry > 0
    		        BEGIN
    		            BEGIN TRY
						    SET DEADLOCK_PRIORITY LOW
    		                EXEC unicorn2_spFinishMulti @kWawiIdList = @kWawiIdListLocal, @kShopId = @kShopIdLocal 
							BREAK  
    		            END TRY
    		            BEGIN CATCH
    		                    		                
    		                SET @kErrorNumber = ERROR_NUMBER()
    		                SET @kErrorLine = ERROR_LINE()
    		                SET @kErrorMessage = ERROR_MESSAGE()
    		                
    		                IF (ERROR_NUMBER() = 1203 OR ERROR_NUMBER() = 1204 OR ERROR_NUMBER() = 1205 OR ERROR_NUMBER() = 1222 OR ERROR_NUMBER() = 1807 OR ERROR_NUMBER() = 3616 OR ERROR_NUMBER() = 3609 OR ERROR_NUMBER() = 3991 OR ERROR_NUMBER() = 3992 OR ERROR_NUMBER() = 3993 OR ERROR_NUMBER() = 3994)
    		                    BEGIN 
    		                        SET @kRetry = @kRetry - 1
									
										IF @kRetry = 9
											BEGIN
												WAITFOR DELAY '00:00:00.010' -- Wait for 10 ms
											END
                        				IF @kRetry = 8
											BEGIN
												WAITFOR DELAY '00:00:00.020' -- Wait for 20 ms
											END
                        				IF @kRetry = 7
											BEGIN
												WAITFOR DELAY '00:00:00.050' -- Wait for 50 ms
											END
                        				IF @kRetry = 6
											BEGIN
												WAITFOR DELAY '00:00:00.100' -- Wait for 100 ms
											END
                        				IF @kRetry = 5
											BEGIN
												WAITFOR DELAY '00:00:00.200' -- Wait for 200 ms
											END
                        				IF @kRetry = 4
											BEGIN
												WAITFOR DELAY '00:00:00.500' -- Wait for 500 ms
											END
                        				IF @kRetry = 3
											BEGIN
												WAITFOR DELAY '00:00:01.000' -- Wait for 1 s
											END
                        				IF @kRetry = 2
											BEGIN
												WAITFOR DELAY '00:00:02.000' -- Wait for 2 s
											END
                        				IF @kRetry = 1
											BEGIN
												WAITFOR DELAY '00:00:05.000' -- Wait for 5 s
											END
                        				-- IF @kRetry = 0
										-- RAISERROR ('unicorn 2: Could not execute unicorn2_spFinishMulti. Deadlock retry count was %i, cumulative waittime was 8.880 seconds',16,1,@kRetry) 
                        				
                        				CONTINUE 																		  
    		                    END
    		                ELSE
    		                    BEGIN
									SET @kRetry = @kRetry - 1     		                          		                             

									IF @kRetry > 4
										BEGIN
										  SET @kRetry = 4
										END  
									IF @kRetry = 4
										BEGIN
										  WAITFOR DELAY '00:00:00.020' -- Wait for 20 ms
										END										  
									IF @kRetry = 3
										BEGIN
										  WAITFOR DELAY '00:00:00.050' -- Wait for 50 ms
										END
									IF @kRetry = 2
										BEGIN
										  WAITFOR DELAY '00:00:00.100' -- Wait for 100 ms
										END
									IF @kRetry = 1
										BEGIN
										  WAITFOR DELAY '00:00:00.200' -- Wait for 200 ms
										END
									-- IF @kRetry = 0
										-- RAISERROR ('unicorn 2: Non-deadlock condition encountered. Errornumber: %i Line: %d, Message: %s',16,1,@kErrorNumber,@kErrorLine,@kErrorMessage)  
									
									CONTINUE 
    		                    END		                
    		            END CATCH
    		        END      
        END
    go

