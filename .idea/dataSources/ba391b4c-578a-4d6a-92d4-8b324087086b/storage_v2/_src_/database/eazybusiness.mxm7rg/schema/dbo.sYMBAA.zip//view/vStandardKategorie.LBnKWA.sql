CREATE VIEW [dbo].[vStandardKategorie] AS
SELECT dbo.tKategorie.kKategorie, 
	dbo.tKategorieSprache.cName, 
	dbo.tKategorieSprache.cBeschreibung, 
	dbo.tKategorie.kOberKategorie, 
	dbo.tKategorie.cInet, 
	dbo.tKategorie.cAktiv, 
	dbo.tKategorie.cDelInet, 
	dbo.tKategorie.nSort,
	dbo.tKategorieSprache.cUrlPfad AS cSeo
FROM dbo.tKategorie
JOIN dbo.tSpracheUsed ON dbo.tSpracheUsed.nStandard = 1 
LEFT JOIN dbo.tKategorieSprache ON dbo.tKategorieSprache.kKategorie = dbo.tKategorie.kKategorie 
	AND dbo.tKategorieSprache.kSprache = dbo.tSpracheUsed.kSprache
	AND dbo.tKategorieSprache.kPlattform = 1
go

