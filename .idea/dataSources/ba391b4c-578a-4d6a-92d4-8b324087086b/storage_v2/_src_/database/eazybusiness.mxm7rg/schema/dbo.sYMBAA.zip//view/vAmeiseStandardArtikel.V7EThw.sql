CREATE VIEW [dbo].[vAmeiseStandardArtikel] AS
    --
    -- Copyright (c) 2012-2017 by JTL Software GmbH
    -- Datum: $Date$
    -- Version: $Rev$
    -- Autor: SB/MP
    --
SELECT        dbo.tArtikel.kArtikel, dbo.tArtikel.cArtNr, dbo.tArtikelBeschreibung.cName, dbo.tArtikelBeschreibung.cBeschreibung, dbo.tArtikel.fVKNetto, 
                         dbo.tArtikel.fVKNetto + dbo.tArtikel.fVKNetto / 100 * dbo.tSteuercache.fSteuersatz AS fVKbrutto, dbo.tArtikel.fUVP, dbo.tArtikel.cAnmerkung, dbo.tArtikel.cPreisliste, 
                         dbo.tArtikel.cAktiv, dbo.tArtikel.nLagerbestand, dbo.tSteuercache.fSteuersatz AS fMwSt, VerkaufsEinheitSprache.cName AS cEinheit, dbo.tArtikel.nMindestbestellmaenge, 
                         dbo.tArtikel.cBarcode, dbo.tArtikel.cErloeskonto, 0 AS fVKHaendlerBrutto, 0 AS fVKHaendlerNetto, dbo.tArtikel.cTopArtikel, dbo.tArtikel.cInet, dbo.tArtikel.cDelInet, 
                         dbo.tArtikel.fGewicht, dbo.tArtikel.cNeu, dbo.tArtikelBeschreibung.cKurzBeschreibung, dbo.tArtikel.cLagerArtikel, dbo.tArtikel.cTeilbar, dbo.tArtikel.cLagerAktiv, 
                         dbo.tArtikel.cLagerKleinerNull, dbo.tArtikel.nMidestbestand, dbo.tArtikel.fEKNetto, dbo.tHersteller.cName AS cHersteller, dbo.tArtikel.fEbayPreis, 
                         dbo.tArtikel.cLagerVariation, dbo.tArtikel.nDelete, dbo.tArtikel.dMod, dbo.tArtikel.fPackeinheit, dbo.tArtikel.nVPE, dbo.tArtikel.fVPEWert, 
                         VPEEinheitSprache.cName AS cVPEEinheit, dbo.tLieferStatus.cName AS cLieferstatus, dbo.tArtikel.cSuchbegriffe, dbo.tArtikel.cTaric, dbo.tArtikel.cHerkunftsland, 
                         dbo.tArtikel.kSteuerklasse, dbo.tArtikel.dErstelldatum, dbo.tArtikelBeschreibung.cUrlPfad AS cSeo, dbo.tArtikel.dErscheinungsdatum, dbo.tArtikel.nSort, 
                         dbo.tArtikel.kVersandklasse, dbo.tArtikel.fArtGewicht, dbo.tArtikel.cHAN, dbo.tArtikel.cSerie, dbo.tArtikel.cISBN, dbo.tArtikel.cUNNummer, dbo.tArtikel.cGefahrnr, 
                         dbo.tArtikel.cASIN, dbo.tArtikel.kEigenschaftKombi, dbo.tArtikel.kVaterArtikel, dbo.tArtikel.nIstVater, dbo.tArtikel.nIstMindestbestand, dbo.tArtikel.fAbnahmeintervall, 
                         dbo.tArtikel.kStueckliste, dbo.tArtikel.cUPC, dbo.tArtikel.kWarengruppe, dbo.tArtikel.cEPID, dbo.tArtikel.nMHD, dbo.tArtikel.nCharge, dbo.tArtikel.nNichtBestellbar, 
                         dbo.tArtikel.fAmazonVK, dbo.tArtikel.nPufferTyp, dbo.tArtikel.nPuffer, dbo.tArtikel.nProzentualePreisStaffelAktiv, dbo.tArtikel.nSeriennummernVerfolgung, 
                         dbo.tArtikel.kHersteller, dbo.tArtikel.kLieferStatus, dbo.tArtikel.kMassEinheit, dbo.tArtikel.fMassMenge, dbo.tArtikel.kGrundPreisEinheit, 
                         dbo.tArtikel.fGrundpreisMenge, dbo.tArtikel.fBreite, dbo.tArtikel.fHoehe, dbo.tArtikel.fLaenge, dbo.tArtikel.nLiefertageWennAusverkauft, dbo.tArtikel.kVPEEinheit, 
                         dbo.tArtikel.kVerkaufsEinheit, dbo.tArtikel.dZulaufVerfuegbarAm, dbo.tArtikel.nAutomatischeLiefertageberechnung, dbo.tArtikel.nBearbeitungszeit, dbo.tArtikel.dNeuImSortiment,
						 dbo.tArtikel.fLetzterEK,dbo.tArtikel.dLetzterEK, dbo.tArtikel.kBenutzerLetzteAenderung, dbo.tArtikel.nZulaufVerfuegbarMenge, dbo.tArtikel.nEbayAbgleich,
						 dbo.tArtikel.cAmazonFNSKU, dbo.tArtikel.kZustand,
						 dbo.tArtikelBeschreibung.cMetaDescription,dbo.tArtikelBeschreibung.cMetaKeywords,dbo.tArtikelBeschreibung.cTitleTag,dbo.tArtikelBeschreibung.cUrlPfad
	FROM dbo.tArtikel 
	JOIN dbo.tSpracheUsed ON dbo.tSpracheUsed.nStandard = 1 
	JOIN dbo.tArtikelBeschreibung ON dbo.tArtikelBeschreibung.kArtikel = dbo.tArtikel.kArtikel 
									AND dbo.tArtikelBeschreibung.kSprache = dbo.tSpracheUsed.kSprache 
									AND dbo.tArtikelBeschreibung.kPlattform = 1 
	LEFT JOIN dbo.tSteuercache ON dbo.tSteuercache.kSteuerklasse = dbo.tArtikel.kSteuerklasse
									AND dbo.tSteuercache.kFirma = 0
	LEFT JOIN dbo.tLieferStatus ON dbo.tLieferStatus.kLieferStatus = dbo.tArtikel.kLieferStatus 
									AND dbo.tLieferStatus.kSprache = tSpracheUsed.kSprache 
	LEFT JOIN dbo.tHersteller ON dbo.tHersteller.kHersteller = dbo.tArtikel.kHersteller 
	LEFT JOIN dbo.tEinheitSprache AS VPEEinheitSprache ON VPEEinheitSprache.kEinheit = dbo.tArtikel.kVPEEinheit 
															AND VPEEinheitSprache.kSprache = dbo.tSpracheUsed.kSprache                         
	LEFT JOIN dbo.tEinheitSprache AS VerkaufsEinheitSprache ON VerkaufsEinheitSprache.kEinheit = dbo.tArtikel.kVerkaufsEinheit 
																AND VerkaufsEinheitSprache.kSprache = dbo.tSpracheUsed.kSprache
go

