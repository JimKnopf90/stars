--- 
--- spWarenlagerAusgangPicklistePos
---

CREATE PROCEDURE dbo.spWarenlagerAusgangPicklistePos
@xPicklistePos XML = NULL,
@kPicklistePos INT = NULL,
@cKommentar VARCHAR(255) = NULL,
@kBenutzer INT = NULL
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
	IF(OBJECT_ID('tempdb..#Pickpositionen') IS NOT NULL)
	BEGIN
		DROP TABLE #Pickpositionen;
	END
	CREATE TABLE #Pickpositionen(
		kPickpos INT NOT NULL,
		kBenutzer INT NOT NULL,
		cKommentar VARCHAR(255) NULL
	);
	IF(@xPicklistePos IS NOT NULL)
	BEGIN
		INSERT INTO #Pickpositionen(kPickpos, kBenutzer, cKommentar)
			SELECT DISTINCT ParamValues.ID.value('kPicklistePos[1]', 'VARCHAR(20)'),
					ParamValues.ID.value('kBenutzer[1]', 'VARCHAR(20)'),
					ParamValues.ID.value('cKommentar[1]', 'VARCHAR(255)')
				FROM @xPicklistePos.nodes('/Pickposition') AS ParamValues(ID)
	END
	ELSE
	BEGIN
		INSERT INTO #Pickpositionen(kPickpos, kBenutzer, cKommentar)
			VALUES(@kPicklistePos, @kBenutzer, @cKommentar)
	END
	IF(NOT EXISTS(SELECT * FROM #Pickpositionen))
	BEGIN
		RAISERROR(N'Aufruf dbo.spWarenlagerAusgangPicklistePos ohne korrekte Parameter',15,1);
		RETURN;
	END 
	IF(EXISTS(SELECT #Pickpositionen.kPickpos 
				FROM #Pickpositionen 
				WHERE #Pickpositionen.kPickpos NOT IN (SELECT kPickpos FROM dbo.tPicklistePos)))
	BEGIN
		RAISERROR(N'Aufruf dbo.spWarenlagerAusgangPicklistePos mit ungültiger Pickposition', 15,1);
		RETURN;
	END 
	IF(EXISTS(SELECT #Pickpositionen.kPickpos
				FROM #Pickpositionen
				WHERE #Pickpositionen.kBenutzer NOT IN(SELECT kBenutzer FROM eazybusiness.dbo.tbenutzer)))
	BEGIN
		RAISERROR(N'Aufruf dbo.spWarenLagerAusgangPicklistePos mit ungültigem Benutzer', 15,1);
		RETURN;
	END
	DECLARE @xWarenlagerAusgaenge XML;
	SET @xWarenlagerAusgaenge = (
		SELECT dbo.tPicklistePos.kWarenLagerEingang,
				dbo.tPicklistePos.kLieferscheinPos,
				dbo.tPicklistePos.fAnzahl,
				dbo.tPicklistePos.kWarenlagerPlatz,
				dbo.tPicklistePos.kArtikel,
				#Pickpositionen.cKommentar,
				#Pickpositionen.kBenutzer,
				20 AS kBuchungsart
			FROM #Pickpositionen 
			JOIN dbo.tPicklistePos ON dbo.tPicklistePos.kPicklistePos = #Pickpositionen.kPickpos
			FOR XML PATH('WarenAusgang'), TYPE
		);
	EXEC spWarenlagerAusgangSchreiben @xWarenlagerAusgaenge;
END
go

