CREATE TRIGGER [dbo].[tgr_tbestellung_Connector_DELETE]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: FB
--
ON [dbo].[tbestellung]
AFTER DELETE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
    --Überprüfen ob Trigger gefüllt aufgerufen wird
    IF((SELECT COUNT(1)
        FROM DELETED
        WHERE DELETED.kShop > 0) = 0)
    BEGIN
        RETURN;
    END;

    --
    -- Connector-Bestellungen
    --
    -- Bisherige Queue-Einträge entfernen
    DELETE dbo.tQueue
    FROM dbo.tQueue
    JOIN DELETED ON dbo.tQueue.kOption1 = DELETED.kBestellung
    JOIN dbo.tShop ON dbo.tQueue.kShop = dbo.tShop.kShop
                AND dbo.tShop.nTyp = 1
    WHERE dbo.tQueue.cName = 'tBestellung';

    -- Lösch-Eintrag in tQueue schreiben
    INSERT INTO dbo.tQueue (kShop, kPlattform, cName, kWert, nAction, kOption1, kOption2, nInBearbeitung)
    SELECT DELETED.kShop, 2, 'tBestellung', 0, 2, DELETED.kBestellung, 0, 0
    FROM DELETED
    JOIN dbo.tShop ON DELETED.kShop = dbo.tShop.kShop
                AND dbo.tShop.nTyp = 1;

    --
    -- JTL-Shop-Bestellungen
    --
    -- Bisherige Queue-Einträge entfernen
    DELETE dbo.tQueue
    FROM dbo.tQueue
    JOIN DELETED ON dbo.tQueue.kWert = DELETED.kInetBestellung
    JOIN dbo.tShop ON dbo.tQueue.kShop = dbo.tShop.kShop
                AND dbo.tShop.nTyp = 0
    WHERE dbo.tQueue.cName = 'tBestellung';

    -- Lösch-Eintrag in tQueue schreiben
    INSERT INTO dbo.tQueue (kShop, kPlattform, cName, kWert, nAction, kOption1, kOption2, nInBearbeitung)
    SELECT DELETED.kShop, 2, 'tBestellung', DELETED.kInetBestellung, 2, 0, 0, 0
    FROM DELETED
    JOIN dbo.tShop ON DELETED.kShop = dbo.tShop.kShop
            AND dbo.tShop.nTyp = 0;
END
go

