CREATE TRIGGER [dbo].[jtlActionValidator_tRMRetoure]
	--
	-- Copyright (c) 2012-2017 by JTL Software GmbH
	-- Datum: $Date$
	-- Version: $Rev$
	-- Autor: MP
	--
	ON [dbo].[tRMRetoure]
	AFTER DELETE
	AS
	SET NOCOUNT ON;
	SET ANSI_NULLS ON;
	SET ANSI_NULL_DFLT_ON ON;
	SET ANSI_PADDING ON;
	SET CONCAT_NULL_YIELDS_NULL ON;
	SET XACT_ABORT OFF;
	BEGIN

		--
		-- Zugehoerige Retourpositionen entfernen
		--
		
	DELETE dbo.tRMRetourePos
	FROM dbo.tRMRetourePos
	JOIN DELETED ON dbo.tRMRetourePos.kRmRetoure = DELETED.kRmRetoure;
		
	DELETE dbo.tRMRetoureAbholAdresse
	FROM dbo.tRMRetoureAbholAdresse
	JOIN DELETED ON dbo.tRMRetoureAbholAdresse.kRMRetoureAbholAdresse = DELETED.kRMRetoureAbholAdresse;	
	
	DELETE dbo.tRMRetourenEtikett
	FROM dbo.tRMRetourenEtikett
	JOIN DELETED ON dbo.tRMRetourenEtikett.kRmRetoure = DELETED.kRmRetoure;
		
	DELETE dbo.tRMRetoureAustauschArtikel
	FROM dbo.tRMRetoureAustauschArtikel
	JOIN DELETED ON dbo.tRMRetoureAustauschArtikel.kRmRetoure = DELETED.kRmRetoure;

	END
go

