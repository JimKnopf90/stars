
    CREATE VIEW unicorn2_vVersand 
    AS
        SELECT kId, kWawiId, dChangedDate
        FROM unicorn2_tChangeCache WITH (NOLOCK)
        WHERE cStatus = 'Add' AND cType = 'Versand';
    go

