--
-- CleanUp-Trigger für das Löschen von WMS-Lagerbereichen
--
	CREATE TRIGGER [dbo].[jtlActionValidator_tWMSLagerbereich]
	--
	-- Copyright (c) 2012-2017 by JTL Software GmbH
	-- Datum: $Date$
	-- Version: $Rev$
	-- Autor: MaikS
	--
	ON [dbo].[tWMSLagerBereich]
	AFTER DELETE
	AS
	SET NOCOUNT ON;
	SET ANSI_NULLS ON;
	SET ANSI_NULL_DFLT_ON ON;
	SET ANSI_PADDING ON;
	SET CONCAT_NULL_YIELDS_NULL ON;
	SET XACT_ABORT OFF;
	BEGIN
	  IF EXISTS(SELECT 1 FROM DELETED)
	  BEGIN
		--
		-- WMS-Lagerbereich-Platz-Zuordnung entfernen
		--
			DELETE twmslagerbereichplatz WITH(ROWLOCK)
			FROM twmslagerbereichplatz WITH(ROWLOCK)
			JOIN DELETED ON twmslagerbereichplatz.kwmslagerbereich = DELETED.kwmslagerbereich
			
		---
		--- Vorgabe Lagerbereiche für Artikel Löschen
		---
			DELETE tWarenlagerArtikelOptionen WITH(ROWLOCK)
			FROM tWarenlagerArtikelOptionen WITH(ROWLOCK)
			JOIN DELETED ON tWarenlagerArtikelOptionen.kwmslagerbereich = DELETED.kwmslagerbereich
				
	  END
	END
go

