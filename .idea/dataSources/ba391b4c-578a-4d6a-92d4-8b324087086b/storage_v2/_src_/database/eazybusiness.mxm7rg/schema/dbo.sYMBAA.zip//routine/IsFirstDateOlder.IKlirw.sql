CREATE FUNCTION IsFirstDateOlder(@date1 DATETIME, @date2 DATETIME)
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Author: Martin Kuen
--
-- Gibt 1 zurück wenn @date 1 älter als @date 2 ist sonst 0
--
RETURNS TINYINT
AS
BEGIN
	RETURN(SELECT CASE WHEN CONVERT(DECIMAL(14,8), @date1) - CONVERT(DECIMAL(14,8), @date2) > 0
				THEN 0
				ELSE 1
			 END	 
	)
END
go

