--- 
--- spGutschriftposVonGutschriftLoeschen
---

CREATE PROCEDURE [dbo].[spGutschriftposVonGutschriftLoeschen]
	@xGutschrift XML = NULL,
	@kGutschrift INT = NULL
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
DECLARE @ErrorMessage NVARCHAR(4000);
DECLARE @ErrorSeverity INT;
DECLARE @ErrorState INT;
DECLARE @retry INT;
SET @retry = 5;
WHILE @retry > 0
BEGIN
	SET CONTEXT_INFO 0x0;
	BEGIN TRY
		BEGIN TRANSACTION
			IF(OBJECT_ID('tempdb..#Gutschrift') IS NOT NULL)
			BEGIN
				DROP TABLE #Gutschrift;
			END
			CREATE TABLE #Gutschrift (kGutschrift INT);
			IF(@xGutschrift IS NOT NULL)
			BEGIN
				INSERT INTO #Gutschrift(kGutschrift)
					SELECT Gutschrift.ID.value('kGutschrift[1]', 'INT')
						FROM @xGutschrift.nodes('Gutschrift') AS Gutschrift(ID);
			END
			ELSE
			BEGIN
				INSERT INTO #Gutschrift(kGutschrift)
					VALUES(@kGutschrift);
			END
			DECLARE @xGutschriftpos XML;
			SET @xGutschriftpos = (
				SELECT dbo.tGutschriftpos.kGutschriftPos
					FROM #Gutschrift
					JOIN dbo.tGutschriftpos ON dbo.tGutschriftpos.tGutschrift_kGutschrift = #Gutschrift.kGutschrift
					FOR XML PATH('Gutschriftpos'), TYPE
				);
			IF(@xGutschriftpos IS NOT NULL)
			BEGIN
				EXEC Gutschrift.spGutschriftposLoeschen @xGutschriftpos;
			END			
			SET @retry = -1;
			SET CONTEXT_INFO 0x0;
		COMMIT
	END TRY
	BEGIN CATCH
	IF(ERROR_NUMBER() = 1205)
			BEGIN
				SET @retry = @retry - 1;
				ROLLBACK;
				WAITFOR DELAY '00:00:00:5';
			END
			ELSE 
			BEGIN
				SET @retry = -1;
				SELECT @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
				ROLLBACK;
				RAISERROR (	@ErrorMessage, 
							@ErrorSeverity,
							@ErrorState
				);
				SET CONTEXT_INFO 0x0;
				RETURN;
			END
	END CATCH
	SET CONTEXT_INFO 0x0;	
END
go

