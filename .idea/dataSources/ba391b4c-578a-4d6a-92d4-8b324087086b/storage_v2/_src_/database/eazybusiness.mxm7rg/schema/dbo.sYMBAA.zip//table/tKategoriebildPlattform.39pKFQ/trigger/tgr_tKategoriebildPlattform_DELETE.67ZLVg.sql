CREATE TRIGGER [dbo].[tgr_tKategoriebildPlattform_DELETE]  
--     
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Author: Markus Hütz
--    
ON [dbo].[tKategoriebildPlattform]  
AFTER DELETE
AS 
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
    IF((SELECT COUNT(1) FROM DELETED) = 0) 
    BEGIN
	   RETURN;
    END;

    --
    -- tQueue für jeden gelöschten Datensatz schreiben
    --
    INSERT INTO dbo.tQueue (kShop, kPlattform, cName, kWert, nAction, kOption1, kOption2)
    SELECT kShop = DELETED.kShop, kPlattform = DELETED.kPlattform, cName = 'tKategoriebildPlattform', kWert = DELETED.kKategoriebildPlattform, nAction = 2, kOption1 = DELETED.kKategorie, kOption2 = DELETED.nNr
    FROM DELETED
	WHERE DELETED.kShop > 0;

    --
    -- tBild ggfs. aufräumen
    --
	DECLARE @Bilder AS TYPE_spBildLoeschenWennNichtVerwendet;

    INSERT INTO @Bilder (kBild)
	SELECT DELETED.kBild
	FROM DELETED
	WHERE DELETED.kPlattform = 1
	GROUP BY DELETED.kBild;

    EXEC dbo.spBildLoeschenWennNichtVerwendet @Bilder;
END
go

