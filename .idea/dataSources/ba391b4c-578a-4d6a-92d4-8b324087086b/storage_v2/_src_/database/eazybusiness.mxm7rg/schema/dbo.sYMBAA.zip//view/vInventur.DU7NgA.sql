CREATE VIEW [dbo].[vInventur]
AS
WITH Bestände(kArtikel, fBestand, kWarenlager) 
AS 
(
	SELECT	tlagerbestandProLagerLagerartikel.kArtikel,
			ISNULL(tlagerbestandProLagerLagerartikel.fBestand, 0) AS fBestand,
			tlagerbestandProLagerLagerartikel.kWarenLager
	FROM dbo.tlagerbestandProLagerLagerartikel
)
--
-- Bestandsartikel
--
SELECT	Bestände.kArtikel,
		Bestände.fBestand,
		Bestände.kWarenlager
FROM Bestände
UNION
--
-- Virtuelle Bestände (Stückliste)
--
SELECT	dbo.tArtikel.kArtikel,
		CASE WHEN dbo.tArtikel.cTeilbar = 'Y'
			THEN CONVERT(DECIMAL(28, 14), MIN(ISNULL(Bestände.fBestand, 0.0) / dbo.tStueckliste.fAnzahl))
			ELSE CONVERT(DECIMAL(28,14) , FLOOR(MIN(ISNULL(Bestände.fBestand, 0.0) / dbo.tStueckliste.fAnzahl)))		
		END AS fBestand,
		dbo.tWarenLager.kWarenLager
FROM dbo.tArtikel
JOIN dbo.tWarenLager ON dbo.tWarenLager.nAktiv = 1
JOIN dbo.tStueckliste ON dbo.tArtikel.kStueckliste = dbo.tStueckliste.kStueckliste
JOIN dbo.tArtikel AS komponenten ON dbo.tStueckliste.kArtikel = komponenten.kArtikel
LEFT JOIN Bestände ON dbo.tStueckliste.kArtikel = Bestände.kArtikel
	AND dbo.tWarenLager.kWarenLager = Bestände.kWarenlager
WHERE	dbo.tArtikel.kStueckliste > 0
		AND komponenten.cLagerAktiv = 'Y'
		AND dbo.tArtikel.cAktiv = 'Y'			
GROUP BY	dbo.tArtikel.kArtikel,
			dbo.tArtikel.cTeilbar,			
			dbo.tWarenLager.kWarenLager
UNION
SELECT	Beständekumuliert.kArtikel,
		SUM(Beständekumuliert.fBestand) AS fBestand,
		Beständekumuliert.kWarenLager
FROM
(
	--
	-- Virtuelle Bestände (Varkombivater = Summe der Kinder die keine Stückliste sind)
	--
	SELECT	dbo.tArtikel.kVaterArtikel AS kArtikel,
			SUM(Bestände.fBestand) AS fBestand,
			Bestände.kWarenlager
	FROM dbo.tArtikel
	JOIN Bestände ON dbo.tArtikel.kArtikel = Bestände.kArtikel
	WHERE	dbo.tArtikel.cLagerAktiv = 'Y'
			AND dbo.tArtikel.cAktiv = 'Y'
			AND dbo.tArtikel.kVaterArtikel > 0		
	GROUP BY	dbo.tArtikel.kVaterArtikel,				
				Bestände.kWarenlager
	UNION
	--
	-- Virtuelle Bestände (Varkombivater = Summe der Kinder die Stückliste sind)
	--
	SELECT	dbo.tArtikel.kVaterArtikel,
			CASE WHEN dbo.tArtikel.cTeilbar = 'Y'
				THEN CONVERT(DECIMAL(28, 14), MIN(ISNULL(Bestände.fBestand, 0.0) / dbo.tStueckliste.fAnzahl))
				ELSE CONVERT(DECIMAL(28,14) , FLOOR(MIN(ISNULL(Bestände.fBestand, 0.0) / dbo.tStueckliste.fAnzahl)))		
			END AS fBestand,
			dbo.tWarenLager.kWarenLager
	FROM dbo.tArtikel
	JOIN dbo.tWarenLager ON dbo.tWarenLager.nAktiv = 1
	JOIN dbo.tStueckliste ON dbo.tArtikel.kStueckliste = dbo.tStueckliste.kStueckliste
	JOIN dbo.tArtikel AS komponenten ON dbo.tStueckliste.kArtikel = komponenten.kArtikel
	LEFT JOIN Bestände ON dbo.tStueckliste.kArtikel = Bestände.kArtikel
		AND dbo.tWarenLager.kWarenLager = Bestände.kWarenlager
	WHERE	dbo.tArtikel.kStueckliste > 0
			AND komponenten.cLagerAktiv = 'Y'
			AND dbo.tArtikel.cAktiv = 'Y'	
			AND dbo.tArtikel.kVaterArtikel > 0			
	GROUP BY	dbo.tArtikel.kVaterArtikel,
				dbo.tArtikel.cTeilbar,			
				dbo.tWarenLager.kWarenLager
) AS Beständekumuliert
GROUP BY	Beständekumuliert.kArtikel,
			Beständekumuliert.kWarenlager
go

