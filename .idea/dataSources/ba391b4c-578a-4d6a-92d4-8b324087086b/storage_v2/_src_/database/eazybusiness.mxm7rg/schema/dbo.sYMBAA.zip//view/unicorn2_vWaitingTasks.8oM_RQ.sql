
    CREATE VIEW unicorn2_vWaitingTasks 
    AS
        SELECT 
        		dm_ws.wait_duration_ms,
        		dm_ws.wait_type,
        		dm_es.status,
        		dm_t.TEXT,
        		dm_qp.query_plan,
        		dm_ws.session_ID,
        		dm_es.cpu_time,
        		dm_es.memory_usage,
        		dm_es.logical_reads,
        		dm_es.total_elapsed_time,
        		dm_es.program_name,
        		DB_NAME(dm_r.database_id) DatabaseName,
        		dm_ws.blocking_session_id,
        		dm_r.wait_resource,
        		dm_es.login_name,
        		dm_r.command,
        		dm_r.last_wait_type
        FROM 
        		sys.dm_os_waiting_tasks dm_ws WITH (NOLOCK) 
        INNER JOIN
        		sys.dm_exec_requests dm_r ON dm_ws.session_id = dm_r.session_id
        INNER JOIN 
        		sys.dm_exec_sessions dm_es ON dm_es.session_id = dm_r.session_id
        CROSS APPLY 
        		sys.dm_exec_sql_text (dm_r.sql_handle) dm_t
        CROSS 
        		APPLY sys.dm_exec_query_plan (dm_r.plan_handle) dm_qp
        WHERE
            dm_ws.session_id >= 50 AND 
            dm_ws.session_id <> @@spid AND 
        	dm_ws.session_id IS NOT NULL AND 
        	dm_ws.wait_duration_ms >= 80 AND
			dm_t.TEXT NOT LIKE '%unicorn2_BackgroundWorker%';
    go

