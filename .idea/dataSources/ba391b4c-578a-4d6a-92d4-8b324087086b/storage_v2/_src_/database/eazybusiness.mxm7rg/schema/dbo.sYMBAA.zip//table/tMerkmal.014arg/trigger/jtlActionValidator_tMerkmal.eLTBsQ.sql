CREATE TRIGGER [dbo].[jtlActionValidator_tMerkmal]  
--     
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MaikS
--    
ON [dbo].[tMerkmal]  
AFTER DELETE 
AS 
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF; 
BEGIN 

	--
	--Überprüfen ob Trigger mit Inhalt aufgerufen wird
	--
	IF((SELECT COUNT(1) FROM DELETED) = 0)
	BEGIN
		RETURN;
	END;

	--
	-- tMerkmalBild aufräumen
	--
	DELETE dbo.tMerkmalBildPlattform
	FROM dbo.tMerkmalBildPlattform
	JOIN DELETED ON DELETED.kMerkmal = dbo.tMerkmalBildPlattform.kMerkmal;
 

 	--
	-- MerkmalGruppeMerkmal aufräumen
	--
	DELETE dbo.tMerkmalGruppeMerkmal
	FROM dbo.tMerkmalGruppeMerkmal
	JOIN DELETED ON DELETED.kMerkmal = dbo.tMerkmalGruppeMerkmal.kMerkmal;

	--	
	-- MerkmalSprache aufräumen
	--
	DELETE dbo.tMerkmalSprache
	FROM dbo.tMerkmalSprache
	JOIN DELETED ON DELETED.kMerkmal = dbo.tMerkmalSprache.kMerkmal;

	--	
	-- MerkmalWert aufräumen
	--
	DELETE dbo.tMerkmalWert
	FROM dbo.tMerkmalWert
	JOIN DELETED ON DELETED.kMerkmal = dbo.tMerkmalWert.kMerkmal;

	DELETE dbo.tQueue
	FROM dbo.tQueue
	JOIN DELETED ON dbo.tQueue.kWert = DELETED.kMerkmal
	WHERE dbo.tQueue.cName = 'tMerkmal';
				 
	--
	-- tQueue schreiben um Merkmale zu senden
	--
	INSERT INTO dbo.tQueue(kShop, kPlattform, cName, kWert, nAction)
	SELECT dbo.tShop.kShop, 2, 'tMerkmal', DELETED.kMerkmal, 2
	FROM DELETED
	CROSS JOIN dbo.tShop
	LEFT JOIN dbo.tQueue ON dbo.tQueue.kShop = dbo.tShop.kShop
			AND dbo.tQueue.kPlattform = 2
			AND dbo.tQueue.cName = 'tMerkmal'
			AND dbo.tQueue.kWert = DELETED.kMerkmal
			AND dbo.tQueue.nAction = 2
	WHERE dbo.tQueue.kWert IS NULL
	AND DELETED.nVerwendungszweck IN (0, 3);

END
go

