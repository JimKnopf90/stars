--- 
--- spReservierungAktualisieren
---

CREATE PROCEDURE [dbo].[spReservierungAktualisieren]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP/MK
--
@xPositionen XML,
@firstCall TINYINT = NULL
AS

IF(CONTEXT_INFO() = 0x5087 OR CONTEXT_INFO() = 0x5052 OR CONTEXT_INFO() = 0x5068)
    RETURN;

SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;

DECLARE @ErrorSeverity INT;
DECLARE @ErrorState INT;
DECLARE @ErrorMessage VARCHAR(MAX);


BEGIN
	--
	-- SP arbeitet auf @spReservierungAktualisierenBestellPositionen (kKey INT, nPlattform INT)
	--
	--	nPlattform: 1 = Wawi, 2 = eBay, 3 = Amazon
	--
	-- Beinhaltet nur Bestellungen, die folgende Bedinungen erfüllen:
	--	nKomplettausgeliefert = 0
	--	nStorno = 0
	--	
	IF(object_id('tempdb..#spReservierungAktualisierenBestellPositionen') IS NOT NULL)
    BEGIN
	  DROP TABLE #spReservierungAktualisierenBestellPositionen
    END
    CREATE TABLE #spReservierungAktualisierenBestellPositionen (kKey INT, nPlattform INT, kArtikel INT, fAnzahl DECIMAL(28,14), fBestandReserviert DECIMAL(28,14), fBestandReserviertEigen DECIMAL(28,14), kBestellung INT)
    INSERT INTO #spReservierungAktualisierenBestellPositionen(kKey, nPlattform, kArtikel, fAnzahl, fBestandReserviert, fBestandReserviertEigen, kBestellung)
		SELECT DISTINCT ParamValues.ID.value('kKey[1]','VARCHAR(20)') AS kKey,
			   ParamValues.ID.value('nPlattform[1]','VARCHAR(20)') AS nPlattform,
			   0 AS kArtikel,
			   0.0 AS fAnzahl,
			   0.0 AS fBestandReserviert,
			   0.0 AS fBestandReserviertEigen,
			   0 AS kBestellung
			FROM @xPositionen.nodes('/Keys') AS ParamValues(ID) 
			JOIN dbo.tbestellpos ON ParamValues.ID.value('kKey[1]','VARCHAR(20)') = dbo.tBestellpos.kBestellPos
				AND ParamValues.ID.value('nPlattform[1]','VARCHAR(20)') = 1
			JOIN dbo.tBestellung ON tBestellung.kBestellung = dbo.tbestellpos.tBestellung_kBestellung
				WHERE dbo.tBestellung.nStorno = 0
					AND ParamValues.ID.value('nPlattform[1]','VARCHAR(20)') IS NOT NULL
					AND ParamValues.ID.value('kKey[1]','VARCHAR(20)') IS NOT NULL;
		IF(NOT EXISTS(SELECT kArtikel FROM #spReservierungAktualisierenBestellPositionen))
		BEGIN
			RETURN
		END
		--
		-- Alten Werte rausholen, da als nächstes gelöscht und neu inserted wird
		--
		UPDATE #spReservierungAktualisierenBestellPositionen
			SET fAnzahl = dbo.tReserviert.fAnzahl,
				fBestandReserviert = dbo.tReserviert.fBestandReserviert,
				fBestandReserviertEigen = dbo.tReserviert.fBestandReserviertEigen,
				kBestellung = dbo.tReserviert.kBestellung
			FROM #spReservierungAktualisierenBestellPositionen AS TempValue
			JOIN dbo.tReserviert WITH(NOLOCK) ON TempValue.kKey = dbo.tReserviert.kKey
				AND dbo.tReserviert.kPlattform = TempValue.nPlattform;
		
		--
		-- Neue Werte für kBestellpos rausholen, da als nächstes gelöscht und neu inserted wird
		--
		IF(EXISTS(SELECT Positionen.kKey 
					FROM #spReservierungAktualisierenBestellPositionen AS Positionen
					WHERE Positionen.nPlattform = 1))
		BEGIN
			UPDATE #spReservierungAktualisierenBestellPositionen 
				SET kArtikel = dbo.tbestellpos.tArtikel_kArtikel
				FROM #spReservierungAktualisierenBestellPositionen AS TempValue
				JOIN dbo.tbestellpos WITH(NOLOCK) ON TempValue.kKey = dbo.tbestellpos.kBestellpos
					AND TempValue.nPlattform = 1
		END

		DELETE dbo.tReserviert
			FROM dbo.tReserviert
			JOIN #spReservierungAktualisierenBestellPositionen AS TempValue ON TempValue.kKey = dbo.tReserviert.kKey
				AND dbo.tReserviert.kPlattform = TempValue.nPlattform


		DECLARE @retry INT;
		SET @retry = 50;
		WHILE @retry > 0
		BEGIN
			BEGIN TRANSACTION
				BEGIN TRY

					--
					-- Temporäre Tabelle für ReservierungsEckdaten
					--
					IF(OBJECT_ID('tempdb..#ReservierungEckdaten') IS NOT NULL)
					BEGIN
						DROP TABLE #ReservierungEckdaten;
					END
					CREATE TABLE #ReservierungEckdaten
					(
						kArtikel INT,
						fAnzahl DECIMAL(28,14),
						kKey INT,
						nPlattform INT,
						kBestellung INT
					);
					--
					-- Fehlende Wawi Reservierungen anlegen
					--	
					IF(EXISTS(SELECT * FROM #spReservierungAktualisierenBestellPositionen WHERE #spReservierungAktualisierenBestellPositionen.nPlattform = 1))
					BEGIN
						INSERT INTO #ReservierungEckdaten
						(
							kArtikel,
							fAnzahl,
							kKey,
							nPlattform,
							kBestellung
						)
						SELECT	WawiReservierungen.kArtikel, 
								WawiReservierungen.fAnzahl, 
								WawiReservierungen.kBestellpos AS kKey, 
								1 AS nPlattform, 				    
								WawiReservierungen.tBestellung_kBestellung AS kBestellung
							FROM
							(
								--
								-- Normale Artikel
								--
								SELECT	dbo.tbestellpos.tArtikel_kArtikel AS kArtikel,
										dbo.tbestellpos.kBestellPos, 
										dbo.tbestellpos.tBestellung_kBestellung,
										fAnzahl = CASE WHEN dbo.tbestellpos.nAnzahl - ISNULL(Gutschriften.nAnzahl, 0.0) - ISNULL(Lieferscheine.fAnzahl, 0.0) < 0.0
															THEN 0.0
														ELSE dbo.tbestellpos.nAnzahl - ISNULL(Gutschriften.nAnzahl, 0.0) - ISNULL(Lieferscheine.fAnzahl, 0.0)
													END
									FROM #spReservierungAktualisierenBestellPositionen  AS TempValue
									JOIN dbo.tbestellpos WITH(NOLOCK) ON TempValue.kKey = dbo.tbestellpos.kBestellPos 		
									LEFT JOIN
									(
										SELECT dbo.tgutschriftpos.kBestellPos,
												SUM(ISNULL(dbo.tgutschriftpos.nAnzahl, 0.0)) AS nAnzahl
											FROM dbo.tgutschriftpos WITH(NOLOCK)
											GROUP BY dbo.tgutschriftpos.kBestellPos
									) AS Gutschriften ON dbo.tbestellpos.kBestellPos = Gutschriften.kBestellPos
									LEFT JOIN
									(
										SELECT dbo.tLieferscheinPos.kBestellPos,
												SUM(ISNULL(dbo.tLieferscheinPos.fAnzahl, 0.0)) AS fAnzahl
											FROM dbo.tLieferscheinPos WITH(NOLOCK)
											GROUP BY dbo.tLieferscheinPos.kBestellPos
									) AS Lieferscheine ON dbo.tbestellpos.kBestellPos = Lieferscheine.kBestellPos
									WHERE TempValue.nPlattform = 1 
										AND TempValue.kArtikel > 0
										AND tbestellpos.nType IN(1,11)
								--
								-- Freipositionen
								--
								UNION ALL
								SELECT	dbo.tbestellpos.tArtikel_kArtikel, 
										dbo.tbestellpos.kBestellPos, 
										dbo.tbestellpos.tBestellung_kBestellung,
										fAnzahl = CASE WHEN dbo.tbestellpos.nAnzahl - ISNULL(Gutschriften.nAnzahl, 0.0) - ISNULL(Lieferscheine.fAnzahl, 0.0) < 0.0
															THEN 0.0
														ELSE dbo.tbestellpos.nAnzahl - ISNULL(Gutschriften.nAnzahl, 0.0) - ISNULL(Lieferscheine.fAnzahl, 0.0)
													END
									FROM #spReservierungAktualisierenBestellPositionen AS TempValue
									JOIN dbo.tbestellpos WITH(NOLOCK) ON TempValue.kKey = dbo.tbestellpos.kBestellPos 					
									LEFT JOIN
									(
										SELECT dbo.tgutschriftpos.kBestellPos,
												SUM(ISNULL(dbo.tgutschriftpos.nAnzahl, 0.0)) AS nAnzahl
											FROM dbo.tgutschriftpos WITH(NOLOCK)
											GROUP BY dbo.tgutschriftpos.kBestellPos
									) AS Gutschriften ON dbo.tbestellpos.kBestellPos = Gutschriften.kBestellPos
									LEFT JOIN
									(
										SELECT dbo.tLieferscheinPos.kBestellPos,
												SUM(ISNULL(dbo.tLieferscheinPos.fAnzahl, 0.0)) AS fAnzahl
											FROM dbo.tLieferscheinPos WITH(NOLOCK)
											GROUP BY dbo.tLieferscheinPos.kBestellPos
									) AS Lieferscheine ON dbo.tbestellpos.kBestellPos = Lieferscheine.kBestellPos
									WHERE TempValue.nPlattform = 1				
										AND dbo.tbestellpos.nType IN(0,11)
							) AS WawiReservierungen
							JOIN dbo.tbestellung WITH(NOLOCK) ON WawiReservierungen.tBestellung_kBestellung = dbo.tbestellung.kBestellung 							
							WHERE dbo.tBestellung.cType IN ('B','U');
					END


					--
					-- neue Reservierungen einfügen
					--	
					--
					-- Temporäre Tabelle zum Zwischenspeichern des Ergebnisses
					--
					IF(OBJECT_ID('tempdb..#ReserviertTemp') IS NOT NULL)
					BEGIN
						DROP TABLE #ReserviertTemp;
					END
					CREATE TABLE #ReserviertTemp(kArtikel INT, 
						fAnzahl DECIMAL(28,14), 
						kKey INT, 
						kPlattform INT,
						fBestandReserviert DECIMAL(28,14),
						fBestandReserviertEigen DECIMAL(28,14), 
						kBestellung INT)	
			
					--
					-- Fehlende Datensätze in tReserviert anlegen, damit diese aktualisiert werden können.
					--
					INSERT INTO #ReserviertTemp (kArtikel, fAnzahl, kKey, kPlattform, fBestandReserviert, fBestandReserviertEigen, kBestellung)		
					SELECT Reservierungen.kArtikel, 
						Reservierungen.fAnzahl, 
						Reservierungen.kKey, 
						Reservierungen.nPlattform, 
						fBestandReserviert = 
							CASE WHEN Reservierungen.kArtikel = 0 OR tArtikel.cLagerAktiv = 'N'
								THEN Reservierungen.fAnzahl
								ELSE 
									CASE WHEN dbo.tlagerbestand.fLagerbestand <= Reservierungen.fAnzahl 
										THEN dbo.tlagerbestand.fLagerbestand
										ELSE Reservierungen.fAnzahl
									END
							END, 
						fBestandReserviertEigen =
							CASE WHEN Reservierungen.kArtikel = 0 OR tArtikel.cLagerAktiv = 'N'
								THEN Reservierungen.fAnzahl
								ELSE 					
									CASE WHEN dbo.tlagerbestand.fLagerbestandEigen <= Reservierungen.fAnzahl 
										THEN dbo.tlagerbestand.fLagerbestandEigen
										ELSE Reservierungen.fAnzahl
									END
							END, 
						Reservierungen.kBestellung 
						FROM #ReservierungEckdaten AS Reservierungen
						JOIN #spReservierungAktualisierenBestellPositionen AS ReservierungenTemp ON Reservierungen.kKey = ReservierungenTemp.kKey 
						AND Reservierungen.nPlattform = ReservierungenTemp.nPlattform 		  
						LEFT JOIN dbo.tartikel WITH(NOLOCK) ON ReservierungenTemp.kArtikel = dbo.tartikel.kArtikel 
							AND dbo.tartikel.cLagerAktiv = 'Y'
						LEFT JOIN dbo.tlagerbestand WITH(NOLOCK) ON dbo.tartikel.kArtikel = dbo.tlagerbestand.kArtikel
			
							
    				INSERT INTO dbo.tReserviert(kArtikel, fAnzahl, kKey, kPlattform, fBestandReserviert, fBestandReserviertEigen, kBestellung)
						SELECT DISTINCT kArtikel, fAnzahl, kKey, kPlattform, fBestandReserviert, fBestandReserviertEigen, #ReserviertTemp.kBestellung
						FROM #ReserviertTemp
						JOIN dbo.tBestellung ON #ReserviertTemp.kBestellung = dbo.tBestellung.kBestellung
						WHERE dbo.tbestellung.nKomplettAusgeliefert < 2;
						;

						-- Lagerbestand
						UPDATE dbo.tlagerbestand
						   SET fInAuftraegen = Result.fAnzahl,
							fVerfuegbar = dbo.tlagerbestand.fLagerbestand - dbo.tLagerbestand.fVerfuegbarGesperrt - Result.fAnzahl
						   FROM dbo.tlagerbestand 
						   JOIN (
							SELECT dbo.tReserviert.kArtikel,
							  SUM(dbo.tReserviert.fAnzahl) AS fAnzahl
							 FROM dbo.tReserviert 
							 JOIN(SELECT DISTINCT #ReserviertTemp.kArtikel
							  FROM #ReserviertTemp 
							 ) AS Artikel ON Artikel.kArtikel = dbo.tReserviert.kArtikel
							 JOIN dbo.tArtikel ON dbo.tArtikel.kArtikel = dbo.tReserviert.kArtikel
							 GROUP BY dbo.tReserviert.kArtikel
						   )AS Result ON dbo.tlagerbestand.kArtikel = Result.kArtikel
						   JOIN dbo.tArtikel ON Result.kArtikel = dbo.tArtikel.kArtikel
						   WHERE dbo.tArtikel.cLagerVariation <> 'Y';
						-- Verfügbarkeit Lagerbestand Stücklisten
						UPDATE dbo.tlagerbestand
							SET fVerfuegbar = Result.fVerfuegbar
							FROM dbo.tlagerbestand
							JOIN (SELECT dbo.vLagerbestandStueckliste.kArtikel, dbo.vLagerbestandStueckliste.fVerfuegbar 
									FROM #ReserviertTemp 
									JOIN dbo.tStueckliste ON dbo.tStueckliste.kArtikel = #ReserviertTemp.kArtikel
									JOIN dbo.vLagerbestandStueckliste ON dbo.vLagerbestandStueckliste.kStueckliste = dbo.tStueckliste.kStueckliste
							) AS Result ON Result.kArtikel = dbo.tlagerbestand.kArtikel
						UPDATE dbo.tlagerbestand
							SET 
								fInAuftraegen = Result.fAnzahl,
								fVerfuegbar = ISNULL(LagerBestand.fVerfuegbar, 0.0),
								fLagerbestand = ISNULL(LagerBestand.fLagerbestand, 0.0) + Result.fAnzahl,
								fLagerbestandEigen = ISNULL(LagerBestand.fLagerbestand, 0.0) + Result.fAnzahl
							FROM dbo.tlagerbestand 
							JOIN (
								SELECT	dbo.tReserviert.kArtikel,
										SUM(dbo.tReserviert.fAnzahl) AS fAnzahl
									FROM dbo.tReserviert 
									JOIN(SELECT DISTINCT #ReserviertTemp.kArtikel
										FROM #ReserviertTemp 
									) AS Artikel ON Artikel.kArtikel = dbo.tReserviert.kArtikel
									JOIN dbo.tArtikel ON Artikel.kArtikel = dbo.tArtikel.kArtikel
									WHERE dbo.tArtikel.cLagerVariation = 'Y'
									GROUP BY dbo.tReserviert.kArtikel
							)AS Result ON dbo.tlagerbestand.kArtikel = Result.kArtikel
							LEFT JOIN
							(
								SELECT 
									VariationsBestaende.kArtikel, 
									MIN(ISNULL(VariationsBestaende.fVerfuegbar, 0.0)) AS fVerfuegbar,
									MIN(ISNULL(VariationsBestaende.fLagerbestand, 0.0)) AS fLagerbestand
									FROM
								(
									SELECT dbo.tEigenschaft.kArtikel, 
										SUM(CASE WHEN ISNULL(tEigenschaftWert.fLagerbestand, 0) <= 0 THEN 0.0 ELSE tEigenschaftWert.fLagerbestand END) AS fVerfuegbar,
										SUM(ISNULL(tEigenschaftWert.fLagerbestand, 0)) AS fLagerbestand
									FROM dbo.tEigenschaftWert WITH(NOLOCK)
									LEFT JOIN dbo.tEigenschaft WITH(NOLOCK) ON dbo.tEigenschaft.kEigenschaft = dbo.tEigenschaftWert.kEigenschaft
									GROUP BY dbo.tEigenschaft.kArtikel, dbo.tEigenschaft.kEigenschaft
								) AS VariationsBestaende
								GROUP BY VariationsBestaende.kArtikel
							) AS LagerBestand ON Result.kArtikel = LagerBestand.kArtikel
							JOIN dbo.tArtikel ON Result.kArtikel = dbo.tArtikel.kArtikel
							WHERE dbo.tArtikel.cLagerVariation = 'Y';

						IF(OBJECT_ID('tempdb..#LagerbestandKind') IS NOT NULL)
						BEGIN
							DROP TABLE #LagerbestandKind;
						END
						CREATE TABLE #LagerbestandKind(
							kArtikel INT,
							fInAuftraegen DECIMAL(28,14),			
							fBestandReserviert DECIMAL(28,14),
							fVerfuegbar DECIMAL(28,14)
						);
								
    					INSERT #LagerbestandKind(kArtikel, fInAuftraegen, fVerfuegbar)
    						SELECT dbo.tartikel.kVaterArtikel AS kArtikel,
								SUM(dbo.tlagerbestand.fInAuftraegen) AS fInAuftraegen,
								SUM(CASE WHEN dbo.tArtikel.cLagerAktiv = 'Y' 
								THEN dbo.tlagerbestand.fVerfuegbar
								ELSE 0.0
								END) AS fVerfuegbar
							FROM dbo.tlagerbestand 
							JOIN dbo.tartikel ON tlagerbestand.kArtikel = dbo.tartikel.kArtikel
							WHERE dbo.tartikel.kVaterArtikel IN(
								SELECT Artikel.kVaterArtikel
								FROM dbo.tArtikel AS Artikel
								JOIN #ReserviertTemp ON #ReserviertTemp.kArtikel = Artikel.kArtikel
								)
							GROUP BY dbo.tartikel.kVaterArtikel	
						-- Vaterartikel aktualisieren
						UPDATE dbo.tlagerbestand
							SET fInAuftraegen = Vater.fInAuftraegen,
								fVerfuegbar = Vater.fVerfuegbar
							FROM dbo.tlagerbestand 
							JOIN #LagerbestandKind AS Vater ON Vater.kArtikel = dbo.tlagerbestand.kArtikel;
						 DROP TABLE #LagerbestandKind;   

					COMMIT
					SET @retry = -100; -- -100 Alles normal durchlaufen
				END TRY
				BEGIN CATCH
					IF(@retry > 0)
					BEGIN
						SET @retry = @retry -1;
						ROLLBACK;
						
					   
						SET @ErrorMessage = N'DB-Error: (' + CAST(ERROR_NUMBER() AS VARCHAR) + ' - ' +  CAST(ERROR_SEVERITY() AS VARCHAR) + ' - ' + CAST(ERROR_STATE() AS VARCHAR) + ' ) ' + ' Zeile:' + CAST(ERROR_LINE() AS VARCHAR) + ' - SP: ' +  ISNULL(ERROR_PROCEDURE(), 'none') + ' - Text: ' + ERROR_MESSAGE();
						SET @ErrorSeverity = CAST(ERROR_SEVERITY() AS VARCHAR);
						SET @ErrorState = CAST(ERROR_STATE() AS VARCHAR);


						INSERT INTO dbo.tLog
						(dDatum, kBenutzer, cLog,  nTyp,  nVorgang )
						VALUES
						(GETDATE(),  1,   @ErrorMessage,   14,  99);

						DECLARE @DELAY VARCHAR(255)
						SET @DELAY = '00:00:' + CAST(CAST(3*RAND() AS INT) AS VARCHAR) +':' + CAST(CAST(1000*RAND() AS INT) AS VARCHAR)
						SELECT @Delay
					END
				END CATCH
		END   	

		if(@retry <= 0 AND @retry > -100)
		BEGIN

			RAISERROR (	@ErrorMessage, 
						@ErrorSeverity,
						@ErrorState );
			RETURN;
		END

		IF(EXISTS(SELECT dbo.tReserviert.kKey 
						FROM dbo.tReserviert WITH(NOLOCK) 
						WHERE dbo.tReserviert.fAnzahl <= 0.0))
		BEGIN
			DELETE dbo.tReserviert 
				FROM dbo.tReserviert
				WHERE dbo.tReserviert.fAnzahl <= 0.0;
		END	
END
go

