CREATE TRIGGER [dbo].[tgr_tlagerbestand_Connector_UPDATE]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: FB
--
ON [dbo].[tlagerbestand]
AFTER UPDATE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN

	--Überprüfen ob Trigger gefüllt aufgerufen wird
	IF((SELECT COUNT(1) INSERTED) = 0)
	BEGIN 
		RETURN;
	END

	DECLARE @Komplett AS INT;
	--DECLARE @Preis AS INT;
	DECLARE @Bestand AS INT;

	SET @Komplett = 1;
	--SET @Preis = 2;
	SET @Bestand = 4;

	--
	-- Artikel vollständig zu Webshops senden, wenn Änderungen vorgenommen wurden
	--
	DECLARE @Exists INT;
	SET @Exists = 0;
	SELECT @Exists = COUNT(1)
			  FROM dbo.tArtikelShop WITH (NOLOCK)
			  JOIN INSERTED ON dbo.tArtikelShop.kArtikel = INSERTED.kArtikel
			  JOIN DELETED ON INSERTED.kArtikel = DELETED.kArtikel
    		  WHERE (INSERTED.fVerfuegbar <> DELETED.fVerfuegbar
    				AND (dbo.tArtikelShop.nAktion & @Bestand = 0)
					OR dbo.tArtikelShop.nInBearbeitung = 1)
	IF(@Exists > 0 OR (EXISTS(SELECT * FROM dbo.tOptions WHERE dbo.tOptions.cKey = 'BestandArtikelKomplettSenden' AND dbo.tOptions.cValue = '1')))
	BEGIN
		IF(EXISTS(SELECT * FROM dbo.tOptions WHERE dbo.tOptions.cKey = 'BestandArtikelKomplettSenden' AND dbo.tOptions.cValue = '1'))
		BEGIN
			UPDATE dbo.tArtikelShop
				SET dbo.tArtikelShop.nAktion = @Komplett,
					dbo.tArtikelShop.cInet = 'Y',
					dbo.tArtikelShop.nInBearbeitung = 0
			FROM dbo.tArtikelShop
			JOIN INSERTED ON dbo.tArtikelShop.kArtikel = INSERTED.kArtikel
			JOIN DELETED ON INSERTED.kArtikel = DELETED.kArtikel
    		WHERE (INSERTED.fVerfuegbar <> DELETED.fVerfuegbar
    			AND (dbo.tArtikelShop.nAktion & @Komplett = 0))
				OR dbo.tArtikelShop.nInBearbeitung = 1;
		END
		ELSE
		BEGIN
			UPDATE dbo.tArtikelShop
				SET dbo.tArtikelShop.nAktion =
					--
					-- Wurde der eigene Bestand abverkauft und der Artikel arbeitet mit Lieferantenbestand, soll dieser vollständig zum Shop gesendet werden.
					-- Damit wird die Lieferzeit im Shop korrigiert. (#23733)
					--
					CASE WHEN INSERTED.fLagerbestand > 0 AND INSERTED.fLagerbestandEigen = 0 AND INSERTED.fLagerbestandEigen <> DELETED.fLagerbestandEigen
						THEN dbo.tArtikelShop.nAktion | @Komplett
						ELSE dbo.tArtikelShop.nAktion | @Bestand						
					END,
					dbo.tArtikelShop.cInet = 'Y',
					dbo.tArtikelShop.nInBearbeitung = 0
			FROM dbo.tArtikelShop
			JOIN INSERTED ON dbo.tArtikelShop.kArtikel = INSERTED.kArtikel
			JOIN DELETED ON INSERTED.kArtikel = DELETED.kArtikel
    		WHERE (INSERTED.fVerfuegbar <> DELETED.fVerfuegbar
    			AND (dbo.tArtikelShop.nAktion & @Bestand = 0))
				OR dbo.tArtikelShop.nInBearbeitung = 1;
		END;
	END

	SET @Exists = 0;
	SELECT @Exists = COUNT(1)
			  FROM dbo.tArtikelShop WITH (NOLOCK)
			  JOIN INSERTED ON dbo.tArtikelShop.kArtikel = INSERTED.kArtikel
			  JOIN DELETED ON INSERTED.kArtikel = DELETED.kArtikel
			  JOIN dbo.tArtikel ON dbo.tArtikelShop.kArtikel = dbo.tArtikel.kArtikel
				AND dbo.tArtikel.nMHD = 1
    		  WHERE (INSERTED.fVerfuegbar <> DELETED.fVerfuegbar
    				AND (dbo.tArtikelShop.nAktion & @Komplett = 0)
					OR dbo.tArtikelShop.nInBearbeitung = 1)
	IF(@Exists > 0)
	BEGIN
		UPDATE dbo.tArtikelShop
			SET dbo.tArtikelShop.nAktion = @Komplett,
				dbo.tArtikelShop.cInet = 'Y',
				dbo.tArtikelShop.nInBearbeitung = 0
		FROM dbo.tArtikelShop
		JOIN INSERTED ON dbo.tArtikelShop.kArtikel = INSERTED.kArtikel
		JOIN DELETED ON INSERTED.kArtikel = DELETED.kArtikel
		JOIN dbo.tArtikel ON dbo.tArtikelShop.kArtikel = dbo.tArtikel.kArtikel
			AND dbo.tArtikel.nMHD = 1
    	WHERE (INSERTED.fVerfuegbar <> DELETED.fVerfuegbar
    		AND (dbo.tArtikelShop.nAktion & @Komplett = 0))
			OR dbo.tArtikelShop.nInBearbeitung = 1;
	END
END
go

