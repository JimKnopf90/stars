--- 
--- spVersendeKategorienArtikel
---

CREATE PROCEDURE [dbo].[spVersendeKategorienArtikel]

-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$

-- versendet eine übergebene Kategorie und auf Wunsch auch ihre Unterkategorien/ihre Artikel/ihre Artikel und die Artikel der Unterkategorien
	@kRoot INT,						-- PK Wurzelkategorie
	@nKategorienRekursiv TINYINT,	-- 0/1, ob Unterkategorien mit versendet werden sollen
	@nArtikelWurzel TINYINT,		-- 0/1, ob Artikel der Wurzelkategorie (und keine weiteren Artikel) mit versendet werden sollen
	@nArtikelRekursiv TINYINT		-- 0/1, ob Artikel der Wurzelkategorie und Artikel der Unterkategorien mit versendet werden sollen
-- Achtung: Verhalten bei @nArtikelWurzel = @nArtikelRekursiv = 1 undefiniert!
AS
BEGIN
	SET NOCOUNT ON;
	SET ANSI_NULLS ON;
	SET ANSI_NULL_DFLT_ON ON;
	SET ANSI_PADDING ON;
	SET CONCAT_NULL_YIELDS_NULL ON;
	SET XACT_ABORT OFF;

	DECLARE @tKategorienRekursiv AS TABLE (kKategorie INT); -- inkl. Wurzel
	DECLARE @tKategorienRelevant AS TABLE (kKategorie INT);
	DECLARE @tArtikelRelevant AS TABLE (kArtikel INT); 			

	-- Berechnung relevanter Kategorien und Artikel
	-- Berechnung relevanter Kategorien 	
	IF (@nKategorienRekursiv = 1 OR @nArtikelRekursiv = 1)
	BEGIN		
		INSERT INTO @tKategorienRekursiv VALUES (@kRoot);
		INSERT INTO @tKategorienRekursiv EXEC spGetSubCategories @kRoot;		
	END;
	IF (@nKategorienRekursiv = 0)
		INSERT INTO @tKategorienRelevant VALUES (@kRoot);
	ELSE
		INSERT INTO @tKategorienRelevant SELECT * FROM @tKategorienRekursiv;
	-- Berechnung relevanter Artikel
	IF (@nArtikelWurzel = 1)
	BEGIN		
		INSERT INTO @tArtikelRelevant
		SELECT tkategorieartikel.kArtikel
		FROM tkategorieartikel WITH(NOLOCK)
		WHERE tkategorieartikel.kKategorie = @kRoot;		
	END;	
	IF (@nArtikelRekursiv = 1)
	BEGIN		
		INSERT INTO @tArtikelRelevant
		SELECT tkategorieartikel.kArtikel
		FROM tkategorieartikel WITH(NOLOCK) JOIN @tKategorienRekursiv AS tKategorienRekursiv
			ON tkategorieartikel.kKategorie = tKategorienRekursiv.kKategorie;
	END;
	-- Kind-Artikel
	INSERT INTO @tArtikelRelevant
	SELECT tartikel.kArtikel
	FROM tartikel WITH(NOLOCK) JOIN @tArtikelRelevant AS tArtikelRelevant
		ON tartikel.kVaterArtikel = tArtikelRelevant.kArtikel;	
	
	-- versende relevante Kategorien
	UPDATE tKategorieShop
	SET tKategorieShop.cInet = 'Y'
	FROM tKategorieShop WITH(NOLOCK) JOIN @tKategorienRelevant AS tKategorienRelevant
		ON tKategorieShop.kKategorie = tKategorienRelevant.kKategorie
	WHERE tKategorieShop.cInet = 'N';
	
	-- versende relevante Artikel
	UPDATE tArtikelShop
	SET tArtikelShop.cInet = 'Y'
	FROM tArtikelShop WITH(NOLOCK) JOIN @tArtikelRelevant AS tArtikelRelevant
		ON tArtikelShop.kArtikel = tArtikelRelevant.kArtikel
	WHERE tArtikelShop.cInet = 'N';
END
go

