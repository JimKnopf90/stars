--- 
--- spGetNextBestellNr
---

CREATE PROC [dbo].[spGetNextBestellNr] 
AS 
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
DECLARE @cNextNummer VARCHAR(30)
DECLARE @TableNummer TABLE(Nummer VARCHAR(30))
BEGIN TRANSACTION
	INSERT INTO @TableNummer(Nummer) EXEC [spGetNextNummer] @cName = 'Auftrag', @kFirma = 0, @nNoUpdate = 0
	SET @cNextNummer = (SELECT Nummer FROM @TableNummer)
	SELECT @cNextNummer
COMMIT
go

