
    CREATE PROCEDURE unicorn2_spSetAllArticleShopInactive @kShop INT, @kBenutzer INT
    AS
        DECLARE @kVaterArtikel INT
        DECLARE @kKinderCount INT
        DECLARE @kShopLocal INT
			SET @kShopLocal = @kShop
		DECLARE @kArtikelLocal INT
        DECLARE @kBenutzerLocal INT
            SET @kBenutzerLocal = @kBenutzer

		SET DEADLOCK_PRIORITY LOW
		DECLARE ins CURSOR READ_ONLY FAST_FORWARD FOR SELECT kArtikel FROM eazybusiness.dbo.vLagerbestandEx WITH (NOLOCK) WHERE fVerfuegbar <= 1 AND kArtikel IN (SELECT kArtikel FROM eazybusiness.dbo.tArtikelShop WITH (NOLOCK) WHERE kShop = @kShopLocal AND kArtikel IN (SELECT kArtikel FROM eazybusiness.dbo.tArtikel WHERE cLagerAktiv = 'Y' AND cLagerKleinerNull = 'N'))
		OPEN ins

			FETCH NEXT FROM ins INTO @kArtikelLocal
			WHILE (@@FETCH_STATUS = 0)
				BEGIN
					EXEC eazybusiness.dbo.unicorn2_spSetSpecificArticleShopInactive @kShop = @kShopLocal, @kArtikel = @kArtikelLocal, @kBenutzer = @kBenutzerLocal

                    SET @kVaterArtikel = (SELECT TOP 1 kVaterArtikel FROM eazybusiness.dbo.tArtikel WHERE kArtikel = @kArtikelLocal)
                    IF (@kVaterArtikel > 0)
                        BEGIN

                            SET @kKinderCount = (SELECT COUNT(kArtikel) FROM eazybusiness.dbo.tArtikelShop WHERE kShop = @kShopLocal AND kArtikel IN (SELECT kArtikel FROM eazybusiness.dbo.tArtikel WHERE kVaterArtikel = @kVaterArtikel))
                            IF (@kKinderCount = 0)
                                BEGIN
                                    EXEC eazybusiness.dbo.unicorn2_spSetSpecificArticleShopInactive @kShop = @kShopLocal, @kArtikel = @kVaterArtikel, @kBenutzer = @kBenutzerLocal
                                END
                        END

					FETCH NEXT FROM ins INTO @kArtikelLocal
				END
		CLOSE ins
		DEALLOCATE ins

        DECLARE ins2 CURSOR READ_ONLY FAST_FORWARD FOR SELECT kArtikel FROM eazybusiness.dbo.tArtikelShop WITH (NOLOCK) WHERE kShop = @kShopLocal AND kArtikel IN (SELECT kArtikel FROM eazybusiness.dbo.tArtikel WHERE cLagerAktiv = 'Y' AND cLagerKleinerNull = 'N') AND kArtikel IN (SELECT kVaterArtikel FROM eazybusiness.dbo.tArtikel)
		OPEN ins2

			FETCH NEXT FROM ins2 INTO @kVaterArtikel
			WHILE (@@FETCH_STATUS = 0)
				BEGIN
                    SET @kKinderCount = (SELECT COUNT(kArtikel) FROM eazybusiness.dbo.tArtikelShop WHERE kShop = @kShopLocal AND kArtikel IN (SELECT kArtikel FROM eazybusiness.dbo.tArtikel WHERE kVaterArtikel = @kVaterArtikel))
                    IF (@kKinderCount = 0)
                        BEGIN
                            EXEC eazybusiness.dbo.unicorn2_spSetSpecificArticleShopInactive @kShop = @kShopLocal, @kArtikel = @kVaterArtikel, @kBenutzer = @kBenutzerLocal
                        END

					FETCH NEXT FROM ins2 INTO @kVaterArtikel
				END
		CLOSE ins2
		DEALLOCATE ins2
    go

