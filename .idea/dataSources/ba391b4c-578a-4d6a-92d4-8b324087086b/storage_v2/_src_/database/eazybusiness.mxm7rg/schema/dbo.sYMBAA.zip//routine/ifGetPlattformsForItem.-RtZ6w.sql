CREATE FUNCTION [dbo].[ifGetPlattformsForItem] (@kArtikel AS INT)
RETURNS TABLE
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP
-- Beschreibung:	Dient zur ermittlung von Plattformen, auf denen der Artikel gelistet ist.
--
AS

RETURN
(
	SELECT	shops.kShop AS kShop, 
			plattforms.kPlattform AS kPlattform
	FROM dbo.tArtikel
	LEFT JOIN
	(
		SELECT	dbo.tPlattform.nPlattform AS kPlattform, 
				dbo.tPlattform.cName AS cName
		FROM dbo.tPlattform 
		WHERE dbo.tPlattform.nPlattform NOT IN (1, 140, 151, 5)
	) AS plattforms ON 1=1
	LEFT  JOIN
	(
		SELECT dbo.tShop.kShop 
		FROM dbo.tShop
	) AS shops ON 1=1
	LEFT JOIN
	(
		SELECT	dbo.pf_amazon_angebot.nPlattform AS kPlattform, 
				dbo.pf_amazon_angebot.cSellerSKU AS cArtNr, 
				1 AS nAmazonAktiv
		FROM dbo.pf_amazon_angebot
		GROUP BY	dbo.pf_amazon_angebot.nPlattform, 
					dbo.pf_amazon_angebot.cSellerSKU
	) AS amazonAktiv ON amazonAktiv.kPlattform = plattforms.kPlattform 
		AND amazonAktiv.cArtNr = dbo.tArtikel.cArtNr
	LEFT JOIN 
	( 
		SELECT	dbo.tPlattform.nPlattform AS kPlattform, 
				dbo.ebay_item.kArtikel, 
				1 AS nEbayAktiv
		FROM dbo.tPlattform
		JOIN dbo.ebay_xx_sites ON dbo.ebay_xx_sites.kPlattform = dbo.tPlattform.nPlattform
		JOIN dbo.ebay_item ON dbo.ebay_item.SiteID = dbo.ebay_xx_sites.SiteID
		WHERE dbo.ebay_item.Status IN (3,7)
	) AS ebayAktiv ON ebayAktiv.kPlattform = plattforms.kPlattform 
		AND ebayAktiv.kArtikel = dbo.tArtikel.kArtikel
	LEFT JOIN 
	(
		SELECT	dbo.tPlattform.nPlattform AS kPlattform, 
				dbo.ebay_item.kArtikel, 
				dbo.ebay_item2kombi.kEigenschaftKombi, 
				1 AS nEbayKombiAktiv
		FROM dbo.tPlattform  
		JOIN dbo.ebay_xx_sites ON dbo.ebay_xx_sites.kPlattform = dbo.tPlattform.nPlattform
		JOIN dbo.ebay_item ON dbo.ebay_item.SiteID = dbo.ebay_xx_sites.SiteID
		JOIN dbo.ebay_item2kombi ON dbo.ebay_item.kItem = dbo.ebay_item2kombi.kItem
		WHERE dbo.ebay_item.Status IN (3, 7)
	) AS ebayKombiAktiv ON ebayKombiAktiv.kPlattform = plattforms.kPlattform
		AND ebayKombiAktiv.kArtikel = dbo.tArtikel.kArtikel 
		AND dbo.tArtikel.kEigenschaftKombi = ebayKombiAktiv.kEigenschaftKombi
	LEFT JOIN 
	( 
		SELECT	2 AS kPlattform, 
				dbo.tArtikelShop.kShop, 
				dbo.tArtikelShop.kArtikel, 
				1 AS nShopAktiv
		FROM dbo.tShop  
		JOIN dbo.tArtikelShop ON dbo.tArtikelShop.kShop = dbo.tShop.kShop
		WHERE dbo.tArtikelShop.cDelInet <> 'Y' 
	) AS shopAktiv ON shopAktiv.kPlattform = plattforms.kPlattform
		AND shopAktiv.kArtikel = dbo.tArtikel.kArtikel 
		AND shopAktiv.kShop = shops.kShop
	WHERE	CASE WHEN ISNULL(nAmazonAktiv, 0) + ISNULL(nEbayAktiv, 0) + ISNULL(nEbayKombiAktiv, 0) + ISNULL(nShopAktiv, 0) > 0 THEN 1 ELSE 0 END = 1
			AND dbo.tArtikel.kArtikel = @kArtikel
	GROUP BY	shops.kShop, 
				plattforms.kPlattform,				
				dbo.tArtikel.cArtNr
)
go

