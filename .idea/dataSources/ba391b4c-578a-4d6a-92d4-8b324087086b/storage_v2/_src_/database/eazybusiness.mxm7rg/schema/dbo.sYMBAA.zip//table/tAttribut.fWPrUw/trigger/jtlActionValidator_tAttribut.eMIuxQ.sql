CREATE TRIGGER [dbo].[jtlActionValidator_tAttribut]  
--     
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MaikS
--    
ON [dbo].[tAttribut]  
AFTER DELETE 
AS  
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN 

	--
	--Überprüfen ob Trigger mit Inhalt aufgerufen wird
	--
		IF((SELECT COUNT(1) FROM DELETED) = 0)
		BEGIN
			RETURN
		END

	--
	-- tAttributSprache aufräumen
	--
		DELETE tAttributSprache WITH(ROWLOCK)
		FROM tAttributSprache WITH(ROWLOCK)
		JOIN DELETED ON DELETED.kAttribut = tAttributSprache.kAttribut 
 

 	--
	-- tArtikelAttribut aufräumen
	--
		DELETE tArtikelAttribut WITH(ROWLOCK)
		FROM tArtikelAttribut WITH(ROWLOCK)
		JOIN DELETED ON DELETED.kAttribut = tArtikelAttribut.kAttribut

	--
	-- tKategorieAttribut aufräumen
	--
		DELETE tKategorieAttribut WITH(ROWLOCK)
		FROM tKategorieAttribut WITH(ROWLOCK)
		JOIN DELETED ON DELETED.kAttribut = tKategorieAttribut.kAttribut
		
	--
	-- tWawiAttribut aufräumen
	--
		DELETE tWawiAttribut WITH(ROWLOCK)
		FROM tWawiAttribut WITH(ROWLOCK)
		JOIN DELETED ON DELETED.kAttribut = tWawiAttribut.kAttribut
			
 	--
	-- tAttributShop aufräumen
	--
		DELETE tAttributShop WITH(ROWLOCK)
		FROM tAttributShop WITH(ROWLOCK)
		JOIN DELETED ON DELETED.kAttribut = tAttributShop.kAttribut
 																	 
END
go

