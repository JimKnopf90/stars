--- 
--- spPicklisteposPicken
---

CREATE PROCEDURE [dbo].[spPicklisteposPicken]
  @kPicklistePos INT,
  @kLhm INT,
  @kBenutzer INT,
  @fPickMenge DECIMAL(28,14),
  @dTimestamp DATETIME,
  @nRestmengeLoeschen INT, -- 0= Nein, 1= Ja,
  @nStatusNachPick INT
  
--  
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
DECLARE @fPickPosMenge DECIMAL(28,14);
DECLARE @kWarenLagerPlatz INT;
DECLARE @nPicklistePosStatus INT;
DECLARE @cKommentar VARCHAR(255);
DECLARE @kPicklistePosNeu INT;
DECLARE @kPickliste INT;

BEGIN 
    SELECT @fPickPosMenge = dbo.tPicklistePos.fAnzahl, @nPicklistePosStatus = dbo.tPicklistePos.nStatus,@kPickliste = dbo.tPicklistePos.kPickliste
    FROM dbo.tPicklistePos WITH(NOLOCK)
    WHERE dbo.tPicklistePos.kPicklistePos = @kPicklistePos;


    IF (@nPicklistePosStatus < @nStatusNachPick)
    BEGIN

        IF(@kLhm > 0)
	   BEGIN
		  SELECT @kWarenLagerPlatz = kWarenLagerPlatz 
		  FROM dbo.tLHM  WITH(NOLOCK) 
		  WHERE kLHM = @kLhm;
	   END;
	   ELSE
	   BEGIN
		  SELECT @kWarenLagerPlatz = dbo.tPicklistePos.kWarenLagerPlatz 
		  FROM dbo.tPicklistePos  WITH(NOLOCK) 
		  WHERE dbo.tPicklistePos.kPicklistePos = @kPicklistePos;
	   END;

	   IF(@nStatusNachPick = 20)
		  		SET @cKommentar = 'Gepickt in der Pickliste ' + cast(@kPickliste AS VARCHAR)
	   IF(@nStatusNachPick = 30 AND CONTEXT_INFO() NOT IN(0x5087))
		 		SET @cKommentar = 'In Box gelegt durch die Pickliste ' + cast(@kPickliste AS VARCHAR)

	   EXEC dbo.spPlatzUmbuchenPickposition
			 @kWarenlagerplatzNeu = @kWarenLagerPlatz,
			 @kPicklistePos = @kPicklistePos,
			 @kLHM = @kLhm,
			 @kBuchungsart =  null, -- Er soll die alte Buchungsart des WEs behalten
			 @kBenutzer = @kBenutzer,
			 @fAnzahl = @fPickMenge,
	           @cKommentar = @cKommentar,
			 @kPicklistePosNeu = @kPicklistePosNeu OUTPUT;



	   -- Falls die Restmenge der PickPos gelöscht werden soll
	   IF(@fPickPosMenge > @fPickMenge AND @nRestmengeLoeschen = 1 AND @kPicklistePosNeu > 0)
	   BEGIN

		  DELETE FROM dbo.tPicklistePos
		  WHERE dbo.tPicklistePos.kPicklistePos = @kPicklistePosNeu;

	   END;

    END;

    EXEC dbo.spPicklisteposStatusAendern @kPicklistePos = @kPicklistePos, @nNewStatus = @nStatusNachPick, @kBenutzer = @kBenutzer, @dTimestamp = @dTimestamp;

    DECLARE  @nIstAusDemWE INT;
    SET @nIstAusDemWE = 0;

    SELECT TOP 1  @nIstAusDemWE = CASE WHEN ISNULL(tPickliste.kPicklistenVorlage,0) < 0 THEN 1 ELSE 0 END
    FROM tPickliste
    JOIN tPicklistePos ON tPicklistePos.kPickliste = tPickliste.kPickliste
    WHERE tPicklistePos.kPicklistePos = @kPicklistePos

    -- Nach in Box legen, die versandbox prüfen
    IF(@nStatusNachPick = 30 AND @kLhm > 0)
    BEGIN
	   EXEC dbo.spVersandBoxPruefen 
	   @kLHM = @kLhm,
	   @nAusDemWE = @nIstAusDemWE
    END;
END;
go

