CREATE TRIGGER [dbo].[tgr_tArtikelbildPlattform_INSERT]  
--     
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Author: Markus Hütz
--    
ON [dbo].[tArtikelbildPlattform]  
AFTER INSERT
AS  
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
    IF((SELECT COUNT(1) FROM INSERTED) = 0) 
    BEGIN
	   RETURN;
    END;

	--
	-- nInet auf 0 setzen wenn Artikel gar nicht für Shop aktiv
	--
	UPDATE dbo.tArtikelbildPlattform
		SET dbo.tArtikelbildPlattform.nInet = 0
	FROM dbo.tArtikelbildPlattform
	JOIN INSERTED ON dbo.tArtikelbildPlattform.kArtikelbildPlattform = INSERTED.kArtikelbildPlattform
	LEFT JOIN dbo.tArtikelShop ON INSERTED.kArtikel = dbo.tArtikelShop.kArtikel
		AND INSERTED.kShop = dbo.tArtikelShop.kShop
	WHERE	dbo.tArtikelShop.kArtikel IS NULL
			AND INSERTED.nInet = 1;

    --
    -- eBay aktualisieren
    --
    DECLARE @Artikel AS XML;
    SET @Artikel =
    (
	   SELECT INSERTED.kArtikel AS 'kArtikel'
	   FROM INSERTED
	   WHERE INSERTED.kPlattform = 30 AND INSERTED.nNr <= 12
	   GROUP BY INSERTED.kArtikel
	   FOR XML PATH('Artikel'), TYPE
    );
    EXEC dbo.spUpdateEbayBilderLaufendGeplant @Artikel;

	DELETE dbo.tQueue
	FROM dbo.tQueue
	JOIN INSERTED ON dbo.tQueue.kShop = INSERTED.kShop
		AND dbo.tQueue.kOption1 = INSERTED.kArtikel
	JOIN dbo.tShop ON dbo.tShop.kShop = INSERTED.kShop
		AND dbo.tShop.nTyp = 0
	WHERE	dbo.tQueue.cName = 'tArtikelbildPlattform'
			AND dbo.tQueue.nAction = 2
			AND INSERTED.nInet = 1
			AND dbo.tQueue.kOption2 = INSERTED.nNr
END
go

