CREATE VIEW dbo.vObjectBrowserArtikel
AS
SELECT        dbo.tkategorieartikel.kKategorieArtikel, dbo.tkategorie.kKategorie, dbo.tKategorieSprache.cName AS cKategorie, dbo.tArtikel.kArtikel, dbo.tArtikel.cArtNr, 
                         dbo.tArtikelBeschreibung.cName, dbo.tArtikel.cBarcode, dbo.tHersteller.cName AS cHersteller, dbo.tArtikel.cHAN, dbo.tArtikel.cISBN, dbo.tArtikel.cASIN, 
                         dbo.tArtikel.cUPC, dbo.tWarengruppe.kWarengruppe, dbo.tWarengruppe.cName AS cWarengruppe, dbo.tArtikelSpeicher.cNummer AS cSuchnummer
FROM            dbo.tkategorieartikel INNER JOIN
                         dbo.tkategorie ON dbo.tkategorieartikel.kKategorie = dbo.tkategorie.kKategorie INNER JOIN
                         dbo.tKategorieSprache ON dbo.tKategorieSprache.kKategorie = dbo.tkategorie.kKategorie INNER JOIN
                         dbo.tArtikel ON dbo.tkategorieartikel.kArtikel = dbo.tArtikel.kArtikel AND dbo.tArtikel.cAktiv = 'Y' INNER JOIN
                         dbo.tArtikelSpeicher ON dbo.tArtikelSpeicher.kArtikel = dbo.tArtikel.kArtikel LEFT OUTER JOIN
                         dbo.tWarengruppe ON dbo.tWarengruppe.kWarengruppe = dbo.tArtikel.kWarengruppe INNER JOIN
                         dbo.tSpracheUsed AS tStandardSpracheUsed ON tStandardSpracheUsed.nStandard = 1 INNER JOIN
                         dbo.tArtikelBeschreibung ON dbo.tArtikelBeschreibung.kArtikel = dbo.tArtikel.kArtikel AND dbo.tArtikelBeschreibung.kSprache = tStandardSpracheUsed.kSprache AND 
                         dbo.tArtikelBeschreibung.kPlattform = 0 INNER JOIN
                         dbo.tHersteller ON dbo.tHersteller.kHersteller = dbo.tArtikel.kHersteller INNER JOIN
                         dbo.tSpracheUsed ON 1 = 1 AND dbo.tSpracheUsed.nStandard = 1 AND dbo.tKategorieSprache.kSprache = dbo.tSpracheUsed.kSprache
go

