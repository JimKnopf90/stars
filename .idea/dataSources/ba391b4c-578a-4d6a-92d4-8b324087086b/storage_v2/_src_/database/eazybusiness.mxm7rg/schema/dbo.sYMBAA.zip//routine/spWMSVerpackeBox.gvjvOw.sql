--- 
--- spWMSVerpackeBox
---

CREATE PROCEDURE [dbo].[spWMSVerpackeBox]
@kBenutzer INT,         -- Der Benutzer der den Vorgang ausführt
@kWarenlager INT,		 -- Warenlager auf dem wir arbeiten
@cLhmId VARCHAR(255),              -- Box die wir verpacken  
@cLieferscheinNr VARCHAR(255),
@kLieferschein INT OUT

	
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Author PN    

-- Funktion: Mit dieser Procedur werden Warenlagereingänge geändert, ohne übers ausbuchen zu gehen.
	
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;

   
   DECLARE @kBestellung INT;
   DECLARE @kBestellPos INT;
   DECLARE @kLHM INT;
   DECLARE @kLagerArtikel INT;
   DECLARE @kLieferscheinPosSerNo INT;
   DECLARE @kLagerArtikelkLieferscheinPos INT;
   DECLARE @IsNowDate DATETIME;
   DECLARE @kArtikel INT;
   DECLARE @cSerNo VARCHAR(255);
   DECLARE @cKommentar VARCHAR(255);
   DECLARE @fDataMenge	DECIMAL(28,14);
   DECLARE @kLhmStatus INT;
   DECLARE @temp_SerNoBestellpos TABLE(kBestellPos INT,kArtikel INT, nMengeMax INT, nMengeIS INT);


DECLARE @retry INT;
SET @retry = 10;
WHILE @retry > 0
BEGIN TRY

   SET @IsNowDate = GETDATE();
   SET @cKommentar = 'Versand mit Boxen verpacken';
   SET @kLieferschein = 0;

   SELECT @kBestellung = tLHMStatus.kBestellung , @kLHM = tLHM.kLHM
   FROM tLHM
   JOIN tLHMStatus ON tLHMStatus.kLHMStatus = tLHM.kLHMStatus
   WHERE tLHM.cLHMId = @cLhmId
   AND tLHM.kWarenlager = @kWarenlager;

   IF(EXISTS (SELECT * FROM tUmlagerung WHERE kBestellung = @kBestellung))
   BEGIN
       SET @cKommentar = 'Ausgehende Umlagerung mit Boxen verpacken';
   END;


   BEGIN TRANSACTION

   --
   -- Lieferschein erstellen
   --
   EXEC  Versand.spLieferscheinErstellen 
		   @xLieferschein= null,
		   @kBestellung = @kBestellung,
		   @kBenutzer = @kBenutzer,
		   @cLieferscheinNr = @cLieferscheinNr,
		   @cHinweis= '',
		   @dMailVersand = null,
		   @dGedruckt = null,
		   @nFulfillment = 0,
		   @kLieferantenBestellung = null,
		   @kSessionId = null,
		   @kLieferschein = @kLieferschein OUTPUT;


   --
   -- LieferscheinPos erstellen
   --
   DECLARE @LieferscheinPositionen AS XML
   SET @LieferscheinPositionen = (
	   SELECT 0 AS kLieferscheinPos, @kLieferschein AS kLieferschein,tBestellPos.kBestellPos AS kBestellPos, tBestellPos.nAnzahl - ISNULL(vGeliefert.fAnzahlGeliefert,0) - ISNULL(tGutschriftPos.nAnzahl,0) AS fAnzahl, '' AS cHinweis
	   FROM dbo.tbestellpos 
	   LEFT JOIN Versand.vBestellPosLieferInfo ON Versand.vBestellPosLieferInfo.kBestellPos = tbestellpos.kBestellPos
	   LEFT JOIN dbo.tGutschriftPos ON tGutschriftPos.kBestellPos = dbo.tbestellpos.kBestellPos
	   LEFT JOIN ( SELECT kBestellPos, SUM(fAnzahl) as fAnzahlGeliefert 
				   FROM dbo.tLieferscheinPos 
  				   GROUP BY kBestellPos) vGeliefert on vGeliefert.kBestellPos = tBEstellPos.kBestellPos
	   WHERE dbo.tbestellpos.tBestellung_kBestellung = @kBestellung
	   AND (dbo.tBestellPos.nAnzahl - ISNULL(vGeliefert.fAnzahlGeliefert,0)) > 0
	   AND ((Versand.vBestellPosLieferInfo.kBestellPos IS NOT NULL OR tbestellpos.kBestellPos = tbestellpos.kBestellStueckliste) AND (tbestellpos.nType IN (0,1,11)) OR (tbestellpos.nType NOT IN (0,1,11)))
   FOR XML PATH('LieferscheinPos'), TYPE );


   EXEC [Versand].[spLieferscheinPosErstellen]
							@xLieferscheinPos = @LieferscheinPositionen,
							@kLieferschein = null,
							@kBestellPos = null,
							@fAnzahl  = null,
							@cHinweis  = null,
							@kLieferscheinPos = null;




   IF(@kLieferschein = 0)
   BEGIN
          RAISERROR(  'Lieferschein konnte nicht erstellt werden.' , 11 , 1 );
          RETURN -1;
   END;
    

   --
   -- Serienummern aus neuer Tabelle holen und ausbuchen
   --
   IF(EXISTS(SELECT * FROM dbo.tWMSBoxenPackVerpackteSerNos WHERE kBestellung = @kBestellung))
   BEGIN
    
  	 DECLARE cur_GetWMSPackItemDataSerNo CURSOR LOCAL FAST_FORWARD FOR  
  	 SELECT dbo.tWMSBoxenPackVerpackteSerNos.kArtikel, dbo.tWMSBoxenPackVerpackteSerNos.cSerNo, COUNT(*) AS fMenge, dbo.tWMSBoxenPackVerpackteSerNos.kBestellPos, dbo.tLieferscheinPos.kLieferscheinPos  
  	 FROM dbo.tWMSBoxenPackVerpackteSerNos
  	 JOIN dbo.tLieferscheinPos ON  dbo.tLieferscheinPos.kBestellPos = dbo.tWMSBoxenPackVerpackteSerNos.kBestellPos
  	 WHERE dbo.tWMSBoxenPackVerpackteSerNos.kBestellung = @kBestellung
  	 GROUP BY dbo.tWMSBoxenPackVerpackteSerNos.kArtikel, dbo.tWMSBoxenPackVerpackteSerNos.cSerNo,  dbo.tWMSBoxenPackVerpackteSerNos.kBestellPos,dbo.tLieferscheinPos.kLieferscheinPos  
    
    
  	 OPEN cur_GetWMSPackItemDataSerNo    
  	 FETCH NEXT FROM cur_GetWMSPackItemDataSerNo INTO  @kArtikel,@cSerNo,@fDataMenge,@kBestellPos,@kLieferscheinPosSerNo
  	 WHILE (@@FETCH_STATUS = 0 )
  	 BEGIN  
    
  	 	-- Ersten gültigen Lagerartikel holen
  	 	SELECT TOP(1) @kLagerArtikel = dbo.tLagerArtikel.kLagerArtikel , @kLagerArtikelkLieferscheinPos = dbo.tLagerArtikel.kLieferscheinPos
  	 		FROM dbo.tLagerArtikel WITH(NOLOCK) 
  	 		WHERE kArtikel = @kArtikel
  	 		AND kWarenlager = @kWarenlager
  	 		AND ISNULL(kLieferscheinPos,0) IN (0,999999999)
  	 		ORDER BY CASE WHEN cSeriennr = @cSerNo 
  	 					THEN 0 
  	 					ELSE 1 
  	 				END,
  	 				CASE WHEN cSeriennr = '#$KEINE$#' 
  	 					THEN 0 
  	 					ELSE 1 
  	 				END, 
  	 				kLieferscheinPos;
    
  	 	-- SerNo Ausbuchen
  	 	UPDATE dbo.tLagerArtikel WITH(ROWLOCK) 
  	 	SET dbo.tLagerArtikel.kLieferscheinPos = @kLieferscheinPosSerNo,dbo.tLagerArtikel.cSeriennr = @cSerNo,dbo.tLagerArtikel.kBestellPos = @kBestellPos
  	 	WHERE dbo.tLagerArtikel.kLagerArtikel = @kLagerArtikel;	    
  	 	
  	 	-- Alte SerNo reservierungen löschen
  	 	UPDATE dbo.tLagerArtikel WITH(ROWLOCK)
  	 	SET dbo.tLagerArtikel.kBestellPos = 0
  	 	WHERE dbo.tLagerArtikel.kLagerArtikel != @kLagerArtikel AND dbo.tLagerArtikel.kBestellPos = @kBestellPos AND dbo.tLagerArtikel.kLieferscheinPos = 0;
    
  	 	FETCH NEXT FROM cur_GetWMSPackItemDataSerNo 
        INTO  @kArtikel,@cSerNo,@fDataMenge,@kBestellPos,@kLieferscheinPosSerNo;
    
  	 END	   
  	 CLOSE cur_GetWMSPackItemDataSerNo
  	 DEALLOCATE cur_GetWMSPackItemDataSerNo	   
    
  	 DELETE FROM tWMSBoxenPackVerpackteSerNos
  	 WHERE kBestellung = @kBestellung; 
    
   END;

   --Warenlagereingänge ausbuchen
   DECLARE @xWarenlagerAusgaenge XML;
   SET @xWarenlagerAusgaenge = (
   SELECT dbo.tWarenLagereingang.kWarenLagerEingang AS kWarenLagerEingang,
    	  dbo.tlieferscheinPos.kLieferscheinPos AS kLieferscheinPos,
    	  dbo.tWarenLagereingang.fAnzahlAktuell AS fAnzahl,
    	  @cKommentar AS cKommentar,
    	  @kBenutzer AS kBenutzer,
    	  130 AS kBuchungsart
       FROM dbo.tlhm
       JOIN dbo.tLHMStatus on tLHMStatus.kLHMStatus = tlhm.kLHMStatus
       JOIN dbo.tBestellung on tBestellung.kBestellung = tLHMStatus.kBestellung
       JOIN dbo.tWarenLagereingang on tWarenLagereingang.kLhm = tlhm.kLhm and twarenlagereingang.fanzahlaktuell > 0
       JOIN dbo.vStandardArtikel AS tArtikel on tArtikel.kArtikel = tWarenLagereingang.kArtikel
       JOIN dbo.tPicklistePos on tPicklistePos.kWarenLagereingang = tWarenLagereingang.kWarenLagereingang
       JOIN dbo.tBestellpos on tBestellpos.kBestellpos = tPicklistePos.kBestellpos and tBestellpos.tBestellung_kBestellung = tBestellung.kBestellung
       JOIN dbo.tlieferscheinPos ON tlieferscheinPos.kbestellpos = tBestellpos.kbestellpos
       WHERE dbo.tlhm.kLHM = @kLHM
       AND dbo.tWarenLagereingang.fAnzahlAktuell > 0
	   AND dbo.tlieferscheinPos.kLieferschein = @kLieferschein
       FOR XML PATH('WarenAusgang'), TYPE );

		EXEC dbo.spWarenlagerAusgangSchreiben
		@xWarenlagerAusgaenge = @xWarenlagerAusgaenge


		 -- Status der Pickpos auf 40 setzten
		INSERT INTO dbo.tPicklistePosStatus WITH(ROWLOCK) (kPicklistePos,kBenutzer,nStatus,dZeitstempel) 
		SELECT DISTINCT kPicklistePos,@kBenutzer,40,@IsNowDate
		FROM tPicklistePos
		JOIN dbo.tbestellpos ON dbo.tbestellpos.kBestellPos = dbo.tPicklistePos.kBestellPos
		JOIN dbo.tLieferscheinPos ON dbo.tLieferscheinPos.kBestellPos = dbo.tbestellpos.kBestellPos
		WHERE dbo.tPicklistePos.nStatus = 30
		AND dbo.tLieferscheinPos.kLieferschein = @kLieferschein;

		-- LieferscheinPos in der PicklistePos setzen
		UPDATE dbo.tPicklistePos WITH(ROWLOCK) 
		SET dbo.tPicklistePos.kLieferscheinpos = tLieferscheinPos.kLieferscheinPos,dbo.tPicklistePos.nStatus = 40
		FROM tPicklistePos 
		JOIN dbo.tbestellpos ON dbo.tbestellpos.kBestellPos = dbo.tPicklistePos.kBestellPos
		JOIN dbo.tLieferscheinPos ON dbo.tLieferscheinPos.kBestellPos = dbo.tbestellpos.kBestellPos
		WHERE dbo.tPicklistePos.nStatus = 30
		AND dbo.tLieferscheinPos.kLieferschein = @kLieferschein;

    --
	--  LHM status wieder auf 10 (frei) setzen, weil der Inhalt geleert wurde und die LHM wieder verwendet werden darf
	--
	INSERT INTO dbo.tLHMStatus ( kLHM, nStatus, dZeitstempel,  kBestellung)
	VALUES(  @kLHM, 10,  @IsNowDate,  0 );

	SET @kLhmStatus = scope_identity();

	UPDATE tLHM SET kLHMStatus = @kLhmStatus,kBenutzer = null, dBearbeitet = null
	WHERE kLHM = @kLHM;

	SET @kLieferschein = @kLieferschein;
	SET @retry = - 1;




	COMMIT;

END TRY
BEGIN CATCH
    DECLARE @ErrorMessage NVARCHAR(4000);
    DECLARE @ErrorSeverity INT;
    DECLARE @ErrorState INT;

	IF(ERROR_NUMBER() = 1205) --Deadlock
	BEGIN
		SET @retry = @retry - 1;
		ROLLBACK;
		IF(@retry = 0)
		BEGIN
			SELECT @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();

			INSERT INTO dbo.tLog (dDatum, kBenutzer, cLog,  nTyp,  nVorgang )
			VALUES (GETDATE(),  1,  'DEADLOCK:' + @ErrorMessage,   14,  88);

			RAISERROR (	@ErrorMessage, 
						@ErrorSeverity,
						@ErrorState
			);
			RETURN;
		END
		WAITFOR DELAY '00:00:01';
	END
	ELSE 
	BEGIN
		SET @retry = -1;
		SELECT @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
		ROLLBACK;

		INSERT INTO dbo.tLog (dDatum, kBenutzer, cLog,  nTyp,  nVorgang )
		VALUES (GETDATE(),  1,   @ErrorMessage,   14,  88);

		RAISERROR (	@ErrorMessage, 
					@ErrorSeverity,
					@ErrorState
		);
	
		RETURN;
	END;

END CATCH
go

