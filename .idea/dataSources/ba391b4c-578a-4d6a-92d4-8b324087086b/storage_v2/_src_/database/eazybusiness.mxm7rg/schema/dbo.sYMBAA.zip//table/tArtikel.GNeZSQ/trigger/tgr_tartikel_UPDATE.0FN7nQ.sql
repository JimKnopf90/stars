CREATE TRIGGER [dbo].[tgr_tartikel_UPDATE]    
--      
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP/MaikS
--        
ON [dbo].[tArtikel]    
AFTER UPDATE    
AS    
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
DECLARE @OldContextInfo VARBINARY(128);

IF UPDATE(fVKNetto)  OR UPDATE(cAktiv) 
BEGIN
BEGIN TRANSACTION 

    IF(ISNULL((SELECT SUM(ISNULL(inserted.nProzentualePreisStaffelAktiv, 0)) FROM inserted), 0) > 0 OR UPDATE(fVKNetto))  
    BEGIN  

       UPDATE tPreisDetail SET
           tPreisDetail.fNettoPreis =  CASE WHEN ISNULL(tPreisDetail.fProzent, 0.0) != 0.0 THEN ISNULL(tartikel.fVKNetto, 0.0) * (1 - tPreisDetail.fProzent / 100) ELSE tPreisDetail.fNettoPreis END
        FROM tPreisDetail
        JOIN tPreis ON tPreis.kPreis = tPreisDetail.kPreis    
        JOIN inserted ON tPreis.kArtikel = inserted.kArtikel   
        JOIN tartikel ON tPreis.kArtikel = tartikel.kArtikel   
    END

    IF(EXISTS(SELECT cAktiv FROM INSERTED WHERE cAktiv != 'Y'))
	BEGIN
		--
		-- Alle Varkombi-Kindartikel deaktivieren
		--
		UPDATE dbo.tArtikel 
			SET tArtikel.cAktiv = 'N'
		FROM dbo.tArtikel 
		JOIN INSERTED ON INSERTED.kArtikel = tArtikel.kVaterArtikel
		WHERE INSERTED.cAktiv != 'Y'

		--
		--  Bei Amazon aus dem Sortiment nehmen
		--
		UPDATE dbo.pf_amazon_angebot_ext
			SET pf_amazon_angebot_ext.nMaxBestand = 0, 
				pf_amazon_angebot_ext.dLetzteBestandAenderung = NULL
		FROM dbo.pf_amazon_angebot_ext
		JOIN INSERTED ON pf_amazon_angebot_ext.cSellerSKU = INSERTED.cArtNr
		WHERE INSERTED.cAktiv != 'Y'

		--
		--  Varkombi-Kindartikel bei Amazon aus dem Sortiment nehmen
		--
		UPDATE dbo.pf_amazon_angebot_ext
			SET pf_amazon_angebot_ext.nMaxBestand = 0, 
				pf_amazon_angebot_ext.dLetzteBestandAenderung = NULL
		FROM dbo.pf_amazon_angebot_ext
		JOIN dbo.tArtikel ON dbo.tArtikel.cArtNr = dbo.pf_amazon_angebot_ext.cSellerSKU
		JOIN INSERTED ON INSERTED.kArtikel = dbo.tArtikel.kVaterArtikel
		WHERE INSERTED.cAktiv != 'Y'

		--
		-- Artikel aus den Shops entfernen
		--
		INSERT INTO dbo.tQueue 
			(kShop, kPlattform, cName, kWert, nAction, kOption1, kOption2)
		SELECT 
			dbo.tArtikelShop.kShop, 
			0 AS kPlattform, 
			'tArtikel' AS cName, 
			dbo.tArtikelShop.kArtikel AS kWert, 
			2 AS nAction, 
			0 AS kOption1, 
			0 AS kOption2
		FROM dbo.tArtikelShop
		JOIN INSERTED ON INSERTED.kArtikel = dbo.tArtikelShop.kArtikel
		WHERE INSERTED.cAktiv != 'Y'

		--
		-- Varkombi-Kindartikel aus den Shops entfernen
		--
		INSERT INTO dbo.tQueue 
			(kShop, kPlattform, cName, kWert, nAction, kOption1, kOption2)
		SELECT 
			dbo.tArtikelShop.kShop, 
			0 AS kPlattform, 
			'tArtikel' AS cName, 
			dbo.tArtikelShop.kArtikel AS kWert, 
			2 AS nAction, 
			0 AS kOption1, 
			0 AS kOption2
		FROM dbo.tArtikelShop
		JOIN dbo.tArtikel ON dbo.tArtikel.kArtikel = dbo.tArtikelShop.kArtikel
		JOIN INSERTED ON INSERTED.kArtikel = dbo.tArtikel.kVaterArtikel
		WHERE INSERTED.cAktiv != 'Y'
	END

    IF(EXISTS(SELECT i.cAktiv 
                FROM INSERTED i 
                JOIN DELETED d ON i.kArtikel = d.kArtikel
                WHERE i.cAktiv = 'Y'
                    AND d.cAktiv != 'Y'))
    BEGIN
       UPDATE tArtikel 
          SET cAktiv = 'Y'
          FROM tArtikel
          JOIN INSERTED ON INSERTED.kArtikel = tArtikel.kVaterArtikel
          JOIN DELETED ON DELETED.kArtikel = INSERTED.kArtikel
          WHERE INSERTED.cAktiv = 'Y'
             AND DELETED.cAktiv != 'Y'
    END

	--
	--  Bei Amazon aus dem Sortiment nehmen
	--
		UPDATE pf_amazon_angebot_ext
		SET nMaxBestand = 0, 
			dLetzteBestandAenderung = NULL
		FROM pf_amazon_angebot_ext
		JOIN INSERTED ON pf_amazon_angebot_ext.cSellerSKU = INSERTED.cArtNr
					AND INSERTED.cAktiv != 'Y'

COMMIT
END
IF(UPDATE(kStueckliste))
BEGIN
	DELETE FROM dbo.tStueckliste 
		FROM dbo.tStueckliste 
		JOIN DELETED ON DELETED.kStueckliste = dbo.tStueckliste.kStueckliste 
		JOIN INSERTED ON DELETED.kArtikel = INSERTED.kArtikel
		WHERE INSERTED.kStueckliste = 0;

	DECLARE @typeArtikel AS TYPE_spUpdateLagerbestand;

	INSERT INTO @typeArtikel (kArtikel)
	SELECT DISTINCT INSERTED.kArtikel
	FROM INSERTED
	JOIN DELETED ON DELETED.kArtikel = INSERTED.kArtikel
	WHERE INSERTED.kStueckliste <> DELETED.kStueckliste;
	
	EXEC dbo.spUpdateLagerbestand @typeArtikel;
END

-- Wenn Artikel von LagerAktiv auf LagerDeaktiv gegangen ist
IF(EXISTS(SELECT i.cLagerAktiv 
                FROM INSERTED i 
                JOIN DELETED d ON i.kArtikel = d.kArtikel
                WHERE i.cLagerAktiv = 'N'  AND d.cLagerAktiv = 'Y'))
BEGIN

    DECLARE @xWarenlagerAusgaenge XML;
	SET @xWarenlagerAusgaenge = (
		    SELECT DISTINCT dbo.tWarenLagerEingang.kWarenLagerEingang AS kWarenLagerEingang,
				   0 AS kLieferscheinPos,
				   dbo.tWarenLagerEingang.fAnzahlAktuell AS fAnzahl,
				   'Lagerbestand deaktiviert' AS cKommentar,
				   dbo.tWarenLagerEingang.kBenutzer AS kBenutzer,
				   70 AS kBuchungsart
			FROM dbo.tWarenLagerEingang 
			JOIN INSERTED i ON i.kArtikel = dbo.tWarenLagerEingang.kArtikel
			JOIN DELETED d  ON i.kArtikel = d.kArtikel
			WHERE i.cLagerAktiv = 'N'  AND d.cLagerAktiv = 'Y'
			AND dbo.tWarenLagerEingang.fAnzahlAktuell > 0
		    FOR XML PATH('WarenAusgang'), TYPE
	    );

	IF(@xWarenlagerAusgaenge IS NOT NULL)
	BEGIN

		EXEC dbo.spWarenlagerAusgangSchreiben
		@xWarenlagerAusgaenge = @xWarenlagerAusgaenge;

	END;
END;
--
-- Änderung am Artikeltyp
--
IF(UPDATE(kStueckliste) OR UPDATE(nIstVater) OR UPDATE (cLagerVariation))
BEGIN
	DELETE FROM dbo.tlagerbestand
		FROM dbo.tlagerbestand 
		WHERE kArtikel IN (
			SELECT INSERTED.kArtikel 
				FROM INSERTED 
				JOIN DELETED ON INSERTED.kArtikel = DELETED.kArtikel
				WHERE INSERTED.kStueckliste <> DELETED.kStueckliste
					OR INSERTED.nIstVater <> DELETED.nIstVater
					OR INSERTED.cLagerVariation <> DELETED.cLagerVariation
			);
	DECLARE @typeArtikelTypGeandert AS TYPE_spUpdateLagerbestand;

	INSERT INTO @typeArtikelTypGeandert (kArtikel)
	SELECT DISTINCT INSERTED.kArtikel 
	FROM INSERTED 
	JOIN DELETED ON INSERTED.kArtikel = DELETED.kArtikel
	WHERE INSERTED.kStueckliste <> DELETED.kStueckliste
					OR INSERTED.nIstVater <> DELETED.nIstVater
					OR INSERTED.cLagerVariation <> DELETED.cLagerVariation;

	EXEC dbo.spUpdateLagerbestand @typeArtikelTypGeandert;
END
--
-- Kind vom Vater lösen
--
IF(UPDATE(kVaterArtikel))
BEGIN
	DECLARE @typeVaterLoesen AS TYPE_spUpdateLagerbestand;
	INSERT INTO @typeVaterLoesen(kArtikel)
		SELECT DISTINCT dbo.tArtikel.kArtikel
			FROM INSERTED
			JOIN DELETED ON INSERTED.kArtikel = DELETED.kArtikel
			JOIN dbo.tArtikel ON dbo.tArtikel.kArtikel = DELETED.kVaterArtikel
			WHERE INSERTED.kVaterArtikel <> DELETED.kVaterArtikel;
	EXEC dbo.spUpdateLagerbestand @typeVaterLoesen;
END
go

