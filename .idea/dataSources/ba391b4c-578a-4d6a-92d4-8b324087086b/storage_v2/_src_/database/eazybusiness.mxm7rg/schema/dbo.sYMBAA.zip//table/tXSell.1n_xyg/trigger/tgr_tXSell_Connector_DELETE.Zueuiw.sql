CREATE TRIGGER [dbo].[tgr_tXSell_Connector_DELETE]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP
--
ON [dbo].[tXSell]
AFTER DELETE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
	--Überprüfen ob Trigger gefüllt aufgerufen wird
	IF((SELECT COUNT(1) FROM DELETED) = 0)
	BEGIN 
		RETURN;
	END;

	DECLARE @Komplett AS INT;
	--DECLARE @Preis AS INT;
	--DECLARE @Bestand AS INT;

	SET @Komplett = 1
	--SET @Preis = 2
	--SET @Bestand = 4

	INSERT INTO dbo.tQueue (kShop, kPlattform, cName, kWert, nAction, kOption1, kOption2, nInBearbeitung)
	SELECT dbo.tArtikelShop.kShop, 0, 'tXSell', DELETED.kArtikel, 2, 0, 0, 0
	FROM DELETED
	JOIN dbo.tArtikelShop ON DELETED.kArtikel = dbo.tArtikelShop.kArtikel
	LEFT JOIN dbo.tXSell ON DELETED.kArtikel = dbo.tXSell.kArtikel
	WHERE dbo.tXSell.kArtikel IS NULL

	UPDATE dbo.tArtikelShop
		SET dbo.tArtikelShop.cInet = 'Y',
			dbo.tArtikelShop.nAktion = @Komplett,
			dbo.tArtikelShop.nInBearbeitung = 0
	FROM DELETED
	JOIN dbo.tArtikelShop ON DELETED.kArtikel = dbo.tArtikelShop.kArtikel
	JOIN dbo.tXSell ON DELETED.kArtikel = dbo.tXSell.kArtikel
	WHERE	dbo.tArtikelShop.cInet = 'N'
			OR dbo.tArtikelShop.nAktion & @Komplett = 0
			OR dbo.tArtikelShop.nInBearbeitung = 1;


END
go

