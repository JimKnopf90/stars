CREATE TRIGGER [dbo].[jtlActionValidator_tMerkmalWert]  
--     
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MaikS
--    
ON [dbo].[tMerkmalWert]  
AFTER DELETE 
AS 
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF; 
BEGIN 

	--
	--Überprüfen ob Trigger mit Inhalt aufgerufen wird
	--
	IF((SELECT COUNT(1) FROM DELETED) = 0)
	BEGIN
		RETURN;
	END;

	--
	-- tMerkmalWertSprache aufräumen
	--
	DELETE dbo.tMerkmalWertSprache
	FROM dbo.tMerkmalWertSprache
	JOIN DELETED ON DELETED.kMerkmalWert = dbo.tMerkmalWertSprache.kMerkmalWert;
  						
	--
	-- tMerkmalWertBild aufräumen
	--
	DELETE dbo.tMerkmalwertBildPlattform
	FROM dbo.tMerkmalwertBildPlattform
	JOIN DELETED ON DELETED.kMerkmalWert = dbo.tMerkmalwertBildPlattform.kMerkmalWert;
		
	--
	-- tArtikelMerkmal aufräumen
	--
	DELETE dbo.tArtikelMerkmal
	FROM dbo.tArtikelMerkmal
	JOIN DELETED ON DELETED.kMerkmalWert = dbo.tArtikelMerkmal.kMerkmalWert;

	--
	-- tQueue schreiben um Merkmale zu senden
	--
	INSERT INTO dbo.tQueue(kShop, kPlattform, cName, kWert, nAction)
	SELECT dbo.tShop.kShop, 2, 'tMerkmal', DELETED.kMerkmal, 1
	FROM DELETED  
	JOIN dbo.tMerkmal ON DELETED .kMerkmal = dbo.tMerkmal.kMerkmal
	CROSS JOIN dbo.tShop
	LEFT JOIN dbo.tQueue ON dbo.tQueue.kShop = dbo.tShop.kShop
			AND dbo.tQueue.kPlattform = 2
			AND dbo.tQueue.cName = 'tMerkmal'
			AND dbo.tQueue.kWert = DELETED.kMerkmal
			AND dbo.tQueue.nAction = 2
	WHERE dbo.tQueue.kWert IS NULL
	AND dbo.tMerkmal.nVerwendungszweck IN (0, 3);
END
go

