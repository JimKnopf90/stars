--- 
--- spWMSWareneingangKorrigieren
---

CREATE PROCEDURE [dbo].[spWMSWareneingangKorrigieren]
@kBenutzer INT,         -- Der Benutzer der den Vorgang ausführt
@kWarenlager INT,		 -- Warenlager auf dem wir arbeiten
@kArtikel INT,
@kWarenlagerPlatz INT,
@fMenge  DECIMAL(28,14),
@cCharge VARCHAR,
@dMhd DATETIME,
@kSessionId INT,
@kRMRetourPos INT = 0
	
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Author PN    

-- Funktion: Mit dieser Procedur werden Warenlagereingänge geändert, ohne übers ausbuchen zu gehen.
	
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;

DECLARE @kWarenlagereingang INT;
DECLARE @kLieferantenBestellung INT;
DECLARE @kLieferantenBestellungToCheck INT;
DECLARE @fMengeWarenlagereingang DECIMAL(28,14);
DECLARE @fMengeAktuell DECIMAL(28,14);
DECLARE @kLieferantenBestellungPos INT;
DECLARE @kRMRetoure INT;
DECLARE @fRetourePosMaxAnzahl INT;
DECLARE @nOtherRetourePos INT;
DECLARE @cInfoText VARCHAR(255);
DECLARE @fMengeKomplettWarenlagereingang DECIMAL(28,14);

IF(OBJECT_ID('tempdb..#LieferantenBestellungen') IS NOT NULL)
	BEGIN
		DROP TABLE #LieferantenBestellungen;
	END
	CREATE TABLE #LieferantenBestellungen(
		kLieferantenbestellung INT NOT NULL,
	);

	IF(OBJECT_ID('tempdb..#Warenlagereingaenge') IS NOT NULL)
	BEGIN
		DROP TABLE #Warenlagereingaenge;
	END
	CREATE TABLE #Warenlagereingaenge(
		kWarenlagereingang INT NOT NULL,
		kLieferantenBestellung INT NULL,
		fAnzahlAktuell DECIMAL(28,14) NOT NULL,
		nSort INT NOT NULL,
		dLieferdatum datetime,
		dErstellt datetime,
		kLieferantenBestellungPos INT
	);
   
BEGIN TRY
	BEGIN TRAN T0;
	SET @cInfoText =  'WMS-WE Korrekturbuchung';

    IF(@kRMRetourPos > 0)
	BEGIN

		SELECT @kRMRetoure = dbo.tRMRetourePos.kRMRetoure ,@fRetourePosMaxAnzahl = dbo.tRMRetourePos.fAnzahl, @nOtherRetourePos =count(OtherRetourPos.kRMRetourePos)
		FROM dbo.tRMRetourePos
		LEFT JOIN dbo.tRMRetourePos AS OtherRetourPos ON OtherRetourPos.kRMRetoure = dbo.tRMRetourePos.kRMRetoure AND  OtherRetourPos.kRMRetourePos != dbo.tRMRetourePos.kRMRetourePos AND dbo.tRMRetourePos.fAnzahl > 0
		WHERE dbo.tRMRetourePos.kRMRetourePos = @kRMRetourPos
		GROUP BY dbo.tRMRetourePos.kRMRetoure ,dbo.tRMRetourePos.fAnzahl;


		IF(@fRetourePosMaxAnzahl < @fMenge OR (@fRetourePosMaxAnzahl = @fMenge AND @nOtherRetourePos = 0))
		BEGIN

			IF(@fRetourePosMaxAnzahl = @fMenge AND @nOtherRetourePos = 0)
				RAISERROR ('ERROR_WMSWareneingangKorrigieren_1', 16, 1);
			ELSE
			    RAISERROR ('ERROR_WMSWareneingangKorrigieren_2', 16, 1);

			RETURN;
		END;

		SET @cInfoText =  'WMS/Packtisch+ Retouren Korrekturbuchung';

		-- Komplette retourpos löschen ?
		IF(@fRetourePosMaxAnzahl = @fMenge)
		BEGIN

			DELETE FROM  dbo.tRMRetourePos WHERE dbo.tRMRetourePos.kRMRetourePos = @kRMRetourPos;
			DELETE FROM  dbo.tRmStatusVerlauf WHERE dbo.tRmStatusVerlauf.kRMRetourePos = @kRMRetourPos;

		END;
		ELSE -- Oder Menge abziehen
		BEGIN

			UPDATE dbo.tRMRetourePos SET dbo.tRMRetourePos.fAnzahl =  (dbo.tRMRetourePos.fAnzahl - @fMenge)
			WHERE dbo.tRMRetourePos.kRMRetourePos = @kRMRetourPos;

		END;
		
		IF NOT EXISTS( SELECT kArtikel FROM tArtikel WHERE kArtikel = @kArtikel AND cLageraktiv = 'Y' AND kArtikel > 0)
		BEGIN		
		  COMMIT TRAN T0; 
		  RETURN;
		END;
	END;

    INSERT INTO #Warenlagereingaenge
    SELECT dbo.twarenlagereingang.kWarenlagereingang,dbo.tLieferantenBestellungPos.kLieferantenBestellung,dbo.twarenlagereingang.fAnzahlAktuell,
     CASE WHEN (dbo.tLieferantenBestellungPos.fMenge - dbo.tLieferantenBestellungPos.fMengeGeliefert) < 0 
               THEN 0 WHEN (dbo.tLieferantenBestellungPos.fMenge - dbo.tLieferantenBestellungPos.fMengeGeliefert) > 0 
			   THEN 1 
			   ELSE 2 END AS nSort, dbo.tLieferantenBestellung.dLieferdatum, dbo.tLieferantenBestellung.derstellt,dbo.tLieferantenBestellungPos.kLieferantenBestellungPos
    FROM  dbo.twarenlagereingang
    LEFT JOIN vStandardArtikel AS tartikel ON tArtikel.kArtikel = dbo.twarenlagereingang.kartikel 
    LEFT JOIN dbo.tWarenlagerPlatz ON dbo.tWarenlagerPlatz.kWarenlagerPLatz = dbo.tWarenlagerEingang.kWarenlagerPlatz
    LEFT JOIN dbo.tLieferantenBestellungPos ON dbo.tLieferantenBestellungPos.kLieferantenBestellungPos = dbo.twarenlagereingang.kLieferantenBestellungPos
    LEFT JOIN dbo.tLieferantenBestellung ON dbo.tLieferantenBestellung.kLieferantenBestellung = dbo.tLieferantenBestellungPos.kLieferantenBestellung
    WHERE  ((tWarenLagerEingang.kWarenLagerPlatz = @kWarenlagerPlatz AND tArtikel.kArtikel = @kArtikel) OR (dbo.tWarenLagerEingang.kRMRetourePos = @kRMRetourPos AND dbo.tWarenLagerEingang.kRMRetourePos > 0))
    AND dbo.twarenlagereingang.fAnzahlAktuell > 0  
    AND dbo.twarenlagerplatz.kwarenlager = @kWarenlager
    AND dbo.twarenlagereingang.kSessionID = @kSessionId
    AND (@dMhd IS NULL OR CONVERT(varchar(255), dbo.tWarenlagerEingang.dMHD, 104) = CONVERT(varchar(255), CONVERT(Datetime,@dMhd) , 104)) 
    AND (@cCharge = '' OR @cCharge IS NULL OR cChargenNr = @cCharge);
 

	INSERT INTO dbo.tArtikelHistory
	(
		--kArtikelHistory - this column value is auto-generated
		kWarenLagerPlatz,
		kArtikel,
		fAnzahl,
		dGebucht,
		kBenutzer,
		kWarenEingang,
		kBestellPos,
		kGutschriftPos,
		fEKNetto,
		cKommentar,
		kBuchungsart,
		kLieferscheinPos,
		fLagerBestandGesamt,
		fLagerBestand,
		kLieferantenBestellungPos,
		cLieferscheinNr,
		cChargenNr,
		dMHD,
		fVerfuegbar,
		fReserviert
  
	)
	SELECT dbo.tWarenLagerEingang.kWarenLagerPlatz,tWarenLagerEingang.kArtikel,-1 * @fMenge ,GETDATE() AS dErstellt, dbo.tWarenLagerEingang.kBenutzer,
	       0 AS kWarenLagerEingang,0 AS  kBestellPos, ISNULL(dbo.tWarenLagerEingang.kGutschriftPos,0),ISNULL(tWarenLagerEingang.fEKEinzel, ISNULL(dbo.tArtikel.fEKNetto,0.0)) AS fEKEinzel,
		   @cInfoText, 30, 0 ,MAX(dbo.tlagerbestand.fLagerbestandEigen) - @fMenge AS fLagerBestandGesamt, 
	   	   MAX(LagerBestandAufPlatz.fAnzahl) - @fMenge AS fLagerBestand, -- Nur Lagerbestand auf dem Platz wo der WE grade liegt
		   WLE.kLieferantenBestellungPos,dbo.tWarenLagerEingang.cLieferscheinNr,dbo.tWarenLagerEingang.cChargenNr,dbo.tWarenLagerEingang.dMHD,  ISNULL(dbo.tlagerbestand.fVerfuegbar,0),
		   ISNULL(dbo.tlagerbestand.fInAuftraegen,0)
	FROM #Warenlagereingaenge AS WLE
	JOIN dbo.tWarenLagerEingang ON dbo.tWarenLagerEingang.kWarenLagerEingang = WLE.kWarenlagereingang
	JOIN dbo.tlagerbestand ON dbo.tlagerbestand.kArtikel = dbo.tWarenLagerEingang.kArtikel
	JOIN dbo.tArtikel ON dbo.tArtikel.kArtikel = dbo.tWarenLagerEingang.kArtikel
	OUTER APPLY (SELECT	SUM(WLE_Platz.fAnzahlAktuell) AS fAnzahl
				 FROM dbo.tWarenLagerEingang AS WLE_Platz
			     WHERE WLE_Platz.kArtikel = dbo.tWarenLagerEingang.kArtikel
			     AND WLE_Platz.kWarenLagerPlatz = dbo.tWarenLagerEingang.kWarenlagerPlatz) AS LagerBestandAufPlatz
	WHERE ((dbo.tWarenLagerEingang.kWarenLagerPlatz = @kWarenlagerPlatz AND dbo.tWarenLagerEingang.kArtikel = @kArtikel) 
	   OR (dbo.tWarenLagerEingang.kRMRetourePos = @kRMRetourPos AND dbo.tWarenLagerEingang.kRMRetourePos > 0))
	GROUP BY dbo.tWarenLagerEingang.kWarenLagerPlatz,dbo.tWarenLagerEingang.kArtikel,dbo.tWarenLagerEingang.kBenutzer,ISNULL(dbo.tWarenLagerEingang.kGutschriftPos,0),ISNULL(dbo.tWarenLagerEingang.fEKEinzel, ISNULL(dbo.tArtikel.fEKNetto,0.0)),
			 dbo.tWarenLagerEingang.cKommentar, WLE.kLieferantenBestellungPos,dbo.tWarenLagerEingang.cLieferscheinNr,dbo.tWarenLagerEingang.cChargenNr,dbo.tWarenLagerEingang.dMHD,dbo.tlagerbestand.fVerfuegbar,dbo.tlagerbestand.fInAuftraegen;




    DECLARE CUR_Warenlagereingang CURSOR LOCAL FAST_FORWARD FOR 
    SELECT tWe.kWarenlagereingang,tWe.kLieferantenBestellung,tWe.fAnzahlAktuell,tWe.kLieferantenBestellungPos
    FROM #Warenlagereingaenge AS tWe
    ORDER BY tWe.nSort,tWe.dLieferdatum DESC,tWe.dErstellt;
			  
	   
	SELECT @fMengeKomplettWarenlagereingang = SUM(dbo.tWarenlagereingang.fAnzahlaktuell)
	FROM dbo.tWarenlagereingang
	WHERE dbo.tWarenlagereingang.kSessionID = @kSessionId
	AND dbo.tWarenlagereingang.kArtikel = @kArtikel;



    OPEN CUR_Warenlagereingang
    FETCH NEXT FROM CUR_Warenlagereingang INTO  @kWarenlagereingang,@kLieferantenBestellung,@fMengeWarenlagereingang,@kLieferantenBestellungPos

    SET @fMengeAktuell = @fMenge;

    WHILE (@@FETCH_STATUS = 0 AND @fMengeAktuell > 0)
    BEGIN

      -- Lieferantenbestellpos , MengeOffen anpassen
     IF (@kLieferantenBestellungPos IS NOT NULL AND @kLieferantenBestellungPos > 0)
	 BEGIN


	   DECLARE @xLieferantenBestellungPos AS XML;
	   SET @xLieferantenBestellungPos = (
		SELECT dbo.tLieferantenBestellungPos.kLieferantenbestellungPos AS kLieferantenbestellungPos, dbo.tLieferantenBestellungPos.kLieferantenbestellung AS kLieferantenbestellung, 
				dbo.tLieferantenBestellungPos.kArtikel AS kArtikel, dbo.tLieferantenBestellungPos.cArtNr, dbo.tLieferantenBestellungPos.cLieferantenArtNr, 
				dbo.tLieferantenBestellungPos.cName, dbo.tLieferantenBestellungPos.cLieferantenBezeichnung,
				dbo.tLieferantenBestellungPos.fUST, dbo.tLieferantenBestellungPos.fMenge, dbo.tLieferantenBestellungPos.cHinweis, 
				dbo.tLieferantenBestellungPos.fEKNetto, dbo.tLieferantenBestellungPos.nPosTyp, dbo.tLieferantenBestellungPos.cNameLieferant, 
				dbo.tLieferantenBestellungPos.nLiefertage, dbo.tLieferantenBestellungPos.dLieferdatum, dbo.tLieferantenBestellungPos.nSort,
				dbo.tLieferantenBestellungPos.kLieferscheinPos, 
				dbo.tLieferantenBestellungPos.fMengeGeliefert -  (CASE WHEN @fMengeAktuell >= @fMengeWarenlagereingang THEN @fMengeWarenlagereingang ELSE @fMengeAktuell END)  fMengeGeliefert, 
				dbo.tLieferantenBestellungPos.cVPEEinheit, dbo.tLieferantenBestellungPos.nVPEMenge
			FROM dbo.tLieferantenBestellungPos
			WHERE dbo.tLieferantenBestellungPos.kLieferantenBestellungPos = @kLieferantenBestellungPos
			FOR XML PATH('LieferantenbestellungPos'), TYPE );

	   

	   EXEC Lieferantenbestellung.spLieferantenBestellungPosBearbeiten @xLieferantenbestellungPos = @xLieferantenBestellungPos;

	   SET @fMengeKomplettWarenlagereingang = @fMengeKomplettWarenlagereingang - (CASE WHEN @fMengeAktuell >= @fMengeWarenlagereingang THEN @fMengeWarenlagereingang ELSE @fMengeAktuell END);
	 END
    
     IF(@kLieferantenBestellungPos IS NOT NULL AND NOT EXISTS (SELECT * FROM #LieferantenBestellungen WHERE kLieferantenbestellung = @kLieferantenBestellung))
	 BEGIN
	   INSERT INTO #LieferantenBestellungen (kLieferantenbestellung) VALUES (@kLieferantenBestellung);
	 END;

	 SET CONTEXT_INFO  0x5096;
     IF(@fMengeAktuell >= @fMengeWarenlagereingang)
	 BEGIN
	 
		DELETE FROM dbo.tWarenLagerEingang
		WHERE kWarenLagerEingang = @kWarenlagereingang;

		DELETE FROM dbo.tWarenLagerEingangHistorie
		WHERE kWarenLagerEingang = @kWarenlagereingang;

		SET @fMengeAktuell = @fMengeAktuell - @fMengeWarenlagereingang;

	 END;
	 ELSE
	 BEGIN

	   UPDATE dbo.tWarenLagerEingang SET fAnzahl = fAnzahl - @fMengeAktuell, fAnzahlAktuell = fAnzahlAktuell - @fMengeAktuell
	   WHERE  kWarenLagerEingang = @kWarenlagereingang;

	   UPDATE dbo.tWarenLagerEingangHistorie SET fAnzahl = fAnzahl - @fMengeAktuell
	   WHERE  kWarenLagerEingang = @kWarenlagereingang
	   AND kBuchungsArt = 10;

	   SET @fMengeAktuell = 0;

	 END;

    FETCH NEXT FROM CUR_Warenlagereingang INTO  @kWarenlagereingang,@kLieferantenBestellung,@fMengeWarenlagereingang,@kLieferantenBestellungPos
    END;

    CLOSE CUR_Warenlagereingang;
    DEALLOCATE CUR_Warenlagereingang;	
    


    --
    -- Lieferantenbestellungen Updaten. Es könnte sich der Status geändern haben
    --

    DECLARE CUR_LieferantenBestellungen CURSOR LOCAL FAST_FORWARD FOR 
    SELECT #LieferantenBestellungen.kLieferantenbestellung
    FROM #LieferantenBestellungen 

    OPEN CUR_LieferantenBestellungen
    FETCH NEXT FROM CUR_LieferantenBestellungen INTO  @kLieferantenBestellungToCheck

    WHILE (@@FETCH_STATUS = 0)
    BEGIN


    EXEC Lieferantenbestellung.spLieferantenBestellungStatusUpdate 
                                        @kLieferantenbestellung = @kLieferantenBestellungToCheck,
                                        @nStatusAuchZuruecksetzten = 1;

    FETCH NEXT FROM CUR_LieferantenBestellungen INTO @kLieferantenBestellungToCheck
    END 

    CLOSE CUR_LieferantenBestellungen
    DEALLOCATE CUR_LieferantenBestellungen	


    IF(@fMengeAktuell != 0)
    BEGIN
	   RAISERROR ('Menge konnte nicht komplett ausgebucht werden. Die Buchung wurde zurückgesetzt.', 16, 1)
	   RETURN;
    END;



    COMMIT TRAN T0; 


   	DECLARE @typeArtikel AS TYPE_spUpdateLagerbestand;

	INSERT INTO @typeArtikel (kArtikel)
	SELECT @kArtikel;

	IF(EXISTS(SELECT * FROM @typeArtikel))
	BEGIN
		EXEC dbo.spUpdatelagerbestand @typeArtikel;
	END;

END TRY
BEGIN CATCH

    ROLLBACK TRAN T0;

    DECLARE @ErrorMessage NVARCHAR(4000);
    SET @ErrorMessage =  ERROR_MESSAGE();

    RAISERROR (@ErrorMessage, 
		  16,
		  1);
END CATCH;
go

