--- 
--- spBestellungReservierenTest
---

CREATE PROCEDURE [dbo].[spBestellungReservierenTest] 
	@kPickliste INT, 
	@kBestellung INT, 
	@kWarenlager INT, 
	@kPicklisteVorlage INT, 
	@kBenutzer INT,
	@nAnzArtMin INT, 
	@nAnzArtMax INT, 
	@nGewMin DECIMAL(28,14), 
	@nGewMax DECIMAL(28,14), 
	@nTeilLiefErlaubt INT, 
	@fTeilliefPreis DECIMAL(28,14), 
	@nWEPlatzReservieren INT, 
	@nLadenlokalReservieren INT, 
	@nRetourenPlatzReservieren INT,
	@nSortierung INT, 
	@kSessionID INT, 
	@nEinartikelpickliste INT, 
	@kReineRollendeKommissionierung INT, 
	@nErfolgreich INT OUTPUT 
AS   
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
BEGIN	 
    DECLARE @kBestellPos INT, @kArtikel INT, @nTeilmengeWurdeReserviert INT, @nTestWert INT, @nIsUnique INT
    DECLARE @fAnzahl DECIMAL(28,14), @fWertDerReserviertenBestellung DECIMAL(28,14) 
    DECLARE @kWarenLagerEingang INT, @kPicklistePos INT, @kWarenlagerPlatz INT, @nMengeFuerDiesePositionGefunden INT, @kStueckliste INT
    DECLARE @fNochZuReservierendeMenge  DECIMAL(28,14), @fWLEAnzahlAktuell DECIMAL(28,14), @fPickposReservierungsMenge DECIMAL(28,14)
    DECLARE @cWarenlagerPlatz VARCHAR(255), @cArtikel VARCHAR(255), @cBestellung VARCHAR(255)
    DECLARE @cTeilbar CHAR(1)
    DECLARE @cLagerBereiche VARCHAR(MAX)
    DECLARE @nIsEazyShippingAuftrag INT
    DECLARE @nRechnungFertigCount INT
    DECLARE @nBoxenNurGanzeStuecklistenAufPL TINYINT;
    DECLARE @nMHDHandling INT
    DECLARE @nMinMHD INT
    DECLARE @fGesammtGewicht DECIMAL(28,14)
    DECLARE @fArtGewicht DECIMAL(28,14)
    DECLARE @temporary_FehlerTable TABLE(kSessionId INT,
								cText VARCHAR(255),
								nValue1 INT,
								nValue2 INT,
								nValue3 INT,
								cValue1 VARCHAR(255),
								cValue2 VARCHAR(255),
								cValue3 VARCHAR(255),
								kkey1 INT,
								kkey2 INT);	
    DECLARE @tempLagerbereiche TABLE(kWMSLagerbereich INT);
	DECLARE @nWAKeinAuftragSplittBeiTeillief TINYINT = 0;
    DECLARE @nOptionalMHDChargeAnywhere TINYINT = 0; -- Versteckte Option, wenn geschaltet kann man MHDs/Chargen auch reservieren wenn sie durcheinander liegen


    SET NOCOUNT ON;
    SET @nErfolgreich = 0
    SET @nTeilmengeWurdeReserviert = 0 
    SET @fGesammtGewicht = 0
    SELECT @cBestellung = cBEstellNr 
    FROM tBEstellung WITH(NOLOCK) 
    WHERE kBestellung = @kBestellung
    SELECT @nMHDHandling = nMHDHandling, 
        @nMinMHD = nMHDMinHaltbarkeit,
	   @nIsEazyShippingAuftrag = nEinArtikelPickliste, 
	   @nBoxenNurGanzeStuecklistenAufPL = nBoxenNurGanzeStuecklistenAufPL,
	   @cLagerBereiche = CASE WHEN LEN(cLagerbereiche) = 0 
					   THEN '' 
					   ELSE cLagerbereiche + ',' 
				    END
    FROM dbo.tPicklisteVorlage  WITH(NOLOCK) 
    WHERE dbo.tPicklisteVorlage.kPicklistevorlage = @kPicklisteVorlage


	IF(EXISTS(SELECT * FROM dbo.tOptions WHERE dbo.tOptions.cKey='MHDChargeAlternativ' AND dbo.tOptions.cValue = '1'))
	BEGIN
	  SET @nOptionalMHDChargeAnywhere = 1;
	END;

	SELECT @nWAKeinAuftragSplittBeiTeillief = nWAKeinAuftragSplittBeiTeillief 
	FROM dbo.tWarenLagerOptionen
	WHERE dbo.tWarenLagerOptionen.kWarenLager = @kWarenlager;

    IF(@nTeilLiefErlaubt = 1 AND @nIsEazyShippingAuftrag = 1 AND @nWAKeinAuftragSplittBeiTeillief = 0)
    BEGIN
	   SELECT @nRechnungFertigCount = COUNT(*) 
		  FROM dbo.trechnung WITH(NOLOCK)
		  WHERE dbo.trechnung.tBestellung_kBestellung = @kBestellung
			 AND (
				dbo.trechnung.dDruckdatum IS NOT NULL 
				OR dbo.trechnung.dEmailversandt IS NOT NULL
				)
	  
	   IF(@nRechnungFertigCount > 0)
		  SET @nTeilLiefErlaubt = 0	
    END;

    IF(LEN(@cLagerBereiche) > 0)
    BEGIN

        -- Füllt die Temporäre Tabelle, mit werten aus dem komma separierten varchar
		   INSERT INTO @tempLagerbereiche (kWMSLagerbereich) 
		   SELECT  CAST(part as INT) FROM [dbo].[SplitString] (@cLagerBereiche,',');
     END

 	DECLARE cur_BestellPos CURSOR LOCAL FAST_FORWARD FOR
	--In diesem Cursor werden alle offenen (Nicht ausgelieferte Menge - Menge in Pickpositionen) Positionen für die Bestellung geholt
SELECT dbo.tbestellpos.kBestellPos
		,dbo.tArtikel.kArtikel
		,Versand.vBestellPosLieferInfo.fAnzahlReserviertEigen AS fAnzahlOffeN
		,tArtikel.cTeilbar
		,ISNULL(dbo.tbestellpos.kBestellstueckliste, 0)
		,CASE ISNULL(dbo.tBestellpos.cUnique, '')
			WHEN ''
				THEN 0
			ELSE 1
			END
		,dbo.tArtikel.fArtGewicht
	FROM dbo.tbestellpos WITH (NOLOCK)
	JOIN Versand.vBestellPosLieferInfo WITH (NOLOCK) ON Versand.vBestellPosLieferInfo.kBestellpos = dbo.tBEstellpos.kBestellpos
	JOIN dbo.tArtikel WITH (NOLOCK) ON dbo.tArtikel.kArtikel = dbo.tbestellpos.tArtikel_kArtikel AND ISNULL(dbo.tArtikel.kStueckliste, 0) = 0
	LEFT JOIN dbo.tbestelleigenschaft WITH (NOLOCK) ON dbo.tbestelleigenschaft.kBestellPos = dbo.tbestellpos.kbestellpos
	WHERE dbo.tbestellpos.tBestellung_kBestellung = @kBestellung
		AND (Versand.vBestellPosLieferInfo.fAnzahlReserviertEigen  > 0)
		AND dbo.tArtikel.cLagerAktiv = 'Y'
		AND dbo.tArtikel.cLagerVariation <> 'Y'
		AND (dbo.tbestellpos.kBestellstueckliste != dbo.tbestellpos.kBestellPos)
		AND dbo.tbestelleigenschaft.kbestelleigenschaft IS NULL
		AND (
			NOT EXISTS (
				SELECT *
				FROM dbo.teigenschaft WITH (NOLOCK)
				WHERE cAktiv = 'Y'
					AND kArtikel = dbo.tartikel.kArtikel
					AND dbo.tEigenschaft.cTyp NOT IN ('PFLICHT-FREIFELD','FREIFELD')
				)
			)
	ORDER BY dbo.tbestellpos.kBestellstueckliste,dbo.tbestellpos.kbestellpos;
		  
		  OPEN cur_BestellPos   
		  FETCH NEXT FROM cur_BestellPos INTO @kBestellPos, @kArtikel, @fAnzahl, @cTeilbar, @kStueckliste, @nIsUnique,@fArtGewicht
		  --	BEGIN TRANSACTION TransBestellung 
		  --Durchläuft jede Bestellpos für die noch Menge reserviert werden kann
		  WHILE @@FETCH_STATUS = 0   
		  BEGIN
			 SET @nMengeFuerDiesePositionGefunden = 0
			 SELECT @cArtikel = cArtNr FROM tartikel WITH(NOLOCK) 
				WHERE kartikel = @kartikel	
			 --Anfang der alten Unterprozedur Bestellpos Reservieren
			 SET @nTeilmengeWurdeReserviert = 0 --Gibt an, ob die komplette Menge reserviert werden konnte  
			 SET @fNochZuReservierendeMenge = @fAnzahl   
			 --Cursor über die WarenlagerEingaenge die den Anforderungen entsprechen.
			 DECLARE cur_WarenlagerEingang CURSOR LOCAL FAST_FORWARD FOR
				SELECT tWarenlagerEingang.kWarenLagerEingang, 
				    tWarenlagerEingang.fAnzahlAktuell - ISNULL(tWarenLagerEingang.fAnzahlReserviertPickpos, 0)
			 , tWarenlagerEingang.kWarenlagerPlatz
			 FROM  tWarenLagerEingang  WITH(NOLOCK)
				JOIN tWarenLagerPlatz  WITH(NOLOCK) ON tWarenLagerPlatz.kWarenLagerPlatz = tWarenLagerEingang.kWarenLagerPlatz 
				                                    AND tWarenLagerPlatz.kWarenLager = @kWarenlager
				                                    AND tWarenLagerPlatz.nStatus = 0
				                                    AND (
												LEN(@cLagerBereiche) = 0 
												OR tWarenLagerPlatz.kWarenLagerPlatz IN (SELECT tWMSLagerBereichPlatz.kWarenLagerPlatz 
																				    FROM tWMSLagerBereichPlatz WITH(NOLOCK)
																				    JOIN @tempLagerbereiche AS t1 ON t1.kWMSLagerbereich = tWMSLagerBereichPlatz.kWMSLagerbereich)
												)
											AND (
											 tWarenlagerPlatz.kWarenlagerPlatzTyp IN (1, 7) 
											 OR (
												@nWEPlatzReservieren = 1 
												AND tWarenlagerPlatz.kWarenlagerPlatzTyp = 3
												)
											 OR (
												@nRetourenPlatzReservieren = 1 
												AND tWarenlagerPlatz.kWarenlagerPlatzTyp = 11
												)
											 OR (
	   											    @nLadenlokalReservieren = 1 
												AND tWarenlagerPlatz.kWarenlagerPlatzTyp = 8
												)
											 )
				JOIN tArtikel  WITH(NOLOCK) ON tWarenlagerEingang.kArtikel = tARtikel.kArtikel
										  --Es dürfen keine Chargen/MHD-Pflichtigen Artikel reserviert werden, bei denen es zwei gleiche Chargen/MHDs
    										  --auf mehr als einem RegalPlatz, BLockplatz,WE gibt
										  --Ansonsten kann der spätere verzögerte Pick inkl. Tauschen beim InDieBoxPacken bzw. Verpacken nicht eindeutig aufgelöst werden
		 								  AND (
												(
												tArtikel.nCharge = 0 
												AND tArtikel.nMHD = 0 
												)
										  OR (@nOptionalMHDChargeAnywhere = 1)
										  OR 
											 (
												NOT EXISTS (
												    SELECT twarenlagereingang.kartikel 
													   FROM twarenlagereingang  WITH(NOLOCK)
													   JOIN tWarenlagerPlatz  WITH(NOLOCK) ON tWarenlagerPlatz.kwarenlagerplatz = twarenlagereingang.kwarenlagerplatz
													   JOIN tartikel  WITH(NOLOCK) on twarenlagereingang.kartikel = tartikel.kartikel
													   WHERE (tartikel.ncharge > 0 OR tartikel.nmhd> 0)
														  AND twarenlagereingang.fAnzahlAktuell > 0				  
														  AND tWarenLagerEingang.kArtikel = @kArtikel
														  AND twarenlagerplatz.kWarenlager = @kWarenlager
														  AND tartikel.kartikel = tWarenLagerEingang.kArtikel
														  AND (
															 tWarenlagerPlatz.kWarenlagerPlatzTyp IN (1, 7) 
															 OR (
																@nWEPlatzReservieren = 1 
																AND tWarenlagerPlatz.kWarenlagerPlatzTyp = 3
																)
															 OR (
																@nRetourenPlatzReservieren = 1 
																AND tWarenlagerPlatz.kWarenlagerPlatzTyp = 11
																)
															 OR (
																@nLadenlokalReservieren = 1 
																AND tWarenlagerPlatz.kWarenlagerPlatzTyp = 8
																)
															 )
													   GROUP BY twarenlagereingang.kartikel, twarenlagereingang.cchargennr, twarenlagereingang.dmhd
													   HAVING COUNT(DISTINCT tWarenlagerPlatz.kwarenlagerplatz) > 1)
													   )	
												--es werden nur chargen und MHD-reine plätze betrachtet
												OR (
												    tArtikel.nMHD = 1 
												    AND 2 > (SELECT COUNT(DISTINCT tWE2.dMHD)
															 FROM tWarenlagerEingang tWE2  WITH(NOLOCK)
															 WHERE kartikel = tartikel.kartikel
																AND tWE2.kwarenlagerplatz = tWarenLagerEingang.kWarenLagerPlatz
																AND tWE2.fanzahlaktuell > 0)
												    )
												OR (
												    tArtikel.nCharge = 1 
												    AND 2 > (SELECT COUNT(DISTINCT tWE3.cChargenNr)
															 FROM tWarenlagerEingang tWE3  WITH(NOLOCK)
															 WHERE tWE3.kartikel = tartikel.kartikel
																AND tWE3.kwarenlagerplatz = tWarenLagerEingang.kWarenLagerPlatz
																AND tWE3.fanzahlaktuell > 0
														  )
												    )
											 )
		      WHERE tWarenLagerEingang.kArtikel = @kArtikel
			 AND (
				    tArtikel.nMHD = 0 
				    OR datediff(d, 0, tWarenlagerEingang.dMHD)  >=  datediff(d, 0, (GETDATE() + @nMinMHD))  -- Es darf kein abgelaufenes MHD reserviert werden, mindest MHD kann optional angegeben werden 
				    OR ISNULL(@nMHDHandling,0) > 0
				 )
				
			 GROUP BY tWarenlagerEingang.kWarenLagerEingang,tartikel.nmhd,tWarenLagerEingang.dErstellt, tWarenLagerPlatz.nsort,tWarenLagerPlatz.nprio, tWarenLagerPlatz.cName, twarenlagereingang.dmhd, tWarenlagerEingang.fAnzahlAktuell, tWarenlagerEingang.kWarenlagerPlatz, tWarenLagerEingang.fAnzahlReserviertPickpos
			 HAVING tWarenlagerEingang.fAnzahlAktuell - isnull(tWarenLagerEingang.fAnzahlReserviertPickpos, 0) > 0
			 ORDER BY
			 --MHD-Artikel werden immer nach MHD ausgelagert
			    CASE tartikel.nmhd WHEN 1 
				   THEN twarenlagereingang.dmhd 
				   ELSE 0  
			    END,
			    CASE @nSortierung WHEN 0 
				   THEN tWarenLagerEingang.dErstellt 
				   ELSE NULL 
			    END,
				CASE @nSortierung WHEN 1 
				   THEN tWarenLagerPlatz.nPrio 
				   ELSE NULL 
			    END DESC,
			    CASE @nSortierung WHEN 1 
				   THEN tWarenLagerPlatz.nsort 
				   ELSE NULL 
			    END,
			    CASE @nSortierung WHEN 2 
				   THEN tWarenLagerPlatz.cName 
				   ELSE NULL 
			    END

				--Durchläuft die WarenlagerEingaenge solange, bis genügend Menge reserviert wurde oder bis alle durchsucht wurden
				OPEN cur_WarenlagerEingang 
				FETCH NEXT FROM cur_WarenlagerEingang INTO @kWarenlagerEingang, @fWLEAnzahlAktuell, @kWarenlagerPlatz 
				WHILE @@FETCH_STATUS = 0 
				BEGIN 
				    SET @nMengeFuerDiesePositionGefunden = 1
				    IF (@fNochZuReservierendeMenge > @fWLEAnzahlAktuell) 
				    BEGIN
					   SET @fPickposReservierungsMenge = @fWLEAnzahlAktuell
					   SET @fNochZuReservierendeMenge = @fNochZuReservierendeMenge - @fWLEAnzahlAktuell 
	   			    END 
				    ELSE 
				    BEGIN
					   SET @fPickposReservierungsMenge = @fNochZuReservierendeMenge
					   SET @fNochZuReservierendeMenge = 0 
				    END			
				    IF (@fTeilliefPreis > 0) 
	    			    --Nur wenn die Einschränkung auf den Preis eingestellt wurde, brauch der Preis berechnet werden  
				    BEGIN
					   SELECT @fWertDerReserviertenBestellung = @fWertDerReserviertenBestellung + tArtikel.fVKBrutto
						  FROM vStandardArtikel AS tArtikel  WITH(NOLOCK)
						  WHERE kArtikel = @kArtikel 
				    END 
				    --Es wurde genügend Menge reserviert
				    IF (@fNochZuReservierendeMenge = 0) 
				    BEGIN 
					   BREAK 
				    END 

				    --Es wurde noch nicht genügend Menge reserviert, es wird nun der nächste WarenlagerEingang geprüft
				    FETCH NEXT FROM cur_WarenlagerEingang INTO @kWarenlagerEingang, @fWLEAnzahlAktuell, @kWarenlagerPlatz 
				END 
				IF (@fNochZuReservierendeMenge = @fAnzahl)
				    SET @nTeilmengeWurdeReserviert = -1 --Es wurde keine Menge reserviert  
				ELSE 
				    IF (@fNochZuReservierendeMenge > 0)
				    BEGIN
					   SET @nTeilmengeWurdeReserviert = 1 --Es wurde nur eine Teilmenge reserviert  
				    END
				CLOSE cur_WarenlagerEingang 
				DEALLOCATE cur_WarenlagerEingang 
				--Ende der alten Unterprozedur BestellposReservieren	  
				IF (@nTeilmengeWurdeReserviert <> 0 AND -- Teilmenge gefunden
				    (@nTeilLiefErlaubt = 0 OR -- Keine Teillieferung relaubt 
				    (((@kStueckliste > 0 ) AND (@nEinartikelpickliste = 1 OR @kReineRollendeKommissionierung = 1 OR @nBoxenNurGanzeStuecklistenAufPL = 1)) OR --Stueckliste nicht komplett für bestimmte prozesse
				    ((@nIsUnique > 0) AND (@nEinartikelpickliste = 1 OR @kReineRollendeKommissionierung = 1))) --Konfi nicht komplett für bestimmte prozesse
				    )) 
				--Es konnte nicht die gesamte Menge der letzten Position reserviert werden und Teilmengen sind nicht erlaubt (bei Stuecklistenpositionen im EazyShipping bzw. der reinen Roko sind Teilmengen nie erlaubt)
				--Komplette Reservierungen dieser Bestellung müssen zurückgesetzt werden 
				BEGIN
				    SET @nErfolgreich = 0  			
				    IF (@kStueckliste = 0 OR @nTeilLiefErlaubt = 0 OR (@nEinartikelpickliste = 0 AND @kReineRollendeKommissionierung = 0))
					   BREAK      
				    END 		
				    IF (@nTeilmengeWurdeReserviert >= 0) --Es wurde eine Teilmenge (1) oder die gesamte Menge (0) reserviert 
				    BEGIN		
					   IF(@kStueckliste > 0 AND @nTeilmengeWurdeReserviert = 1 AND (@nEinartikelpickliste = 1 OR @nBoxenNurGanzeStuecklistenAufPL = 1) AND @nTeilLiefErlaubt = 1)
						  SET @nErfolgreich = 0
					   ELSE
					   BEGIN
						  SET @nErfolgreich = 1 
						  SET @fGesammtGewicht = @fGesammtGewicht + (@fAnzahl - @fNochZuReservierendeMenge) * @fArtGewicht
					   END
				    END	
			 FETCH NEXT FROM cur_BestellPos INTO @kBestellPos, @kArtikel, @fAnzahl, @cTeilbar,@kStueckliste, @nIsUnique,@fArtGewicht
		  END   
		  CLOSE cur_BestellPos   
		  DEALLOCATE cur_BestellPos  
		  
		  IF(((@nGewMax > 0 AND @fGesammtGewicht > @nGewMax)  OR (@nGewMin > 0 AND @fGesammtGewicht < @nGewMin)) AND @nTeilLiefErlaubt = 1)
			 SET @nErfolgreich = 0
		 
END
go

