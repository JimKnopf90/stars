--- 
--- spGetSubCategories
---

CREATE PROCEDURE [dbo].[spGetSubCategories] @kRoot INT -- PK Wurzel-Kategorie

-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$

AS
BEGIN	
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;

-- liefert die PKs aller Unterkategorien zu einer gegebenen Wurzel-Kategorie EXklusive des PKs der Wurzel-Kategorie
-- (in der Reihenfolge einer Breitensuche)

-- Ergebnis-Tabelle
DECLARE @tUnterkategorien AS TABLE (kKategorie INT)

-- Hilfs-Tabelle (klassische Breitensuche)
DECLARE @tQueue AS TABLE (kKategorie INT)
INSERT INTO @tQueue VALUES (@kRoot)

-- Hilfs-Tabelle (Zwischenspeicherung)
DECLARE @tKinder AS TABLE (kKategorie INT)

-- aktueller Knoten
DECLARE @kCurrent INT

WHILE ((SELECT COUNT(*) FROM @tQueue) != 0)
BEGIN
	SET @kCurrent = (SELECT TOP 1 * FROM @tQueue);
	DELETE FROM @tKinder
	INSERT INTO @tKinder
		SELECT kKategorie
		FROM tkategorie WITH(NOLOCK)
		WHERE kOberKategorie = @kCurrent;
	INSERT INTO @tUnterkategorien
		SELECT * FROM @tKinder;
	INSERT INTO @tQueue
		SELECT * FROM @tKinder;
	DELETE FROM @tQueue WHERE kKategorie = @kCurrent; -- Achtung: NICHT DELETE TOP(1), weil sonst neue Datensätze oben statt unten eingefügt != Queue !!! => Absturz
END

SELECT * FROM @tUnterkategorien

END
go

