--
-- CleanUp-Trigger für das Löschen von Mailanhängen
--
	CREATE TRIGGER [dbo].[jtlActionValidator_tFormularEMailVorlageAnhang]
	--
	-- Copyright (c) 2012-2017 by JTL Software GmbH
	-- Datum: $Date$
	-- Version: $Rev$
	-- Autor: MP
	--
	ON [dbo].[tFormularEMailVorlageAnhang]
	AFTER DELETE
	AS
	SET NOCOUNT ON;
	SET ANSI_NULLS ON;
	SET ANSI_NULL_DFLT_ON ON;
	SET ANSI_PADDING ON;
	SET CONCAT_NULL_YIELDS_NULL ON;
	SET XACT_ABORT OFF;
	BEGIN

		--
		-- Vorlagendaten entfernen
		--
			DELETE tFormularAnhangDaten WITH(ROWLOCK)
			FROM tFormularAnhangDaten WITH(ROWLOCK)
			JOIN DELETED ON tFormularAnhangDaten.kFormularAnhangDaten = DELETED.kFormularAnhangDaten
	
	END
go

