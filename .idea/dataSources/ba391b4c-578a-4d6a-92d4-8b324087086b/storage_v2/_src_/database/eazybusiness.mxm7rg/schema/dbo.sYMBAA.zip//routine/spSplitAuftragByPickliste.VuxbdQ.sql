--- 
--- spSplitAuftragByPickliste
---

CREATE PROCEDURE [dbo].[spSplitAuftragByPickliste]
	--
	-- Copyright (c) 2012-2017 by JTL Software GmbH
	-- Datum: $Date$
	-- Version: $Rev$
	--


    -- Funktion: Spittet einen Auftrag nach den Artikelmengen in der Pickliste

	@kBestellung INT,
	@kBenutzer INT,
     @kPickliste INT
  
  
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN TRAN T1  
	DECLARE @nRet INT;
	DECLARE @kBestellungNewOrder INT;
	DECLARE @kWarenlager INT;
	DECLARE @text varchar(1000);
	DECLARE @Temp_BestellPosNeu TABLE(kBestellPos INT,kArtikel INT,fMenge DECIMAL(28,5),kBestellstueckliste INT);
	DECLARE @cBestellNrQuell VARCHAR(255);
	DECLARE @cBestellNrSlitt VARCHAR(255);
  
	BEGIN TRY  
	    SET @nRet = 0;
	    SET @kBestellungNewOrder = 0;

	    SELECT @kWarenlager = dbo.tPickliste.kWarenLager 
         FROM dbo.tPickliste 
         WHERE dbo.tPickliste.kPickliste = @kPickliste;


	    INSERT INTO @Temp_BestellPosNeu
	    SELECT dbo.tbestellpos.kbestellpos AS kBestellpos, dbo.tbestellpos.tArtikel_kArtikel, CASE WHEN SUM(dbo.tpicklistepos.fAnzahl) IS NULL 
	 						 THEN CASE WHEN dbo.tbestellpos.kBestellStueckliste > 0 
							            THEN (cast (SUM(dbo.tbestellpos.nAnzahl)AS DECIMAL) *  (cast (StueckListenAnteile.AnzahlPickposStuecklisten AS DECIMAL) / cast (StueckListenAnteile.AnzahlStuecklistenVater AS DECIMAL)))
							           ELSE SUM(dbo.tbestellpos.nAnzahl) END
	 						 ELSE SUM(ISNULL(dbo.tpicklistepos.fAnzahl,0.0)) END AS fAnzahlNeu, dbo.tbestellpos.kBestellStueckliste
	    FROM dbo.tbestellpos WITH(NOLOCK)
	    LEFT JOIN dbo.tArtikel ON dbo.tArtikel.kArtikel = dbo.tbestellpos.tArtikel_kArtikel
	    LEFT JOIN dbo.tpicklistepos WITH(NOLOCK) ON dbo.tpicklistepos.kbestellpos = dbo.tbestellpos.kbestellpos 
	 									  AND dbo.tpicklistepos.kPickliste = @kPickliste 
	 									  AND dbo.tpicklistepos.nStatus < 40

	    OUTER APPLY (SELECT DISTINCT ISNULL(cast (AnzahlInPickPos.AnzahlPickPos AS DECIMAL) / ( cast (AnzahlInPickPos.AnzahlBestellpos AS DECIMAL) / cast (vater.nAnzahl AS DECIMAL)),0) AS AnzahlPickposStuecklisten , vater.nAnzahl AS AnzahlStuecklistenVater
	                 FROM tBestellPos AS BestPosStueckListe
				   LEFT JOIN (SELECT  tbestellpos.kbestellpos ,tbestellpos.nAnzahl 
				             FROM tbestellpos
						   WHERE tbestellpos.tBestellung_kBestellung = @kBestellung
						   ) AS vater ON vater.kbestellpos = BestPosStueckListe.kbestellstueckliste
				  OUTER APPLY (SELECT TOP 1 SUM(CheckPickPos.fAnzahl) AS AnzahlPickPos,  CheckBestellPos.nAnzahl AS AnzahlBestellpos
						   FROM dbo.tpicklistepos AS CheckPickPos
					        JOIN dbo.tbestellpos AS CheckBestellPos ON  CheckBestellPos.kBestellPos = CheckPickPos.kBestellPos
						   WHERE CheckBestellPos.kBestellStueckliste = tBestellPos.kBestellStueckliste 
						   AND CheckPickPos.kPickliste = @kPickliste 
	 					   AND CheckPickPos.nStatus < 40
						   AND CheckBestellPos.tbestellung_kBestellung = @kBestellung 
						   GROUP BY CheckPickPos.kBestellPos,CheckBestellPos.nAnzahl ) AS AnzahlInPickPos -- Wie ist der Anteil der LagerArtikel in der Pickliste

				  WHERE tBestellPos.kBestellStueckliste = BestPosStueckListe.kBestellStueckliste 
				  AND BestPosStueckListe.tBestellung_kBestellung = @kBestellung
				 
				) AS StueckListenAnteile --Brauchen wir um die Freipositionen der Stücklisten , anteilig des Vater absplitten zu können
	    WHERE dbo.tbestellpos.tBestellung_kBestellung = @kBestellung

	    AND (((dbo.tpicklistepos.kPicklistePos IS NOT NULL 
		    OR dbo.tArtikel.cLagerAktiv = 'N' -- Alle die keine LagerArtikel sind  mit ansplitten
		    OR dbo.tbestellpos.nType IN (0,2))  AND (dbo.tbestellpos.cUnique IS NULL OR dbo.tbestellpos.cUnique = '')) --VersandPos und FreiPos mit ansplitten
	         OR (LEN(dbo.tbestellpos.cUnique) > 0 AND dbo.tbestellpos.cUnique IN  (SELECT cUnique 
	 																   FROM dbo.tbestellpos b2 
	 																   JOIN dbo.tpicklistepos p2 WITH(NOLOCK) ON p2.kbestellpos = b2.kbestellpos
	 																   WHERE b2.tBestellung_kBestellung = @kBestellung
	 	    												           	   AND p2.kPickliste = @kPickliste)))
	    GROUP BY dbo.tbestellpos.kbestellpos, dbo.tbestellpos.tArtikel_kArtikel,dbo.tbestellpos.kBestellStueckliste,StueckListenAnteile.AnzahlPickposStuecklisten,StueckListenAnteile.AnzahlStuecklistenVater
	    HAVING  CASE WHEN SUM(dbo.tpicklistepos.fAnzahl) IS NULL 
	 			  THEN CASE WHEN dbo.tbestellpos.kBestellStueckliste > 0 
				  THEN (SUM(dbo.tbestellpos.nAnzahl) *  (StueckListenAnteile.AnzahlPickposStuecklisten / StueckListenAnteile.AnzahlStuecklistenVater))
				  ELSE SUM(dbo.tbestellpos.nAnzahl) END
	 			  ELSE SUM(ISNULL(dbo.tpicklistepos.fAnzahl,0.0)) END > 0




	    	INSERT INTO @Temp_BestellPosNeu(kBestellPos,kArtikel,fMenge)
		SELECT tbestellpos.kBestellStueckliste,Vater.tArtikel_kArtikel, (( cast (MAX(ISNULL(t1.fAnzahlNeu,0.0))AS DECIMAL) / SUM( cast (ISNULL(tbestellpos.nAnzahl,0.0) AS DECIMAL)  )) * Vater.nAnzahl) AS fMengeGesammt
		FROM tbestellpos
		JOIN tBestellpos AS Vater ON Vater.kBestellPos = tbestellpos.kBestellStueckliste
		LEFT JOIN (SELECT BestNeu.kBestellStueckliste,SUM(cast (ISNULL(BestNeu.fMenge,0.0)AS DECIMAL)) fAnzahlNeu
				    FROM @Temp_BestellPosNeu BestNeu
				    WHERE BestNeu.kBestellPos != BestNeu.kBestellStueckliste
				    and BestNeu.kBestellStueckliste > 0
				    group by BestNeu.kBestellStueckliste) AS t1 ON  t1.kBestellStueckliste = tbestellpos.kBestellStueckliste
		WHERE tbestellpos.kBestellPos != tbestellpos.kBestellStueckliste
		and tbestellpos.kBestellStueckliste > 0
		and tbestellpos.tBestellung_kBestellung = @kBestellung
		group by Vater.tArtikel_kArtikel,tbestellpos.kBestellStueckliste,Vater.nAnzahl
		HAVING MAX(t1.fAnzahlNeu) > 0;


	    -- Alle Artikel die abgesplittet werden sollen
	    DECLARE @xSplitBestellPosition AS XML;
	    SET @xSplitBestellPosition = (
	    SELECT PosNeu.kBestellPos AS kBestellpos,  PosNeu.fMenge AS fAnzahlNeu
	    FROM @Temp_BestellPosNeu AS PosNeu
	    FOR XML PATH ('Bestellpos'), TYPE);


	   --  SET CONTEXT_INFO 0x5127

	     IF(@xSplitBestellPosition IS NOT NULL)
	     BEGIN
		   EXEC Auftrag.spSplitAuftrag @xSplitBestellPosition, @kBenutzer;
	     END

		--SET CONTEXT_INFO 0x0000



		
		-- Die Abgesplittete Bestellung, sie geht bei uns nicht raus.
	     SELECT TOP 1 @kBestellungNewOrder = kBestellung, @cBestellNrSlitt = cBestellNr
	     FROM tBestellung
	     WHERE kSplitBestellung = @kBestellung
	     ORDER BY kBestellung DESC;


		-- Wir splitten das auch was ausgeliefert wird, deswegen tauschen wir die Bestell Nummern wieder
	     SELECT @cBestellNrQuell = cBestellNr
	     FROM tBestellung
	     WHERE kBestellung = @kBestellung
	     ORDER BY kBestellung DESC;

	     UPDATE tBestellung 
	     SET cBestellNr = @cBestellNrSlitt
	     WHERE kBestellung = @kBestellung;
	    
	     UPDATE tBestellung 
	     SET cBestellNr = @cBestellNrQuell
	     WHERE kBestellung = @kBestellungNewOrder;
		---


		-- Teillieferung des Ursprungs rausnehmen
		UPDATE tBestellungWMSFreigabe SET nTeillieferungErlaubt = 0
		WHERE nTeillieferungErlaubt = 1
		AND kBestellung = @kBestellung;


		--- PicklistePos muß auch zurechtgesplittet werden
		UPDATE tPicklistePos 
		SET tPicklistePos.kBestellung = @kBestellungNewOrder
		FROM tPicklistePos
		JOIN tBestellPos ON tBestellPos.kBestellPos = tPicklistePos.kBestellPos
		WHERE tBestellPos.tBestellung_kBestellung  IN (@kBestellungNewOrder,@kBestellung)
	     AND tPicklistePos.kPickliste = @kPickliste;



	     EXEC dbo.spSplitPicklisteByAuftrag  
		      @kBestellungNewOrder = @kBestellung,
			 @kBestellung = @kBestellungNewOrder,
			 @kWarenlager = @kWarenlager,
			 @kPickliste = @kPickliste;

	     ---
	
		IF(@kBestellungNewOrder = 0)
			SET @nRet = -203000474;
		ELSE
		BEGIN
			SELECT @kBestellungNewOrder;
		END;


		IF (@nRet = 0)
			COMMIT TRAN T1;
		ELSE
			ROLLBACK TRAN T1;


		SELECT @nRet;

	END TRY  
  
	BEGIN CATCH
		SET @text = ERROR_MESSAGE();
		ROLLBACK TRAN T1
		SELECT -203000473; -- unbekannter Fehler
		SET @nRet = -203000473;

	END CATCH
go

