-- 
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date: 2017-02-15 07:48:57 +0100 (Mi, 15 Feb 2017) $
-- Version: $Rev: 54820 $
--
CREATE VIEW [dbo].[vBestellLieferInfo] AS  
SELECT  
	vBestellposLieferInfo.kBestellung,   
	-- Bildet die Summen über vBestellposLieferInfo, dort stehen genauere Erklärungen zur Berechnung   
	SUM(ISNULL(vBestellposLieferInfo.nAnzahlAuszuliefern,0)) AS nAnzahlAuszuliefern,   
	SUM(ISNULL(vBestellposLieferInfo.nAnzahlGeliefert,0)) AS nAnzahlGeliefert,   
	SUM(ISNULL(vBestellposLieferInfo.nAnzahlVerfuegbar,0)) AS nAnzahlVerfuegbar,   
	SUM(ISNULL(CASE WHEN vBestellposLieferInfo.nAnzahlFehlbestand > 0 THEN vBestellposLieferInfo.nAnzahlFehlbestand ELSE 0 END ,0)) AS nAnzahlFehlbestand,   
	CASE   
	-- Status 10 (Vollständig Lieferbar):  nAnzahlFehlbestand = 0   
	WHEN SUM(ISNULL(CASE WHEN vBestellposLieferInfo.nAnzahlFehlbestand > 0 THEN vBestellposLieferInfo.nAnzahlFehlbestand ELSE 0 END ,0)) <= 0 THEN 10    
	-- Status 20 (Nicht Lieferbar): nAnzahlAuszuliefern <= nAnzahlFehlbestand   
	WHEN SUM(ISNULL(vBestellposLieferInfo.nAnzahlAuszuliefern,0)) <= SUM(ISNULL(vBestellposLieferInfo.nAnzahlFehlbestand,0)) THEN 20   
	-- Status 30 (Teilweise Lieferbar): nAnzahlFehlbestand > 0 AND nAnzahlFehlbestand < nAnzahlAuszuliefern   
	ELSE 30   
	END AS nStatus   
FROM   
	vBestellposLieferInfo  
GROUP BY vBestellposLieferInfo.kBestellung
go

