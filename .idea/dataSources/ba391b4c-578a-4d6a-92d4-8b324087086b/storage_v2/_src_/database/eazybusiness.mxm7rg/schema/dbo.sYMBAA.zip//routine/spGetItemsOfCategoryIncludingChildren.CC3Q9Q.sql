--- 
--- spGetItemsOfCategoryIncludingChildren
---

CREATE PROCEDURE [dbo].[spGetItemsOfCategoryIncludingChildren] 
	@kCategory int 
AS 
BEGIN	 
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
	CREATE TABLE #tItemsOfCategory (kItem int); 
	INSERT INTO #tItemsOfCategory 
		SELECT tkategorieartikel.kArtikel 
			FROM tkategorieartikel WITH(NOLOCK)
			WHERE tkategorieartikel.kKategorie = @kCategory; 
	CREATE TABLE #tChildItems (kItem int); 
	INSERT INTO #tChildItems 
		SELECT tartikel.kArtikel 
			FROM #tItemsOfCategory 
			JOIN tartikel ON tartikel.kVaterArtikel = #tItemsOfCategory.kItem; 
	SELECT * FROM #tItemsOfCategory 
	UNION 
	SELECT * FROM #tChildItems; 
END
go

