--- 
--- spPlatzUmbuchenPickposition
---

CREATE PROCEDURE spPlatzUmbuchenPickposition
	@kWarenlagerplatzNeu INT,
	@kPicklistePos INT,
	@kLHM INT,
	@kBuchungsart INT,
	@kBenutzer INT,
	@fAnzahl DECIMAL (28,15) = NULL,
	@cKommentar VARCHAR(255),
	@kPicklistePosNeu INT OUTPUT
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
	SET @kPicklistePosNeu = 0;
	DECLARE @kWarenlagerEingang INT;
	DECLARE @kWarenlagerEingangNeu INT;
	DECLARE @PickposSplitNotwendig BIT;
	SELECT	@kWarenlagerEingang = dbo.tpicklistePos.kWarenlagerEingang,
			@fAnzahl = CASE WHEN @fAnzahl IS NULL
							THEN dbo.tpicklistePos.fAnzahl 
							ELSE @fAnzahl
						END,
			@PickposSplitNotwendig = CASE WHEN @fAnzahl IS NULL OR @fAnzahl = dbo.tpicklistePos.fAnzahl
												THEN 0
												ELSE 1
										END
		FROM dbo.tpicklistePos
		WHERE dbo.tpicklistePos.kPicklistePos = @kPicklistePos;
	-- PicklisteSplit ausführen
	IF(@PickposSplitNotwendig = 1)
	BEGIN
		INSERT INTO dbo.tPicklistePos
		(
		    kPickliste,
		    kWarenLager,
		    kWarenLagerEingang,
		    fAnzahl,
		    kBestellPos,
		    kArtikel,
		    kWarenlagerPlatz,
		    kPicklistePos_Ursprung,
		    kLieferscheinPos,
		    kBestellung,
		    nPickPrio,
		    kAnsprechpartner
		)
		SELECT dbo.tPicklistePos.kPickliste,
				dbo.tPicklistePos.kWarenLager,
				dbo.tPicklistePos.kWarenLagerEingang,
				dbo.tPicklistePos.fAnzahl - @fAnzahl,
				dbo.tPicklistePos.kBestellPos,
				dbo.tPicklistePos.kArtikel,
				dbo.tPicklistePos.kWarenlagerPlatz,
				dbo.tPicklistePos.kPicklistePos,
				dbo.tPicklistePos.kLieferscheinPos,
				dbo.tPicklistePos.kBestellung,
				dbo.tPicklistePos.nPickPrio,
				dbo.tPicklistePos.kAnsprechpartner				
			FROM dbo.tPicklistePos 
			WHERE dbo.tPicklistePos.kPicklistePos = @kPicklistePos
		SELECT @kPicklistePosNeu = SCOPE_IDENTITY();
		INSERT INTO dbo.tPicklistePosStatus
		(
		    kPicklistePos,
		    kbenutzer,
		    dZeitstempel,
		    nStatus
		)
		SELECT	@kPicklistePosNeu,
				dbo.tPicklistePosStatus.kbenutzer,
				dbo.tPicklistePosStatus.dZeitstempel,
				dbo.tPicklistePosStatus.nStatus
			FROM dbo.tPicklistePosStatus 
			WHERE dbo.tPicklistePosStatus.kPicklistePos = @kPicklistePos
	END
	-- Umlagerung ausführen
	BEGIN TRANSACTION
		EXEC dbo.spPlatzUmbuchenAusfuehren @kWarenlagerEingang, @fAnzahl, @kWarenlagerplatzNeu, @kLHM, @kBuchungsart, 1, @kBenutzer, @cKommentar, @kWarenlagerEingangNeu OUTPUT;
		-- Pickposition umschreiben
		IF(@kWarenlagerEingangNeu <> @kWarenlagerEingang)
		BEGIN
			UPDATE dbo.tPicklistePos
				SET kWarenLagerEingang = @kWarenlagerEingangNeu,
					fAnzahl = @fAnzahl
				WHERE kPicklistePos = @kPicklistePos;
		END
	COMMIT
	RETURN
END
go

