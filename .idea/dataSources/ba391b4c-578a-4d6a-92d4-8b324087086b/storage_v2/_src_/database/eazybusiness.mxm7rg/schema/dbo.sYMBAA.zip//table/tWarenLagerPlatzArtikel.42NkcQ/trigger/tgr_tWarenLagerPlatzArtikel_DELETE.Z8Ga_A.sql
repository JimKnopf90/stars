CREATE TRIGGER [dbo].[tgr_tWarenLagerPlatzArtikel_DELETE]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--
ON [dbo].[tWarenLagerPlatzArtikel]
AFTER DELETE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
	--Überprüfen ob Trigger gefüllt aufgerufen wird
	IF((SELECT COUNT(1) FROM DELETED) = 0)
	BEGIN
		RETURN
	END

	DECLARE @typeArtikel AS TYPE_spUpdateLagerbestand;

	INSERT INTO @typeArtikel (kArtikel)
	SELECT kArtikel
	FROM DELETED
	GROUP BY DELETED.kArtikel;

	EXEC spUpdateLagerBestand @typeArtikel;
END
go

