CREATE TRIGGER [dbo].[tgr_tartikel_Connector]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP
--
ON [dbo].[tArtikel]
AFTER UPDATE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN	

	--Überprüfen ob Trigger gefüllt aufgerufen wird
	IF((SELECT COUNT(1) FROM INSERTED FULL JOIN DELETED ON INSERTED.kArtikel = DELETED.kArtikel) = 0)
	BEGIN 
		RETURN;
	END

	DECLARE @Komplett AS INT;
	DECLARE @Preis AS INT;
	--DECLARE @Bestand AS INT;

	SET @Komplett = 1;
	SET @Preis = 2;
	--SET @Bestand = 4;

	--
	-- Stücklistenkomponenten senden
	--
	UPDATE dbo.tArtikelShop
		SET dbo.tArtikelShop.nAktion = dbo.tArtikelShop.nAktion | @Komplett,
			dbo.tArtikelShop.cInet = 'Y',
			dbo.tArtikelShop.nInBearbeitung = 0
	FROM dbo.tArtikelShop
	JOIN
	(
		SELECT	dbo.tartikel.kArtikel,
				dbo.tArtikelShop.kShop
		FROM dbo.tartikel
		JOIN dbo.tStueckliste ON dbo.tartikel.kStueckliste = dbo.tStueckliste.kStueckliste
		JOIN
		(
			SELECT INSERTED.kArtikel 
				FROM INSERTED 
				WHERE INSERTED.kStueckliste = 0
			UNION ALL
			SELECT DELETED.kArtikel 
				FROM DELETED 
				WHERE DELETED.kStueckliste = 0
		) AS U1 ON dbo.tStueckliste.kArtikel = U1.kArtikel
		JOIN dbo.tArtikelShop ON U1.kArtikel = dbo.tArtikelShop.kArtikel			
		WHERE	dbo.tArtikelShop.cInet != 'N'
				OR dbo.tArtikelShop.nAktion > 0
	) AS updatedItems ON dbo.tArtikelShop.kArtikel = updatedItems.kArtikel
		AND dbo.tArtikelShop.kShop = updatedItems.kShop
	WHERE	dbo.tArtikelShop.cInet = 'N'
				OR dbo.tArtikelShop.nAktion & @Komplett = 0
				OR dbo.tArtikelShop.nInBearbeitung = 1;

	--
	-- Preise senden
	--
	UPDATE dbo.tArtikelShop
		SET dbo.tArtikelShop.nAktion = dbo.tArtikelShop.nAktion | @Preis,
			dbo.tArtikelShop.cInet = 'Y',
			dbo.tArtikelShop.nInBearbeitung = 0
	FROM dbo.tArtikelShop
	JOIN
	(
		SELECT INSERTED.*
		FROM DELETED
		JOIN INSERTED ON DELETED.kArtikel = INSERTED.kArtikel
		WHERE INSERTED.fVKNetto <> DELETED.fVKNetto
	) AS refreshableItems ON dbo.tArtikelShop.kArtikel = refreshableItems.kArtikel
	WHERE	dbo.tArtikelShop.cInet = 'N'
			OR dbo.tArtikelShop.nAktion & @Preis = 0
			OR dbo.tArtikelShop.nInBearbeitung = 1;

	--
	-- Artikel vollständig zu Webshops senden, wenn Änderungen vorgenommen wurden
	--
	UPDATE dbo.tArtikelShop
		SET dbo.tArtikelShop.nAktion = dbo.tArtikelShop.nAktion | @Komplett,
			dbo.tArtikelShop.cInet = 'Y',
			dbo.tArtikelShop.nInBearbeitung = 0
	FROM dbo.tArtikelShop
	JOIN
	(
		SELECT INSERTED.*
		FROM DELETED
		JOIN INSERTED ON DELETED.kArtikel = INSERTED.kArtikel
		WHERE	INSERTED.cArtNr <> DELETED.cArtNr
				OR INSERTED.fUVP <> DELETED.fUVP
				OR INSERTED.cAktiv <> DELETED.cAktiv
				OR INSERTED.nMindestbestellmaenge <> DELETED.nMindestbestellmaenge
				OR INSERTED.fGewicht <> DELETED.fGewicht
				OR ISNULL(INSERTED.cNeu, 'N') <> ISNULL(DELETED.cNeu, 'N')
				OR INSERTED.cLagerAktiv <> DELETED.cLagerAktiv
				OR INSERTED.cLagerKleinerNull <> DELETED.cLagerKleinerNull
				OR INSERTED.cLagerVariation <> DELETED.cLagerVariation
				OR INSERTED.fPackeinheit <> DELETED.fPackeinheit
				OR INSERTED.fVPEWert <> DELETED.fVPEWert
				OR INSERTED.kSteuerklasse <> DELETED.kSteuerklasse
				OR ISNULL(INSERTED.dErscheinungsdatum, GETDATE()) <> ISNULL(DELETED.dErscheinungsdatum, GETDATE()) 
				OR INSERTED.fArtGewicht <> DELETED.fArtGewicht
				OR INSERTED.kEigenschaftKombi <> DELETED.kEigenschaftKombi
				OR INSERTED.kVaterArtikel <> DELETED.kVaterArtikel
				OR INSERTED.nIstVater <> DELETED.nIstVater
				OR INSERTED.fAbnahmeintervall <> DELETED.fAbnahmeintervall
				OR INSERTED.kStueckliste <> DELETED.kStueckliste
				OR INSERTED.kWarengruppe <> DELETED.kWarengruppe
				OR INSERTED.nMHD <> DELETED.nMHD
				OR INSERTED.nCharge <> DELETED.nCharge
				OR INSERTED.nNichtBestellbar <> DELETED.nNichtBestellbar
				OR INSERTED.nPufferTyp <> DELETED.nPufferTyp
				OR INSERTED.nPuffer <> DELETED.nPuffer
				OR INSERTED.fGrundpreisMenge <> DELETED.fGrundpreisMenge
				OR INSERTED.fBreite <> DELETED.fBreite
				OR INSERTED.fHoehe <> DELETED.fHoehe
				OR INSERTED.fLaenge <> DELETED.fLaenge
				OR INSERTED.dZulaufVerfuegbarAm <> DELETED.dZulaufVerfuegbarAm
				OR INSERTED.nZulaufVerfuegbarMenge <> DELETED.nZulaufVerfuegbarMenge
				OR ISNULL(INSERTED.nBearbeitungszeit, 0) <> ISNULL(DELETED.nBearbeitungszeit, 0)
				OR ISNULL(INSERTED.kVPEEinheit, 0) <> ISNULL(DELETED.kVPEEinheit, 0)
				OR ISNULL(INSERTED.nLiefertageWennAusverkauft, 0) <> ISNULL(DELETED.nLiefertageWennAusverkauft, 0)
				OR ISNULL(INSERTED.kVerkaufsEinheit, 0) <> ISNULL(DELETED.kVerkaufsEinheit, 0)
				OR ISNULL(INSERTED.kHersteller, 0) <> ISNULL(DELETED.kHersteller, 0)
				OR ISNULL(INSERTED.kLieferstatus, 0) <> ISNULL(DELETED.kLieferstatus, 0)
				OR ISNULL(INSERTED.kMassEinheit, 0) <> ISNULL(DELETED.kMassEinheit, 0)
				OR ISNULL(INSERTED.kGrundPreisEinheit, 0) <> ISNULL(DELETED.kGrundPreisEinheit, 0)
				OR ISNULL(INSERTED.cAnmerkung, '') <> ISNULL(DELETED.cAnmerkung, '')
				OR ISNULL(INSERTED.cBarcode, '') <> ISNULL(DELETED.cBarcode, '')
				OR ISNULL(INSERTED.cTopArtikel, '') <> ISNULL(DELETED.cTopArtikel, '')
				OR ISNULL(INSERTED.cLagerArtikel, '') <> ISNULL(DELETED.cLagerArtikel, '')
				OR ISNULL(INSERTED.cTeilbar, '') <> ISNULL(DELETED.cTeilbar, '')
				OR ISNULL(INSERTED.nVPE, 0) <> ISNULL(DELETED.nVPE, 0)
				OR ISNULL(INSERTED.cSuchbegriffe, '') <> ISNULL(DELETED.cSuchbegriffe, '')
				OR ISNULL(INSERTED.cTaric, '') <> ISNULL(DELETED.cTaric, '')
				OR ISNULL(INSERTED.cHerkunftsland, '') <> ISNULL(DELETED.cHerkunftsland, '')
				OR ISNULL(INSERTED.nSort, 0) <> ISNULL(DELETED.nSort, 0)
				OR ISNULL(INSERTED.kVersandklasse, 0) <> ISNULL(DELETED.kVersandklasse, 0)
				OR ISNULL(INSERTED.cHAN, 0) <> ISNULL(DELETED.cHAN, 0)
				OR ISNULL(INSERTED.cSerie, 0) <> ISNULL(DELETED.cSerie, 0)
				OR ISNULL(INSERTED.cISBN, 0) <> ISNULL(DELETED.cISBN, 0)
				OR ISNULL(INSERTED.cUNNummer, 0) <> ISNULL(DELETED.cUNNummer, 0)
				OR ISNULL(INSERTED.cGefahrnr, 0) <> ISNULL(DELETED.cGefahrnr, 0)
				OR ISNULL(INSERTED.cASIN, '') <> ISNULL(DELETED.cASIN, '')
				OR ISNULL(INSERTED.nIstMindestbestand, 0) <> ISNULL(DELETED.nIstMindestbestand, 0)
				OR ISNULL(INSERTED.cUPC, '') <> ISNULL(DELETED.cUPC, '')
				OR ISNULL(INSERTED.cEPID, '') <> ISNULL(DELETED.cEPID, '')
				OR ISNULL(INSERTED.dZulaufVerfuegbarAm, GETDATE()) <> ISNULL(DELETED.dZulaufVerfuegbarAm, GETDATE())
				OR ISNULL(INSERTED.nZulaufVerfuegbarMenge, 0) <> ISNULL(DELETED.nZulaufVerfuegbarMenge, 0)
				OR ISNULL(INSERTED.nAutomatischeLiefertageberechnung, 0) <> ISNULL(DELETED.nAutomatischeLiefertageberechnung, 0)
				OR ISNULL(INSERTED.dErscheinungsdatum, GETDATE()) <> ISNULL(DELETED.dErscheinungsdatum, GETDATE())
				OR ISNULL(INSERTED.dNeuImSortiment, GETDATE()) <> ISNULL(DELETED.dNeuImSortiment, GETDATE())

	) AS refreshableItems ON dbo.tArtikelShop.kArtikel = refreshableItems.kArtikel
	WHERE	dbo.tArtikelShop.cInet = 'N'
			OR dbo.tArtikelShop.nAktion & @Komplett = 0
			OR dbo.tArtikelShop.nInBearbeitung = 1;

	DELETE dbo.tArtikelShop
	FROM dbo.tArtikelShop
	JOIN INSERTED ON dbo.tArtikelShop.kArtikel = INSERTED.kArtikel
	JOIN DELETED ON INSERTED.kArtikel = DELETED.kArtikel
		AND INSERTED.cAktiv <> DELETED.cAktiv
	WHERE	INSERTED.cAktiv = 'N'			

	--
	-- Varkombi-Väter werden nur gesendet, wenn mindestens ein Kind gesendet wird (Connector)
	--
	IF(EXISTS(SELECT * FROM INSERTED WHERE INSERTED.nIstVater = 1))
	BEGIN
		UPDATE dbo.tArtikelShop
			SET dbo.tArtikelShop.nAktion = dbo.tArtikelShop.nAktion | @Komplett,
				dbo.tArtikelShop.cInet = 'Y',
				dbo.tArtikelShop.nInBearbeitung = 0
		FROM dbo.tArtikelShop
		JOIN
		(
			SELECT TOP (SELECT COUNT(dbo.tShop.kShop) FROM dbo.tShop WHERE dbo.tShop.nTyp = 1) dbo.tArtikelShop.*
			FROM dbo.tArtikelShop
			JOIN dbo.tShop ON dbo.tArtikelShop.kShop = dbo.tShop.kShop
							AND dbo.tShop.nTyp = 1
			JOIN dbo.tArtikel ON dbo.tArtikelShop.kArtikel = dbo.tArtikel.kArtikel
  			JOIN tartikel AS vater ON vater.kArtikel = dbo.tArtikel.kVaterArtikel
  			JOIN INSERTED ON INSERTED.kArtikel = dbo.tArtikel.kVaterArtikel
			WHERE INSERTED.nIstVater = 1
			ORDER BY dbo.tArtikelShop.kArtikel
		) AS ErsteKinder ON dbo.tArtikelShop.kArtikel = ErsteKinder.kArtikel
						AND dbo.tArtikelShop.kShop = ErsteKinder.kShop
	END;
	
END
go

