CREATE TRIGGER [dbo].[tgr_tArtikelShop_Connector_DELETE]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP/FB
--
ON [dbo].[tArtikelShop]
AFTER DELETE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN	

    --
    -- tQueue für jeden gelöschten Datensatz schreiben
    --
    INSERT INTO dbo.tQueue (kShop, kPlattform, cName, kWert, nAction, kOption1, kOption2)
    SELECT	DELETED.kShop AS kShop,
			dbo.tArtikelbildPlattform.kPlattform AS kPlattform,
			'tArtikelbildPlattform' AS cName, 
			dbo.tArtikelbildPlattform.kArtikelbildPlattform AS kWert, 
			2 AS nAction, 
			DELETED.kArtikel AS kOption1,
			dbo.tArtikelbildPlattform.nNr AS kOption2
    FROM DELETED
	JOIN dbo.tArtikelbildPlattform ON DELETED.kArtikel = dbo.tArtikelbildPlattform.kArtikel
		AND DELETED.kShop = Dbo.tArtikelbildPlattform.kShop
	WHERE DELETED.kShop > 0;

	--
	-- tEigenschaftWertPict aufraeumen 
	--
	DELETE FROM dbo.tEigenschaftWertPict
	WHERE dbo.tEigenschaftWertPict.kEigenschaftWertPict IN
	(
		SELECT dbo.tEigenschaftWertPict.kEigenschaftWertPict
		FROM dbo.tEigenschaftWertPict
		JOIN dbo.tEigenschaftWert ON dbo.tEigenschaftWert.kEigenschaftwert = dbo.tEigenschaftwertpict.kEigenschaftwert
		JOIN dbo.tEigenschaft ON dbo.teigenschaft.kEigenschaft = dbo.teigenschaftwert.kEigenschaft
		JOIN DELETED ON DELETED.kShop = dbo.tEigenschaftWertPict.kShop AND DELETED.kArtikel = dbo.tEigenschaft.kArtikel
	)

	DECLARE @KomplettVersenden AS INT;
	DECLARE @ShopTypConnector AS INT;
	SET @KomplettVersenden = 1;		
	SET @ShopTypConnector = 1;

	--
	-- Bei Connectoren hängen alle Kinder am Vaterartikel, wird ein Kind für den Shop deaktiviert, muss der Vater erneut übertragen werden.
	--
	UPDATE dbo.tArtikelShop
		SET dbo.tArtikelShop.cInet = 'Y',
			dbo.tArtikelShop.nAktion = @KomplettVersenden
	FROM dbo.tArtikelShop
	JOIN dbo.tShop ON dbo.tArtikelShop.kShop = dbo.tShop.kShop
	JOIN
	(
		SELECT dbo.tArtikel.kVaterArtikel AS kArtikel
		FROM DELETED
		JOIN dbo.tArtikel ON DELETED.kArtikel = dbo.tArtikel.kArtikel	
		WHERE dbo.tArtikel.kVaterArtikel > 0
		GROUP BY dbo.tArtikel.kVaterArtikel
		UNION ALL 
		SELECT weitereKindArtikel.kArtikel
		FROM DELETED
		JOIN dbo.tArtikel ON DELETED.kArtikel = dbo.tArtikel.kArtikel	
		JOIN dbo.tArtikel AS weitereKindArtikel ON dbo.tArtikel.kVaterartikel = weitereKindArtikel.kVaterartikel
		WHERE dbo.tArtikel.kVaterArtikel > 0
		GROUP BY weitereKindArtikel.kArtikel
	) AS Vaterartikel ON dbo.tArtikelShop.kArtikel = Vaterartikel.kArtikel
	WHERE dbo.tShop.nTyp = @ShopTypConnector
	
	UPDATE dbo.tArtikelbildPlattform
	SET dbo.tArtikelbildPlattform.nInet = 0
	FROM dbo.tArtikelbildPlattform
	JOIN DELETED ON dbo.tArtikelbildPlattform.kArtikel = DELETED.kArtikel
		AND dbo.tArtikelbildPlattform.kShop = DELETED.kShop
	WHERE dbo.tArtikelbildPlattform.nInet = 1;

	--
	-- tQueue schreiben um Artikel aus Shop zu löschen
	--
	INSERT INTO dbo.tQueue(kShop, kPlattform, cName, kWert, nAction)
	SELECT DELETED.kShop, 2, 'tArtikel', DELETED.kArtikel, 2
	FROM DELETED  
	LEFT JOIN dbo.tQueue ON dbo.tQueue.kShop = DELETED.kShop
			AND dbo.tQueue.kPlattform = 2
			AND dbo.tQueue.cName = 'tArtikel'
			AND dbo.tQueue.kWert = DELETED.kArtikel
			AND dbo.tQueue.nAction = 2
		WHERE dbo.tQueue.kWert IS NULL;

	DELETE dbo.tQueue
	FROM dbo.tQueue
	JOIN
	(
		SELECT dbo.tArtikel.kHersteller, DELETED.kShop
		FROM DELETED
		JOIN dbo.tShopKonfiguration ON DELETED.kShop = dbo.tShopKonfiguration.kShop
									AND dbo.tShopKonfiguration.nHerstellerGefiltertSenden = 1
		JOIN dbo.tArtikel ON dbo.tArtikel.kArtikel = DELETED.kArtikel
		LEFT JOIN (
			SELECT dbo.tHersteller.kHersteller, dbo.tArtikelShop.kShop, COUNT(1) AS Anzahl
				FROM tArtikel
				JOIN dbo.tHersteller ON dbo.tArtikel.kHersteller = dbo.tHersteller.kHersteller
				JOIN dbo.tArtikelShop ON dbo.tArtikel.kArtikel = dbo.tArtikelShop.kArtikel
				GROUP BY dbo.tHersteller.kHersteller, dbo.tArtikelShop.kShop
		) AS Result ON Result.kHersteller = dbo.tArtikel.kHersteller
					AND DELETED.kShop = Result.kShop
		WHERE ISNULL(Anzahl, 0) = 0
	) AS Items ON dbo.tQueue.kWert = Items.kHersteller
			AND dbo.tQueue.cName = 'tHersteller'
			AND dbo.tQueue.kShop = Items.kShop
			AND dbo.tQueue.nAction = 1

	INSERT INTO dbo.tQueue(kWert, kShop, cName, kPlattform, nAction)
	SELECT dbo.tArtikel.kHersteller, DELETED.kShop, 'tHersteller', 2, 2
	FROM DELETED
	JOIN dbo.tShopKonfiguration ON DELETED.kShop = dbo.tShopKonfiguration.kShop
								AND dbo.tShopKonfiguration.nHerstellerGefiltertSenden = 1
	JOIN dbo.tArtikel ON dbo.tArtikel.kArtikel = DELETED.kArtikel
	LEFT JOIN (
		SELECT dbo.tHersteller.kHersteller, dbo.tArtikelShop.kShop, COUNT(1) AS Anzahl
			FROM tArtikel
			JOIN dbo.tHersteller ON dbo.tArtikel.kHersteller = dbo.tHersteller.kHersteller
			JOIN dbo.tArtikelShop ON dbo.tArtikel.kArtikel = dbo.tArtikelShop.kArtikel
			GROUP BY dbo.tHersteller.kHersteller, dbo.tArtikelShop.kShop
	) AS Result ON Result.kHersteller = dbo.tArtikel.kHersteller
				AND DELETED.kShop = Result.kShop
	WHERE dbo.tArtikel.kHersteller > 0 AND ISNULL(Anzahl, 0) = 0
	GROUP BY dbo.tArtikel.kHersteller, DELETED.kShop

END
go

