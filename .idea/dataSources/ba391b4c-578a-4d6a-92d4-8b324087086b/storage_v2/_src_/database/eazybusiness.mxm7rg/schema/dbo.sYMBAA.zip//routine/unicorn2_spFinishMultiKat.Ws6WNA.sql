
    CREATE PROCEDURE unicorn2_spFinishMultiKat @kWawiIdList VARCHAR(MAX), @kShopId INT 
    AS
        DECLARE @kWawiIdListLocal VARCHAR(MAX)
    		SET @kWawiIdListLocal = @kWawiIdList
			
		DECLARE @kShopIdLocal INT
    		SET @kShopIdLocal = @kShopId
    	
        SET DEADLOCK_PRIORITY LOW		
        UPDATE tKategorieShop SET cInet = 'N'
        WHERE kShop = @kShopIdLocal AND kKategorie IN (SELECT * FROM unicorn2_fSplitInts(@kWawiIdListLocal, ','));
    go

