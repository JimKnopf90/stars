CREATE TRIGGER [dbo].[jtlActionValidator_tWawiAttribut]  
--     
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MaikS
--    
ON [dbo].[tWawiAttribut] AFTER DELETE 
AS  
BEGIN 

	--
	--Überprüfen ob Trigger mit Inhalt aufgerufen wird
	--
		IF((SELECT COUNT(1) FROM DELETED) = 0)
		BEGIN
			RETURN
		END

	--
	-- tWawiAttributSprache aufräumen
	--
		DELETE tWawiAttributSprache WITH(ROWLOCK)
		FROM tWawiAttributSprache WITH(ROWLOCK)
		JOIN DELETED ON DELETED.kWawiAttribut = tWawiAttributSprache.kWawiAttribut 
END
go

