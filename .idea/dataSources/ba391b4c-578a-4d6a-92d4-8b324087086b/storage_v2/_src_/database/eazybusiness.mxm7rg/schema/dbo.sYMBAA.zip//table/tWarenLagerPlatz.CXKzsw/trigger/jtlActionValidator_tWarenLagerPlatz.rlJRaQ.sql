CREATE TRIGGER [dbo].[jtlActionValidator_tWarenLagerPlatz]
	--
	-- Copyright (c) 2012-2017 by JTL Software GmbH
	-- Datum: $Date$
	-- Version: $Rev$
	-- Autor: MaikS
	--
	ON [dbo].[tWarenLagerPlatz]
	AFTER DELETE
	AS
	SET NOCOUNT ON;
	SET ANSI_NULLS ON;
	SET ANSI_NULL_DFLT_ON ON;
	SET ANSI_PADDING ON;
	SET CONCAT_NULL_YIELDS_NULL ON;
	SET XACT_ABORT OFF;
	DECLARE @kWarenlagerPlatz INT
	DECLARE @kWarenlager INT

	BEGIN
	  IF EXISTS(SELECT 1 FROM DELETED)
	  BEGIN
		--
		-- WarenlagerArtikelPlatz entfernen
		--
			DELETE tWarenlagerPlatzArtikel WITH(ROWLOCK)
			FROM tWarenlagerPlatzArtikel WITH(ROWLOCK)
			JOIN DELETED ON tWarenlagerPlatzArtikel.kWarenLagerPlatz = DELETED.kWarenLagerPlatz
			WHERE tWarenlagerPlatzArtikel.cKommentar_1 IS NULL AND tWarenlagerPlatzArtikel.cKommentar_1 IS NULL
						
		--
		-- LHMs auf den Platz löschen
		--	
		   DELETE tLHM WITH(ROWLOCK)
		   FROM tLHM WITH(ROWLOCK)
		   JOIN DELETED ON tLHM.kWarenLagerPlatz = DELETED.kWarenLagerPlatz
		 
			
		--
		-- Plätze in Lagerbereichen Löschen
		--
		   DELETE tWMSLagerBereichPlatz 
		   FROM tWMSLagerBereichPlatz	
		   JOIN DELETED ON tWMSLagerBereichPlatz.kWarenLagerPlatz = DELETED.kWarenLagerPlatz
						
		--
		-- Artikelhistory des Platzes löschen
		--
		   DELETE tArtikelHistory 
		   FROM tArtikelHistory	
		   JOIN DELETED ON tArtikelHistory.kWarenLagerPlatz = DELETED.kWarenLagerPlatz		


		--
		-- Vorgabeplätze löschen
		--
		   DELETE tWarenlagerartikeloptionen
		   FROM tWarenlagerartikeloptionen
		   JOIN DELETED ON tWarenlagerartikeloptionen.kWarenLagerPlatz = DELETED.kWarenLagerPlatz;

		
		--
		-- Umbuchen von allen Warenlagereingängen,Ausgängen,ArtikelHistory von dem Platz auf einen anderen Platz names "SYSTEM-JTL"
		--
		   DECLARE @OldContextInfo VARBINARY(128)

		   IF(CONTEXT_INFO() IS NOT NULL)
			BEGIN
			  SET @OldContextInfo = CONTEXT_INFO()
			END;
			ELSE
			BEGIN
			  SET @OldContextInfo = 0x0000
		   END;


		   SET CONTEXT_INFO 0x5097;

		   UPDATE dbo.tWarenLagerEingang
		   SET kWarenLagerPlatz = tWarenlagerPlatz.kWarenlagerPlatz
		   FROM tWarenLagerEingang
		   JOIN DELETED ON tWarenLagerEingang.kWarenLagerPlatz = DELETED.kWarenLagerPlatz
		   JOIN tWarenlagerPlatz ON tWarenlagerPlatz.kWarenlager = DELETED.kWarenlager AND tWarenlagerPlatz.cName = 'SYSTEM-JTL' 

		   SET CONTEXT_INFO @OldContextInfo
				
	END
END
go

