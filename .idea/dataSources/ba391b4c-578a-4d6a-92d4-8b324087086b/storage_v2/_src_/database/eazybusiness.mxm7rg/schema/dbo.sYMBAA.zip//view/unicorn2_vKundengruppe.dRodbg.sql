
    CREATE VIEW unicorn2_vKundengruppe 
    AS
        SELECT kId, kWawiId, cStatus, dChangedDate
        FROM unicorn2_tChangeCache WITH (NOLOCK)
        WHERE cType = 'Kundengruppe';
    go

