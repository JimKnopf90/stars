CREATE TRIGGER [dbo].[tgr_tAnfangsNr_INSUPDEL]     
-- 
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP/FB
--  
ON [dbo].[tAnfangsNr]     
AFTER INSERT, UPDATE, DELETE   
AS     
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
	--
	-- Laufende Nummern in tLaufendeNummern aktualisieren
	--
		EXEC dbo.spRefreshLaufendeNummern;  
END
go

