CREATE TRIGGER [dbo].[tgr_tArtikelMerkmal_INSERT]
ON [dbo].[tArtikelMerkmal]
AFTER INSERT
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN

	INSERT INTO dbo.tMerkmalBildPlattform (kMerkmal, kBild, kPlattform, kShop, nInet)
	SELECT INSERTED.kMerkmal, StandardBild.kBild, 2, dbo.tArtikelShop.kShop, 1
	FROM dbo.tArtikelShop
	JOIN INSERTED ON dbo.tArtikelShop.kArtikel = INSERTED.kArtikel
	JOIN dbo.tMerkmalBildPlattform AS StandardBild ON StandardBild.kMerkmal = INSERTED.kMerkmal
												AND (StandardBild.kShop IS NULL OR StandardBild.kShop = 0)
	LEFT JOIN dbo.tMerkmalBildPlattform ON INSERTED.kMerkmal = dbo.tMerkmalBildPlattform.kMerkmal
									AND dbo.tArtikelShop.kShop = dbo.tMerkmalBildPlattform.kShop
	WHERE dbo.tMerkmalBildPlattform.kShop IS NULL
	GROUP BY INSERTED.kMerkmal, dbo.tArtikelShop.kShop, dbo.tMerkmalBildPlattform.kBild, dbo.tMerkmalBildPlattform.kShop, StandardBild.kBild;

	INSERT INTO dbo.tMerkmalwertBildPlattform (kMerkmalwert, kBild, kPlattform, kShop, nInet)
	SELECT INSERTED.kMerkmalWert, StandardBild.kBild, 2, dbo.tArtikelShop.kShop, 1
	FROM dbo.tArtikelShop
	JOIN INSERTED ON dbo.tArtikelShop.kArtikel = INSERTED.kArtikel
	JOIN dbo.tMerkmalwertBildPlattform AS StandardBild ON StandardBild.kMerkmalwert = INSERTED.kMerkmalWert
													AND (StandardBild.kShop IS NULL OR StandardBild.kShop = 0)
	LEFT JOIN dbo.tMerkmalwertBildPlattform ON INSERTED.kMerkmalWert = dbo.tMerkmalwertBildPlattform.kMerkmalwert
									AND dbo.tArtikelShop.kShop = dbo.tMerkmalwertBildPlattform.kShop
	WHERE dbo.tMerkmalwertBildPlattform.kShop IS NULL
	GROUP BY INSERTED.kMerkmalWert, dbo.tArtikelShop.kShop, dbo.tMerkmalwertBildPlattform.kBild, dbo.tMerkmalwertBildPlattform.kShop, StandardBild.kBild;

END
go

