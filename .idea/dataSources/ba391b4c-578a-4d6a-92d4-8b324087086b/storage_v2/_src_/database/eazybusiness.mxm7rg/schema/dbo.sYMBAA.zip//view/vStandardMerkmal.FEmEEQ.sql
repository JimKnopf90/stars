CREATE VIEW [dbo].[vStandardMerkmal] AS
    --
    -- Copyright (c) 2012-2017 by JTL Software GmbH
    -- Datum: $Date$
    -- Version: $Rev$
    -- Autor: MaikS
    --
    SELECT tMerkmal.kMerkmal, tMerkmal.nSort, tMerkmalSprache.cName, tMerkmal.nGlobal, tMerkmal.cTyp
    FROM tMerkmal
    JOIN tSpracheUsed ON nStandard = 1
    JOIN tMerkmalSprache ON tMerkmalSprache.kMerkmal = tMerkmal.kMerkmal 
				    AND tMerkmalSprache.kSprache = tSpracheUsed.kSprache
go

