CREATE TRIGGER [dbo].[tgr_tMerkmalBildPlattform_UPDATE]  
--     
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Author: Markus Hütz
--    
ON [dbo].[tMerkmalBildPlattform]  
AFTER UPDATE
AS  
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
    --
    -- Überprüfen ob Trigger gefüllt aufgerufen wird
    --
    IF NOT EXISTS(SELECT INSERTED.kMerkmalBildPlattform FROM INSERTED FULL JOIN DELETED ON INSERTED.kMerkmalBildPlattform = DELETED.kMerkmalBildPlattform)
    BEGIN
	   RETURN;
    END;

    --
    -- Wenn kBild nicht gleich ist es ein neues Bild und muss übertragen werden
    --
    UPDATE dbo.tMerkmalBildPlattform
    SET dbo.tMerkmalBildPlattform.nInet = 1
    FROM dbo.tMerkmalBildPlattform
    JOIN DELETED ON DELETED.kMerkmalBildPlattform = dbo.tMerkmalBildPlattform.kMerkmalBildPlattform
    JOIN INSERTED ON INSERTED.kMerkmalBildPlattform = dbo.tMerkmalBildPlattform.kMerkmalBildPlattform
    WHERE DELETED.kBild != INSERTED.kBild;

    --
    -- tBild ggfs. aufräumen
    --
    IF(
	   SELECT COUNT(1)
    	   FROM DELETED
	   LEFT JOIN INSERTED ON DELETED.kBild != INSERTED.kBild
	   WHERE INSERTED.kBild IS NULL
    ) > 0
    BEGIN
	   DECLARE @Bilder AS TYPE_spBildLoeschenWennNichtVerwendet;

		INSERT INTO @Bilder (kBild)
	    SELECT DELETED.kBild
		FROM DELETED
		LEFT JOIN INSERTED ON DELETED.kBild != INSERTED.kBild
		GROUP BY DELETED.kBild;

	   EXEC spBildLoeschenWennNichtVerwendet @Bilder;
    END;
END
go

