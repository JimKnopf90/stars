CREATE TRIGGER [dbo].[tgr_tBild_DELETE]  
--     
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Author: Markus Hütz
--    
ON [dbo].[tBild]  
AFTER DELETE
AS  
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
    IF((SELECT COUNT(1) FROM DELETED) = 0) 
    BEGIN
	   RETURN;
    END;

    --
    -- tArtikelbildPlattform
    --
    DELETE dbo.tArtikelbildPlattform
    FROM dbo.tArtikelbildPlattform
    JOIN DELETED ON DELETED.kBild = dbo.tArtikelbildPlattform.kBild
    WHERE dbo.tArtikelbildPlattform.kBild = DELETED.kBild;

    --
    -- tKategoriebildPlattform
    --
    DELETE dbo.tKategoriebildPlattform
    FROM dbo.tKategoriebildPlattform
    JOIN DELETED ON DELETED.kBild = dbo.tKategoriebildPlattform.kBild
    WHERE dbo.tKategoriebildPlattform.kBild = DELETED.kBild;

    --
    -- tEigenschaftWertPict
    --
    DELETE dbo.tEigenschaftWertPict
    FROM dbo.tEigenschaftWertPict
    JOIN DELETED ON DELETED.kBild = dbo.tEigenschaftWertPict.kBild
    WHERE dbo.tEigenschaftWertPict.kBild = DELETED.kBild;

    --
    -- tMerkmalBildPlattform
    --
    DELETE dbo.tMerkmalBildPlattform
    FROM dbo.tMerkmalBildPlattform
    JOIN DELETED ON DELETED.kBild = dbo.tMerkmalBildPlattform.kBild
    WHERE dbo.tMerkmalBildPlattform.kBild = DELETED.kBild;

    --
    -- tMerkmalwertBildPlattform
    --
    DELETE dbo.tMerkmalwertBildPlattform
    FROM dbo.tMerkmalwertBildPlattform
    JOIN DELETED ON DELETED.kBild = dbo.tMerkmalwertBildPlattform.kBild
    WHERE dbo.tMerkmalwertBildPlattform.kBild = DELETED.kBild;

    --
    -- tHerstellerBild
    --
    DELETE dbo.tHerstellerBildPlattform
    FROM dbo.tHerstellerBildPlattform
    JOIN DELETED ON DELETED.kBild = dbo.tHerstellerBildPlattform.kBild
    WHERE dbo.tHerstellerBildPlattform.kBild = DELETED.kBild;
END
go

