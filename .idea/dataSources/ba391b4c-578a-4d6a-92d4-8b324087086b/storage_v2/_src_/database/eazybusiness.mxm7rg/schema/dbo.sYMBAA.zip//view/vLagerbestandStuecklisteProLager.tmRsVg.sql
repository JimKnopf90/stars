CREATE VIEW [dbo].[vLagerbestandStuecklisteProLager] AS
SELECT
	dbo.tArtikel.kArtikel,
	dbo.tArtikel.cArtNr,
	Stuecklisten.kStueckliste,
	CASE 
		WHEN fLagerbestandDominant = 1000000000 AND fLagerbestandNichtDominant = 1000000000 THEN 0
		WHEN fLagerbestandDominant = 1000000000 THEN fLagerbestandNichtDominant
		WHEN fLagerbestandNichtDominant = 1000000000 THEN fLagerbestandDominant
		ELSE fLagerbestandDominant
	END AS fLagerbestand,
	Stuecklisten.kWarenlager
FROM dbo.tArtikel
JOIN 
(
	SELECT	
		dbo.tStueckliste.kStueckliste,
		MIN(CASE 
				WHEN dbo.tArtikel.cLagerAktiv = 'N' THEN 1000000000
				WHEN dbo.tArtikel.cLagerKleinerNull = 'Y' THEN 1000000000
				WHEN VaterArtikel.cTeilbar = 'Y' THEN dbo.tlagerbestandProLagerLagerartikel.fBestand / dbo.tStueckliste.fAnzahl
				ELSE FLOOR(dbo.tlagerbestandProLagerLagerartikel.fBestand / dbo.tStueckliste.fAnzahl)
			END) AS fLagerbestandDominant,
		MIN(CASE 
				WHEN dbo.tArtikel.cLagerAktiv = 'N' THEN 1000000000
				WHEN VaterArtikel.cTeilbar = 'Y' THEN dbo.tlagerbestandProLagerLagerartikel.fBestand / dbo.tStueckliste.fAnzahl
				ELSE FLOOR(dbo.tlagerbestandProLagerLagerartikel.fBestand / dbo.tStueckliste.fAnzahl)
			END) AS fLagerbestandNichtDominant,
		dbo.tlagerbestandProLagerLagerartikel.kWarenlager
	FROM dbo.tStueckliste
	JOIN dbo.tArtikel AS VaterArtikel ON VaterArtikel.kStueckliste = dbo.tStueckliste.kStueckliste
	JOIN dbo.tArtikel ON dbo.tArtikel.kArtikel = dbo.tStueckliste.kArtikel
	JOIN dbo.tlagerbestandProLagerLagerartikel ON dbo.tlagerbestandProLagerLagerartikel.kArtikel = tArtikel.kArtikel
	GROUP BY dbo.tStueckliste.kStueckliste, VaterArtikel.cTeilbar, dbo.tlagerbestandProLagerLagerartikel.kWarenlager
) AS Stuecklisten ON Stuecklisten.kStueckliste = dbo.tArtikel.kStueckliste
go

