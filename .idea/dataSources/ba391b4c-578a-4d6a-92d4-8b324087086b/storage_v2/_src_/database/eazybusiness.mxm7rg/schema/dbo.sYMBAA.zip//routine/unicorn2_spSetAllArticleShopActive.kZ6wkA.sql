
    CREATE PROCEDURE unicorn2_spSetAllArticleShopActive @kShop INT, @kBenutzer INT
    AS
       DECLARE @kVaterArtikel INT
       DECLARE @kVaterCount INT
       DECLARE @kShopLocal INT
			SET @kShopLocal = @kShop
		DECLARE @kArtikelLocal INT
        DECLARE @kBenutzerLocal INT
            SET @kBenutzerLocal = @kBenutzer

		SET DEADLOCK_PRIORITY LOW

		DECLARE ins CURSOR READ_ONLY FAST_FORWARD FOR SELECT kArtikel FROM eazybusiness.dbo.vLagerbestandEx WITH (NOLOCK) WHERE fVerfuegbar > 1 AND kArtikel IN (SELECT kWawiId FROM eazybusiness.dbo.unicorn2_tShopDeletedArtikel WITH (NOLOCK) WHERE kShopId = @kShopLocal AND GETDATE() > DATEADD(day, 1, dDeletionDate))
		OPEN ins

			FETCH NEXT FROM ins INTO @kArtikelLocal
			WHILE (@@FETCH_STATUS = 0)
				BEGIN
					EXEC eazybusiness.dbo.unicorn2_spSetSpecificArticleShopActive @kShop = @kShopLocal, @kArtikel = @kArtikelLocal, @kBenutzer = @kBenutzerLocal

                    SET @kVaterArtikel = (SELECT TOP 1 kVaterArtikel FROM eazybusiness.dbo.tArtikel WHERE kArtikel = @kArtikelLocal)
                    IF (@kVaterArtikel > 0)
                        BEGIN

                            SET @kVaterCount = (SELECT COUNT(kWawiId) FROM eazybusiness.dbo.unicorn2_tShopDeletedArtikel WITH (NOLOCK) WHERE kShopId = @kShopLocal AND kWawiId = @kVaterArtikel)
                            IF (@kVaterCount > 0)
                                BEGIN
                                    EXEC eazybusiness.dbo.unicorn2_spSetSpecificArticleShopActive @kShop = @kShopLocal, @kArtikel = @kVaterArtikel, @kBenutzer = @kBenutzerLocal
                                END
                        END

					FETCH NEXT FROM ins INTO @kArtikelLocal
				END
		CLOSE ins
		DEALLOCATE ins
    go

