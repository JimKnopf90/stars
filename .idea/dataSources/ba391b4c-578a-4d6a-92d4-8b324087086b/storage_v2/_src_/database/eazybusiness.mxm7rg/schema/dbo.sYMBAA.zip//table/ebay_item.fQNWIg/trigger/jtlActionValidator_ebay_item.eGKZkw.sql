CREATE TRIGGER [dbo].[jtlActionValidator_ebay_item]  
--     
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
--    
ON [dbo].[ebay_item]  
AFTER DELETE 
AS  
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN 

	--
	--Überprüfen ob Trigger mit Inhalt aufgerufen wird
	--
		IF((SELECT COUNT(1) FROM DELETED) = 0)
		BEGIN
			RETURN
		END

	--
	-- ebay_item2kombi aufräumen
	--
		DELETE dbo.ebay_item2kombi
		FROM dbo.ebay_item2kombi
		JOIN DELETED ON DELETED.kItem = dbo.ebay_item2kombi.kItem; 
 

 	--
	-- ebay_specific aufräumen
	--
		DELETE dbo.ebay_specific
		FROM dbo.ebay_specific
		JOIN DELETED ON DELETED.kItem = dbo.ebay_specific.kItem;

	--
	-- ebay_beschreibungstemplate aufräumen
	--
		DELETE dbo.ebay_beschreibungstemplate
		FROM dbo.ebay_beschreibungstemplate
		JOIN DELETED ON DELETED.kItem  = dbo.ebay_beschreibungstemplate.kItem;
		
	--
	-- ebay_ShippingServiceOptions aufräumen
	--
		DELETE dbo.ebay_ShippingServiceOptions
		FROM dbo.ebay_ShippingServiceOptions
		JOIN DELETED ON DELETED.kItem = dbo.ebay_ShippingServiceOptions.kItem; 
			
 	--
	-- ebay_InternationalShippingServiceOption aufräumen
	--
		DELETE dbo.ebay_InternationalShippingServiceOption
		FROM dbo.ebay_InternationalShippingServiceOption
		JOIN DELETED ON DELETED.kItem  = dbo.ebay_InternationalShippingServiceOption.kItem; 
 																	 
 	--
	-- ebay_data_htmltemplatetagcontent aufräumen
	--
		DELETE dbo.ebay_data_htmltemplatetagcontent
		FROM dbo.ebay_data_htmltemplatetagcontent
		JOIN DELETED ON DELETED.kItem  = dbo.ebay_data_htmltemplatetagcontent.kEbayItem;  

 	--
	-- ebay_vw_htmltemplaterendered aufräumen
	--
		DELETE dbo.ebay_vw_htmltemplaterendered
		FROM dbo.ebay_vw_htmltemplaterendered
		JOIN DELETED ON DELETED.kItem  = dbo.ebay_vw_htmltemplaterendered.kEbay_item;  


 	--
	-- ebay_item_adderror aufräumen
	--
		DELETE dbo.ebay_item_adderror
		FROM dbo.ebay_item_adderror
		JOIN DELETED ON DELETED.kItem  = dbo.ebay_item_adderror.kItem; 

 	--
	-- ebay_item_reviseerror aufräumen
	--
		DELETE dbo.ebay_item_reviseerror
		FROM dbo.ebay_item_reviseerror
		JOIN DELETED ON DELETED.kItem  = dbo.ebay_item_reviseerror.kItem; 

 	--
	-- ebay_geaenderte_laufende_angebote aufräumen
	--
		DELETE dbo.ebay_geaenderte_laufende_angebote
		FROM dbo.ebay_geaenderte_laufende_angebote
		JOIN DELETED ON DELETED.kItem  = dbo.ebay_geaenderte_laufende_angebote.kItem;
 																	 
 	--
	-- ebay_data_membermessage_in aufräumen
	--
		DELETE dbo.ebay_data_membermessage_in
		FROM dbo.ebay_data_membermessage_in
		JOIN DELETED ON DELETED.ItemID  = dbo.ebay_data_membermessage_in.ItemID  
		WHERE DELETED.Type = 'L';

 	--
	-- ebay_data_membermessage_out aufräumen
	--
		DELETE dbo.ebay_data_membermessage_out
		FROM dbo.ebay_data_membermessage_out
		JOIN DELETED ON DELETED.ItemID  = dbo.ebay_data_membermessage_out.ItemID  
		WHERE DELETED.Type = 'L';

 	--
	-- ebay_bestoffer aufräumen
	--
		DELETE dbo.ebay_bestoffer
		FROM dbo.ebay_bestoffer
		JOIN DELETED ON DELETED.ItemID  = dbo.ebay_bestoffer.ItemID  
		WHERE DELETED.Type = 'L';
 
END;
go

