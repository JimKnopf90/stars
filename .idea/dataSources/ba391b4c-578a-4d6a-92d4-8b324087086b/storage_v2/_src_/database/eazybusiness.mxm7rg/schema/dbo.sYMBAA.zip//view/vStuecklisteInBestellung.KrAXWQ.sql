CREATE VIEW [dbo].[vStuecklisteInBestellung]
AS
SELECT	Vater.kBestellStueckliste AS Stueckliste,
		Kind.tArtikel_kArtikel, 
		(Kind.nAnzahl / Vater.nAnzahl) AS MengeInBestellung
	FROM dbo.tbestellpos AS Vater
	JOIN dbo.tbestellpos AS Kind ON Kind.kBestellStueckliste = Vater.kBestellPos
	WHERE Kind.kBestellPos <> Kind.kBestellStueckliste
go

