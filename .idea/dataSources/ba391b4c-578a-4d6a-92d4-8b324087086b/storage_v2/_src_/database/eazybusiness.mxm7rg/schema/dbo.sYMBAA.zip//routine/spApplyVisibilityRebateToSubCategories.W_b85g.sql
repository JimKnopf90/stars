--- 
--- spApplyVisibilityRebateToSubCategories
---

CREATE PROCEDURE [dbo].[spApplyVisibilityRebateToSubCategories]

-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$

	@kRoot INT,						-- PK Wurzel-Kategorie
	@nProcessVisibility TINYINT,	-- 0/1, ob Sichtbarkeit verarbeitet werden soll
	@nProcessRebate TINYINT			-- 0/1, ob Rabatt verarbeitet werden soll
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
    SET NOCOUNT ON;
	--
    -- wendet Sichtbarkeits- und/oder Rabatt-Einstellungen für eine gegebene Wurzel-Kategorie auf alle Unterkategorien inkl. Artikel und Kind-Artikel an
    -- (auch für Artikel und Kind-Artikel der Wurzel-Kategorie)
	--
    -- Berechnung Unterkategorien
	--
    DECLARE @tUnterkategorien AS TABLE (kKategorie INT); -- EXklusive Wurzel!
    INSERT INTO @tUnterkategorien EXEC spGetSubCategories @kRoot;
	--
    -- Sichtbarkeit
	--
    IF (@nProcessVisibility = 1)
    BEGIN
		--
	    -- Kategorien
		--
	    -- alte Einstellungen löschen
		--
	    DELETE dbo.tKategorieSichtbarkeit WITH(ROWLOCK)
	    FROM dbo.tKategorieSichtbarkeit WITH(ROWLOCK) 
		JOIN @tUnterkategorien AS tUnterkategorien ON dbo.tKategorieSichtbarkeit.kKategorie = tUnterkategorien.kKategorie;
		--
	    -- Einstellungen von Wurzel-Kategorie übernehmen
		--
	    INSERT INTO dbo.tKategorieSichtbarkeit WITH(ROWLOCK)(kKategorie, kKundenGruppe, kShop)
		SELECT DISTINCT tUnterkategorien.kKategorie, dbo.tKategorieSichtbarkeit.kKundenGruppe, dbo.tKategorieSichtbarkeit.kShop
		FROM @tUnterkategorien AS tUnterkategorien, dbo.tKategorieSichtbarkeit
		WHERE dbo.tKategorieSichtbarkeit.kKategorie = @kRoot;
		--
	    -- Artikel & Kind-Artikel
		--
	    -- relevante Artikel bestimmen
		--
	    DECLARE @tArtikelRelevant AS TABLE (kArtikel INT);
		--
	    -- Nicht-Kind-Artikel von Wurzel-Kategorie
		--
	    INSERT INTO @tArtikelRelevant
		SELECT dbo.tkategorieartikel.kArtikel
		FROM dbo.tkategorieartikel WITH(NOLOCK)
		WHERE dbo.tkategorieartikel.kKategorie = @kRoot;
		--
	    -- Nicht-Kind-Artikel von Unterkategorien
		--
	    INSERT INTO @tArtikelRelevant
		SELECT dbo.tkategorieartikel.kArtikel
		FROM @tUnterkategorien AS tUnterkategorien 
		JOIN dbo.tkategorieartikel ON dbo.tkategorieartikel.kKategorie = tUnterkategorien.kKategorie;
		--
	    -- Kind-Artikel
		--
	    INSERT INTO @tArtikelRelevant
		SELECT dbo.tartikel.kArtikel
		FROM @tArtikelRelevant AS tArtikelRelevant 
		JOIN dbo.tartikel ON dbo.tartikel.kVaterArtikel = tArtikelRelevant.kArtikel;		
		--
	    -- alte Einstellungen löschen
		--
	    DELETE dbo.tArtikelSichtbarkeit WITH(ROWLOCK)
		FROM dbo.tArtikelSichtbarkeit WITH(ROWLOCK) 
		JOIN @tArtikelRelevant AS tArtikelRelevant ON dbo.tArtikelSichtbarkeit.kArtikel = tArtikelRelevant.kArtikel;		
		--
	    -- Einstellungen von Wurzel-Kategorie übernehmen
		--
	    INSERT INTO dbo.tArtikelSichtbarkeit WITH(ROWLOCK)(kArtikel, kKundenGruppe, kShop)
		SELECT DISTINCT tArtikelRelevant.kArtikel, dbo.tKategorieSichtbarkeit.kKundenGruppe, dbo.tKategorieSichtbarkeit.kShop
		FROM @tArtikelRelevant AS tArtikelRelevant, dbo.tKategorieSichtbarkeit
		WHERE dbo.tKategorieSichtbarkeit.kKategorie = @kRoot;
    END
	--
    -- Rabatt (nur Kategorien)
	--
    IF (@nProcessRebate = 1)
    BEGIN
		--
	    -- alte Einstellungen löschen
		--
	    DELETE dbo.tKategorieRabatt WITH(ROWLOCK)
		FROM dbo.tKategorieRabatt WITH(ROWLOCK)
		JOIN @tUnterkategorien AS tUnterkategorien ON dbo.tKategorieRabatt.kKategorie = tUnterkategorien.kKategorie;
		--
		-- Einstellungen von Wurzel-Kategorie übernehmen
		--
		INSERT INTO dbo.tKategorieRabatt (kKategorie, kKundenGruppe, kShop, fRabatt)
		SELECT DISTINCT tUnterkategorien.kKategorie, dbo.tKategorieRabatt.kKundenGruppe, dbo.tKategorieRabatt.kShop, dbo.tKategorieRabatt.fRabatt
		FROM @tUnterkategorien AS tUnterkategorien, dbo.tKategorieRabatt
		WHERE dbo.tKategorieRabatt.kKategorie = @kRoot;
    END
	--
	-- Kategorien für WebShop-Abgleich vormerken
	--
	UPDATE dbo.tKategorieShop WITH(ROWLOCK)
	SET cInet = 'Y'
	FROM dbo.tKategorieShop WITH(ROWLOCK) 
	JOIN @tUnterkategorien AS UnterKategorien ON dbo.tKategorieShop.kKategorie = UnterKategorien.kKategorie;	
END
go

