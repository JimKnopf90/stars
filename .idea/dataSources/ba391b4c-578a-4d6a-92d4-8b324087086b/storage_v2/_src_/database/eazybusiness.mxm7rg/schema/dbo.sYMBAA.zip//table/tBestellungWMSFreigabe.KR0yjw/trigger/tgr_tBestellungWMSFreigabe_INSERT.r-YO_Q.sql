CREATE TRIGGER [dbo].[tgr_tBestellungWMSFreigabe_INSERT] 
ON [dbo].[tBestellungWMSFreigabe] 
AFTER INSERT
AS 
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--
BEGIN
     DECLARE @kLHMBox INT;
     
	IF((SELECT COUNT(1) FROM INSERTED) = 0)
	BEGIN
		RETURN;
	END	
	UPDATE dbo.tBestellungWMSFreigabe WITH(ROWLOCK) SET nAktiv = 0 
	WHERE kBestellung IN (SELECT kBestellung FROM INSERTED)
	AND kBestellungWMSFreigabe NOT IN (SELECT kBestellungWMSFreigabe FROM INSERTED)
	AND nAktiv = 1;
	  
	  
	---
     --- Über alle LHM die die Bestellung haben, welcher es grade erlaubt wurde teilzuliefern
     ---
	--DECLARE cur_AllLHMWithTeillieferungErlaubt CURSOR LOCAL FAST_FORWARD FOR  
 --    SELECT dbo.tlhm.kLHM
	--FROM dbo.tlhm WITH(NOLOCK)
	--JOIN dbo.tlhmstatus WITH(NOLOCK) on dbo.tlhmstatus.klhmstatus = dbo.tlhm.klhmstatus
	--JOIN dbo.tWarenlagerPlatz WITH(NOLOCK) ON dbo.tWarenlagerPlatz.kWarenlagerPlatz = dbo.tLHM.kWarenlagerPlatz
	--JOIN INSERTED ON INSERTED.kBestellung = dbo.tlhmstatus.kBestellung AND INSERTED.nTeillieferungErlaubt = 1
	--LEFT JOIN dbo.tBestellungWMSFreigabe WITH(NOLOCK) ON dbo.tBestellungWMSFreigabe.kBestellung = INSERTED.kBestellung
	--                                              AND dbo.tBestellungWMSFreigabe.kBestellungWMSFreigabe != INSERTED.kBestellungWMSFreigabe
	--                                              AND dbo.tBestellungWMSFreigabe.dZeitstempel =  (SELECT TOP 1 t2.dZeitstempel
	--																	     FROM dbo.tBestellungWMSFreigabe t2 WITH(NOLOCK)
	--																	     WHERE t2.kBestellung = INSERTED.kBestellung
	--																		AND t2.nAktiv = 0
	--							                                                       ORDER BY t2.dZeitstempel desc) 
	--							           AND dbo.tBestellungWMSFreigabe.nTeillieferungErlaubt = 1
	--WHERE dbo.tlhmstatus.nstatus = 20
	--AND dbo.tBestellungWMSFreigabe.kBestellungWMSFreigabe IS NULL;

	
	--OPEN cur_AllLHMWithTeillieferungErlaubt    
 --    FETCH NEXT FROM cur_AllLHMWithTeillieferungErlaubt INTO  @kLHMBox
 --    WHILE (@@FETCH_STATUS = 0)
 --    BEGIN  
								    
 --      EXEC dbo.spVersandBoxPruefen @kLHM = @kLHMBox;
     
     
 --    FETCH NEXT FROM cur_AllLHMWithTeillieferungErlaubt INTO  @kLHMBox
 --    END;

 --    CLOSE cur_AllLHMWithTeillieferungErlaubt;
	--DEALLOCATE cur_AllLHMWithTeillieferungErlaubt;
END
go

