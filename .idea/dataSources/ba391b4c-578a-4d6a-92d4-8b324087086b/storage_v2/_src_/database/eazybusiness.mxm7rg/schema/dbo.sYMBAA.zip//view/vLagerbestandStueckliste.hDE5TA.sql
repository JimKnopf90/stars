CREATE VIEW [dbo].[vLagerbestandStueckliste] AS
SELECT
	dbo.tArtikel.kArtikel,
	dbo.tArtikel.cArtNr,
	Stuecklisten.kStueckliste,
	CASE 
		WHEN fLagerbestandDominant = 1000000000 AND fLagerbestandNichtDominant = 1000000000 THEN 0
		WHEN fLagerbestandDominant = 1000000000 THEN fLagerbestandNichtDominant
		WHEN fLagerbestandNichtDominant = 1000000000 THEN fLagerbestandDominant
		ELSE fLagerbestandDominant
	END AS fLagerbestand,
	CASE 
		WHEN fLagerbestandEigenDominant = 1000000000 AND fLagerbestandEigenNichtDominant = 1000000000 THEN 0
		WHEN fLagerbestandEigenDominant = 1000000000 THEN fLagerbestandEigenNichtDominant
		WHEN fLagerbestandEigenNichtDominant = 1000000000 THEN fLagerbestandEigenDominant
		ELSE fLagerbestandEigenDominant
	END AS fLagerbestandEigen,
	CASE 
		WHEN fVerfuegbarGesperrtDominant = 1000000000 AND fVerfuegbarGesperrtNichtDominant = 1000000000 THEN 0
		WHEN fVerfuegbarGesperrtDominant = 1000000000 THEN fVerfuegbarGesperrtNichtDominant
		WHEN fVerfuegbarGesperrtNichtDominant = 1000000000 THEN fVerfuegbarGesperrtDominant
		ELSE fVerfuegbarGesperrtDominant
	END AS fVerfuegbarGesperrt,
	CASE 
		WHEN fZulaufDominant = 1000000000 AND fZulaufNichtDominant = 1000000000 THEN 0
		WHEN fZulaufDominant = 1000000000 THEN fZulaufNichtDominant
		WHEN fZulaufNichtDominant = 1000000000 THEN fZulaufDominant
		ELSE fZulaufDominant
	END AS fZulauf,
	fAufEinkaufsliste,
	CASE 
		WHEN dLieferdatum = CAST('01.01.1900' AS DATETIME) THEN NULL
		ELSE dLieferdatum 
	END AS dLieferdatum,
	CASE 
		WHEN fVerfuegbarDominant = 1000000000 AND fVerfuegbarNichtDominant = 1000000000 THEN 0
		WHEN fVerfuegbarDominant = 1000000000 THEN fVerfuegbarNichtDominant
		WHEN fVerfuegbarNichtDominant = 1000000000 THEN fVerfuegbarDominant
		ELSE fVerfuegbarDominant
	END AS fVerfuegbar
FROM dbo.tArtikel
JOIN 
(
	SELECT	
		dbo.tStueckliste.kStueckliste,
		MIN(CASE 
				WHEN dbo.tArtikel.cLagerAktiv = 'N' THEN 1000000000
				WHEN dbo.tArtikel.cLagerKleinerNull = 'Y' THEN 1000000000
				WHEN VaterArtikel.cTeilbar = 'Y' THEN dbo.tlagerbestand.fLagerbestand / dbo.tStueckliste.fAnzahl
				ELSE FLOOR(dbo.tlagerbestand.fLagerbestand / dbo.tStueckliste.fAnzahl)
			END) AS fLagerbestandDominant,
		MIN(CASE 
				WHEN dbo.tArtikel.cLagerAktiv = 'N' THEN 1000000000
				WHEN VaterArtikel.cTeilbar = 'Y' THEN dbo.tlagerbestand.fLagerbestand / dbo.tStueckliste.fAnzahl
				ELSE FLOOR(dbo.tlagerbestand.fLagerbestand / dbo.tStueckliste.fAnzahl)
			END) AS fLagerbestandNichtDominant,
			MIN(CASE 
				WHEN dbo.tArtikel.cLagerAktiv = 'N' THEN 1000000000
				WHEN dbo.tArtikel.cLagerKleinerNull = 'Y' THEN 1000000000
				WHEN VaterArtikel.cTeilbar = 'Y' THEN dbo.tlagerbestand.fLagerbestandEigen / dbo.tStueckliste.fAnzahl
				ELSE FLOOR(dbo.tlagerbestand.fLagerbestandEigen / dbo.tStueckliste.fAnzahl)
			END) AS fLagerbestandEigenDominant,
		MIN(CASE 
				WHEN dbo.tArtikel.cLagerAktiv = 'N' THEN 1000000000
				WHEN VaterArtikel.cTeilbar = 'Y' THEN dbo.tlagerbestand.fLagerbestandEigen / dbo.tStueckliste.fAnzahl
				ELSE FLOOR(dbo.tlagerbestand.fLagerbestandEigen / dbo.tStueckliste.fAnzahl)
			END) AS fLagerbestandEigenNichtDominant,
		MIN(CASE 
				WHEN dbo.tArtikel.cLagerAktiv = 'N' THEN 1000000000
				WHEN dbo.tArtikel.cLagerKleinerNull = 'Y' THEN 1000000000
				WHEN VaterArtikel.cTeilbar = 'Y' THEN dbo.tlagerbestand.fVerfuegbar / dbo.tStueckliste.fAnzahl
				ELSE FLOOR(dbo.tlagerbestand.fVerfuegbar / dbo.tStueckliste.fAnzahl)
			END) AS fVerfuegbarDominant,
		MIN(CASE 
				WHEN dbo.tArtikel.cLagerAktiv = 'N' THEN 1000000000
				WHEN VaterArtikel.cTeilbar = 'Y' THEN dbo.tlagerbestand.fVerfuegbar / dbo.tStueckliste.fAnzahl
				ELSE FLOOR(dbo.tlagerbestand.fVerfuegbar / dbo.tStueckliste.fAnzahl)
			END) AS fVerfuegbarNichtDominant,
		MIN(CASE 
				WHEN dbo.tArtikel.cLagerAktiv = 'N' THEN 1000000000
				WHEN dbo.tArtikel.cLagerKleinerNull = 'Y' THEN 1000000000
				WHEN VaterArtikel.cTeilbar = 'Y' THEN dbo.tlagerbestand.fVerfuegbarGesperrt / dbo.tStueckliste.fAnzahl
				ELSE FLOOR(dbo.tlagerbestand.fVerfuegbarGesperrt / dbo.tStueckliste.fAnzahl)
			END) AS fVerfuegbarGesperrtDominant,
		MIN(CASE 
				WHEN dbo.tArtikel.cLagerAktiv = 'N' THEN 1000000000
				WHEN VaterArtikel.cTeilbar = 'Y' THEN dbo.tlagerbestand.fVerfuegbarGesperrt / dbo.tStueckliste.fAnzahl
				ELSE CEILING(dbo.tlagerbestand.fVerfuegbarGesperrt / dbo.tStueckliste.fAnzahl)
			END) AS fVerfuegbarGesperrtNichtDominant,
		MIN(CASE 
				WHEN dbo.tArtikel.cLagerAktiv = 'N' THEN 1000000000
				WHEN dbo.tArtikel.cLagerKleinerNull = 'Y' THEN 1000000000
				WHEN VaterArtikel.cTeilbar = 'Y' THEN dbo.tlagerbestand.fZulauf / dbo.tStueckliste.fAnzahl
				ELSE FLOOR(dbo.tlagerbestand.fZulauf / dbo.tStueckliste.fAnzahl)
			END) AS fZulaufDominant,
		MIN(CASE 
				WHEN dbo.tArtikel.cLagerAktiv = 'N' THEN 1000000000
				WHEN VaterArtikel.cTeilbar = 'Y' THEN dbo.tlagerbestand.fZulauf / dbo.tStueckliste.fAnzahl
				ELSE FLOOR(dbo.tlagerbestand.fZulauf / dbo.tStueckliste.fAnzahl)
			END) AS fZulaufNichtDominant,
		CASE	
			WHEN VaterArtikel.cTeilbar = 'Y' THEN MIN(dbo.tlagerbestand.fAufEinkaufsliste / dbo.tStueckliste.fAnzahl) 
			ELSE FLOOR(MIN(dbo.tlagerbestand.fAufEinkaufsliste / dbo.tStueckliste.fAnzahl))
		END AS fAufEinkaufsliste,
		MAX(ISNULL(dbo.tlagerbestand.dLieferdatum, CAST('01.01.1900' AS DATETIME))) AS dLieferdatum
	FROM dbo.tStueckliste
	JOIN dbo.tArtikel AS VaterArtikel ON VaterArtikel.kStueckliste = dbo.tStueckliste.kStueckliste
	JOIN dbo.tArtikel ON dbo.tArtikel.kArtikel = dbo.tStueckliste.kArtikel
	JOIN dbo.tlagerbestand ON tlagerbestand.kArtikel = tArtikel.kArtikel
	GROUP BY dbo.tStueckliste.kStueckliste, VaterArtikel.cTeilbar
) AS Stuecklisten ON Stuecklisten.kStueckliste = dbo.tArtikel.kStueckliste
go

