CREATE TRIGGER [dbo].[tgr_tbestellpos_INSUPDEL]
ON [dbo].[tbestellpos]
AFTER INSERT, UPDATE, DELETE
AS
    --
	-- Ausnahmen:
	--
	IF NOT EXISTS(SELECT* FROM INSERTED FULL JOIN DELETED ON INSERTED.kBestellPos = DELETED.kBestellPos)
    BEGIN
	   RETURN;
    END;
	IF(CONTEXT_INFO() IN(0x5098, 0x5099, 0x5100))
	BEGIN
		RETURN;
	END
	IF(NOT(UPDATE(tArtikel_kArtikel) 
		OR UPDATE(tBestellung_kBestellung)
		OR UPDATE(fVKPreis)
		OR UPDATE(fMwSt)
		OR UPDATE(nAnzahl)
		OR UPDATE(fRabatt)
		OR UPDATE(fVKNetto)
		OR UPDATE(kKonfigitem)
		OR UPDATE(nDropshipping)
		OR UPDATE(cTransactionID)
		OR UPDATE(kAmazonBestellungPos)
		OR UPDATE(kBestellStueckliste)
		OR UPDATE(nType))
		AND EXISTS(SELECT * FROM INSERTED JOIN DELETED ON INSERTED.kBestellpos = DELETED.kBestellPos))
	BEGIN
		RETURN
	END
	ROLLBACK;
	RAISERROR (N'Die Tabelle dbo.tbestellpos kann nur über die SPs spBestellposAendern, spBestellposAnlegen und spBestellposLoeschen geändert werden.', 15,1);
go

