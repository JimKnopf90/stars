--- 
--- spPicklistePosSplitten
---

CREATE PROCEDURE [dbo].[spPicklistePosSplitten]
  @kPicklistePos INT,
  @nMenge DECIMAL(28,14), 
  @kNewPicklistePos INT OUT,
  @nRet INT OUT

--  
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- 

-- Funktion: Splittet die eingegebene Menge von der Pickpos ab und erstellt dazu neue Pickpos. Die Mengenberechnung ob die alte Pickpos genug Menge hat muß vorher gemacht werden.
-- Liefer die neue Pickpos wieder
  
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
DECLARE @kPicklisteposStatus   INT
BEGIN TRAN T1  
	SET NOCOUNT ON;
		BEGIN TRY
		SET @nRet = 0

		-- Virtuelle Tabelle erstellen
		SELECT * INTO #PicklistePos 
			FROM tPicklistePos WITH(NOLOCK) 
			WHERE kPicklistePos = @kPicklistePos

		UPDATE #PicklistePos 
			SET fAnzahl = @nMenge 
			WHERE kPicklistePos = @kPicklistePos
		-- PK der Virtuellen Tabelle dropen, damit er in der reallen erstellt werden kann
		ALTER TABLE #PicklistePos 
			DROP COLUMN kPicklistePos 
		INSERT INTO tPicklistePos WITH(ROWLOCK) 
			SELECT #PicklistePos.* FROM #PicklistePos

		-- Neuen Pickpos wird aktuelle Pickpos
		SET @kNewPicklistePos = scope_identity()
		-- Ursprungs Pickpos Menge reduzieren
		UPDATE tPicklistePos WITH(ROWLOCK) 
			SET fAnzahl = (fAnzahl - @nMenge) 
			WHERE kPicklistePos = @kPicklistePos

		-- Ursprungs Pickpos in der neuen Pickpos eintragen
		UPDATE tPicklistePos WITH(ROWLOCK) 
			SET kPicklistePos_Ursprung = @kPicklistePos WHERE kPicklistePos = @kNewPicklistePos


		--Pickpos Status muß für den geplitteten neu erstellt werden
		SELECT @kPicklisteposStatus = kPicklisteposStatus 
			FROM tPicklistePos WITH(NOLOCK) 
			WHERE kPicklistePos = @kNewPicklistePos

		SELECT * INTO #Picklisteposstatus 
			FROM tPicklisteposstatus WITH(NOLOCK) 
			WHERE kPicklisteposStatus = @kPicklisteposStatus
  
		UPDATE #Picklisteposstatus 
			SET kPicklistePos = @kNewPicklistePos
  
		ALTER TABLE #Picklisteposstatus 
			DROP COLUMN kPicklisteposstatus
		INSERT INTO tPicklisteposstatus WITH(ROWLOCK) 
			SELECT #Picklisteposstatus.* 
			FROM #Picklisteposstatus 
	 
	COMMIT TRAN T1
END TRY
BEGIN CATCH
	SET @nRet = -203000013 -- unbekannter Fehler
	ROLLBACK TRAN T1
END CATCH
go

