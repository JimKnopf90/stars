--- 
--- spPicklisteposStatusAendern
---

CREATE PROCEDURE [dbo].[spPicklisteposStatusAendern]
  @kPicklistePos INT,
  @nNewStatus    INT,
  @kBenutzer     INT,
  @dTimestamp    DATETIME

--  
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--

AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
DECLARE @dIsTimestamp DATETIME

BEGIN
	IF (@nNewStatus > 0)
	BEGIN
		IF(@dTimestamp IS NULL)
			SET @dIsTimestamp =  GETDATE();
		ELSE
			SET @dIsTimestamp =  @dTimestamp;

		INSERT INTO tPicklistePosStatus  WITH(ROWLOCK) (kPicklistePos, kbenutzer, dZeitstempel, nStatus)
			VALUES (@kPicklistePos, @kBenutzer, @dIsTimestamp, @nNewStatus)
	END
	ELSE
	    SELECT -203000014
END
go

