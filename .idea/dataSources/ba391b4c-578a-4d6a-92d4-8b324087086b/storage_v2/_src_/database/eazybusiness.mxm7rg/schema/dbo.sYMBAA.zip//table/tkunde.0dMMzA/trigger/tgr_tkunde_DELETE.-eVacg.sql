CREATE TRIGGER [dbo].[tgr_tkunde_DELETE]    
--      
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: GJ
--        
ON [dbo].[tkunde]
    AFTER DELETE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN

    --
    -- Bestehende Kunden-Suchstrings löschen
    --
    DELETE tKunde_suche WITH( ROWLOCK )
      FROM tKunde_suche WITH ( ROWLOCK ) JOIN DELETED  ON tKunde_suche.kKunde = DELETED.kKunde;

END;
go

