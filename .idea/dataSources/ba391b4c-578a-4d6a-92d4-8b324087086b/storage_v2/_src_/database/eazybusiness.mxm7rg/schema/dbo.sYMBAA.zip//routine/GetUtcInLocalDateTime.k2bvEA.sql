CREATE FUNCTION [dbo].[GetUtcInLocalDateTime](@dateTime DATETIME)
--
-- berechnet aus einem UTC-DateTime das lokale DateTime
--
RETURNS DATETIME
AS
BEGIN
	RETURN(DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), @dateTime))
END
go

