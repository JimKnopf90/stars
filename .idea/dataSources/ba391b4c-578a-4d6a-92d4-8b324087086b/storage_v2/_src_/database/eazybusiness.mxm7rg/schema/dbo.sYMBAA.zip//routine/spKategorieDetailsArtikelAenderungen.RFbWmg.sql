--- 
--- spKategorieDetailsArtikelAenderungen
---

CREATE PROCEDURE [dbo].[spKategorieDetailsArtikelAenderungen]

-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: SW

-- setzt Versandklasse und Warengruppe und erhöht prozentual oder absolut die Bruttopreise
--		für alle Artikel und Kind-Artikel einer Kategorie und auf Wunsch auch für die Artikel und Kind-Artikel aller Unterkategorien
	@kRoot INT,									-- PK (Wurzel-)Kategorie
	@nVersandklasse INT,						-- Wert Versandklasse;							-1 = ignorieren
	@nWarengruppe INT,							-- Wert Warengruppe;							-1 = ignorieren	
	@dProzent DECIMAL(28,14),					-- Prozentwert Bruttopreise (zB 34 für 34%);	 0 = ignorieren
	@dBetrag DECIMAL(28,14),					-- Absolutbetrag Bruttopreise;					 0 = ignorieren
	@nRekursivVersandklasseWarengruppe TINYINT,	-- 0/1, ob die Unterkategorien für Versandklasse/Warengruppe miteinbezogen werden sollen;
												--		Achtung: = 1 => Unterkategorien + zugehörige Artikel werden in jedem Fall berechnet!
	@nRekursivBruttoPreise TINYINT,				-- 0/1, ob die Unterkategorien für die Bruttopreise miteinbezogen werden sollen;
												--		Achtung: = 1 => Unterkategorien + zugehörige Artikel werden in jedem Fall berechnet!
	@kSteuerzone INT							-- PK der Steuerzone des angemeldeten Benutzers (welchen die DB nicht kennt weil Session-abhängig)
AS
BEGIN
	SET NOCOUNT ON;
	SET ANSI_NULLS ON;
	SET ANSI_NULL_DFLT_ON ON;
	SET ANSI_PADDING ON;
	SET CONCAT_NULL_YIELDS_NULL ON;
	SET XACT_ABORT OFF;

	DECLARE @tArtikelWurzel AS TABLE (kArtikel INT);
	DECLARE @tArtikelRekursiv AS TABLE (kArtikel INT);
	DECLARE @tArtikelRelevant AS TABLE (kArtikel INT);
	DECLARE @tKategorien AS TABLE (kKategorie INT);
	
	-- Berechnung relevanter Artikel
	-- Artikel der Wurzelkategorie
	IF (@nRekursivVersandklasseWarengruppe = 0 OR @nRekursivBruttoPreise = 0)
	BEGIN		
		INSERT INTO @tArtikelWurzel
		SELECT tkategorieartikel.kArtikel
		FROM tkategorieartikel WITH(NOLOCK)
		WHERE tkategorieartikel.kKategorie = @kRoot;
		-- Kind-Artikel
		INSERT INTO @tArtikelWurzel
		SELECT tartikel.kArtikel
		FROM tartikel WITH(NOLOCK) JOIN @tArtikelWurzel AS tArtikelWurzel
			ON tartikel.kVaterArtikel = tArtikelWurzel.kArtikel;
	END;	
	-- Artikel der Wurzelkategorie und der Unterkategorien
	IF (@nRekursivVersandklasseWarengruppe = 1 OR @nRekursivBruttoPreise = 1)
	BEGIN		
		INSERT INTO @tKategorien VALUES (@kRoot);
		INSERT INTO @tKategorien EXEC spGetSubCategories @kRoot;
		INSERT INTO @tArtikelRekursiv
			SELECT tkategorieartikel.kArtikel
			FROM tkategorieartikel WITH(NOLOCK) JOIN @tKategorien AS tKategorien
				ON tkategorieartikel.kKategorie = tKategorien.kKategorie;
		-- Kind-Artikel
		INSERT INTO @tArtikelRekursiv
		SELECT tartikel.kArtikel
		FROM tartikel WITH(NOLOCK) JOIN @tArtikelRekursiv AS tArtikelRekursiv
			ON tartikel.kVaterArtikel = tArtikelRekursiv.kArtikel;
	END;
		
	-- Versandklasse/Warengruppe
	IF (@nVersandklasse != -1 OR @nWarengruppe != -1)
	BEGIN
		IF (@nRekursivVersandklasseWarengruppe = 0)
			INSERT INTO @tArtikelRelevant SELECT * FROM @tArtikelWurzel;
		ELSE
			INSERT INTO @tArtikelRelevant SELECT * FROM @tArtikelRekursiv;

		IF (@nVersandklasse != -1)
			UPDATE tartikel	WITH(ROWLOCK)	
			SET kVersandklasse = @nVersandklasse
			FROM tartikel WITH(ROWLOCK) JOIN @tArtikelRelevant AS tArtikelRelevant
				ON tartikel.kArtikel = tArtikelRelevant.kArtikel;	

		IF (@nWarengruppe != -1)
			UPDATE tartikel	WITH(ROWLOCK)	
			SET kWarengruppe = @nWarengruppe
			FROM tartikel WITH(ROWLOCK) JOIN @tArtikelRelevant AS tArtikelRelevant
				ON tartikel.kArtikel = tArtikelRelevant.kArtikel;	
	END

	-- Preise
	IF (@dProzent != 0 OR @dBetrag != 0)
	BEGIN
		DELETE FROM @tArtikelRelevant;
		IF (@nRekursivBruttoPreise = 0)
			INSERT INTO @tArtikelRelevant SELECT * FROM @tArtikelWurzel;
		ELSE
			INSERT INTO @tArtikelRelevant SELECT * FROM @tArtikelRekursiv;

		IF (@dProzent != 0)
		BEGIN
			UPDATE tartikel	WITH(ROWLOCK)
			SET tartikel.fVKNetto = dbo.POSITIV(tartikel.fVKNetto * (1 + (@dProzent / 100.0)))
			FROM tartikel WITH(ROWLOCK) JOIN @tArtikelRelevant AS tArtikelRelevant
				ON tartikel.kArtikel = tArtikelRelevant.kArtikel;		
						
			UPDATE tPreisDetail WITH(ROWLOCK)
			SET tPreisDetail.fNettoPreis = dbo.POSITIV(tPreisDetail.fNettoPreis * (1 + (@dProzent / 100.0)))
			FROM tPreisDetail WITH(ROWLOCK) 
				JOIN tPreis 
					ON tPreis.kPreis = tPreisDetail.kPreis
				JOIN @tArtikelRelevant AS tArtikelRelevant 
					ON tPreis.kArtikel = tArtikelRelevant.kArtikel
			WHERE tPreisDetail.nAnzahlAb = 0;				
		END

		IF (@dBetrag != 0)
		BEGIN
			UPDATE tartikel	WITH(ROWLOCK)
			SET tartikel.fVKNetto = dbo.POSITIV(tartikel.fVKNetto + (@dBetrag / (1 + (tsteuersatz.fSteuersatz / 100))))
			FROM tartikel WITH(ROWLOCK) 
				JOIN @tArtikelRelevant AS tArtikelRelevant
					ON tartikel.kArtikel = tArtikelRelevant.kArtikel
				JOIN tsteuersatz WITH(NOLOCK)
					ON tsteuersatz.kSteuerklasse = tartikel.kSteuerklasse
			WHERE tsteuersatz.kSteuerzone = @kSteuerzone;											
				
			UPDATE tPreisDetail WITH(ROWLOCK)
			SET tPreisDetail.fNettoPreis = dbo.POSITIV(tPreisDetail.fNettoPreis + @dBetrag / (1 + (tsteuersatz.fSteuersatz / 100)))
			FROM @tArtikelRelevant AS tArtikelRelevant 
				JOIN tPreis
					ON tPreis.kArtikel = tArtikelRelevant.kArtikel 
				JOIN tPreisDetail WITH(ROWLOCK)
				     ON tPreis.kPreis = tPreisDetail.kPreis
				JOIN tartikel WITH(NOLOCK)
					ON tartikel.kArtikel = tArtikelRelevant.kArtikel 
				JOIN tsteuersatz WITH(NOLOCK)
					ON tsteuersatz.kSteuerklasse = tartikel.kSteuerklasse
			WHERE tsteuersatz.kSteuerzone = @kSteuerzone
			  AND tPreisDetail.nAnzahlAb = 0;		
		END	
	END
END
go

