CREATE TRIGGER [dbo].[trg_tinetbestellpos_DELETE]
--     
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--    
ON [dbo].[tinetbestellpos]  
AFTER DELETE 
AS  
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN 
	
	UPDATE dbo.tArtikelShop
		SET dbo.tArtikelShop.cInet = 'Y',
			dbo.tArtikelShop.nAktion = 1, 
			dbo.tArtikelShop.nInBearbeitung = 0
	FROM DELETED
	JOIN dbo.tArtikelShop ON DELETED.kArikel = dbo.tArtikelShop.kArtikel
						AND DELETED.kShop = dbo.tArtikelShop.kShop
	WHERE dbo.tArtikelShop.cInet <> 'Y'
		AND dbo.tArtikelShop.nAktion = 0;

END;
go

