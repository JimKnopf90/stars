
    CREATE VIEW unicorn2_vKategorieStruktur 
    AS
        SELECT			
			tKategorie.kKategorie AS kKategorie, 
			tKategorie.kOberKategorie AS kOberKategorie,
			ROW_NUMBER() OVER(ORDER BY vKategorien.Ebene, tKategorie.nSort, vKategorien.cName) AS kUnicornSort,
			vKategorien.cName AS cName,
			vKategorien.Pfad AS cPfad,
			vKategorien.Ebene AS kEbene,
			tKategorie.cAktiv AS cAktiv
		FROM vKategorien 
		JOIN tKategorie 
			ON tKategorie.kKategorie = vKategorien.kKategorie;
    go

