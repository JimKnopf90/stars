--- 
--- spGetNewDruckJob
---

CREATE PROCEDURE [dbo].[spGetNewDruckJob]  
	@kWarenlager INT, 
	@kWarenlagerPlatz INT
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--
-- Holt sich anhand vom Warenlager und ggf. WarenlagerPlatz den nächsten offenen Druckjob   
-- Muss als Procedure und Transaction aufgerufen werden, damit bei parallelen DruckJobs nicht die Dokumente doppelt gedruckt werden  
AS    
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN TRANSACTION 
	DECLARE @kDruckQueue INT  
	
	SELECT @kDruckQueue = tDruckqueue.kDruckQueue  
		FROM tdruckqueue WITH(NOLOCK)
		JOIN twarenlagerplatz WITH(NOLOCK) ON tDruckQueue.kWarenlagerPlatz = tWarenlagerPlatz.kWarenlagerPlatz 
		WHERE tWarenlagerPlatz.kWarenlager = @kWarenlager  
			AND tDruckqueue.nStatus = 10  
			AND (ISNULL(@kWarenlagerPlatz,0) = 0 or tWarenlagerPlatz.kWarenlagerPlatz = @kWarenlagerPlatz)  
		ORDER BY dZeitstempel DESC

	IF (@kDruckQueue > 0)  
	BEGIN  
	  -- Sorgt dafür, dass dieser Job von keinem anderen ausgeführt wird  
	  UPDATE tDruckQueue WITH(ROWLOCK) 
		SET nStatus = 20 
		WHERE kDruckQueue = @kDruckQueue  
	END  
	SELECT @kDruckQueue
COMMIT
go

