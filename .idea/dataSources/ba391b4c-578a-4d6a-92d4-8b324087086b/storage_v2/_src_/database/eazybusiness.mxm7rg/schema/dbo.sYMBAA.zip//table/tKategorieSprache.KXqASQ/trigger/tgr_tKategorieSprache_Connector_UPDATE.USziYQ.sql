CREATE TRIGGER [dbo].[tgr_tKategorieSprache_Connector_UPDATE]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP
--
ON [dbo].[tKategorieSprache]
AFTER UPDATE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN	

	--Überprüfen ob Trigger gefüllt aufgerufen wird
	IF((SELECT COUNT(1) 
		FROM INSERTED 
		FULL JOIN DELETED ON INSERTED.kKategorie = DELETED.kKategorie
			AND INSERTED.kSprache = DELETED.kSprache
			AND INSERTED.kPlattform = DELETED.kPlattform
			AND INSERTED.kShop = DELETED.kShop) = 0)
	BEGIN 
		RETURN;
	END

	--
	-- Alle Shops abgleichen deren Kategoriebeschreibungen sich geändert haben
	-- Gilt für alle Shopspezifischen Kategoriebeschreibungen
	--
	UPDATE dbo.tKategorieShop
		SET dbo.tKategorieShop.cInet = 'Y'
	FROM dbo.tKategorieShop
	JOIN INSERTED ON dbo.tKategorieShop.kKategorie = INSERTED.kKategorie
		AND dbo.tKategorieShop.kShop = INSERTED.kShop
	JOIN DELETED ON INSERTED.kKategorie = DELETED.kKategorie
			AND INSERTED.kSprache = DELETED.kSprache
			AND INSERTED.kPlattform = DELETED.kPlattform
			AND INSERTED.kShop = DELETED.kShop
	WHERE	(ISNULL(INSERTED.cName, '') <> ISNULL(DELETED.cName, '')
			OR ISNULL(INSERTED.cBeschreibung, '') <> ISNULL(DELETED.cBeschreibung, '')
			OR ISNULL(INSERTED.cUrlPfad, '') <> ISNULL(DELETED.cUrlPfad, '')
			OR ISNULL(INSERTED.cMetaDescription, '') <> ISNULL(DELETED.cMetaDescription, '')
			OR ISNULL(INSERTED.cTitleTag, '') <> ISNULL(DELETED.cTitleTag, '')
			OR ISNULL(INSERTED.cMetaKeywords, '') <> ISNULL(DELETED.cMetaKeywords, ''))

	--
	-- Alle Shops abgleichen deren Kategoriebeschreibungen sich geändert haben
	-- Gilt für alle globalen Kategoriebeschreibungen
	--
	UPDATE dbo.tKategorieShop
		SET dbo.tKategorieShop.cInet = 'Y'
	FROM dbo.tKategorieShop
	LEFT JOIN dbo.tKategorieSprache ON dbo.tKategorieShop.kKategorie = dbo.tKategorieSprache.kKategorie
		AND dbo.tKategorieShop.kShop = dbo.tKategorieSprache.kShop
		AND dbo.tKategorieSprache.kPlattform = 2
	JOIN INSERTED ON dbo.tKategorieShop.kKategorie = INSERTED.kKategorie
		AND INSERTED.kShop = 0
	JOIN DELETED ON INSERTED.kKategorie = DELETED.kKategorie
			AND INSERTED.kSprache = DELETED.kSprache
			AND INSERTED.kPlattform = DELETED.kPlattform
			AND INSERTED.kShop = DELETED.kShop
	WHERE	(ISNULL(INSERTED.cName, '') <> ISNULL(DELETED.cName, '')
			OR ISNULL(INSERTED.cBeschreibung, '') <> ISNULL(DELETED.cBeschreibung, '')
			OR ISNULL(INSERTED.cUrlPfad, '') <> ISNULL(DELETED.cUrlPfad, '')
			OR ISNULL(INSERTED.cMetaDescription, '') <> ISNULL(DELETED.cMetaDescription, '')
			OR ISNULL(INSERTED.cTitleTag, '') <> ISNULL(DELETED.cTitleTag, '')
			OR ISNULL(INSERTED.cMetaKeywords, '') <> ISNULL(DELETED.cMetaKeywords, ''))
			AND dbo.tKategorieSprache.kKategorie IS NULL
END
go

