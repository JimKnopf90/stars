--- 
--- spAddAttribut
---

CREATE PROCEDURE dbo.spAddAttribut( @cWertVarChar AS NVARCHAR( MAX ) , 
                                         @cName AS VARCHAR( MAX ) , 
                                         @cGruppeName AS NVARCHAR( MAX ) , 
                                         @cBeschreibung AS NVARCHAR( MAX ) , 
                                         @kSprache AS int,
								 @kFeldTyp AS int,
								 @nIstStandard AS int,
								 @nIstMehrsprachig AS int,
								 @cWertListe AS nvarchar(max),
								 @nBezugstyp AS int)
AS
BEGIN
    IF( SELECT COUNT( * )
        FROM
             dbo.tAttribut AS Attribut
             JOIN dbo.tAttributSprache AS Sprache ON Sprache.kAttribut = Attribut.kAttribut
                                                 AND Attribut.cGruppeName = @cGruppeName
                                                 AND Attribut.nBezugstyp = @nBezugstyp
                                                 AND Attribut.nIstFreifeld = 0
                                                 AND Sprache.cName = @cName ) = 0
        BEGIN
            INSERT INTO dbo.tAttribut(
            --kAttribut - this column value is auto-generated
            dbo.tAttribut.nIstMehrsprachig , 
            dbo.tAttribut.nIstFreifeld , 
            dbo.tAttribut.nSortierung , 
            dbo.tAttribut.cBeschreibung , 
            dbo.tAttribut.nBezugstyp , 
            dbo.tAttribut.nAusgabeweg , 
            dbo.tAttribut.nIstStandard , 
            dbo.tAttribut.kFeldTyp , 
            dbo.tAttribut.cRegEx , 
            dbo.tAttribut.cGruppeName )
            VALUES(
                  -- kAttribut - int
                  @nIstMehrsprachig , 
                  -- nIstMehrsprachig - tinyint
                  0 , 
                  -- nIstFreifeld - tinyint
                  1 , 
                  -- nSortierung - int
                  @cBeschreibung , 
                  -- cBeschreibung - varchar
                  @nBezugstyp , 
                  -- nBezugstyp - tinyint
                  0 , 
                  -- nAusgabeweg - tinyint
                  @nIstStandard , 
                  -- nIstStandard - tinyint
                  @kFeldTyp , 
                  -- kFeldTyp - int
                  N'' , 
                  -- cRegEx - nvarchar
                  @cGruppeName -- cGruppeName - nvarchar
                  );

            INSERT INTO dbo.tAttributSprache( dbo.tAttributSprache.kAttribut , 
                                              dbo.tAttributSprache.kSprache , 
                                              dbo.tAttributSprache.cName , 
                                              dbo.tAttributSprache.cWertListe )
            VALUES( @@IDENTITY , 
                    -- kAttribut - int
                    @kSprache , 
                    -- kSprache - int
                    @cName , 
                    -- cName - varchar
                    @cWertListe -- cWertListe - varchar
                  );
        END;
END;
go

