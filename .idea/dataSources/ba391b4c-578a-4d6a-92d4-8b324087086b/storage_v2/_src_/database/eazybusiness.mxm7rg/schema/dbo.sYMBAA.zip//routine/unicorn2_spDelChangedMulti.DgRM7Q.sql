
    CREATE PROCEDURE unicorn2_spDelChangedMulti @kWawiIdList VARCHAR(MAX)
    AS
        DECLARE @kWawiIdListLocal VARCHAR(MAX)
    		SET @kWawiIdListLocal = @kWawiIdList
    	
        SET DEADLOCK_PRIORITY LOW		
        DELETE FROM unicorn2_tChangeCache
        WHERE kWawiId IN (SELECT * FROM unicorn2_fSplitInts(@kWawiIdListLocal, ','));
    go

