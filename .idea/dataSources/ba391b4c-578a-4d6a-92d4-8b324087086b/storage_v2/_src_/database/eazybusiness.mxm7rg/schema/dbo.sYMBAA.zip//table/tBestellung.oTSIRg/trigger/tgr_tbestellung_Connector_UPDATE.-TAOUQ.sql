CREATE TRIGGER [dbo].[tgr_tbestellung_Connector_UPDATE]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: FB
--
ON [dbo].[tbestellung]
AFTER UPDATE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
    --Überprüfen ob Trigger gefüllt aufgerufen wird
    IF((SELECT COUNT(1)
        FROM INSERTED
        JOIN DELETED ON INSERTED.kBestellung = DELETED.kBestellung
        WHERE INSERTED.kShop > 0
            AND (INSERTED.nStorno <> DELETED.nStorno
                OR DELETED.nStorno IS NULL)) = 0)
    BEGIN
        RETURN;
    END;

    --
    -- STORNO
    --
    -- Connector-Bestellungen
    --
    -- Bisherige Queue-Einträge entfernen
    DELETE dbo.tQueue
    FROM dbo.tQueue
    JOIN INSERTED ON dbo.tQueue.kOption1 = INSERTED.kBestellung
    JOIN DELETED ON INSERTED.kBestellung = DELETED.kBestellung
    JOIN dbo.tShop ON dbo.tQueue.kShop = dbo.tShop.kShop
                AND dbo.tShop.nTyp = 1
    WHERE dbo.tQueue.cName = 'tBestellung'
        AND INSERTED.nStorno = 1 AND DELETED.nStorno = 0;

    -- Storno-Eintrag in tQueue schreiben
    INSERT INTO dbo.tQueue (kShop, kPlattform, cName, kWert, nAction, kOption1, kOption2, nInBearbeitung)
    SELECT INSERTED.kShop, 2, 'tBestellung', 0, 5, INSERTED.kBestellung, 0, 0
    FROM INSERTED
    JOIN DELETED ON INSERTED.kBestellung = DELETED.kBestellung
    JOIN dbo.tShop ON INSERTED.kShop = dbo.tShop.kShop
                AND dbo.tShop.nTyp = 1
    WHERE INSERTED.nStorno = 1 AND DELETED.nStorno = 0;

    --
    -- JTL-Shop-Bestellungen
    --
    -- Bisherige Queue-Einträge entfernen
    DELETE dbo.tQueue
    FROM dbo.tQueue
    JOIN INSERTED ON dbo.tQueue.kWert = INSERTED.kInetBestellung
    JOIN DELETED ON INSERTED.kBestellung = DELETED.kBestellung
    JOIN dbo.tShop ON dbo.tQueue.kShop = dbo.tShop.kShop
                AND dbo.tShop.nTyp = 0
    WHERE dbo.tQueue.cName = 'tBestellung'
        AND INSERTED.nStorno = 1 AND DELETED.nStorno = 0;

    -- Storno-Eintrag in tQueue schreiben
    INSERT INTO dbo.tQueue (kShop, kPlattform, cName, kWert, nAction, kOption1, kOption2, nInBearbeitung)
    SELECT INSERTED.kShop, 2, 'tBestellung', INSERTED.kInetBestellung, 5, 0, 0, 0
    FROM INSERTED
    JOIN DELETED ON INSERTED.kBestellung = DELETED.kBestellung
    JOIN dbo.tShop ON INSERTED.kShop = dbo.tShop.kShop
                AND dbo.tShop.nTyp = 0
    WHERE INSERTED.nStorno = 1 AND DELETED.nStorno = 0;

    --
    -- STORNO RÜCKGÄNGIG
    --
    -- Connector-Bestellungen
    --
    -- Storno-Rückgängig-Eintrag in tQueue schreiben
    INSERT INTO dbo.tQueue (kShop, kPlattform, cName, kWert, nAction, kOption1, kOption2, nInBearbeitung)
    SELECT INSERTED.kShop, 2, 'tBestellung', 0, 6, INSERTED.kBestellung, 0, 0
    FROM INSERTED
    JOIN DELETED ON INSERTED.kBestellung = DELETED.kBestellung
    JOIN dbo.tShop ON INSERTED.kShop = dbo.tShop.kShop
                AND dbo.tShop.nTyp = 1
    WHERE INSERTED.nStorno = 0 AND DELETED.nStorno = 1;

    --
    -- JTL-Shop-Bestellungen
    --
    -- Storno-Eintrag in tQueue schreiben
    INSERT INTO dbo.tQueue (kShop, kPlattform, cName, kWert, nAction, kOption1, kOption2, nInBearbeitung)
    SELECT INSERTED.kShop, 2, 'tBestellung', INSERTED.kInetBestellung, 6, 0, 0, 0
    FROM INSERTED
    JOIN DELETED ON INSERTED.kBestellung = DELETED.kBestellung
    JOIN dbo.tShop ON INSERTED.kShop = dbo.tShop.kShop
                AND dbo.tShop.nTyp = 0
    WHERE INSERTED.nStorno = 0 AND DELETED.nStorno = 1;

END
go

