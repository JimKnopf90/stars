CREATE TRIGGER [dbo].[tgr_ebay_item_INSUPDEL]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Author: MK / SW / MP
--
    ON [dbo].[ebay_item]
	AFTER INSERT,DELETE,UPDATE
AS 
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
    SET NOCOUNT ON;
	
	DECLARE @nPlattformEbayBietAuktion AS INT;
	SET @nPlattformEbayBietAuktion = 4;
	DECLARE @nPlattformEbay AS INT;
	SET @nPlattformEbay = 2;
	DECLARE @nStatusLaufendesAngebot AS INT;
	SET @nStatusLaufendesAngebot = 3;
	IF(NOT EXISTS(	SELECT * FROM 
						(SELECT Type  FROM INSERTED
							UNION 
						SELECT Type FROM  DELETED) AS Result
						WHERE Result.Type NOT IN('V', 'G')))
	BEGIN
		RETURN
	END					

    IF(UPDATE(Quantity) OR UPDATE(Status) OR UPDATE(bBestandReserviert))
	BEGIN
		--
		-- Reservierungen initialisieren für Datensätze die als laufende Angebote eingefügt werden (ebay_item.Status = 3)
		-- oder zu einem laufenden Angebot (ebay_item.Status = 3) werden
		-- oder deren Bestand jetzt reserviert werden soll (ebay_item.bBestandReserviert = 1)
		-- und die noch keine Reservierung erzeugt haben (tReserviert.kPlattform = 4)
		--
		INSERT INTO dbo.tReserviert(kArtikel, fAnzahl, kKey, kPlattform)
		SELECT	INSERTED.kArtikel, 
				INSERTED.Quantity * CASE WHEN(dbo.teinstellungen.cLootSize = 'Y')
										THEN ISNULL(CAST(INSERTED.LotSize AS DECIMAL(28,14)),1)
										ELSE 1
									END, 
				INSERTED.kItem, 
				@nPlattformEbayBietAuktion
		FROM INSERTED
		LEFT JOIN DELETED ON INSERTED.kItem = DELETED.kItem
		LEFT JOIN dbo.tReserviert ON INSERTED.kArtikel = dbo.tReserviert.kArtikel
			AND dbo.tReserviert.kKey = INSERTED.kItem
			AND dbo.tReserviert.kPlattform = @nPlattformEbayBietAuktion
		CROSS JOIN dbo.teinstellungen
		WHERE	(
					(
						(
							INSERTED.Status = @nStatusLaufendesAngebot 
							AND ISNULL(DELETED.Status, 0) <> @nStatusLaufendesAngebot
						)
						OR
						(
							INSERTED.bBestandReserviert = 1 
							AND ISNULL(DELETED.bBestandReserviert, 0) <> 1
						)
					)
					AND INSERTED.Status = @nStatusLaufendesAngebot 
					AND INSERTED.bBestandReserviert = 1
				)
				AND dbo.tReserviert.kArtikel IS NULL;
		INSERT INTO dbo.tReserviert(kArtikel, fAnzahl, kKey, kPlattform)
			SELECT dbo.tStueckliste.kArtikel, 
					INSERTED.Quantity * dbo.tReserviert.fAnzahl * dbo.tStueckliste.fAnzahl,
					dbo.tReserviert.kKey, 
					dbo.tReserviert.kPlattform
				FROM dbo.tReserviert
				JOIN INSERTED ON dbo.tReserviert.kKey = INSERTED.kItem
								AND dbo.tReserviert.kPlattform = @nPlattformEbayBietAuktion
				JOIN dbo.tArtikel ON dbo.tReserviert.kArtikel = dbo.tArtikel.kArtikel
				JOIN dbo.tStueckliste ON dbo.tStueckliste.kStueckliste = dbo.tArtikel.kStueckliste
				LEFT JOIN dbo.tReserviert AS Kind ON Kind.kKey = INSERTED.kItem
											AND Kind.kPlattform = @nPlattformEbayBietAuktion
											AND Kind.kArtikel <> INSERTED.kArtikel 
				WHERE Kind.kArtikel IS NULL;
		--
		-- Menge der Reservierung aktualisieren
		--
		--UPDATE dbo.tReserviert
		--	SET dbo.tReserviert.fAnzahl = INSERTED.Quantity * ISNULL(CAST(INSERTED.LotSize AS DECIMAL(28,15)),1) 
		--FROM dbo.tReserviert
		--JOIN INSERTED ON dbo.tReserviert.kKey = INSERTED.kItem
		--JOIN DELETED ON INSERTED.kItem = DELETED.kItem
		--JOIN dbo.teinstellungen ON dbo.teinstellungen.cLootSize = 'Y'
		--WHERE	dbo.tReserviert.kPlattform = @nPlattformEbayBietAuktion
		--		AND INSERTED.Quantity <> DELETED.Quantity;		
	END

	DECLARE @Type_spUpdateLagerbestand AS TYPE_spUpdateLagerbestand;
	INSERT INTO @Type_spUpdateLagerbestand (kArtikel)
			SELECT kArtikel
				FROM dbo.tReserviert
				JOIN 
				(
					SELECT INSERTED.kItem
						FROM INSERTED
					UNION
					SELECT DELETED.kItem 
						FROM DELETED
					UNION
					SELECT DELETED.kItem 
						FROM DELETED 
						JOIN INSERTED ON DELETED.kItem = INSERTED.kItem
						WHERE	DELETED.bBestandReserviert = 0
								AND DELETED.bBestandReserviert <> INSERTED.bBestandReserviert
					UNION 
					SELECT INSERTED.kItem
						FROM INSERTED
						JOIN DELETED ON INSERTED.kItem = DELETED.kItem
						WHERE DELETED.bBestandReserviert = 1
								AND INSERTED.Status IN(4,5)
				) AS geloeschteEinträge ON dbo.tReserviert.kKey = geloeschteEinträge.kItem
					AND dbo.tReserviert.kPlattform = @nPlattformEbayBietAuktion;
	--
	-- Einträge aus tReserviert löschen für gelöschte Datensätze
	-- und für solche, die keine Reservierung mehr schreiben sollen (dbo.ebay_item.bBestandReserviert = 0)
	--
	DELETE FROM dbo.tReserviert
	FROM dbo.tReserviert
	JOIN 
	(
		SELECT DELETED.kItem 
			FROM DELETED 
			LEFT JOIN INSERTED ON DELETED.kItem = INSERTED.kItem
			WHERE INSERTED.kItem IS NULL
		UNION
		SELECT DELETED.kItem 
			FROM DELETED 
			JOIN INSERTED ON DELETED.kItem = INSERTED.kItem
			WHERE	DELETED.bBestandReserviert = 0
					AND DELETED.bBestandReserviert <> INSERTED.bBestandReserviert
		UNION 
		SELECT INSERTED.kItem
			FROM INSERTED
			JOIN DELETED ON INSERTED.kItem = DELETED.kItem
			WHERE DELETED.bBestandReserviert = 1
					AND INSERTED.Status IN(4,5)
	) AS geloeschteEinträge ON dbo.tReserviert.kKey = geloeschteEinträge.kItem
		AND dbo.tReserviert.kPlattform = @nPlattformEbayBietAuktion;
	
	--
	-- Lagerbestände für alle betroffenen Datensätze aktualisieren
	--
	IF(EXISTS(SELECT * FROM @Type_spUpdateLagerbestand))
	BEGIN
		EXEC spUpdatelagerbestand @Type_spUpdateLagerbestand;
	END

END
go

