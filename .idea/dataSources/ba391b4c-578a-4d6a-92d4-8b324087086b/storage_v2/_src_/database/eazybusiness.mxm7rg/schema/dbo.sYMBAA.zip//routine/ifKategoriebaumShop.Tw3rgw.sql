CREATE FUNCTION [dbo].[ifKategoriebaumShop](@kShop AS INT)
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP/FB
--
RETURNS TABLE
AS
RETURN
(
	WITH kategorien AS
	(
		SELECT dbo.tkategorie.kKategorie, 0 AS nLevel, dbo.tkategorie.kOberKategorie 
		FROM dbo.tkategorie			
		WHERE dbo.tkategorie.kOberKategorie = (SELECT ISNULL(dbo.tShop.kKategorie, 0) FROM dbo.tShop WHERE dbo.tShop.kShop = @kShop)
		UNION ALL
		SELECT dbo.tkategorie.kKategorie, kategorien.nLevel + 1 AS nLevel, dbo.tkategorie.kOberKategorie
		FROM dbo.tkategorie		
		JOIN kategorien ON dbo.tkategorie.kOberKategorie = kategorien.kKategorie
	)
	SELECT	kategorien.kKategorie,
			ISNULL(oberKategorie.kKategorie, 0) AS kOberKategorie,
			kategorien.nLevel
	FROM kategorien
	JOIN dbo.tKategorieShop ON kategorien.kKategorie = dbo.tKategorieShop.kKategorie
	LEFT JOIN dbo.tkategorie AS oberKategorie ON kategorien.kOberKategorie = oberKategorie.kKategorie
	WHERE	dbo.tKategorieShop.kShop = @kShop
			AND dbo.tKategorieShop.cInet = 'Y'
)
go

