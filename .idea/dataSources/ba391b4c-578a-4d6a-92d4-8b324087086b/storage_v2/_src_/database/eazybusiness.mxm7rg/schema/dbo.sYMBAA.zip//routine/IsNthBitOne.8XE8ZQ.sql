--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--
-- Prüft, ob ein bestimmtes Bit in der binären Darstellung einer nichtnegativen Ganzzahl 1 ist.
-- @z ist die Ganzzahl, @n beszeichnet das Bit (0-basiert von rechts). Rückgabewert = 0/1.
--
CREATE FUNCTION [dbo].[IsNthBitOne](@z int, @n int) RETURNS tinyint
BEGIN 
RETURN CASE WHEN CAST(@z / POWER(2, @n) AS INT) - CAST(@z / POWER(2, @n + 1) AS INT) * 2 = 1
	THEN 1
	ELSE 0 END
END
go

