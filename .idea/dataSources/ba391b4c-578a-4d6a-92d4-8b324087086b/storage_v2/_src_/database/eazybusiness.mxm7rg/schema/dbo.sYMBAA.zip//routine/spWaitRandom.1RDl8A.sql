--- 
--- spWaitRandom
---

CREATE PROCEDURE dbo.spWaitRandom (@SekundenDelay INT = 5)
AS
BEGIN
	DECLARE @Delay VARCHAR(20);
	SET @Delay = '00:00:' + CAST(CAST(@SekundenDelay * RAND() AS INT) AS VARCHAR) +':' + CAST(CAST(1000*RAND() AS INT) AS VARCHAR);
	WAITFOR DELAY @Delay;
END
go

