CREATE FUNCTION [dbo].[HasStandardLieferant](@kArtikel INT,@nStandard INT)
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Author: Paul
--
-- Gibt 1 zurück wenn der Artikel schon nen Standardlieferanten hat.
-- @nStandard Muß komischweise hier rein, obwohl ich das nicht benutze. Die funktion geht nicht mit einen parameter wenn es um UPDATE geht, SQL SERVER BUG ?
--
RETURNS BIT
AS
BEGIN
    DECLARE @nStandardArtikelCount INT;
    SET @nStandardArtikelCount = 0;


    SELECT @nStandardArtikelCount = count(*) 
    FROM dbo.tLiefArtikel
    WHERE dbo.tLiefArtikel.tArtikel_kArtikel = @kArtikel
    AND dbo.tLiefArtikel.nStandard = 1;


    RETURN(CASE WHEN @nStandardArtikelCount > 1 THEN 1 ELSE 0 END);

END;
go

