CREATE TRIGGER tgr_tgutschriftpos_INSUPDEL
ON dbo.tGutschriftPos
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
	IF(CONTEXT_INFO() IN (0x5117, 0x5118, 0x5119))
	BEGIN
		RETURN;
	END
	ROLLBACK;
	RAISERROR(N'Die Tabelle tgutschriftpos kann nur über die SPs spGutschriftposAendern, spGutschrftposAnlegen und spGutschriftposLoeschen bearbeitet werden.', 15, 1);
END
go

