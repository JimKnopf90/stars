--- 
--- spBestellungEckdatenAktualisieren
---

CREATE PROCEDURE [dbo].[spBestellungEckdatenAktualisieren]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MK
--
@xBestellungen XML = NULL,
@kBestellung INT = NULL,
@nKomplettAusgeliefertNichtBerechnen INT = 0
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN

    -- Verpacken durch Eazyshipping, Raus hier. machen wir später im bulk
    IF(CONTEXT_INFO() = 0x5087 OR CONTEXT_INFO() = 0x5052 OR CONTEXT_INFO() = 0x5068)
	   RETURN;

    IF(object_id('tempdb..#spBestellungEckdaten') IS NOT NULL)
    BEGIN
		DROP TABLE #spBestellungEckdaten;
    END
    CREATE TABLE #spBestellungEckdaten (kBestellung INT, fWert DECIMAL(28,14), fZahlung DECIMAL(28,14), 
																fGutschrift DECIMAL(28,14), fGutschein DECIMAL(28,14), 
																fFaktor DECIMAL(28,14), cWaehrung VARCHAR(20));
	DECLARE @fRunden DECIMAL(28,14);
	SET @fRunden = 0.009;
	IF(ISNULL((SELECT TOP(1) dbo.teinstellungen.nRunden FROM dbo.teinstellungen), 0) > 0)
	BEGIN
		SET @fRunden = 0.059;
	END
	IF(@xBestellungen IS NOT NULL)
	BEGIN
		INSERT INTO #spBestellungEckdaten(kBestellung)
			SELECT ParamValues.ID.value('.','VARCHAR(20)') AS kBestellung
			FROM @xBestellungen.nodes('/Bestellung/kBestellung') AS ParamValues(ID);
	END
	ELSE IF(@kBestellung IS NOT NULL)
	BEGIN
		INSERT INTO #spBestellungEckdaten(kBestellung)
			SELECT @kBestellung;
	END;
	--
	-- BestellungEckdaten berechnen
	--
	UPDATE #spBestellungEckdaten
		SET fWert = ISNULL(Bestellpos.fWert,0.0),
			fZahlung = ISNULL(Zahlung.fZahlung,0.0),
			fGutschrift = ISNULL(Gutschrift.fGutschrift,0.0),
			fGutschein = ISNULL(dbo.tbestellung.fGutschein,0.0),
			fFaktor = ISNULL(dbo.tbestellung.fFaktor, 1.0), 
			cWaehrung = dbo.tbestellung.cWaehrung
		FROM #spBestellungEckdaten
		LEFT JOIN 
		(
			SELECT dbo.tbestellpos.tBestellung_kBestellung AS kBestellung,
				ROUND(SUM((ISNULL(dbo.tbestellpos.fVKPreis,0.0) * ISNULL(dbo.tbestellpos.nAnzahl,0.0)) - 
					((dbo.tbestellpos.fVKPreis * dbo.tbestellpos.nAnzahl) * dbo.tbestellpos.fRabatt)/100.0),4) AS fWert
				FROM dbo.tbestellpos 
				GROUP BY dbo.tbestellpos.tBestellung_kBestellung
		) AS Bestellpos ON Bestellpos.kBestellung = #spBestellungEckdaten.kBestellung
		LEFT JOIN 
		(
			SELECT dbo.tZahlung.kBestellung, 
				ROUND(SUM(ISNULL(dbo.tZahlung.fBetrag,0.0)),4) AS fZahlung
				FROM dbo.tZahlung 
				GROUP BY dbo.tZahlung.kBestellung
		) AS Zahlung ON Zahlung.kBestellung = #spBestellungEckdaten.kBestellung
		LEFT JOIN
		(
			SELECT dbo.trechnung.tBestellung_kBestellung AS kBestellung,
				ROUND(SUM(ISNULL(dbo.tgutschriftpos.fVKPreis,0.0) * ISNULL(dbo.tgutschriftpos.nAnzahl,0.0) * (100 - ISNULL(dbo.tgutschriftpos.fRabatt,0.0))/100),4) AS fGutschrift
				FROM dbo.tgutschriftpos 
				JOIN dbo.tgutschrift ON dbo.tgutschriftpos.tGutschrift_kGutschrift = dbo.tgutschrift.kGutschrift
				JOIN dbo.trechnung ON dbo.trechnung.kRechnung = dbo.tgutschrift.kRechnung
				GROUP BY dbo.trechnung.tBestellung_kBestellung
		) AS Gutschrift ON Gutschrift.kBestellung = #spBestellungEckdaten.kBestellung
		JOIN dbo.tbestellung ON dbo.tbestellung.kBestellung = #spBestellungEckdaten.kBestellung;
	DELETE FROM #spBestellungEckdaten WHERE #spBestellungEckdaten.fWert IS NULL;
	
	-- Daten in die Tabelle schreiben
	UPDATE dbo.tBestellungEckDaten
		SET fWert = #spBestellungEckdaten.fWert,
	    fZahlung = #spBestellungEckdaten.fZahlung,
	    fGutschrift = #spBestellungEckdaten.fGutschrift,
	    fGutschein = #spBestellungEckdaten.fGutschein,
	    fFaktor = #spBestellungEckdaten.fFaktor,
	    cWaehrung = #spBestellungEckdaten.cWaehrung 
		FROM #spBestellungEckdaten 	
		JOIN dbo.tBestellungEckDaten ON #spBestellungEckdaten.kBestellung = dbo.tBestellungEckDaten.kBestellung;
		
	INSERT INTO dbo.tBestellungEckDaten(kBestellung, fWert, fZahlung, fGutschrift, fGutschein, fFaktor, cWaehrung)
		SELECT	#spBestellungEckdaten.kBestellung,
				ISNULL(#spBestellungEckdaten.fWert, 0.0),
				ISNULL(#spBestellungEckdaten.fZahlung, 0.0),
				ISNULL(#spBestellungEckdaten.fGutschrift, 0.0),
				ISNULL(#spBestellungEckdaten.fGutschein, 0.0),
				ISNULL(#spBestellungEckdaten.fFaktor, 0.0),
				#spBestellungEckdaten.cWaehrung 
			FROM #spBestellungEckdaten
			WHERE #spBestellungEckdaten.kBestellung NOT IN (SELECT dbo.tBestellungEckDaten.kBestellung FROM dbo.tBestellungEckDaten)
			AND #spBestellungEckdaten.kBestellung IS NOT NULL;
	--
	-- nKomplettAusgeliefert berechnen ( Wenn schon Positionen angelegt sind
	--
	IF(OBJECT_ID('tempdb..#UpdateBestellung') IS NOT NULL)
	BEGIN
		DROP TABLE #UpdateBestellung;
	END
	CREATE TABLE #UpdateBestellung (kBestellung INT, nKomplettAusgeliefert INT, dBezahlt DATETIME, kZahlungsart INT);
	INSERT INTO #UpdateBestellung(kBestellung, nKomplettAusgeliefert, dBezahlt, kZahlungsart)
		SELECT dbo.tBestellung.kBestellung,
			CASE WHEN dbo.tbestellung.nKomplettAusgeliefert < 2
				THEN 
					CASE WHEN dbo.tbestellung.cType = 'A' OR dbo.tbestellpos.kBestellpos IS NULL
						THEN 0
						ELSE ISNULL(StatusAuslieferung.nKomplettAusgeliefert,1)
					END
				ELSE dbo.tbestellung.nKomplettAusgeliefert
			END,
			
			CASE WHEN (#spBestellungEckdaten.fWert - #spBestellungEckdaten.fZahlung - @fRunden - #spBestellungEckdaten.fGutschrift + #spBestellungEckdaten.fGutschein) > 0
				THEN NULL
				ELSE ISNULL(Zahlung.dDatum, ISNULL(dbo.tbestellung.dErstellt, GETDATE()))
			END,
			CASE WHEN ISNULL(Zahlung.kZahlungsart, 0) = 0 THEN dbo.tbestellung.kZahlungsArt ELSE Zahlung.kZahlungsart END AS kZahlungsart
		FROM dbo.tbestellung 
		LEFT JOIN dbo.tbestellpos ON dbo.tbestellpos.tBestellung_kBestellung = dbo.tbestellung.kBestellung
		LEFT JOIN 
		(
			SELECT dbo.tReserviert.kBestellung,
				CASE WHEN SUM(dbo.tReserviert.fAnzahl) = 0
					THEN 1
					ELSE 0
				END AS nKomplettAusgeliefert
				FROM dbo.tReserviert 
				GROUP BY dbo.tReserviert.kBestellung
		) AS StatusAuslieferung ON dbo.tbestellung.kBestellung = StatusAuslieferung.kBestellung
		JOIN #spBestellungEckdaten ON #spBestellungEckdaten.kBestellung = dbo.tbestellung.kBestellung
		LEFT JOIN
		(
			SELECT	dbo.tZahlung.kBestellung,
					ISNULL(MAX(dbo.tZahlung.kZahlungsart), 0) AS kZahlungsart,
					MAX(dbo.tZahlung.dDatum) AS dDatum
			FROM dbo.tZahlung
			GROUP BY dbo.tZahlung.kBestellung
		) AS Zahlung ON Zahlung.kBestellung = #spBestellungEckdaten.kBestellung;
	--
	-- Hack für bis zur 1.0. Danach umschreiben!
	--
	DECLARE @ContextInfoOld VARBINARY(128);
	SET @ContextInfoOld = ISNULL(CONTEXT_INFO(),0x0);
	SET CONTEXT_INFO 0x5104;
	UPDATE dbo.tbestellung
		    SET dBezahlt = #UpdateBestellung.dBezahlt,
			    nKomplettausgeliefert = #UpdateBestellung.nKomplettAusgeliefert,
				cInet = CASE WHEN cInet <> 'Y' AND dbo.tbestellung.dBezahlt <> #UpdateBestellung.dBezahlt THEN 'Y' ELSE dbo.tbestellung.cInet END			   
			    FROM dbo.tBestellung 
			    JOIN #UpdateBestellung ON dbo.tBestellung.kBestellung = #UpdateBestellung.kBestellung
	DELETE dbo.tReserviert 
		FROM dbo.tReserviert 
		JOIN #UpdateBestellung ON #UpdateBestellung.kBestellung = dbo.tReserviert.kBestellung
		WHERE #UpdateBestellung.nKomplettAusgeliefert = 2;


	DECLARE @typeArtikel AS TYPE_spUpdateLagerbestand;

	INSERT INTO @typeArtikel (kArtikel)
	SELECT kArtikel 
	FROM dbo.tReserviert 
	JOIN #UpdateBestellung ON #UpdateBestellung.kBestellung = dbo.tReserviert.kBestellung
	WHERE #UpdateBestellung.nKomplettAusgeliefert = 2;

	EXEC dbo.spUpdateLagerbestand @typeArtikel;	

	SET CONTEXT_INFO  @ContextInfoOld;

	--
	-- Weiterer Hack bis der Kram hier drüber über die spBestellungÄndern läuft. Dann kann das hier raus.
	--
	IF(EXISTS (SELECT * FROM dbo.tWarenLagerOptionen
					    JOIN dbo.tWarenlager ON dbo.tWarenlager.kWarenLager = dbo.tWarenLagerOptionen.kWarenLager
						WHERE dbo.tWarenlager.nAktiv = 1
						AND dbo.tWarenlager.nLagerplatzVerwaltung = 1))
	BEGIN

		DECLARE @kLHMToCheck INT = 0;

		SELECT TOP 1 @kLHMToCheck = tLHM.kLHM
		FROM dbo.tLHM
		JOIN dbo.tLHMStatus ON dbo.tLHMStatus.kLHMStatus = dbo.tLHM.kLHMStatus
		JOIN #UpdateBestellung ON #UpdateBestellung.kBestellung = dbo.tLHMStatus.kBestellung
		WHERE dbo.tLHMStatus.nStatus = 20
		AND #UpdateBestellung.dBezahlt IS NOT NULL;

		IF(@kLHMToCheck > 0)
		BEGIN
			EXEC dbo.spVersandBoxPruefen @kLHM = @kLHMToCheck, @nAusDemWE = 1;
		END;
	END;

END;
go

