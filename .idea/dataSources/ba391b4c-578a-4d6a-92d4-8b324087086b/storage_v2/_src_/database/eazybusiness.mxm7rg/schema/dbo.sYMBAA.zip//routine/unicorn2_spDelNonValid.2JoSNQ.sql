
    CREATE PROCEDURE unicorn2_spDelNonValid @kId INT
    AS
        DECLARE @kIdLocal INT
    		SET @kIdLocal = @kId
    	
        SET DEADLOCK_PRIORITY LOW		
        DELETE FROM unicorn2_tChangeCache
        WHERE kId = @kIdLocal;
    go

