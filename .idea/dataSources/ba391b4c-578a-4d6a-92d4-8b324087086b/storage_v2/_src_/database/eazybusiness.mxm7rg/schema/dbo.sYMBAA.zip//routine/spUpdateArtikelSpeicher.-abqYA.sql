--- 
--- spUpdateArtikelSpeicher
---

CREATE PROCEDURE [dbo].[spUpdateArtikelSpeicher]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: PN
--
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN

TRUNCATE TABLE dbo.tArtikelSpeicher;

---
--- Beachten: Die Artikel IDs werden getrimt. 
---
;WITH Alle AS 
(
		  SELECT LTRIM(RTRIM(tArtikel.cArtNr)) AS Nummer, tArtikel.kArtikel, 0 AS Art , CASE WHEN dbo.tOptions.cValue = '1' THEN 1 ELSE 0 END AS nAktiv
			 FROM tArtikel 
			 LEFT JOIN dbo.tOptions WITH(NOLOCK) ON dbo.tOptions.cKey = 'ArtikelEigenschaft Artikelnummer'
			 WHERE tArtikel.cArtNr IS NOT NULL 
			 AND tArtikel.cArtNr <> '' 
							
    UNION ALL
		  SELECT LTRIM(RTRIM(tArtikel.cBarcode)) AS Nummer, tArtikel.kArtikel, 1 AS Art , CASE WHEN dbo.tOptions.cValue = '1' THEN 1 ELSE 0 END AS nAktiv
			 FROM tArtikel 
			 LEFT JOIN dbo.tOptions WITH(NOLOCK) ON dbo.tOptions.cKey = 'ArtikelEigenschaft EAN'
			 WHERE tArtikel.cBarcode IS NOT NULL 
				AND tArtikel.cBarcode <> '' 
    UNION ALL
		  SELECT  LTRIM(RTRIM(tArtikel.cHAN)) AS Nummer, tArtikel.kArtikel, 2 AS Art , CASE WHEN dbo.tOptions.cValue = '1' THEN 1 ELSE 0 END AS nAktiv
			 FROM tArtikel 
			 LEFT JOIN dbo.tOptions WITH(NOLOCK) ON dbo.tOptions.cKey = 'ArtikelEigenschaft HAN'
			 WHERE tArtikel.cHAN IS NOT NULL 
				AND tArtikel.cHAN <> '' 
    UNION ALL
		  SELECT  LTRIM(RTRIM(tArtikel.cUPC)) AS Nummer, tArtikel.kArtikel, 3 AS Art , CASE WHEN dbo.tOptions.cValue = '1' THEN 1 ELSE 0 END AS nAktiv
			 FROM tArtikel 
			 LEFT JOIN dbo.tOptions WITH(NOLOCK) ON dbo.tOptions.cKey = 'ArtikelEigenschaft UPC'
			 WHERE tArtikel.cUPC IS NOT NULL 
				AND tArtikel.cUPC <> '' 
    UNION ALL
		  SELECT  LTRIM(RTRIM(tArtikel.cISBN)) AS Nummer, tArtikel.kArtikel, 4 AS Art , CASE WHEN dbo.tOptions.cValue = '1' THEN 1 ELSE 0 END AS nAktiv
			 FROM tArtikel 
			 LEFT JOIN dbo.tOptions WITH(NOLOCK) ON dbo.tOptions.cKey = 'ArtikelEigenschaft ISBN'
			 WHERE tArtikel.cISBN IS NOT NULL 
				AND tArtikel.cISBN <> '' 
    UNION ALL
		  SELECT LTRIM(RTRIM(tGebinde.cEAN)) AS Nummer, dbo.tGebinde.kArtikel, 6 AS Art , CASE WHEN dbo.tOptions.cValue = '1' THEN 1 ELSE 0 END AS nAktiv
			 FROM dbo.tGebinde 
			 JOIN tArtikel ON tArtikel.kArtikel = dbo.tGebinde.kArtikel 
			 LEFT JOIN dbo.tOptions WITH(NOLOCK) ON dbo.tOptions.cKey = 'ArtikelEigenschaft GebindeEAN'
			 WHERE dbo.tGebinde.cEAN IS NOT NULL 
				AND dbo.tGebinde.cEAN <> '' 
    UNION ALL
		  SELECT LTRIM(RTRIM(tGebinde.cUPC)) AS Nummer, dbo.tGebinde.kArtikel, 9 AS Art , CASE WHEN dbo.tOptions.cValue = '1' THEN 1 ELSE 0 END AS nAktiv
			 FROM dbo.tGebinde 
			 JOIN tArtikel ON tArtikel.kArtikel = dbo.tGebinde.kArtikel 
			 LEFT JOIN dbo.tOptions WITH(NOLOCK) ON dbo.tOptions.cKey = 'ArtikelEigenschaft GebindeUPC'
			 WHERE dbo.tGebinde.cUPC IS NOT NULL 
				AND dbo.tGebinde.cUPC <> '' 
    UNION ALL
		  SELECT  LTRIM(RTRIM(tArtikel.cAmazonFNSKU)) AS Nummer, tArtikel.kArtikel, 10 AS Art , CASE WHEN dbo.tOptions.cValue = '1' THEN 1 ELSE 0 END AS nAktiv
			 FROM tArtikel 
			 LEFT JOIN dbo.tOptions WITH(NOLOCK) ON dbo.tOptions.cKey = 'ArtikelEigenschaft FNSKU'
			 WHERE tArtikel.cAmazonFNSKU IS NOT NULL 
				AND tArtikel.cAmazonFNSKU <> '' 

	UNION ALL
		  SELECT  LTRIM(RTRIM(tArtikel.cJfpid)) AS Nummer, tArtikel.kArtikel, 11 AS Art , CASE WHEN dbo.tOptions.cValue = '1' THEN 1 ELSE 0 END AS nAktiv
			 FROM tArtikel 
			 LEFT JOIN dbo.tOptions WITH(NOLOCK) ON dbo.tOptions.cKey = 'ArtikelEigenschaft JTLFPID'
			 WHERE tArtikel.cJfpid IS NOT NULL 
				AND tArtikel.cJfpid <> '' 

    UNION ALL
		  SELECT  LTRIM(RTRIM(tArtikel.cASIN)) AS Nummer, tArtikel.kArtikel, 7 AS Art , CASE WHEN dbo.tOptions.cValue = '1' THEN 1 ELSE 0 END AS nAktiv
			 FROM tArtikel 
			 LEFT JOIN dbo.tOptions WITH(NOLOCK) ON dbo.tOptions.cKey = 'ArtikelEigenschaft ASIN'
			 WHERE tArtikel.cASIN IS NOT NULL 
				AND tArtikel.cASIN <> '' 
    UNION ALL
		  SELECT LTRIM(RTRIM(tLiefArtikel.cLiefArtNr)) AS Nummer, dbo.tLiefArtikel.tArtikel_kArtikel, 8 AS Art , CASE WHEN dbo.tOptions.cValue = '1' THEN 1 ELSE 0 END AS nAktiv
			 FROM dbo.tLiefArtikel
			 JOIN tArtikel ON tArtikel.kArtikel = dbo.tLiefArtikel.tArtikel_kArtikel 
			 LEFT JOIN dbo.tOptions WITH(NOLOCK) ON dbo.tOptions.cKey = 'ArtikelEigenschaft LieferantenArtNummer'
		  WHERE dbo.tLiefArtikel.cLiefArtNr IS NOT NULL 
			 AND dbo.tLiefArtikel.cLiefArtNr <> '' 

    UNION ALL

    SELECT LTRIM(RTRIM(dbo.tArtikelBeschreibung.cName)) AS Nummer, dbo.tArtikelBeschreibung.kArtikel, 5 AS Art , CASE WHEN dbo.tOptions.cValue = '1' THEN 1 ELSE 0 END AS nAktiv
			 FROM dbo.tArtikelBeschreibung
			 JOIN tArtikel ON tArtikel.kArtikel = dbo.tArtikelBeschreibung.kArtikel 
			 LEFT JOIN dbo.tOptions WITH(NOLOCK) ON dbo.tOptions.cKey = 'ArtikelEigenschaft Artikelname'
			 JOIN tSpracheUsed ON dbo.tArtikelBeschreibung.kSprache = tSpracheUsed.kSprache AND tSpracheUsed.nStandard = 1 
		  WHERE dbo.tArtikelBeschreibung.cName IS NOT NULL 
		  AND dbo.tArtikelBeschreibung.kPlattform = 1
	       AND dbo.tArtikelBeschreibung.cName <> '' 

)
INSERT INTO dbo.tArtikelSpeicher WITH(ROWLOCK) (kArtikel,cNummer,nID,nAktiv)
    SELECT DISTINCT Alle.kArtikel, Alle.Nummer, Alle.Art ,Alle.nAktiv
		  FROM Alle

END;
go

