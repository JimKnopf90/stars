
    CREATE PROCEDURE unicorn2_spDelChanged @kWawiId INT
    AS
        DECLARE @kWawiIdLocal INT
    		SET @kWawiIdLocal = @kWawiId
    	
        SET DEADLOCK_PRIORITY LOW		
        DELETE FROM unicorn2_tChangeCache
        WHERE kWawiId = @kWawiIdLocal;
    go

