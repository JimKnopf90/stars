--- 
--- spUpdateLagerbestand
---

CREATE PROCEDURE [dbo].[spUpdateLagerbestand]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MK/MP
--
@Artikel TYPE_spUpdateLagerbestand READONLY
AS
SET NOCOUNT ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET ANSI_WARNINGS ON;
SET ANSI_PADDING ON;
BEGIN

     -- Verpacken durch Eazyshipping, Raus hier. machen wir später im bulk
     IF(CONTEXT_INFO() = 0x5087 OR CONTEXT_INFO() = 0x5052)
	   RETURN;

	IF(object_id('tempdb..#spUpdateLagerbestandArtikelliste') IS NOT NULL)
	BEGIN
		DROP TABLE #spUpdateLagerbestandArtikelliste
	END
	CREATE TABLE #spUpdateLagerbestandArtikelliste (
		kArtikel INT
		)
	INSERT INTO #spUpdateLagerbestandArtikelliste(kArtikel)
	SELECT kArtikel FROM @Artikel;

	IF((SELECT COUNT(1) FROM #spUpdateLagerbestandArtikelliste) = 0)
	BEGIN
		RETURN
	END
     --
    -- Artikel hinzufügen wenn noch kein Eintrag vorhanden ist
    --
    INSERT INTO dbo.tlagerbestand WITH(ROWLOCK) (kArtikel, fLagerbestand, fVerfuegbar, fZulauf, fAufEinkaufsliste, fInAuftraegen, nLagerAktiv, nArtikelTyp, nTeilbar, nLagerkleinerNull)
    (
	   SELECT TempTable.kArtikel, 0, 0, 0, 0, 0, 
			CASE WHEN dbo.tArtikel.cLagerAktiv = 'Y'
				THEN 1
				ELSE 0
			END,
			CASE WHEN dbo.tArtikel.kStueckliste > 0
					THEN 1
				WHEN dbo.tArtikel.nIstVater > 0
					THEN 2
				WHEN dbo.tArtikel.cLagerVariation = 'Y'
					THEN 3
				ELSE 0
			END,
			CASE WHEN dbo.tArtikel.cTeilbar = 'Y'
				THEN 1
				ELSE 0
			END,
			CASE WHEN dbo.tArtikel.cLagerKleinerNull = 'Y'
				THEN 1
				ELSE 0
			END
		   FROM #spUpdateLagerbestandArtikelliste AS TempTable
		   JOIN dbo.tArtikel ON dbo.tArtikel.kArtikel = TempTable.kArtikel
		   WHERE TempTable.kArtikel NOT IN (SELECT kArtikel FROM dbo.tlagerbestand)
    )
    --
    -- Daten für die Aktualisierung aufbereiten
    -- nNestingDeep: 0 (normaler Artikel), 1 (nIstVater > 0), 2 - n (Stückliste)
    --
	IF(OBJECT_ID('tempdb..#ItemsForUpdate') IS NOT NULL)
	BEGIN
		DROP TABLE #ItemsForUpdate;
	END
    CREATE TABLE #ItemsForUpdate (
		kArtikel INT NOT NULL, 
		nIstVater TINYINT, 
		cLagerVariation CHAR(1), 
		cLagerAktiv CHAR(1), 
		kStueckliste INT, 
		kVaterArtikel BIGINT, 
		cTeilbar CHAR(1), 
		cLagerKleinerNull CHAR(1), 
		nNestingDeep TINYINT NOT NULL
		);
    INSERT INTO #ItemsForUpdate
	   SELECT TempTable.kArtikel, dbo.tartikel.nIstVater, dbo.tartikel.cLagerVariation, dbo.tartikel.cLagerAktiv, dbo.tartikel.kStueckliste, dbo.tartikel.kVaterArtikel, dbo.tartikel.cTeilbar, dbo.tartikel.cLagerKleinerNull,
		  --
		  -- Ermittlung der Verschachtelungstiefe
		  -- 
			 CASE 
				WHEN dbo.tartikel.nIstVater > 0
				    THEN 1
				ELSE
				    CASE WHEN dbo.tartikel.kStueckliste > 0
					   THEN 2
					   ELSE 0
				    END
			 END AS nNestingDeep
	   FROM #spUpdateLagerbestandArtikelliste AS TempTable		  
	   JOIN dbo.tartikel WITH(NOLOCK) ON TempTable.kArtikel = dbo.tartikel.kArtikel
	   GROUP BY TempTable.kArtikel, dbo.tartikel.nIstVater, dbo.tartikel.cLagerVariation, dbo.tartikel.cLagerAktiv, dbo.tartikel.kStueckliste, dbo.tartikel.kVaterArtikel, dbo.tartikel.cTeilbar, dbo.tartikel.cLagerKleinerNull
    --
    -- Alle Stücklisten zu Komponenten ermitteln
    --
    IF((SELECT MIN(ISNULL(nNestingDeep,-1)) FROM #ItemsForUpdate) = 0)
    BEGIN
	   INSERT INTO #ItemsForUpdate (kArtikel, nIstVater, cLagerVariation, cLagerAktiv, kStueckliste, kVaterArtikel, cTeilbar, cLagerKleinerNull, nNestingDeep)
		  SELECT dbo.tartikel.kArtikel, dbo.tartikel.nIstVater, dbo.tartikel.cLagerVariation, dbo.tartikel.cLagerAktiv, dbo.tartikel.kStueckliste, dbo.tartikel.kVaterArtikel, dbo.tartikel.cTeilbar, dbo.tartikel.cLagerKleinerNull,
				2 AS nNestingDeep
			 FROM #ItemsForUpdate AS TempTable		  
			 JOIN dbo.tStueckliste WITH(NOLOCK) ON TempTable.kArtikel = dbo.tStueckliste.kArtikel
			 JOIN dbo.tartikel WITH(NOLOCK) ON dbo.tStueckliste.kStueckliste = dbo.tartikel.kStueckliste
			 GROUP BY dbo.tartikel.kArtikel, dbo.tartikel.nIstVater, dbo.tartikel.cLagerVariation, dbo.tartikel.cLagerAktiv, dbo.tartikel.kStueckliste, dbo.tartikel.kVaterArtikel, dbo.tartikel.cTeilbar, dbo.tartikel.cLagerKleinerNull
    END

    --
    -- Alle Varkombivaterartikel ermitteln
    --
    IF((SELECT MIN(ISNULL(kVaterArtikel,-1)) FROM #ItemsForUpdate) > 0)
    BEGIN	   
	   INSERT INTO #ItemsForUpdate (kArtikel, nIstVater, cLagerVariation, cLagerAktiv, kStueckliste, kVaterArtikel, cTeilbar, cLagerKleinerNull, nNestingDeep)
		  SELECT dbo.tartikel.kArtikel, dbo.tartikel.nIstVater, dbo.tartikel.cLagerVariation, dbo.tartikel.cLagerAktiv, dbo.tartikel.kStueckliste, dbo.tartikel.kVaterArtikel, dbo.tartikel.cTeilbar, dbo.tartikel.cLagerKleinerNull,
	   			1 AS nNestingDeep
		  FROM #ItemsForUpdate AS TempTable		  
		  JOIN dbo.tartikel WITH(NOLOCK) ON TempTable.kVaterArtikel = dbo.tartikel.kArtikel
    END
    --
    -- Aktualisierung des Lagerbestands für normale, lagerführende Artikel
    --
    IF((SELECT MIN(ISNULL(nNestingDeep,-1)) FROM #ItemsForUpdate) = 0)
    BEGIN	 	
	   UPDATE dbo.tlagerbestand WITH(ROWLOCK) SET
			  dbo.tlagerbestand.fLagerbestand = ISNULL(Lagerbestand.fAnzahl, 0.0) + ISNULL(LiefArtikelBestaende.fAnzahl, 0.0),
			  dbo.tlagerbestand.fVerfuegbar = CASE WHEN ISNULL(U1.cLagerAktiv, 'Y') = 'Y' THEN ISNULL(Lagerbestand.fAnzahl, 0.0) + ISNULL(LiefArtikelBestaende.fAnzahl, 0.0) - ISNULL(Reservierungen.fInAuftraegen, 0.0) - ISNULL(Lagerbestand.fVerfuegbarGesperrt, 0.0) ELSE 0.0 END,
			  dbo.tlagerbestand.fVerfuegbarGesperrt = ISNULL(Lagerbestand.fVerfuegbarGesperrt, 0.0),
			  dbo.tlagerbestand.fZulauf = ISNULL(Zulauf.fZulauf, 0.0),
			  dbo.tlagerbestand.dLieferdatum = Zulauf.dLieferdatum,
			  dbo.tlagerbestand.fAufEinkaufsliste = ISNULL(ArtikelEinkaufsliste.fAnzahl, 0.0),
			  dbo.tlagerbestand.fLagerbestandEigen = ISNULL(Lagerbestand.fAnzahl, 0.0),
			  dbo.tlagerbestand.fInAuftraegen = ISNULL(Reservierungen.fInAuftraegen,0.0),
			  dbo.tlagerbestand.nLagerAktiv = CASE WHEN U1.cLagerAktiv = 'Y'
												THEN 1
												ELSE 0
												END,
			  dbo.tlagerbestand.nArtikelTyp = CASE WHEN U1.kStueckliste > 0
														THEN 1
													WHEN U1.nIstVater > 0
														THEN 2
													WHEN U1.cLagerVariation = 'Y'
														THEN 3
													ELSE 0
												END,
			  dbo.tlagerbestand.nTeilbar = CASE WHEN U1.cTeilbar = 'Y'
												THEN 1
												ELSE 0
												END,
			 dbo.tlagerbestand.nLagerKleinerNull = CASE WHEN U1.cLagerKleinerNull = 'Y'
														THEN 1
														ELSE 0
													END
		   FROM dbo.tlagerbestand WITH(ROWLOCK)
		   JOIN #ItemsForUpdate AS U1 ON dbo.tlagerbestand.kArtikel = U1.kArtikel 
			  AND U1.nNestingDeep = 0
		   LEFT JOIN
		   (
				SELECT	dbo.tWarenLagerEingang.kArtikel, 
						SUM(dbo.tWarenLagerEingang.fAnzahlAktuell) AS fAnzahl, 
						SUM(CASE WHEN dbo.tWarenLagerPlatz.nGesperrt = 1
									THEN dbo.tWarenLagerEingang.fAnzahlAktuell
									ELSE 0.0
							END) AS fVerfuegbarGesperrt																				
					FROM dbo.tWarenLagerEingang 
					JOIN dbo.tWarenLagerPlatz ON dbo.tWarenLagerEingang.kWarenLagerPlatz = dbo.tWarenLagerPlatz.kWarenLagerPlatz
					GROUP BY kArtikel
		   ) AS Lagerbestand ON U1.kArtikel = Lagerbestand.kArtikel
		   LEFT JOIN
		   (
			  SELECT dbo.tliefartikel.tArtikel_kArtikel,
						SUM(dbo.tliefartikel.fLagerbestand) AS fAnzahl					
				  FROM dbo.tliefartikel WITH(NOLOCK)
				  WHERE dbo.tliefartikel.nLagerBeachten=1
				  GROUP BY dbo.tliefartikel.tArtikel_kArtikel
		   ) AS LiefArtikelBestaende ON U1.kArtikel = LiefArtikelBestaende.tArtikel_kArtikel
		   LEFT JOIN
		   (
			  SELECT dbo.tReserviert.kArtikel, 
					 SUM(dbo.tReserviert.fAnzahl) AS fInAuftraegen
				  FROM dbo.tReserviert WITH(NOLOCK)
				  GROUP BY dbo.tReserviert.kArtikel
		   ) AS Reservierungen ON U1.kArtikel = Reservierungen.kArtikel
		   LEFT JOIN
		   (
			  SELECT dbo.tLieferantenBestellungPos.kArtikel, 
					SUM(CASE WHEN  ISNULL((dbo.tLieferantenBestellungPos.fMenge - dbo.tLieferantenBestellungPos.fMengeGeliefert), 0.0) > 0.0 
								THEN  ISNULL((dbo.tLieferantenBestellungPos.fMenge - dbo.tLieferantenBestellungPos.fMengeGeliefert), 0.0)
								ELSE 0.0 
							END) AS fZulauf,
						MIN(ISNULL(dbo.tLieferantenBestellungPos.dLieferdatum, CAST('01.01.1900' AS DATETIME))) AS dLieferdatum
				  FROM dbo.tLieferantenBestellungPos WITH(NOLOCK)
				  JOIN dbo.tLieferantenBestellung WITH(NOLOCK) ON dbo.tLieferantenBestellungPos.kLieferantenBestellung = dbo.tLieferantenBestellung.kLieferantenBestellung
				  LEFT JOIN
				  (
					 SELECT dbo.tWarenlagerEingang.kArtikel, dbo.tWarenlagerEingang.kLieferantenBestellungPos, SUM(dbo.tWarenlagerEingang.fAnzahl) AS fAnzahl
					 FROM dbo.tWarenlagerEingang WITH(NOLOCK)
					 GROUP BY dbo.tWarenlagerEingang.kArtikel, dbo.tWarenlagerEingang.kLieferantenBestellungPos
				  ) AS WarenlagerEingang ON dbo.tLieferantenBestellungPos.kLieferantenBestellungPos = WarenlagerEingang.kLieferantenBestellungPos
					 AND dbo.tLieferantenBestellungPos.kArtikel = WarenlagerEingang.kArtikel							 
					 -- Nur InBearbeitung, Teilgeliefert und Ueberfällig werden berücksichtigt		
				  WHERE dbo.tLieferantenBestellung.nStatus >= 20 -- Teilgeliefert
							AND dbo.tLieferantenBestellung.nStatus <= 50 -- Ueberfällig
							AND (dbo.tLieferantenBestellungPos.fMenge - dbo.tLieferantenBestellungPos.fMengeGeliefert) > 0.0
				  GROUP BY dbo.tLieferantenBestellungPos.kArtikel
		   ) AS Zulauf ON U1.kArtikel = Zulauf.kArtikel
		   LEFT JOIN 
		   (
			  SELECT dbo.tArtikelEinkaufsliste.kArtikel, 
					SUM(ISNULL(dbo.tArtikelEinkaufsliste.fAnzahl, 0.0)) AS fAnzahl
				  FROM dbo.tArtikelEinkaufsliste WITH(NOLOCK)
				  GROUP BY dbo.tArtikelEinkaufsliste.kArtikel
		   ) AS ArtikelEinkaufsliste ON U1.kArtikel = ArtikelEinkaufsliste.kArtikel				
		   WHERE U1.cLagerVariation != 'Y'
    END
	--
	-- fInAufträgen Aktualisieren für nicht Lager Artikel
	--
	UPDATE dbo.tlagerbestand
			SET fInAuftraegen = Reserviert.Anzahl
		FROM dbo.tlagerbestand 
		JOIN #ItemsForUpdate ON dbo.tlagerbestand.kArtikel = #ItemsForUpdate.kArtikel
		JOIN (SELECT kArtikel, SUM(fAnzahl) AS Anzahl
				FROM tReserviert 
				GROUP BY kArtikel
		) AS Reserviert ON Reserviert.kArtikel = #ItemsForUpdate.kArtikel
		WHERE dbo.tlagerbestand.nLagerAktiv = 0;
	    
    --
    -- Aktualisierung des Lagerbestands für Stücklisten 
    -- Der Lagerbestand wird aus den Komponenten ermittelt
    --
    IF((SELECT COUNT(ISNULL(nNestingDeep,-1)) FROM #ItemsForUpdate WHERE nNestingDeep = 2) > 0)
    BEGIN
		UPDATE dbo.tlagerbestand WITH(ROWLOCK) 
				SET dbo.tlagerbestand.fLagerbestand = Lagerbestand.fLagerbestand,
				dbo.tlagerbestand.fVerfuegbar = Lagerbestand.fVerfuegbar,
				dbo.tlagerbestand.fInAuftraegen = ISNULL(Reserviert.fInAuftraegen, 0.0),
				dbo.tlagerbestand.fVerfuegbarGesperrt = Lagerbestand.fVerfuegbarGesperrt,
				dbo.tlagerbestand.fZulauf = Lagerbestand.fZulauf,
				dbo.tlagerbestand.fAufEinkaufsliste = Lagerbestand.fAufEinkaufsliste,
				dbo.tlagerbestand.dLieferdatum = Lagerbestand.dLieferdatum,
				dbo.tlagerbestand.fLagerbestandEigen = Lagerbestand.fLagerbestandEigen	
			FROM dbo.tlagerbestand WITH(ROWLOCK)
			JOIN #ItemsForUpdate AS U1 ON dbo.tlagerbestand.kArtikel = U1.kArtikel 
				AND U1.nNestingDeep = 2
			LEFT JOIN 
			(
				SELECT dbo.tReserviert.kArtikel AS kArtikel,
						SUM(dbo.tReserviert.fAnzahl) AS fInAuftraegen 
					FROM dbo.tReserviert 
					GROUP BY dbo.tReserviert.kArtikel
			) AS Reserviert ON dbo.tlagerbestand.kArtikel = Reserviert.kArtikel
			JOIN dbo.vLagerbestandStueckliste AS Lagerbestand ON U1.kStueckliste = Lagerbestand.kStueckliste
			WHERE U1.kStueckliste > 0 AND U1.cLagerVariation != 'Y'
	END
	 --
    --  Aktualisierung des Lagerbestands für Vaterartikel (nIstVater > 0)
    --
    IF((SELECT COUNT(ISNULL(nNestingDeep,-1)) FROM #ItemsForUpdate WHERE nNestingDeep = 1) > 0)
    BEGIN
    UPDATE dbo.tlagerbestand WITH(ROWLOCK) SET
		  dbo.tlagerbestand.fLagerbestand = ISNULL(Bestaende.Lagerbestand, 0.0),
		  dbo.tlagerbestand.fVerfuegbar = ISNULL(Bestaende.LagerbestandVerfuegbar, 0.0),
		  dbo.tlagerbestand.fVerfuegbarGesperrt = ISNULL(Bestaende.LagerbestandVerfuegbarGesperrt, 0.0),
		  dbo.tlagerbestand.fZulauf = ISNULL(Bestaende.fZulauf, 0.0),
		  dbo.tlagerbestand.fAufEinkaufsliste = ISNULL(Bestaende.fAufEinkaufsliste, 0.0),
		  dbo.tlagerbestand.dLieferdatum = Bestaende.dLieferdatum,
		  dbo.tlagerbestand.fLagerbestandEigen = ISNULL(Bestaende.LagerbestandEigen, 0.0),
		  dbo.tlagerbestand.fInAuftraegen = ISNULL(Bestaende.fInAuftraegen,0.0)
	   FROM dbo.tlagerbestand WITH(ROWLOCK)
	   JOIN #ItemsForUpdate AS U1 ON dbo.tlagerbestand.kArtikel = U1.kArtikel 
		  AND U1.nNestingDeep = 1
	   LEFT JOIN
	   (
		  SELECT dbo.tArtikel.kVaterArtikel AS kArtikel,
				 SUM(ISNULL(dbo.tlagerbestand.fLagerbestand, 0.0)) AS Lagerbestand,
				 SUM(CASE WHEN ISNULL(dbo.tlagerbestand.fVerfuegbar, 0.0) > 0.0 
						THEN ISNULL(dbo.tlagerbestand.fVerfuegbar, 0.0) 
						ELSE 0.0 
					END) AS LagerbestandVerfuegbar,
				 SUM(ISNULL(dbo.tlagerbestand.fInAuftraegen,0.0)) AS fInAuftraegen,
				 SUM(ISNULL(dbo.tlagerbestand.fVerfuegbarGesperrt, 0.0)) AS LagerbestandVerfuegbarGesperrt,
				 SUM(ISNULL(dbo.tlagerbestand.fZulauf, 0.0)) AS fZulauf,
				 SUM(ISNULL(dbo.tlagerbestand.fAufEinkaufsliste, 0.0)) AS fAufEinkaufsliste,
				 MIN(ISNULL(dbo.tlagerbestand.dLieferdatum, CAST('01.01.1900' AS DATETIME))) AS dLieferdatum,
				 SUM(ISNULL(dbo.tlagerbestand.fLagerbestandEigen,0.0)) AS LagerbestandEigen
			  FROM dbo.tlagerbestand WITH(NOLOCK)
			  JOIN dbo.tartikel WITH(NOLOCK) ON dbo.tlagerbestand.kArtikel = dbo.tartikel.kArtikel 
				 AND dbo.tartikel.kVaterArtikel > 0
				 AND dbo.tartikel.nIstVater = 0
			  GROUP BY dbo.tArtikel.kVaterArtikel
	   ) AS Bestaende ON dbo.tlagerbestand.kArtikel = Bestaende.kArtikel
	   WHERE U1.nIstVater > 0 AND U1.cLagerVariation != 'Y'
    END

    --
    -- Aktualisierung der Lagerbestände für einfache Variationen (für Connectoren)
    --
    IF((SELECT COUNT(ISNULL(kArtikel,-1)) FROM #ItemsForUpdate WHERE cLagerVariation = 'Y') > 0)
		BEGIN
		UPDATE dbo.tlagerbestand WITH (ROWLOCK) SET
			  -- Update absetzen ACHTUNG: Normale Variationen ziehen beim Auftrag erstellen die Bestände breits ab, daher andere Berechnung
			  fLagerbestand = ISNULL(LagerBestand.fAnzahl, 0.0) + ISNULL(Reservierungen.fAnzahl, 0.0),
			  fVerfuegbar = ISNULL(LagerBestand.fAnzahl, 0.0),
			  fVerfuegbarGesperrt = 0.0,
			  fZulauf = 0.0,
			  fAufEinkaufsliste = 0.0,
			  fLagerbestandEigen = ISNULL(LagerBestand.fAnzahl, 0.0) + ISNULL(Reservierungen.fAnzahl, 0.0),
			  fInAuftraegen = ISNULL(Reservierungen.fAnzahl, 0.0)
		FROM dbo.tlagerbestand WITH(ROWLOCK)
		JOIN #ItemsForUpdate AS U1 ON tlagerbestand.kArtikel = U1.kArtikel 
			AND U1.nNestingDeep = 0 AND U1.cLagerVariation = 'Y'
		LEFT JOIN
		(
			SELECT VariationsBestaende.kArtikel, Min(ISNULL(VariationsBestaende.fBestand, 0.0)) AS fAnzahl FROM
			(
				SELECT dbo.tEigenschaft.kArtikel, SUM(ISNULL(dbo.tEigenschaftWert.fLagerbestand, 0.0)) AS fBestand
					FROM dbo.tEigenschaftWert WITH(NOLOCK)
					LEFT JOIN dbo.tEigenschaft WITH(NOLOCK) ON dbo.tEigenschaft.kEigenschaft = dbo.tEigenschaftWert.kEigenschaft
					WHERE ISNULL(dbo.tEigenschaftWert.fLagerbestand, 0.0) > 0
					GROUP BY dbo.tEigenschaft.kArtikel, dbo.tEigenschaft.kEigenschaft
			) AS VariationsBestaende
			GROUP BY VariationsBestaende.kArtikel
		) AS LagerBestand ON U1.kArtikel = LagerBestand.kArtikel
		LEFT JOIN
		(
			SELECT dbo.tReserviert.kArtikel, SUM(ISNULL(dbo.tReserviert.fAnzahl, 0.0)) AS fAnzahl
				FROM dbo.tReserviert WITH(NOLOCK)
				GROUP BY dbo.tReserviert.kArtikel
		) AS Reservierungen ON U1.kArtikel = Reservierungen.kArtikel
		WHERE U1.kStueckliste = 0 AND U1.nIstVater = 0 AND U1.cLagerAktiv = 'Y' AND U1.cLagerVariation = 'Y'		
    END
END
go

