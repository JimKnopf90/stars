/* Copyright (c) 2012-2015 by JTL Software GmbH
 Datum: $Date: 2015-03-10 15:49:42 +0100 (Di, 10. Mrz 2015) $
 Version: $Rev: 27430 $
 Autor: MP*/
CREATE VIEW [dbo].[vLagerbestandEx]
AS
SELECT        dbo.tlagerbestand.kArtikel, ISNULL(dbo.tlagerbestand.fLagerbestand, 0.0) AS fLagerbestand, ISNULL(dbo.tlagerbestand.fVerfuegbar, 0.0) AS fVerfuegbar, 
                         ISNULL(dbo.tlagerbestand.fInAuftraegen, 0.0) AS fReserviert, ISNULL(dbo.tlagerbestand.fVerfuegbarGesperrt, 0.0) AS fVerfuegbarGesperrt, 
                         ISNULL(dbo.tlagerbestand.fZulauf, 0.0) AS fZulauf, dbo.tlagerbestand.fVerfuegbar + ISNULL(dbo.tlagerbestand.fZulauf, 0.0) AS fZulaufVerfuegbar, ISNULL(dbo.tlagerbestand.fAufEinkaufsliste, 0.0) 
                         AS fAufEinkaufsliste, CASE WHEN dbo.tlagerbestand.dLieferdatum > GETDATE() OR
                         dbo.tlagerbestand.dLieferdatum IS NULL THEN dbo.tlagerbestand.dLieferdatum ELSE GETDATE() END AS dLieferdatum, CONVERT(DECIMAL(28, 15), 
                         ISNULL(dbo.tlagerbestand.fLagerbestand, 0.0) - ISNULL(SUM(CASE WHEN dbo.tliefartikel.nLagerBeachten = 1 THEN ISNULL(dbo.tliefartikel.fLagerbestand, 0.0) 
                         ELSE 0.0 END), 0.0)) AS fEigenerBestand, ISNULL(dbo.tlagerbestand.fVerfuegbar, 0.0) - ISNULL(dbo.tArtikel.nPuffer, 0.0) AS fVerfuegbarExtern, 
                         dbo.tlagerbestand.fInAuftraegen
FROM            dbo.tlagerbestand WITH (NOLOCK) INNER JOIN
                         dbo.tArtikel WITH (NOLOCK) ON dbo.tlagerbestand.kArtikel = dbo.tArtikel.kArtikel LEFT OUTER JOIN
                         dbo.tliefartikel WITH (NOLOCK) ON dbo.tlagerbestand.kArtikel = dbo.tliefartikel.tArtikel_kArtikel
WHERE        (dbo.tlagerbestand.kArtikel > 0)
GROUP BY dbo.tlagerbestand.kArtikel, dbo.tlagerbestand.fLagerbestand, dbo.tlagerbestand.fVerfuegbar, dbo.tlagerbestand.fVerfuegbarGesperrt, 
                         dbo.tlagerbestand.fZulauf, dbo.tlagerbestand.fAufEinkaufsliste, dbo.tlagerbestand.dLieferdatum, ISNULL(dbo.tArtikel.nPuffer, 0.0), 
                        dbo.tlagerbestand.fInAuftraegen
go

