
    CREATE PROCEDURE unicorn2_spDelNonValidMulti @kIdList VARCHAR(MAX)
    AS
        DECLARE @kIdListLocal VARCHAR(MAX)
    		SET @kIdListLocal = @kIdList
    	
        SET DEADLOCK_PRIORITY LOW		
        DELETE FROM unicorn2_tChangeCache
        WHERE kId IN (SELECT * FROM unicorn2_fSplitInts(@kIdListLocal, ','));
    go

