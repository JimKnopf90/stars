--- 
--- spBildLoeschenWennNichtVerwendet
---

CREATE PROC [dbo].[spBildLoeschenWennNichtVerwendet]
@Bilder TYPE_spBildLoeschenWennNichtVerwendet READONLY
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
    IF(object_id('tempdb..#spBildLoeschenWennNichtVerwendet') IS NOT NULL)
    BEGIN
	   DROP TABLE #spBildLoeschenWennNichtVerwendet;
    END;

    CREATE TABLE #spBildLoeschenWennNichtVerwendet (kBild INT)
    INSERT INTO #spBildLoeschenWennNichtVerwendet(kBild)
	SELECT kBild FROM @Bilder

    IF((SELECT COUNT(1) FROM #spBildLoeschenWennNichtVerwendet) = 0)
    BEGIN
	   RETURN;
    END;

    WITH AllUsed (kBild) AS (
	   SELECT dbo.tArtikelbildPlattform.kBild
	   FROM dbo.tArtikelbildPlattform
	   JOIN #spBildLoeschenWennNichtVerwendet AS TempTable ON dbo.tArtikelbildPlattform.kBild = TempTable.kBild
    --
    -- tEigenschaftWertPict
    --
	   UNION ALL
	   SELECT dbo.tEigenschaftWertPict.kBild
	   FROM dbo.tEigenschaftWertPict
	   JOIN #spBildLoeschenWennNichtVerwendet AS TempTable ON dbo.tEigenschaftWertPict.kBild = TempTable.kBild
    --
    -- tMerkmalBild
    --
	   UNION ALL
	   SELECT dbo.tMerkmalBildPlattform.kBild
	   FROM dbo.tMerkmalBildPlattform
	   JOIN #spBildLoeschenWennNichtVerwendet AS TempTable ON dbo.tMerkmalBildPlattform.kBild = TempTable.kBild
    --
    -- tMerkmalWertBild
    --
	   UNION ALL
	   SELECT dbo.tMerkmalwertBildPlattform.kBild
	   FROM dbo.tMerkmalwertBildPlattform
	   JOIN #spBildLoeschenWennNichtVerwendet AS TempTable ON dbo.tMerkmalwertBildPlattform.kBild = TempTable.kBild
    --
    -- tKategoriebildPlattform
    --
	   UNION ALL
	   SELECT dbo.tKategoriebildPlattform.kBild
	   FROM dbo.tKategoriebildPlattform
	   JOIN #spBildLoeschenWennNichtVerwendet AS TempTable ON dbo.tKategoriebildPlattform.kBild = TempTable.kBild
    --
    -- tHerstellerBild
    --
	   UNION ALL
	   SELECT dbo.tHerstellerBildPlattform.kBild
	   FROM dbo.tHerstellerBildPlattform
	   JOIN #spBildLoeschenWennNichtVerwendet AS TempTable ON dbo.tHerstellerBildPlattform.kBild = TempTable.kBild
    )

    DELETE FROM dbo.tbild 
    WHERE dbo.tbild.kBild NOT IN (SELECT kBild FROM AllUsed)
      AND dbo.tbild.kBild IN (SELECT kBild FROM #spBildLoeschenWennNichtVerwendet);
END
go

