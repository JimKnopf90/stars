
    CREATE TRIGGER dbo.unicorn2_trVersion
    ON dbo.tversion
    AFTER INSERT, UPDATE
    AS  						
			BEGIN
    		    SET NOCOUNT ON
    		    DECLARE @cVersion VARCHAR(19)
    		    SELECT TOP 1 @cVersion = cVersion FROM inserted    				
					
				IF NOT EXISTS(SELECT * FROM unicorn2_tWawiVersionHistory WHERE unicorn2_tWawiVersionHistory.cVersion = @cVersion)
				BEGIN
					
					INSERT INTO unicorn2_tWawiVersionHistory (cVersion, dInstallationDate, bHandled) VALUES (@cVersion, GETDATE(), 0)				
				END		    						
    		END
    go

