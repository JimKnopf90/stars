CREATE TRIGGER [dbo].[tgr_tZahlung_INSUPDEL]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--
ON [dbo].[tZahlung]
AFTER INSERT, UPDATE, DELETE
AS
SET CONCAT_NULL_YIELDS_NULL ON;
SET ANSI_WARNINGS ON;
SET ANSI_PADDING ON;
SET NOCOUNT ON;
BEGIN
	--Überprüfen ob Trigger gefüllt aufgerufen wird
	IF((SELECT COUNT(1) FROM INSERTED FULL JOIN DELETED ON INSERTED.kZahlung = DELETED.kZahlung) = 0)
	BEGIN
		RETURN
	END

	INSERT INTO dbo.tLog (dDatum, kBenutzer, cLog, nTyp, nVorgang)
	SELECT GETDATE(), INSERTED.kBenutzer, 'Zahlung gesetzt: Bestellung ' + CONVERT(VARCHAR(4000), dbo.tBestellung.cBestellNr) + ' ('+ CONVERT(VARCHAR(4000), INSERTED.kBestellung) + ') Betrag: ' + CONVERT(VARCHAR(4000), CAST(INSERTED.fBetrag AS DECIMAL(28, 2))), 8, 1
	FROM INSERTED
	LEFT JOIN DELETED ON INSERTED.kZahlung = DELETED.kZahlung
	JOIN dbo.tBestellung ON INSERTED.kBestellung = dbo.tBestellung.kBestellung
	WHERE DELETED.kZahlung IS NULL;

	INSERT INTO dbo.tLog (dDatum, kBenutzer, cLog, nTyp, nVorgang)
	SELECT GETDATE(), INSERTED.kBenutzer, 'Zahlung geändert: Bestellung ' + CONVERT(VARCHAR(4000), dbo.tBestellung.cBestellNr) + ' ('+ CONVERT(VARCHAR(4000), INSERTED.kBestellung) + ') Betrag: ' + CONVERT(VARCHAR(4000), CAST(INSERTED.fBetrag AS DECIMAL(28, 2))), 8, 2
	FROM INSERTED
	JOIN DELETED ON INSERTED.kZahlung = DELETED.kZahlung
	JOIN dbo.tBestellung ON INSERTED.kBestellung = dbo.tBestellung.kBestellung
	WHERE DELETED.fBetrag <> INSERTED.fBetrag;

	INSERT INTO dbo.tLog (dDatum, kBenutzer, cLog, nTyp, nVorgang)
	SELECT GETDATE(), DELETED.kBenutzer, 'Zahlung gelöscht: Bestellung ' + CONVERT(VARCHAR(4000), dbo.tBestellung.cBestellNr) + ' ('+ CONVERT(VARCHAR(4000), DELETED.kBestellung) + ') Betrag: ' + CONVERT(VARCHAR(4000), CAST(DELETED.fBetrag AS DECIMAL(28, 2))), 8, 3
	FROM DELETED
	LEFT JOIN INSERTED ON DELETED.kZahlung = INSERTED.kZahlung
	JOIN dbo.tBestellung ON DELETED.kBestellung = dbo.tBestellung.kBestellung
	WHERE INSERTED.kZahlung IS NULL;

	DECLARE @kZahlungenOhneZahlungsart AS TABLE (kZahlung INT)
	
	DECLARE @xBestellung AS XML
		SET @xBestellung = (
	    SELECT DISTINCT U1.kBestellung FROM
	    (
		    SELECT DELETED.kBestellung FROM DELETED
		    UNION
		    SELECT INSERTED.kBestellung FROM INSERTED
	    ) AS U1
		JOIN dbo.tbestellpos ON dbo.tbestellpos.tBestellung_kBestellung = U1.kBestellung
	FOR XML PATH('Bestellung'), TYPE
	)	
	IF(@xBestellung IS NOT NULL)
	BEGIN
		EXEC spBestellungEckdatenAktualisieren @xBestellungen = @xBestellung, @nKomplettAusgeliefertNichtBerechnen = 1;				
	END
	
	--
	-- Hier wird sichergestellt, dass kZahlungsart nicht 0 ist
	-- Dies ist für Ameisenexporte von Rechnungen erforderlich
	-- Der Wert 0 als Zahlungsart kann durch Importe aus externen Systemen entstehen
	--
	INSERT INTO @kZahlungenOhneZahlungsart (kZahlung)
	SELECT U1.kZahlung FROM
	(
		SELECT DELETED.kZahlung, DELETED.kZahlungsart FROM DELETED WHERE ISNULL(DELETED.kZahlungsart, 0) = 0	
		UNION
		SELECT INSERTED.kZahlung, INSERTED.kZahlungsart FROM INSERTED WHERE ISNULL(INSERTED.kZahlungsart, 0) = 0
	) AS U1

	if(ISNULL((SELECT COUNT(kZahlung) FROM @kZahlungenOhneZahlungsart), 0) > 0)
	BEGIN
		DECLARE @kStandardZahlungsart INT
		SET @kStandardZahlungsart = ISNULL((SELECT TOP 1 tZahlungsart.kZahlungsart FROM tZahlungsart), 0)

		--
		-- Wenn keine Zahlungsart ermittelt werden kann wird eine Dummy-Zahlungsart angelegt
		--
		if(@kStandardZahlungsart = 0)
		BEGIN
			DECLARE @kZahlungsartPK AS TABLE (kZahlungsart INT)
			INSERT INTO @kZahlungsartPK(kZahlungsart) EXEC spGetAndUpdatePK 'tZahlungsart'
			SET @kStandardZahlungsart = ISNULL((SELECT TOP 1 kZahlungsart FROM @kZahlungsartPK), 0)	
					
			INSERT INTO tZahlungsart(kZahlungsart, cName, cPrtString, nLastschrift, cPrtStringVor, cPaymentOption, cKonto, nAusliefernVorZahlung)
			VALUES(@kStandardZahlungsart, 'Automatisch angelegt', '', 0, '', '', '', 0)
		END

		--
		-- Zahlungsart setzen wo diese = 0 ist
		--
		UPDATE tZahlung WITH(ROWLOCK) SET tZahlung.kZahlungsart = ISNULL(tZahlungsart.kZahlungsart, @kStandardZahlungsart)
		FROM tZahlung WITH(ROWLOCK)
		LEFT JOIN tZahlungsart WITH(NOLOCK) ON LOWER(tZahlung.cName) = LOWER(tZahlungsart.cName)
		WHERE tZahlung.kZahlung IN
		(
			SELECT kZahlung FROM @kZahlungenOhneZahlungsart
		)
	END
END
go

