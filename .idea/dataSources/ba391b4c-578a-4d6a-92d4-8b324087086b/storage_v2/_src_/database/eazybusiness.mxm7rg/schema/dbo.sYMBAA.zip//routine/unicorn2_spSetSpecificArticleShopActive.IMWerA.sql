
    CREATE PROCEDURE unicorn2_spSetSpecificArticleShopActive @kShop INT, @kArtikel INT, @kBenutzer INT
    AS
        DECLARE @kShopLocal INT
			SET @kShopLocal = @kShop
		DECLARE @kArtikelLocal INT
			SET @kArtikelLocal = @kArtikel
        DECLARE @kBenutzerLocal INT
            SET @kBenutzerLocal = @kBenutzer

		SET DEADLOCK_PRIORITY LOW

        BEGIN TRY
		    DELETE FROM eazybusiness.dbo.tQueue WHERE kShop = @kShopLocal AND cName = 'tArtikel' AND kWert = @kArtikelLocal

		    ALTER TABLE eazybusiness.dbo.tArtikelShop DISABLE TRIGGER tgr_tArtikelShop_Connector_DELETE
		    DELETE FROM eazybusiness.dbo.tArtikelShop WHERE kShop = @kShopLocal AND kArtikel = @kArtikelLocal
		    ALTER TABLE eazybusiness.dbo.tArtikelShop ENABLE TRIGGER tgr_tArtikelShop_Connector_DELETE

		    ALTER TABLE eazybusiness.dbo.tArtikelShop DISABLE TRIGGER tgr_tArtikelShop_Connector_INSERT

		    INSERT INTO
			    eazybusiness.dbo.tArtikelShop
		    WITH (ROWLOCK)
			    (kArtikel, kShop, cInet, cDelInet, nAktion, nInBearbeitung)
		    VALUES
			    (@kArtikelLocal, @kShopLocal, 'Y', ' ', 1, 0)

            DELETE FROM eazybusiness.dbo.unicorn2_tShopDeletedArtikel WHERE kWawiId = @kArtikelLocal AND kShopId = @kShopLocal

        END TRY
        BEGIN CATCH
        END CATCH

        BEGIN TRY
		    ALTER TABLE eazybusiness.dbo.tArtikelShop ENABLE TRIGGER tgr_tArtikelShop_Connector_INSERT
        END TRY
        BEGIN CATCH
        END CATCH

		INSERT INTO
			eazybusiness.dbo.tLog
			(dDatum, kBenutzer, cLog,  nTyp,  nVorgang )
		VALUES
			(GETDATE(),  @kBenutzerLocal,  'unicorn 2: Artikel (kArtikel: ' + CAST(@kArtikelLocal AS VARCHAR(10)) + ') zu Shop (kShop: ' + CAST(@kShopLocal AS VARCHAR(10)) + ') hinzugefügt', 1,  2)
    go

