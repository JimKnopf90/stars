CREATE TRIGGER [dbo].[tgr_tStueckliste_DELETE]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP
--      	
ON [dbo].[tStueckliste]
AFTER DELETE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN


	DECLARE @Komplett AS INT;
	SET @Komplett = 1;

	--Überprüfen ob Trigger gefüllt aufgerufen wird
	IF((SELECT COUNT(1) FROM DELETED) = 0)
	BEGIN
		RETURN
	END

	
	UPDATE dbo.tArtikel
	SET dbo.tArtikel.kStueckliste = 0
	FROM DELETED
	JOIN dbo.tArtikel ON dbo.tArtikel.kStueckliste = DELETED.kStueckliste
	LEFT JOIN dbo.tStueckliste ON dbo.tArtikel.kStueckliste = dbo.tStueckliste.kStueckliste
	WHERE dbo.tStueckliste.kStueckliste IS NULL;


	DECLARE @typeSlArtikel AS TYPE_spAktualisiereStueckliste;
	DECLARE @typeArtikel AS TYPE_spUpdateLagerbestand;

	INSERT INTO @typeArtikel (kArtikel)
	SELECT DISTINCT kArtikel 
		FROM
		(
			SELECT kArtikel FROM DELETED
			GROUP BY DELETED.kArtikel
			UNION ALL
			SELECT tartikel.kArtikel
			FROM tartikel WITH (NOLOCK)
			JOIN DELETED ON tartikel.kStueckliste = DELETED.kStueckliste
			GROUP BY tartikel.kArtikel
		) AS U1
		WHERE kArtikel = U1.kArtikel;

	INSERT INTO @typeSlArtikel (kArtikel)
	SELECT kArtikel FROM @typeArtikel

	EXEC spUpdateLagerbestand @typeArtikel
	IF CONTEXT_INFO() <> 0x5009 OR CONTEXT_INFO() IS NULL
	BEGIN
	   EXEC dbo.spAktualisiereStueckliste @typeSlArtikel;
    END;


	--
	-- Stückliste im Shop aktualisieren
	--
	UPDATE dbo.tArtikelShop
		SET dbo.tArtikelShop.nAktion = dbo.tArtikelShop.nAktion | @Komplett,
			dbo.tArtikelShop.cInet = 'Y',
			dbo.tArtikelShop.nInBearbeitung = 0
	FROM dbo.tArtikelShop
	JOIN dbo.tArtikel ON dbo.tArtikel.kArtikel = dbo.tArtikelShop.kArtikel
	JOIN INSERTED ON dbo.tartikel.kStueckliste = INSERTED.kStueckliste
	WHERE dbo.tArtikelShop.cInet = 'N'
	   OR dbo.tArtikelShop.nAktion & @Komplett = 0
	   OR dbo.tArtikelShop.nInBearbeitung = 1;

END
go

