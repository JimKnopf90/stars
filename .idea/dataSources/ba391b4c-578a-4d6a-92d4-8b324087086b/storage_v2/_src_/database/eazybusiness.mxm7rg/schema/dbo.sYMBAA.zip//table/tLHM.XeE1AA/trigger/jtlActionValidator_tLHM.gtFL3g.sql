--
-- CleanUp-Trigger für das Löschen von LHM
--
	CREATE TRIGGER [dbo].[jtlActionValidator_tLHM]
	--
	-- Copyright (c) 2012-2017 by JTL Software GmbH
	-- Datum: $Date$
	-- Version: $Rev$
	-- Autor: MaikS
	--
	ON [dbo].[tLHM]
	AFTER DELETE
	AS
	SET NOCOUNT ON;
	SET ANSI_NULLS ON;
	SET ANSI_NULL_DFLT_ON ON;
	SET ANSI_PADDING ON;
	SET CONCAT_NULL_YIELDS_NULL ON;
	SET XACT_ABORT OFF;
	BEGIN
	  IF EXISTS(SELECT 1 FROM DELETED)
	  BEGIN
		--
		-- LHMSTatus entfernen
		--
			DELETE tLHMStatus WITH(ROWLOCK)
			FROM tLHMStatus WITH(ROWLOCK)
			JOIN DELETED ON tLHMSTatus.kLHM = DELETED.kLHM
				
	  END
	END
go

