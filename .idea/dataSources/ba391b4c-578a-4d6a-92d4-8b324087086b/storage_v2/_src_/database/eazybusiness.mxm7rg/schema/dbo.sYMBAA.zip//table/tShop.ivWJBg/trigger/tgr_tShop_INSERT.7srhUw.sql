CREATE TRIGGER [dbo].[tgr_tShop_INSERT] 
--     
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: FB
--    
ON [dbo].[tShop]  
AFTER INSERT
AS 
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF; 
BEGIN 

    INSERT INTO dbo.tHerstellerBildPlattform(kHersteller, kPlattform, kShop, kBild, nInet)
    SELECT dbo.tHersteller.kHersteller, 2, INSERTED.kShop, dbo.tHerstellerBildPlattform.kBild, 1
    FROM INSERTED
    CROSS JOIN dbo.tHersteller
    JOIN dbo.tHerstellerBildPlattform ON dbo.tHersteller.kHersteller = dbo.tHerstellerBildPlattform.kHersteller
        AND dbo.tHerstellerBildPlattform.kShop = 0

END
go

