--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date: 2017-02-15 07:48:57 +0100 (Mi, 15 Feb 2017) $
-- Autor: MP
-- Version: $Rev: 54820 $
--
CREATE VIEW [dbo].[vBestellLieferInfoVersand] AS
(
	/*DECLARE @KomplettLieferbar AS INT
	DECLARE @NichtLieferbar AS INT
	DECLARE @TeilLieferbar AS INT

	SET @KomplettLieferbar = 10
	SET @NichtLieferbar = 20
	SET @TeilLieferbar = 30*/

	SELECT	fehlBestaende.kBestellung,
			fehlBestaende.kWarenlager,
			CASE WHEN fehlBestaende.fBestandReserviert = 0.0
			THEN 20
			ELSE
				CASE WHEN fehlBestaende.fFehlbestand = 0.0 
					THEN 10
					ELSE 30
				END
			END AS nStatus,
			CASE WHEN fehlBestaende.fBestandReserviertEigen = 0.0
			THEN 20
			ELSE
				CASE WHEN fehlBestaende.fFehlbestandEigen = 0.0 
					THEN 10
					ELSE 30
				END
			END AS nStatusEigen,
			fehlBestaende.nDropshipping AS nDropshipping,
			CASE WHEN dbo.tbestellung.dBezahlt IS NOT NULL OR ISNULL(dbo.tZahlungsart.nAusliefernVorZahlung, 0) = 1 
				THEN 1 
				ELSE 0
			END AS nBezahlt
	FROM
	(
		SELECT	summierteAuftragsmengen.kBestellung,
				SUM(summierteAuftragsmengen.fFehlbestand) AS fFehlbestand,
				SUM(summierteAuftragsmengen.fFehlbestandEigen) AS fFehlbestandEigen,
				SUM(summierteAuftragsmengen.fBestandReserviert) AS fBestandReserviert,
				SUM(summierteAuftragsmengen.fBestandReserviertEigen) AS fBestandReserviertEigen,
				MAX(ISNULL(dbo.tliefartikel.nDropShipping, 0)) AS nDropshipping,
				summierteAuftragsmengen.kWarenlager
		FROM
		(
			SELECT	bestandProLagermitFehlbestand.kBestellung,
					bestandProLagermitFehlbestand.kArtikel,
					bestandProLagermitFehlbestand.offeneMenge,
					CASE WHEN bestandProLagermitFehlbestand.offeneMenge - bestandProLagermitFehlbestand.fLagerbestand < 0.0 
						THEN 0.0
						ELSE bestandProLagermitFehlbestand.offeneMenge - bestandProLagermitFehlbestand.fLagerbestand
					END AS fFehlbestand,
					CASE WHEN bestandProLagermitFehlbestand.offeneMenge - bestandProLagermitFehlbestand.fLagerbestandEigen < 0.0 
						THEN 0.0
						ELSE bestandProLagermitFehlbestand.offeneMenge - bestandProLagermitFehlbestand.fLagerbestandEigen
					END AS fFehlbestandEigen,
					CASE WHEN bestandProLagermitFehlbestand.fBestandReserviert > bestandProLagermitFehlbestand.fLagerbestand 
						THEN bestandProLagermitFehlbestand.fLagerbestand
						ELSE bestandProLagermitFehlbestand.fBestandReserviert
					END AS fBestandReserviert,
					CASE WHEN bestandProLagermitFehlbestand.fBestandReserviertEigen > bestandProLagermitFehlbestand.fLagerbestandEIgen
						THEN bestandProLagermitFehlbestand.fLagerbestandEigen
						ELSE bestandProLagermitFehlbestand.fBestandReserviertEigen
					END AS fBestandReserviertEigen,
					bestandProLagermitFehlbestand.kWarenlager
			FROM
			(			
					-- Freipositionen, Artikel ohne Lagerbestand, Artikel mit Lagerbestand in Variationen
					SELECT 
						dbo.tReserviert.kBestellung,
						dbo.tReserviert.kArtikel,
						SUM(dbo.tReserviert.fAnzahl) AS offeneMenge,
						SUM(dbo.tReserviert.fAnzahl) AS fBestandReserviert,
						SUM(dbo.tReserviert.fAnzahl) AS fBestandReserviertEigen,
						Warenlager.kWarenLager AS kWarenlager,
						SUM(dbo.tReserviert.fAnzahl) AS fLagerbestand,
						SUM(dbo.tReserviert.fAnzahl) AS fLagerbestandEigen
					FROM dbo.tReserviert
					LEFT JOIN dbo.tArtikel ON dbo.tArtikel.kArtikel = dbo.tReserviert.kArtikel
					CROSS JOIN (
						SELECT kWarenLager FROM dbo.tWarenLager WHERE dbo.tWarenLager.nAktiv > 0 UNION SELECT 0 AS kWarenLager
					) AS Warenlager
					WHERE dbo.tReserviert.kPlattform = 1 AND (
						dbo.tReserviert.kArtikel = 0 OR ISNULL(dbo.tArtikel.cLagerAktiv, 'N') = 'N' OR ISNULL(dbo.tArtikel.cLagerVariation, 'Y') = 'Y') 
					GROUP BY 
						dbo.tReserviert.kBestellung,
						dbo.tReserviert.kArtikel,
						Warenlager.kWarenLager
					UNION
					-- Artikel mit Lagerbestand für alle Läger
					SELECT	
						dbo.tReserviert.kBestellung,
						dbo.tReserviert.kArtikel,
						SUM(dbo.tReserviert.fAnzahl) AS offeneMenge,			
						SUM(dbo.tReserviert.fBestandReserviert) AS fBestandReserviert,
						SUM(dbo.tReserviert.fBestandReserviertEigen) AS fBestandReserviertEigen,				
						0 AS kWarenlager,
						dbo.tlagerbestand.fLagerbestand AS fLagerbestand,
						dbo.tlagerbestand.fLagerbestandEigen AS fLagerbestandEigen						
					FROM dbo.tReserviert
					JOIN dbo.tlagerbestand ON dbo.tReserviert.kArtikel = dbo.tlagerbestand.kArtikel
					WHERE dbo.tReserviert.kPlattform = 1 AND dbo.tlagerbestand.nArtikelTyp = 0 AND dbo.tlagerbestand.nLagerAktiv > 0
					GROUP BY	
						dbo.tReserviert.kBestellung,
						dbo.tReserviert.kArtikel,
						dbo.tlagerbestand.fLagerbestandEigen,
						dbo.tlagerbestand.fLagerbestand
					UNION
					-- Artikel mit Lagerbestand für spezielles Lager
					SELECT	
						dbo.tReserviert.kBestellung,
						dbo.tReserviert.kArtikel,
						SUM(dbo.tReserviert.fAnzahl) AS offeneMenge,
						SUM(dbo.tReserviert.fBestandReserviert) AS fBestandReserviert,
						SUM(dbo.tReserviert.fBestandReserviertEigen) AS fBestandReserviertEigen,
						dbo.tWarenLager.kWarenLager AS kWarenlager,
						ISNULL(bestandProLager.fBestand, 0.0) + dbo.tlagerbestand.fLagerbestand - dbo.tlagerbestand.fLagerbestandEigen AS fLagerbestand,
						ISNULL(bestandProLager.fBestand, 0.0) AS fLagerbestandEigen
					FROM dbo.tReserviert
					JOIN tArtikel ON tArtikel.kArtikel = tReserviert.kArtikel
					JOIN dbo.tlagerbestand ON dbo.tlagerbestand.kArtikel = dbo.tReserviert.kArtikel
					CROSS JOIN dbo.tWarenLager
					LEFT JOIN
					(
						SELECT	dbo.tWarenLagerEingang.kArtikel,
								dbo.tWarenLagerPlatz.kWarenLager,
								SUM(dbo.tWarenLagerEingang.fAnzahlAktuell) AS fBestand
						FROM dbo.tWarenLagerEingang
						JOIN dbo.tWarenLagerPlatz ON dbo.tWarenLagerEingang.kWarenLagerPlatz = dbo.tWarenLagerPlatz.kWarenLagerPlatz
						WHERE	dbo.tWarenLagerEingang.fAnzahlAktuell > 0.0
								AND dbo.tWarenLagerEingang.kArtikel > 0
						GROUP BY	dbo.tWarenLagerEingang.kArtikel,
									dbo.tWarenLagerPlatz.kWarenLager
					) AS bestandProLager ON dbo.tReserviert.kArtikel = bestandProLager.kArtikel
						AND dbo.tWarenLager.kWarenLager = bestandProLager.kWarenLager
					WHERE	dbo.tReserviert.kPlattform = 1 AND dbo.tlagerbestand.nArtikelTyp = 0 AND dbo.tlagerbestand.nLagerAktiv > 0 AND ISNULL(dbo.tArtikel.kStueckliste, 0) = 0
					GROUP BY	
							dbo.tReserviert.kBestellung,
							dbo.tReserviert.kArtikel,
							dbo.tWarenLager.kWarenLager,
							bestandProLager.fBestand,
							dbo.tlagerbestand.fLagerbestand,
							dbo.tlagerbestand.fLagerbestandEigen
			) AS bestandProLagermitFehlbestand
		) AS summierteAuftragsmengen		
		LEFT JOIN dbo.tliefartikel ON summierteAuftragsmengen.kArtikel = dbo.tliefartikel.tArtikel_kArtikel
		GROUP BY	summierteAuftragsmengen.kBestellung,
					summierteAuftragsmengen.kWarenlager
	) AS fehlBestaende
	JOIN dbo.tbestellung ON fehlBestaende.kBestellung = dbo.tbestellung.kBestellung
	LEFT JOIN dbo.tZahlungsart ON dbo.tbestellung.kZahlungsArt = dbo.tZahlungsart.kZahlungsart
	WHERE dbo.tbestellung.nKomplettAusgeliefert = 0
)
go

