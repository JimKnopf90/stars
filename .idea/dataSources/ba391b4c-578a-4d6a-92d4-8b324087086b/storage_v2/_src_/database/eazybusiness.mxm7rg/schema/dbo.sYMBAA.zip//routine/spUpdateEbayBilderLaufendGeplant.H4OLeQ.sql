--- 
--- spUpdateEbayBilderLaufendGeplant
---

CREATE PROC [dbo].[spUpdateEbayBilderLaufendGeplant]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--
-- Setzt für alle laufenden/geplanten eBay-Angebote einer Menge von Artikeln in ebay_geaenderte_laufende_angebote.nChanges das Bilder-Bit auf 1/cStatus auf "U".
-- Hierbei werden auch für alle laufenden/geplanten Angebote von Vaterartikeln der übergebenen Artikel das VarKombisNichtPreis-Bit auf 1/cStatus auf "U" gesetzt, 
--		wenn der übergebene Artikel als Variation im laufenden/geplanten Angebot aktiv ist.
--
@Artikel XML
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
	--
	-- XML parsen
	--

	IF(object_id('tempdb..#spUpdateEbayBilderLaufendGeplant_Artikel') IS NOT NULL)
    BEGIN
	   DROP TABLE #spUpdateEbayBilderLaufendGeplant_Artikel;
    END;
    CREATE TABLE #spUpdateEbayBilderLaufendGeplant_Artikel (kArtikel INT);

    INSERT INTO #spUpdateEbayBilderLaufendGeplant_Artikel(kArtikel)
	SELECT ParamValues.ID.value('.','VARCHAR(20)')
	FROM @Artikel.nodes('/Artikel/kArtikel') AS ParamValues(ID);

    IF((SELECT COUNT(1) FROM #spUpdateEbayBilderLaufendGeplant_Artikel) = 0)
    BEGIN
	   RETURN;
    END;

	--
	-- laufende Angebote berechnen 
	--

	IF(object_id('tempdb..#spUpdateEbayBilderLaufendGeplant_EbayItems') IS NOT NULL)
    BEGIN
	   DROP TABLE #spUpdateEbayBilderLaufendGeplant_EbayItems;
    END;
    CREATE TABLE #spUpdateEbayBilderLaufendGeplant_EbayItems (kEbayItem INT);

	DECLARE @EBAY_STATUS_LAUFENDE_ANGEBOTE INT;
	SET @EBAY_STATUS_LAUFENDE_ANGEBOTE = 3;
    DECLARE @EBAY_STATUS_LAUFEND_ERROR INT; 
	SET @EBAY_STATUS_LAUFEND_ERROR = 7;

	INSERT #spUpdateEbayBilderLaufendGeplant_EbayItems(kEbayItem)
	SELECT dbo.ebay_item.kItem
	FROM #spUpdateEbayBilderLaufendGeplant_Artikel JOIN dbo.ebay_item 
		ON dbo.ebay_item.kArtikel = #spUpdateEbayBilderLaufendGeplant_Artikel.kArtikel  
			AND dbo.ebay_item.Status IN (@EBAY_STATUS_LAUFENDE_ANGEBOTE, @EBAY_STATUS_LAUFEND_ERROR);

	--
	-- Bit-Wert für Bilder berechnen
	--

	DECLARE @nBitValue INT; 
	SET @nBitValue = POWER(2, 7);

	--
	-- laufende Angebote updaten
	--

	UPDATE dbo.ebay_geaenderte_laufende_angebote
	SET nChanges = nChanges | @nBitValue
	FROM #spUpdateEbayBilderLaufendGeplant_EbayItems JOIN dbo.ebay_geaenderte_laufende_angebote 
		ON dbo.ebay_geaenderte_laufende_angebote.kItem = #spUpdateEbayBilderLaufendGeplant_EbayItems.kEbayItem;

	INSERT dbo.ebay_geaenderte_laufende_angebote
	(
		kItem,
		nChanges
	)
	SELECT #spUpdateEbayBilderLaufendGeplant_EbayItems.kEbayItem, @nBitValue
	FROM #spUpdateEbayBilderLaufendGeplant_EbayItems LEFT JOIN dbo.ebay_geaenderte_laufende_angebote 
		ON dbo.ebay_geaenderte_laufende_angebote.kItem = #spUpdateEbayBilderLaufendGeplant_EbayItems.kEbayItem 
	WHERE dbo.ebay_geaenderte_laufende_angebote.kItem IS NULL;

	--
	-- geplante Angebote updaten
	--

	UPDATE dbo.ebay_planung
	SET cStatus = 'U'
	FROM #spUpdateEbayBilderLaufendGeplant_Artikel 
		JOIN dbo.ebay_item ON dbo.ebay_item.kArtikel = #spUpdateEbayBilderLaufendGeplant_Artikel.kArtikel 
		JOIN dbo.ebay_planung ON dbo.ebay_planung.kItem = dbo.ebay_item.kItem;

	--
	-- Variationen für laufende Angebote berücksichtigen
	--

	DELETE #spUpdateEbayBilderLaufendGeplant_EbayItems;

    INSERT #spUpdateEbayBilderLaufendGeplant_EbayItems(kEbayItem)
	SELECT DISTINCT dbo.ebay_item.kItem 
	FROM #spUpdateEbayBilderLaufendGeplant_Artikel 
		JOIN dbo.tArtikel ON tArtikel.kArtikel = #spUpdateEbayBilderLaufendGeplant_Artikel.kArtikel
		JOIN dbo.ebay_item ON ebay_item.kArtikel = tartikel.kVaterArtikel
			AND dbo.ebay_item.Status IN (@EBAY_STATUS_LAUFENDE_ANGEBOTE, @EBAY_STATUS_LAUFEND_ERROR)
		JOIN dbo.ebay_item2kombi ON ebay_item2kombi.kItem = ebay_item.kItem
			AND ebay_item2kombi.kEigenschaftKombi = tArtikel.kEigenschaftKombi;
	
	--
	-- Bit-Wert für VarKombisNichtPreis berechnen
	--

	SET @nBitValue = @nBitValue | POWER(2, 9);

	UPDATE dbo.ebay_geaenderte_laufende_angebote
	SET nChanges = nChanges | @nBitValue
	FROM #spUpdateEbayBilderLaufendGeplant_EbayItems JOIN dbo.ebay_geaenderte_laufende_angebote 
		ON dbo.ebay_geaenderte_laufende_angebote.kItem = #spUpdateEbayBilderLaufendGeplant_EbayItems.kEbayItem; 

	INSERT dbo.ebay_geaenderte_laufende_angebote
	(
		kItem,
		nChanges
	)
	SELECT #spUpdateEbayBilderLaufendGeplant_EbayItems.kEbayItem, @nBitValue
	FROM #spUpdateEbayBilderLaufendGeplant_EbayItems LEFT JOIN dbo.ebay_geaenderte_laufende_angebote 
		ON dbo.ebay_geaenderte_laufende_angebote.kItem = #spUpdateEbayBilderLaufendGeplant_EbayItems.kEbayItem 
	WHERE dbo.ebay_geaenderte_laufende_angebote.kItem IS NULL;	

	--
	-- Variationen für geplante Angebote berücksichtigen
	--

	UPDATE dbo.ebay_planung
	SET cStatus = 'U'
	FROM #spUpdateEbayBilderLaufendGeplant_Artikel
		JOIN dbo.tArtikel ON tArtikel.kArtikel = #spUpdateEbayBilderLaufendGeplant_Artikel.kArtikel
		JOIN dbo.ebay_item ON dbo.ebay_item.kArtikel = dbo.tArtikel.kVaterArtikel
		JOIN dbo.ebay_item2kombi ON ebay_item2kombi.kItem = ebay_item.kItem
			AND ebay_item2kombi.kEigenschaftKombi = tArtikel.kEigenschaftKombi
		JOIN dbo.ebay_planung ON dbo.ebay_planung.kItem = dbo.ebay_item.kItem; 
END;
go

