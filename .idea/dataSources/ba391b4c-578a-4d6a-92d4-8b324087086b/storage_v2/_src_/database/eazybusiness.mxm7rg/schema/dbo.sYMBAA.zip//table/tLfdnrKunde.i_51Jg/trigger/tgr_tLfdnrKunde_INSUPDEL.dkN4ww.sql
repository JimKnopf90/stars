CREATE TRIGGER [dbo].[tgr_tLfdnrKunde_INSUPDEL]     
-- 
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--  
ON [dbo].[tLfdnrKunde]     
AFTER INSERT, UPDATE, DELETE   
AS   
SET NOCOUNT ON;  
BEGIN TRANSACTION 
	EXEC spRefreshLaufendeNummern  
COMMIT
go

