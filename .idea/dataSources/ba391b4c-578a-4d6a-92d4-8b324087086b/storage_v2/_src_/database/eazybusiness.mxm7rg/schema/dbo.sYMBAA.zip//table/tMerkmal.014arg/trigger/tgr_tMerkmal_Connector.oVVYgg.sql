CREATE TRIGGER [dbo].[tgr_tMerkmal_Connector]  
--     
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MaikS
--    
ON [dbo].[tMerkmal]  
AFTER INSERT, UPDATE 
AS 
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF; 
BEGIN 

	--
	-- tQueue schreiben um Merkmale zu senden
	--
	INSERT INTO dbo.tQueue(kShop, kPlattform, cName, kWert, nAction)
	SELECT dbo.tShop.kShop, 2, 'tMerkmal', INSERTED.kMerkmal, 1
	FROM INSERTED
	CROSS JOIN dbo.tShop
	LEFT JOIN dbo.tQueue ON dbo.tQueue.kShop = dbo.tShop.kShop
			AND dbo.tQueue.kPlattform = 2
			AND dbo.tQueue.cName = 'tMerkmal'
			AND dbo.tQueue.kWert = INSERTED.kMerkmal
			AND dbo.tQueue.nAction = 1
	WHERE dbo.tQueue.kWert IS NULL
	AND INSERTED.nVerwendungszweck IN (0, 3);

	DELETE dbo.tQueue
	FROM INSERTED
	JOIN dbo.tQueue ON INSERTED.kMerkmal = dbo.tQueue.kWert
		AND dbo.tQueue.cName = 'tMerkmal'
		AND dbo.tQueue.nAction = 1
	JOIN DELETED ON INSERTED.kMerkmal = DELETED.kMerkmal
	WHERE DELETED.nVerwendungszweck IN (0, 3) AND INSERTED.nVerwendungszweck IN (1, 2);

	INSERT INTO dbo.tQueue(kShop, kPlattform, cName, kWert, nAction)
	SELECT dbo.tShop.kShop, 2, 'tMerkmal', INSERTED.kMerkmal, 2
	FROM INSERTED
	JOIN DELETED ON INSERTED.kMerkmal = DELETED.kMerkmal
	CROSS JOIN dbo.tShop
	WHERE DELETED.nVerwendungszweck IN (0, 3) AND INSERTED.nVerwendungszweck IN (1, 2);

	DECLARE @Komplett AS INT;
	--DECLARE @Preis AS INT;
	--DECLARE @Bestand AS INT;

	SET @Komplett = 1;
	--SET @Preis = 2;
	--SET @Bestand = 4;

	--
	-- Artikel vollständig zu Webshops senden, wenn Änderungen vorgenommen wurden
	--
	UPDATE dbo.tArtikelShop
		SET dbo.tArtikelShop.nAktion = dbo.tArtikelShop.nAktion | @Komplett,
			dbo.tArtikelShop.cInet = 'Y',
			dbo.tArtikelShop.nInBearbeitung = 0
	FROM dbo.tArtikelShop
	JOIN
	(
		SELECT dbo.tArtikelMerkmal.kArtikel
		FROM dbo.tArtikelMerkmal
		JOIN
		(
			SELECT INSERTED.kMerkmal
			FROM DELETED
			JOIN INSERTED ON DELETED.kMerkmal = INSERTED.kMerkmal
			WHERE DELETED.nVerwendungszweck <> INSERTED.nVerwendungszweck			
		) AS aktualisierteMerkmale ON dbo.tArtikelMerkmal.kMerkmal = aktualisierteMerkmale.kMerkmal
		GROUP BY dbo.tArtikelMerkmal.kArtikel
	) AS refreshableItems ON dbo.tArtikelShop.kArtikel = refreshableItems.kArtikel			
	WHERE	dbo.tArtikelShop.cInet = 'N'
			OR dbo.tArtikelShop.nAktion & @Komplett = 0
			OR dbo.tArtikelShop.nInBearbeitung = 1;
															 
END
go

