CREATE FUNCTION [dbo].[ifKategoriebaum](@kKategorie AS INT)
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP/FB
--
RETURNS TABLE
AS
RETURN
(
	WITH kategorien AS
	(
		SELECT dbo.tkategorie.kKategorie
		FROM dbo.tkategorie
		WHERE dbo.tkategorie.kKategorie = @kKategorie
		UNION ALL
		SELECT dbo.tkategorie.kKategorie
		FROM dbo.tkategorie
		JOIN kategorien ON dbo.tkategorie.kOberKategorie = kategorien.kKategorie
	)
	SELECT * 
	FROM kategorien
)
go

