CREATE FUNCTION [dbo].[ifArtikelhistorie] (@kArtikel INT, @Enddate DATETIME = NULL,  @Startdate DATETIME = NULL, @nAnzahl INT = 0, @kBuchungsArt INT = 0, @kWarenlager INT = 0, @nOhneLagerBestand INT = 0)
RETURNS TABLE
AS
RETURN(
	SELECT *
		FROM
		(
		SELECT TOP 100 PERCENT  
tArtikelHistory.dGebucht AS Buchungsdatum, 
tArtikelHistory.fAnzahl AS Buchungsmenge, 
CASE WHEN @nOhneLagerBestand = 1 THEN 0 ELSE tArtikelHistory.fLagerBestandGesamt END AS Lagerbestand,
dbo.tWarenLager.cName AS Lager,
dbo.tWarenlager.kWarenLager,
tArtikelHistory.fEKNetto AS EK,
		dbo.tLieferantenBestellungPos.cLieferantenArtNr AS 'ArtNr Lieferant',
		dbo.tLieferantenBestellungPos.cNameLieferant AS Lieferant,
		dbo.tLieferantenBestellung.cEigeneBestellnummer AS Lieferantenbestellung,
				LieferscheinAuftrag.cBestellNr AS AuftragsNr,
				CASE WHEN  tArtikelHistory.kBuchungsart in (10) THEN tArtikelHistory.cLieferscheinNr
											 ELSE LieferscheinAuftrag.cLieferscheinNr  END  AS LieferscheinNr,
				Gutschrift.cGutschriftNr AS GutschriftNr,
				ISNULL(Benutzer.cName, 'n/A') AS Benutzer,
				ISNULL(Benutzer.kBenutzer, 0) AS kBenutzer,
				tArtikelHistory.cKommentar,
				tArtikelHistory.cChargenNr,
				tArtikelHistory.dMHD,
				tArtikelHistory.kBuchungsart,
				tArtikelHistory.kArtikel,
				tArtikelHistory.kWarenLagerPlatz,
				ROW_NUMBER() OVER (ORDER BY tArtikelHistory.dGebucht DESC) AS RowNumber

FROM tArtikelHistory
JOIN dbo.tWarenLagerPlatz ON tWarenLagerPlatz.kWarenLagerPlatz = dbo.tArtikelHistory.kWarenLagerPlatz
JOIN dbo.tWarenLager ON dbo.tWarenLager.kWarenLager = dbo.tWarenLagerPlatz.kWarenLager
LEFT JOIN dbo.tLieferantenBestellungPos ON tArtikelHistory.kLieferantenBestellungPos = dbo.tLieferantenBestellungPos.kLieferantenBestellungPos
LEFT JOIN dbo.tLieferantenBestellung ON dbo.tLieferantenBestellungPos.kLieferantenBestellung = dbo.tLieferantenBestellung.kLieferantenBestellung
LEFT JOIN 
			(
				SELECT dbo.tLieferscheinPos.kLieferscheinPos,
						dbo.tLieferschein.cLieferscheinNr,
						dbo.tbestellung.cBestellNr 
					FROM dbo.tLieferscheinPos 
					JOIN dbo.tLieferschein ON tLieferschein.kLieferschein = tLieferscheinPos.kLieferschein
					JOIN dbo.tbestellung ON dbo.tbestellung.kBestellung = dbo.tLieferschein.kBestellung
		) AS LieferscheinAuftrag ON LieferscheinAuftrag.kLieferscheinPos = tArtikelHistory.kLieferscheinPos
LEFT JOIN 
		(
			SELECT  dbo.tgutschriftpos.kGutschriftPos,
					dbo.tgutschrift.cGutschriftNr
				FROM dbo.tgutschriftpos 
				JOIN dbo.tgutschrift ON dbo.tgutschriftpos.tGutschrift_kGutschrift = dbo.tgutschrift.kGutschrift
		) AS Gutschrift ON Gutschrift.kGutschriftPos = tArtikelHistory.kGutschriftPos
LEFT JOIN eazybusiness.dbo.tbenutzer AS Benutzer ON tArtikelHistory.kBenutzer = Benutzer.kBenutzer


WHERE (tArtikelHistory.kArtikel = @kArtikel OR @kArtikel = 0)
AND ISNULL(@Startdate, CAST('1900-01-01 00:00:00.000' AS DATETIME)) <= tArtikelHistory.dGebucht
AND ISNULL(@Enddate, GETDATE()) >= tArtikelHistory.dGebucht
AND (dbo.tWarenLager.kWarenLager = @kWarenlager OR @kWarenlager = 0)
		AND (tArtikelHistory.kBuchungsart = @kBuchungsArt OR @kBuchungsArt = 0)
		ORDER BY tArtikelHistory.dGebucht DESC

	) AS Result
	WHERE Result.RowNumber <= CASE WHEN @nAnzahl = 0 OR @nAnzahl IS NULL
									THEN Result.RowNumber
									ELSE @nAnzahl
							END
)
go

