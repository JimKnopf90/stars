--- 
--- spRefreshOrderSorting
---

CREATE PROCEDURE [dbo].[spRefreshOrderSorting]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MP
-- Beschreibung: Dient der neu Sortierung aller Positionen eines Auftrags (Lücken in tbestellung.nSort)
--
@kBestellung AS int
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN	

	IF(@kBestellung > 0)
	BEGIN
		UPDATE tbestellpos WITH(ROWLOCK) 
            SET nSort = U1.nSort
		FROM dbo.tbestellpos
		JOIN
		(
			SELECT kBestellPos, 
                   ROW_NUMBER() OVER(ORDER BY nSort, kBestellPos) AS nSort
			FROM 
			(
				SELECT	dbo.tbestellpos.tBestellung_kBestellung AS kBestellung,
						dbo.tbestellpos.kBestellpos,
						CASE WHEN ISNULL(stuecklistenVater.nSort, dbo.tbestellpos.nSort) = 0 THEN maxSort ELSE ISNULL(stuecklistenVater.nSort, dbo.tbestellpos.nSort)  END AS nSort
				FROM dbo.tbestellpos
				JOIN
				(
					SELECT	MAX(nSort) + 1 AS maxSort,
							tBestellung_kBestellung AS kBestellung
					FROM	dbo.tbestellpos
					WHERE dbo.tbestellpos.tBestellung_kBestellung = @kBestellung
					GROUP BY tBestellung_kBestellung
				) AS maxSort ON	dbo.tbestellpos.tBestellung_kBestellung = maxSort.kBestellung			
				LEFT JOIN dbo.tbestellpos AS stuecklistenVater ON dbo.tbestellpos.kBestellStueckliste = stuecklistenVater.kBestellPos
			) AS bestellpos
		) AS U1 ON tbestellpos.kBestellPos = U1.kBestellPos
	END

END
go

