--- 
--- spBestellposAnlegen
---

CREATE PROCEDURE [dbo].[spBestellposAnlegen]
	@kArtikel INT = NULL,
	@kBestellung INT = NULL,
	@fVKPreis DECIMAL(28,14) = NULL,
	@fMwSt DECIMAL(28,14) = NULL,
	@nAnzahl DECIMAL(28,14) =  NULL,
	@fRabatt DECIMAL(28,14) = NULL,
	@cString VARCHAR(255) = NULL,
	@fVKNetto DECIMAL(28,14) = NULL,
	@cArtNr VARCHAR(100) = NULL,
	@nType TINYINT = NULL,
	@cHinweis VARCHAR(2000) = NULL,
	@nHatUpload INT = NULL,
	@cUnique VARCHAR(30) = NULL,
	@kKonfigitem INT = NULL,
	@nDropshipping TINYINT = NULL,
	@fEkNetto DECIMAL(28,14) = NULL,
	@cOrderItemId VARCHAR(255) = NULL,
	@cItemId VARCHAR(255) = NULL,
	@cTransactionID VARCHAR(255) = NULL,
	@kAmazonBestellungPos INT = NULL,
	@nSort INT = NULL,
	@kBestellStueckliste INT = NULL,
	@cEinheit VARCHAR(255) = NULL,
	@nEckDatenNichtAktualisieren INT = 0,
	@kBestellpos INT = NULL OUTPUT
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
DECLARE @ErrorMessage NVARCHAR(4000);
DECLARE @ErrorSeverity INT;
DECLARE @ErrorState INT;
DECLARE @retry INT;
SET @retry = 5;
WHILE @retry > 0
BEGIN	
	BEGIN TRY
		BEGIN TRANSACTION
			IF(EXISTS(SELECT * FROM dbo.tBestellung WHERE tBestellung.kBestellung = @kBestellung AND tBestellung.nIstExterneRechnung = 1))
			BEGIN
				RAISERROR('Diese Bestellung darf nicht geändert werden.', 18,10);
				ROLLBACK;
				RETURN;
			END
			SET CONTEXT_INFO 0x5100;
			DECLARE @xKomplettAusgeliefert AS XML;
			DECLARE @cStringStandard VARCHAR(255);
			SELECT @cStringStandard = dbo.tArtikelBeschreibung.cName
				FROM dbo.tArtikelBeschreibung
				JOIN dbo.tSpracheUsed ON dbo.tSpracheUsed.kSprache = dbo.tArtikelBeschreibung.kSprache
										AND dbo.tSpracheUsed.nStandard = 1
				WHERE dbo.tArtikelBeschreibung.kArtikel = @kArtikel
					AND dbo.tArtikelBeschreibung.kPlattform = 1;
			
			-- Wir runden auf 4 nachkommastellen
			SET @nAnzahl = ROUND(@nAnzahl,4);

			--
			-- Stücklistehkomponenten haben einen EK von 0.0 (für die Statistik, da VK auch 0 ist)
			--
			IF(@kBestellStueckliste > 0)
			BEGIN
				SET @fEkNetto = 0.0;			
			END
			IF(@cEinheit IS NULL)
			BEGIN
				SET @cEinheit = (	SELECT dbo.tEinheitSprache.cName
									FROM dbo.tBestellung
									JOIN dbo.tArtikel ON dbo.tArtikel.kArtikel = @kArtikel
									JOIN dbo.tEinheitSprache ON dbo.tArtikel.kVerkaufsEinheit = dbo.tEinheitSprache.kEinheit
										AND dbo.tEinheitSprache.kSprache = dbo.tBestellung.kSprache
									WHERE	dbo.tBestellung.kBestellung = @kBestellung
											AND @kArtikel > 0
								);
			END

			-- tbestellpos schreiben
			INSERT INTO dbo.tbestellpos
					(tArtikel_kArtikel, tBestellung_kBestellung, fVKPreis, fMwSt, nAnzahl, fRabatt, cString, fVKNetto,
					cArtNr, nType, cHinweis, nHatUpload, cUnique, kKonfigitem, nDropshipping, fEKNetto, cOrderItemId, cItemID,
					cTransactionID, kAmazonBestellungPos, nSort, kBestellStueckliste, cStringStandard, cEinheit)
				VALUES(@kArtikel, @kBestellung, @fVKPreis, @fMwSt, @nAnzahl, @fRabatt, @cString, @fVKNetto,
					@cArtNr, @nType, @cHinweis, @nHatUpload, @cUnique, @kKonfigitem, @nDropshipping, @fEkNetto, @cOrderItemId, @cItemId,
					@cTransactionID, @kAmazonBestellungPos, @nSort, @kBestellStueckliste, CASE WHEN LEN(ISNULL(@cStringStandard, '')) = 0 THEN @cString ELSE @cStringStandard END, @cEinheit);

			SELECT @kBestellpos = SCOPE_IDENTITY();
			IF(EXISTS(SELECT * 
						FROM dbo.tbestellung 
						WHERE dbo.tbestellung.kBestellung = @kBestellung 
							AND dbo.tbestellung.nKomplettAusgeliefert = 1))
			BEGIN			
				SET @xKomplettAusgeliefert = (
					SELECT kBestellung, 0 AS nKomplettAusgeliefert
						FROM dbo.tbestellung 
						WHERE dbo.tbestellung.kBestellung = @kBestellung
								AND dbo.tbestellung.nKomplettAusgeliefert = 1
						FOR XML PATH('BestellungKomplettAusgeliefert'), TYPE
					);
				IF(@xKomplettAusgeliefert IS NOT NULL)
				BEGIN
					EXEC Auftrag.spBestellungKomplettAusgeliefert @xBestellungStorno = @xKomplettAusgeliefert;
				END
			END
			-- Reservierungen von Amazon löschen
			IF(@kAmazonBestellungPos IS NOT NULL)
			BEGIN
				DELETE dbo.tReserviert
					FROM dbo.tReserviert 
					WHERE dbo.tReserviert.kKey = @kAmazonBestellungPos
						AND dbo.tReserviert.kPlattform = 3;
			END
			IF(EXISTS(SELECT * FROM dbo.tbestellung WHERE dbo.tbestellung.kBestellung = @kBestellung))
			BEGIN
				-- Reservierungen aktualisieren
				IF((EXISTS(SELECT * FROM dbo.tArtikel WHERE dbo.tArtikel.kArtikel = @kArtikel AND dbo.tArtikel.cLagerAktiv = 'N' AND dbo.tArtikel.kVaterArtikel = 0 AND @nType IN (0,1,11)) 
					OR @kArtikel = 0 AND @nType IN (0,11))					
					AND (EXISTS(SELECT * FROM dbo.tbestellung WHERE kBestellung = @kBestellung AND cType IN('U', 'B')))
					AND NOT EXISTS(SELECT * FROM dbo.tReserviert WHERE dbo.tReserviert.kKey = @kBestellpos AND dbo.tReserviert.kPlattform = 1 ))
				BEGIN
					INSERT INTO dbo.tReserviert(kArtikel,fAnzahl,kKey,kPlattform,kBestellung,
												fBestandReserviert,fBestandReserviertEigen)
						VALUES(@kArtikel, @nAnzahl, @kBestellpos, 1, @kBestellung, 
								@nAnzahl, @nAnzahl);
					UPDATE dbo.tlagerbestand
						SET fInAuftraegen = fInAuftraegen + @nAnzahl,
							fVerfuegbar = fVerfuegbar - @nAnzahl
							FROM dbo.tlagerbestand 
							WHERE kArtikel = @kArtikel
								AND dbo.tlagerbestand.nArtikelTyp NOT IN (2,3);
					DECLARE @ArtikelVater TYPE_spUpdateLagerbestand;
					INSERT INTO @ArtikelVater(kArtikel)
						SELECT @kArtikel
							FROM dbo.tlagerbestand 
							WHERE kArtikel = @kArtikel 
								AND dbo.tlagerbestand.nArtikelTyp = 2;
					EXEC dbo.spUpdateLagerbestand @ArtikelVater;
				END
				ELSE
				BEGIN

				     IF(@nEckDatenNichtAktualisieren = 0)
					BEGIN
					    DECLARE @xPosition AS XML;
					    SET @xPosition = (
						    SELECT @kBestellpos AS kKey, 1 AS nPlattform
						    FOR XML PATH('Keys'), TYPE
					    );
					    EXEC dbo.spReservierungAktualisieren @xPosition;
					END;
				END
				-- BestellungEckdaten Aktualisieren
				IF((SELECT nKomplettAusgeliefert FROM dbo.tBestellung WHERE tBestellung.kBestellung = @kBestellung) = 1)
				BEGIN
					EXEC Auftrag.spBestellungKomplettAusgeliefert @xBestellungStorno = NULL, @kBestellung = @kBestellung, @nKomplettAusgeliefert = 0;
				END

				IF(@nEckDatenNichtAktualisieren = 0)
				BEGIN
				  EXEC dbo.spBestellungEckdatenAktualisieren NULL, @kBestellung;
				END;
				
			END
			SET @retry = -1;
		COMMIT
	END TRY
	BEGIN CATCH
		IF(ERROR_NUMBER() = 1205)
			BEGIN
				SET @retry = @retry -1;
				ROLLBACK;
				IF(@retry = 0)
				BEGIN
					SELECT @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
					RAISERROR (	@ErrorMessage, 
								@ErrorSeverity,
								@ErrorState
					);
					SET CONTEXT_INFO 0x0;
					RETURN;
				END
				WAITFOR DELAY '00:00:00:5';
			END
			ELSE 
			BEGIN
				SET @retry = -1;
				SELECT @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
				ROLLBACK;
				RAISERROR (	@ErrorMessage, 
							@ErrorSeverity,
							@ErrorState
				);
				SET CONTEXT_INFO 0x0;
				RETURN;
			END
	END CATCH
	SET CONTEXT_INFO 0x0;
END
go

