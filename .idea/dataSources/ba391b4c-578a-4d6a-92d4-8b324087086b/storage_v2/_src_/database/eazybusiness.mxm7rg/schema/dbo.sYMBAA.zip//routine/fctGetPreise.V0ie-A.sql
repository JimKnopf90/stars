CREATE FUNCTION [dbo].[fctGetPreise](@kKundengruppe BIGINT, @cLandISO VARCHAR(5), @kShop BIGINT, @kArtikel INT = NULL)
RETURNS TABLE
    AS
    RETURN(
    --
    -- Copyright (c) 2012-2017 by JTL Software GmbH
    -- Datum: $Date$
    -- Version: $Rev$
    -- Autor: MK/SB
    --
    SELECT 
	   tartikel.kArtikel,
	   ArtikelPreise.fNettoPreis AS fNettoPreis,
	   CAST(ArtikelPreise.fRabatt AS DECIMAL(28,14)) AS fRabatt,
	   CAST(ArtikelPreise.fRabattierterNettoPreis AS DECIMAL(28,14)) AS fRabattierterNettoPreis,
	   CAST(ROUND(ArtikelPreise.fRabattierterNettoPreis * (100 + tsteuersatz.fSteuersatz) / 100, 4) AS DECIMAL(28,14)) AS fRabattierterBruttoPreis,
	   CAST(tsteuersatz.fSteuersatz AS DECIMAL(28,14)) AS fSteuersatz
    FROM tartikel
    JOIN tsteuerzoneland ON tsteuerzoneland.cISO = @cLandISO
    JOIN tsteuerzone ON tsteuerzone.kSteuerzone = tsteuerzoneland.kSteuerzone
    JOIN tsteuersatz ON tsteuersatz.kSteuerzone = tsteuerzone.kSteuerzone AND tsteuersatz.kSteuerklasse = tartikel.kSteuerklasse
    JOIN (
	    SELECT 
		  Preise.kArtikel AS kArtikel,
		  ISNULL(Rabatte.fRabatt, 0.0) AS fRabatt,
		  Preise.fNettoPreis AS fNettoPreis,
		  Preise.fNettoPreis * (100.0 - ISNULL(Rabatte.fRabatt, 0.0)) / 100.0 AS fRabattierterNettoPreis
	   FROM (
		  SELECT 
			 tartikel.kArtikel AS kArtikel,
			 ISNULL(tPreisDetail.fNettoPreis, tartikel.fVKNetto) AS fNettoPreis
		  FROM
			 tartikel 
		  LEFT JOIN tPreis ON tPreis.kArtikel = tartikel.kArtikel AND tPreis.kKundenGruppe = @kKundengruppe AND tPreis.kShop = @kShop 
		  LEFT JOIN tPreisDetail ON tPreisDetail.kPreis = tPreis.kPreis AND tPreisDetail.nAnzahlAb = 0
	   ) AS Preise
	   LEFT JOIN (
		  SELECT 
			 tartikel.kArtikel AS kArtikel,
			 CASE WHEN MAX(tKategorieRabatt.fRabatt) > MAX(ISNULL(tKundenGruppe.fRabatt, 0.0))
				THEN MAX(ISNULL(tKategorieRabatt.fRabatt, 0.0))
				ELSE MAX(ISNULL(tKundenGruppe.fRabatt, 0.0))
			 END AS fRabatt
		  FROM tartikel
		  JOIN tKundenGruppe ON tKundenGruppe.kKundenGruppe = @kKundengruppe
		  LEFT JOIN tkategorieartikel ON (tkategorieartikel.kArtikel = tartikel.kArtikel OR tkategorieartikel.kArtikel = tartikel.kVaterArtikel) 
		  LEFT JOIN tKategorieRabatt ON tKategorieRabatt.kShop = @kShop 
			 AND tKategorieRabatt.kKundenGruppe = tKundenGruppe.kKundenGruppe
			 AND tKategorieRabatt.kKategorie = tkategorieartikel.kKategorie 
		  GROUP BY tartikel.kArtikel
	   ) AS Rabatte ON Rabatte.kArtikel = Preise.kArtikel
    ) AS ArtikelPreise ON ArtikelPreise.kArtikel = tartikel.kArtikel
    WHERE tArtikel.kArtikel = (CASE WHEN @kArtikel IS NULL 
								    THEN tArtikel.kArtikel
								    ELSE @kArtikel 
								  END)
)
go

