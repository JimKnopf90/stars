--- 
--- spShopWurzelKategoriesetzenAlle
---

CREATE PROCEDURE [dbo].[spShopWurzelKategoriesetzenAlle]
AS
BEGIN

	DECLARE cur_Shops CURSOR LOCAL FAST_FORWARD FOR 
	SELECT kShop, kKategorie AS kWurzelkategorie
	FROM dbo.tShop
	WHERE kKategorie > 0;

	OPEN cur_Shops;

	DECLARE @kShop AS INT;
	DECLARE @kWurzelkategorie AS INT;
	
	FETCH NEXT FROM cur_Shops INTO @kShop, @kWurzelkategorie

	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC dbo.spShopWurzelKategoriesetzen @kShop, @kWurzelkategorie;
		FETCH NEXT FROM cur_Shops INTO @kShop, @kWurzelkategorie;
	END

	CLOSE cur_Shops;
	DEALLOCATE cur_Shops;
END
go

