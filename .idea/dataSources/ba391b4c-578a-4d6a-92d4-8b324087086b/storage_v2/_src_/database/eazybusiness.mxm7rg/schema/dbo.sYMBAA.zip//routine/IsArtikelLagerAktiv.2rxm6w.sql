CREATE FUNCTION dbo.IsArtikelLagerAktiv
(
      @kArtikel INT
)    
RETURNS BIT

AS
 BEGIN
 DECLARE @ResultBit BIT 
 SET @ResultBit = 0;

 IF EXISTS (SELECT * FROM dbo.tArtikel WHERE kArtikel = @kArtikel AND cLagerAktiv = 'Y')
      SELECT @ResultBit = 1;

RETURN @ResultBit;

END;
go

