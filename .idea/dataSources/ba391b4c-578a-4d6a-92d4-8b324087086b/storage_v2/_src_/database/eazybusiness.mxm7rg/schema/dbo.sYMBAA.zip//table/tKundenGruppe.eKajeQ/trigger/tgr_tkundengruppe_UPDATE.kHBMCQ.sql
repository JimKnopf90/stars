CREATE TRIGGER tgr_tkundengruppe_UPDATE
ON dbo.tkundengruppe
AFTER UPDATE
AS
BEGIN
	IF(EXISTS(SELECT * 
				FROM DELETED
				JOIN INSERTED ON INSERTED.kKundenGruppe = DELETED.kKundenGruppe
				JOIN dbo.pf_user ON DELETED.kKundenGruppe = pf_user.kKundengruppe
				WHERE INSERTED.kKundenGruppe <> DELETED.kKundenGruppe))
	BEGIN
		UPDATE dbo.pf_amazon_angebot_ext
			SET fPreis = pf_amazon_angebot.fPrice
			FROM dbo.pf_amazon_angebot_ext
			JOIN dbo.pf_amazon_angebot ON pf_amazon_angebot_ext.kUser = pf_amazon_angebot.kUser
										AND pf_amazon_angebot_ext.cSellerSKU = pf_amazon_angebot.cSellerSKU
	END
END
go

