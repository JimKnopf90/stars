CREATE TRIGGER [dbo].[tgr_tlieferant_INSUP]
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--
ON [dbo].[tlieferant]
AFTER INSERT, UPDATE
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
    IF(EXISTS(SELECT dbo.tlieferant.kLieferant 
				FROM dbo.tlieferant WITH(NOLOCK) 
				WHERE dbo.tlieferant.cWaehrungISO IS NULL 
					OR dbo.tlieferant.cWaehrungISO = ''))
    BEGIN
        DECLARE @cStandardISO VARCHAR(20)
        IF(EXISTS(SELECT TOP(1) dbo.tWaehrung.cEAMapping 
					FROM dbo.tWaehrung WITH(NOLOCK) 
					WHERE dbo.tWaehrung.nStandard = 1))
        BEGIN
            SET @cStandardISO = (SELECT TOP(1) dbo.tWaehrung.cEAMapping 
									FROM dbo.tWaehrung WITH(NOLOCK) 
									WHERE dbo.tWaehrung.nStandard = 1)
        END
        ELSE
        BEGIN
			IF(NOT EXISTS(SELECT dbo.tWaehrung.kWaehrung 
							FROM dbo.tWaehrung WITH(NOLOCK) 
							WHERE (dbo.tWaehrung.cEAMapping IS NOT NULL) 
								AND (tWaehrung.cEAMapping <> '')))
			BEGIN
				DECLARE @kWaehrung INT
				DECLARE @TableVar TABLE(Nummer INT)
				INSERT INTO @TableVar(Nummer) 
					EXEC dbo.spGetAndUpdatePK 'tWaehrung'
				SET @kWaehrung = (SELECT Nummer FROM @TableVar)

				INSERT INTO dbo.tWaehrung WITH(ROWLOCK) (kWaehrung, cName, cNameHTML, fFaktor, cEAMapping, nStandard, nVorBetrag, cTrennzeichenCent, cTrennzeichenTausend, dAktualisiert)
					VALUES(@kWaehrung, 'EUR', '&euro', 1, 'EUR', 1, 0, ',', '.', GETDATE())
			END
			SET @cStandardISO = (SELECT TOP(1) dbo.tWaehrung.cEAMapping 
									FROM tWaehrung WITH(NOLOCK) 
									WHERE (dbo.tWaehrung.cEAMapping IS NOT NULL) 
										AND (tWaehrung.cEAMapping <> ''))
        END
        UPDATE dbo.tlieferant WITH(ROWLOCK) 
			SET dbo.tlieferant.cWaehrungISO = @cStandardISO 
			WHERE dbo.tlieferant.cWaehrungISO IS NULL 
				OR dbo.tlieferant.cWaehrungISO = ''
    END
	DELETE FROM dbo.tlieferant
		WHERE dbo.tlieferant.cAktiv = 'N';

    IF(UPDATE(nLieferZeit))
    BEGIN

        IF(EXISTS(SELECT INSERTED.kLieferant FROM INSERTED  
	             JOIN DELETED ON INSERTED.kLieferant = DELETED.kLieferant AND INSERTED.nLieferzeit != DELETED.nLieferzeit))
	   BEGIN
	   

		  UPDATE dbo.tliefartikel SET dbo.tliefartikel.nLieferzeit = Lieferant.nLieferzeit
		  FROM dbo.tliefartikel
		  JOIN INSERTED Lieferant ON Lieferant.kLieferant = tliefartikel.tLieferant_kLieferant
		  JOIN DELETED LieferantDel ON LieferantDel.kLieferant = Lieferant.kLieferant AND LieferantDel.nLieferzeit != Lieferant.nLieferzeit
		  AND dbo.tliefartikel.nLieferzeitAusLieferant = 1;

	   
	   END; 
    END;

      -- Wenn Lieferant VTSFrei dann alle Lieferartikel ohne MWS.
    IF(UPDATE(nVSTFrei))
    BEGIN

        IF(EXISTS(SELECT INSERTED.kLieferant FROM INSERTED  
	             JOIN DELETED ON INSERTED.kLieferant = DELETED.kLieferant AND INSERTED.nVSTFrei != DELETED.nVSTFrei
			   AND  INSERTED.nVSTFrei = 1))
	   BEGIN

		  UPDATE dbo.tliefartikel SET dbo.tliefartikel.fMwSt  = 0
		  FROM dbo.tliefartikel
		  JOIN INSERTED Lieferant ON Lieferant.kLieferant = tliefartikel.tLieferant_kLieferant
	   END; 
    END;
END;
go

