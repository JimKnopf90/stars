CREATE TRIGGER [dbo].[tgr_tWarenlagerAusgang_INSUPDEL]
ON [dbo].[tWarenLagerAusgang]
AFTER INSERT, UPDATE, DELETE
AS
	IF(CONTEXT_INFO() IN(0x5089,0x6001,0x6002))
	BEGIN
		RETURN;
	END
	ROLLBACK;
	RAISERROR (N'Die Tabelle dbo.tWarenlagerAusgang kann nur über die SPs spWarenlagerAusgangSchreiben und spWarenlagerAusgangPicklistePos gefüllt werden.', 15,1);
go

