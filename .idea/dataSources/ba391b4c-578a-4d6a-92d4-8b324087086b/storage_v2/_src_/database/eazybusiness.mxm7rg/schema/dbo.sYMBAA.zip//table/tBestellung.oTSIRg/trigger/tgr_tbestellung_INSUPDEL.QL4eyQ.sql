CREATE TRIGGER [dbo].[tgr_tbestellung_INSUPDEL]
ON [dbo].[tBestellung]
AFTER INSERT, UPDATE, DELETE
AS
	IF NOT EXISTS(SELECT * FROM INSERTED FULL JOIN DELETED ON INSERTED.kBestellung = DELETED.kBestellung)
	BEGIN
		RETURN
	END;

    --
	-- Ausnahmen:
	--
	IF(CONTEXT_INFO() IN(0x5104, 0x5105, 0x5106, 0x5021))
	BEGIN
		RETURN;
	END
	IF(NOT(UPDATE(nKomplettAusgeliefert)
		OR UPDATE(nStorno)
		OR UPDATE(cType)
		OR UPDATE(cWaehrung)
		OR UPDATE(fRabatt)
		OR UPDATE(fGutschein)
		OR UPDATE(fVersandBruttoPreis)
		OR UPDATE(fSkonto)
		OR UPDATE(fFaktor)
		OR UPDATE(dBezahlt))
		AND EXISTS(SELECT * FROM INSERTED JOIN DELETED ON INSERTED.kBestellung = DELETED.kBestellung))
	BEGIN
		RETURN
	END
	ROLLBACK;
	RAISERROR (N'Die Tabelle dbo.tbestellung kann nur über die SPs spBestellungAendern, spBestellungAnlegen und spBestellungLoeschen geändert werden.', 15,1);
go

