--- 
--- spPlatzWarenlagerUmlagern
---

--- 
--- Ruf die spPlatzUmlagern auf, prüft dabei aber noch, ob sich das Warenlager geändert hat und korrigiert ggf. tlagerbestandProLagerLagerartikel
--- Zudem wird noch verhindert, dass JTL-Fulfillment Artikel in ein anderes Lager umgelagert werden können.
---

CREATE PROCEDURE [dbo].[spPlatzWarenlagerUmlagern]
	@kWarenLagerPlatzStart INT, 
	@kWarenLagerPlatzZiel INT,
	@kBenutzer INT,
	@cKommentar VARCHAR(255)
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
	DECLARE @kWarenlagerAlt INT;
	DECLARE @kWarenlagerNeu INT;
	SELECT @kWarenlagerAlt = WarenlagerPlatz.kWarenLager FROM dbo.tWarenLagerPlatz AS WarenlagerPlatz WHERE WarenlagerPlatz.kWarenLagerPlatz = @kWarenLagerPlatzStart;
	SELECT @kWarenlagerNeu = WarenlagerPlatz.kWarenLager FROM dbo.tWarenLagerPlatz AS WarenlagerPlatz WHERE WarenlagerPlatz.kWarenLagerPlatz = @kWarenLagerPlatzZiel;
	BEGIN TRY
	IF(@kWarenlagerAlt = @kWarenlagerNeu)
		BEGIN
			EXEC dbo.spPlatzUmlagern @kWarenLagerPlatzStart, @kWarenLagerPlatzZiel, @kBenutzer, @cKommentar;		
		END
		ELSE		
		BEGIN

			DECLARE @temp_ArtikelZumUmbuchen TABLE(kArtikel INT, fMenge DECIMAL(28,14));
			INSERT INTO @temp_ArtikelZumUmbuchen(kArtikel,fMenge)
			SELECT dbo.twarenlagereingang.kArtikel, SUM(dbo.twarenlagereingang.fAnzahlAktuell)
			FROM dbo.twarenlagereingang WITH(NOLOCK)
			WHERE dbo.tWarenlagerEingang.kWarenlagerPlatz = @kWarenLagerPlatzStart
			AND fAnzahlAktuell > 0
			GROUP BY dbo.twarenlagereingang.kArtikel

			IF ((SELECT COUNT(*)
				FROM dbo.tliefartikel	AS LieferantenArtikel
				-- Artikel, welche über das JTL-Fulfillment Network verschickt werden, haben eine JTL-Fulfillment Product Id (jfpid)
				JOIN dbo.tArtikel		AS Artikel				ON Artikel.kArtikel = LieferantenArtikel.tArtikel_kArtikel AND NOT (Artikel.cJfpid IS NULL OR Artikel.cJfpid = '') 
				JOIN @temp_ArtikelZumUmbuchen AS  ArtikelZumUmbuchen ON  ArtikelZumUmbuchen.kArtikel = Artikel.kArtikel
				-- Ist es ein Fremdartikel, welchen ich als Fulfillment Dienstleister einlager, ist mein Fulfillment-Kunde als Lieferant mit nJTLFulfillment angelegt
				JOIN dbo.tlieferant		AS Lieferant			ON Lieferant.kLieferant = LieferantenArtikel.tLieferant_kLieferant AND LieferantenArtikel.tArtikel_kArtikel = Artikel.kArtikel AND Lieferant.nJtlFulfillment = 1) > 0) 
			BEGIN
				RAISERROR('203000901',15,1, N'JTL-Fulfillment Network Artikel können nicht in ein anderes Lager umgelagert werden.');
			END

			EXEC dbo.spPlatzUmlagern @kWarenLagerPlatzStart, @kWarenLagerPlatzZiel, @kBenutzer, @cKommentar;
			DECLARE @kUmlagArtikel INT;
			DECLARE @fUmlagAnzahl DECIMAL(28,14);
			DECLARE cur_WarenLagerEingang CURSOR LOCAL FAST_FORWARD FOR
			SELECT kArtikel,fMenge FROM @temp_ArtikelZumUmbuchen;


			OPEN cur_WarenLagerEingang
			FETCH NEXT FROM cur_WarenLagerEingang INTO @kUmlagArtikel,@fUmlagAnzahl

			WHILE @@FETCH_STATUS = 0
			BEGIN
			
				UPDATE tlagerbestandProLagerLagerartikel SET fBestand = fBestand - @fUmlagAnzahl WHERE kArtikel =  @kUmlagArtikel AND kWarenlager = @kWarenlagerAlt
				UPDATE tlagerbestandProLagerLagerartikel SET fBestand = fBestand + @fUmlagAnzahl WHERE kArtikel =  @kUmlagArtikel AND kWarenlager = @kWarenlagerNeu

			 FETCH NEXT FROM cur_WarenLagerEingang INTO @kUmlagArtikel,@fUmlagAnzahl;
			 END;
		END
	END TRY
		BEGIN CATCH	
			DECLARE @errorMessage varchar(256) = ERROR_MESSAGE();
			DECLARE @severity INT = ERROR_SEVERITY();
			DECLARE @errorState INT = ERROR_STATE();
			RAISERROR ( @errorMessage, @severity,@errorState );
		END CATCH		
END
go

