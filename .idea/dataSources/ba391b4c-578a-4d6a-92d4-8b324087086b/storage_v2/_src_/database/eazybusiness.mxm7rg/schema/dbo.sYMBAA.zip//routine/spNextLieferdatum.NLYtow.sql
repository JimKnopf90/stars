--- 
--- spNextLieferdatum
---

CREATE PROCEDURE [dbo].[spNextLieferdatum]
    @typeArtikel TYPE_spNextLieferdatum READONLY
    --
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
-- Autor: MK
--
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
BEGIN
    IF(object_id('tempdb..#TempResult') IS NOT NULL)
    BEGIN
	  DROP TABLE #TempResult
    END
    DECLARE @Artikel TABLE(kArtikel INT, dLieferdatum DATETIME);
    INSERT INTO @Artikel(kArtikel)
	SELECT kArtikel
	FROM @typeArtikel

    DECLARE @dLieferdatum DATETIME;

    SELECT Artikel.kArtikel, (POS.fMenge - POS.fMengeGeliefert) AS MengeOffen, POS.dLieferdatum, 
		  RANK() OVER(PARTITION BY POS.kArtikel ORDER BY POS.dLieferdatum) AS Rang
		  INTO #TempResult
	   FROM tLieferantenbestellungPos AS POS
	   JOIN tLieferantenbestellung ON POS.kLieferantenBestellung = tLieferantenbestellung.kLieferantenBestellung
	   JOIN @Artikel AS Artikel ON POS.kArtikel = Artikel.kArtikel
	   WHERE nStatus < 100 AND nStatus >= 5 AND (POS.fMenge - POS.fMengeGeliefert) > 0.0
    --
    -- Kein Fifo aktiv
    --
    IF(ISNULL((SELECT CONVERT(BIT, ISNULL(cValue, 0)) FROM toptions WITH(NOLOCK) WHERE cKey = 'FiFoAuftragsReservierung'), 0) = 0)
    BEGIN
	   UPDATE #TempResult SET dLieferdatum = Result.Lieferdatum	      
	   FROM #TempResult
	   JOIN 
	   (
		  SELECT  tReserviert.kArtikel, ISNULL(a.dLieferdatum,0) AS Lieferdatum,
				(SELECT SUM(ISNULL(b.MengeOffen,0.0)) 
				    FROM #TempResult AS b 
				    WHERE b.Rang <= a.Rang AND b.kArtikel = a.kArtikel
				) AS LaufendeSumme,
				SUM(tReserviert.fBestandReserviert - tReserviert.fAnzahl) AS SummeRes
			 FROM #TempResult AS a
			 JOIN tReserviert ON a.kArtikel = tReserviert.kArtikel
			 GROUP BY a.kArtikel, tReserviert.kArtikel, a.dLieferdatum, a.Rang
			 HAVING SUM(tReserviert.fBestandReserviert - tReserviert.fAnzahl) >= 0
	   ) AS Result ON #TempResult.kArtikel = Result.kArtikel
	   WHERE SummeRes < LaufendeSumme
    END
    ELSE
    BEGIN
	   --
	   -- Fifo aktiv
	   --
	   UPDATE #TempResult SET dLieferdatum = Result.Lieferdatum	      
	   FROM #TempResult
	   JOIN 
	   (
		  SELECT  tReserviert.kArtikel, ISNULL(a.dLieferdatum,0) AS Lieferdatum,
				(SELECT SUM(b.MengeOffen) 
				    FROM #TempResult AS b 
				    WHERE b.Rang <= a.Rang AND b.kArtikel = a.kArtikel
				) AS LaufendeSumme,
				SUM(tReserviert.fAnzahl - tReserviert.fBestandReserviert) AS SummeRes
			 FROM #TempResult AS a
			 JOIN tReserviert ON a.kArtikel = tReserviert.kArtikel
			 GROUP BY a.kArtikel, tReserviert.kArtikel, a.dLieferdatum, a.Rang
			 HAVING SUM(tReserviert.fAnzahl - tReserviert.fBestandReserviert) >= 0
	   ) AS Result ON #TempResult.kArtikel = Result.kArtikel
	   WHERE Result.SummeRes < Result.LaufendeSumme
    END
    BEGIN TRANSACTION
	   UPDATE tartikel SET tartikel.dZulaufVerfuegbarAm = #TempResult.dLieferdatum 
		  FROM tArtikel 
		  JOIN #TempResult ON #TempResult.kArtikel = tArtikel.kArtikel
    COMMIT
END
go

