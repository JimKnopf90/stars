CREATE FUNCTION [dbo].[ifNachschubListe] ( @kWarenLager AS INT )
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Author:		GJ
-- Version: $Rev$
-- Beschreibung:	Gibt eine Nachschubliste mit Artikel aus dem Nachschub-Lagerbereich zurück, die in dem Komissionierbereich fehlen
--
RETURNS TABLE
AS
	RETURN

	WITH 	Standardartikel
	AS
	(
		SELECT
			Artikel.kArtikel
		,	Artikel.cArtNr
		,	Artikel.cBarcode
		,	Artikel.cHAN
		,	Artikel.cISBN
		,	Artikel.cASIN
		,	Artikel.cUPC
		,	Artikel.nCharge
		,	Artikel.nMHD
		,	ArtikelBeschreibung.cName AS cName
		FROM
					dbo.tartikel			 AS Artikel				
			JOIN	dbo.tSpracheUsed		 AS SpracheUsed			 	ON SpracheUsed.nStandard = 1
			JOIN	dbo.tArtikelBeschreibung AS ArtikelBeschreibung	 	ON ArtikelBeschreibung.kArtikel = Artikel.kArtikel AND ArtikelBeschreibung.kSprache = SpracheUsed.kSprache AND ArtikelBeschreibung.kPlattform = 1
	)
	, 		OffeneMenge
	AS
	(
		SELECT
			WarenlagerArtikelOptionen.kArtikel
		,	ISNULL(MengePickbereich.fMengeImPickbereich,0) AS fMengeImPickbereich
		,	WarenlagerArtikelOptionen.fMindestMenge - ISNULL( MengePickbereich.fMengeImPickbereich , 0 ) AS BenoetigteMenge
		FROM
						dbo.tWarenlagerArtikelOptionen	 AS WarenlagerArtikelOptionen	
			LEFT JOIN	(
			SELECT
				WarenLagerEingang.kArtikel
			,	SUM( WarenLagerEingang.fAnzahlAktuell - WarenLagerEingang.fAnzahlReserviertPickpos ) AS fMengeImPickbereich
			FROM
						dbo.tWMSLagerBereich			 AS WmsLagerBereich				
				JOIN	dbo.tWMSLagerBereichPlatz		 AS WmsLagerBereichPlatz		 	ON WmsLagerBereichPlatz.kWMSLagerBereich = WmsLagerBereich.kWMSLagerBereich
				JOIN	dbo.tWarenLagerEingang			 AS WarenLagerEingang			 	ON WarenLagerEingang.kWarenLagerPlatz = WmsLagerBereichPlatz.kWarenLagerPlatz
				JOIN	dbo.tWarenlagerArtikelOptionen	 AS WarenlagerArtikelOptionen	 	ON WarenlagerArtikelOptionen.kArtikel = WarenLagerEingang.kArtikel AND WarenlagerArtikelOptionen.fMindestMenge > 0
			WHERE
				WarenLagerEingang.fAnzahlAktuell - WarenLagerEingang.fAnzahlReserviertPickpos > 0
				AND WmsLagerBereich.kWarenLager = @kWarenLager
				AND WmsLagerBereich.nTyp = 1
			GROUP BY
				WarenLagerEingang.kArtikel )			 AS MengePickbereich			 ON MengePickbereich.kArtikel = WarenlagerArtikelOptionen.kArtikel
		WHERE
			WarenlagerArtikelOptionen.fMindestMenge - ISNULL( MengePickbereich.fMengeImPickbereich , 0 ) > 0
			AND WarenlagerArtikelOptionen.kWarenlager = @kWarenLager
	)
	, 		MengeAufWagen
	AS
	(
		SELECT
			WarenlagerEingang.kArtikel
		,	SUM( WarenlagerEingang.fAnzahlAktuell ) AS MengeAufWagen
		FROM
					dbo.tWarenLagerPlatz	 AS WarenLagerPlatz		
			JOIN	dbo.tWarenlagerEingang	 AS WarenlagerEingang	 ON WarenlagerEingang.kWarenLagerPlatz = WarenLagerPlatz.kWarenLagerPlatz
		WHERE
			WarenLagerPlatz.kWarenLagerPlatzTyp = 9 -- Umlagerungswagen, man kann auch generell den Typ Umlagerungswagen nehmen
		GROUP BY
			WarenlagerEingang.kArtikel
	)
	, 		NachschubArtikel
	AS
	(
		SELECT
			WarenLagerEingang.kWarenLagerPlatz
		,	WarenLagerEingang.kArtikel
		,	MIN(WarenLagerEingang.dErstellt ) AS dErstellt
		,	OffeneMenge.BenoetigteMenge
		,	OffeneMenge.fMengeImPickbereich
		,	SUM( WarenLagerEingang.fAnzahlAktuell - ISNULL( WarenLagerEingang.fAnzahlReserviertPickpos , 0 )) AS fMengeMax
		,	CASE WHEN SUM( WarenLagerEingang.fAnzahlAktuell - ISNULL( WarenLagerEingang.fAnzahlReserviertPickpos , 0 )) > MAX( ISNULL( OffeneMenge.BenoetigteMenge , 0 )) - MAX( ISNULL( MengeAufWagen.MengeAufWagen , 0 )) --Menge aufm Platz ist größer als die Menge die man noch braucht
					THEN MAX( ISNULL( OffeneMenge.BenoetigteMenge , 0 )) - MAX( ISNULL( MengeAufWagen.MengeAufWagen , 0 ))
					ELSE SUM( WarenLagerEingang.fAnzahlAktuell - ISNULL( WarenLagerEingang.fAnzahlReserviertPickpos , 0 )) END AS fMenge
		, WarenlagerArtikelOptionen.fNachschiebenAb AS fNachschiebenAb

		FROM
						dbo.tWMSLagerBereich			 AS WmsLagerBereich				
			JOIN		dbo.tWMSLagerBereichPlatz		 AS WmsLagerBereichPlatz		 	ON WmsLagerBereichPlatz.kWMSLagerBereich = WmsLagerBereich.kWMSLagerBereich
			JOIN		dbo.tWarenlagerPlatz			 AS WarenLagerPlatz				 	ON WarenLagerPlatz.kWarenLagerPlatz = WmsLagerBereichPlatz.kWarenLagerPlatz
			JOIN		dbo.tWarenLagerEingang			 AS WarenLagerEingang			 	ON WarenLagerEingang.kWarenLagerPlatz = WarenLagerPlatz.kWarenLagerPlatz
			JOIN		dbo.tWarenlagerArtikelOptionen	 AS WarenlagerArtikelOptionen	 	ON WarenlagerArtikelOptionen.kArtikel = WarenLagerEingang.kArtikel AND WarenlagerArtikelOptionen.fMindestMenge > 0 AND WarenlagerArtikelOptionen.kWarenlager = WarenLagerPlatz.kWarenLager
			JOIN		OffeneMenge						 AS OffeneMenge					 	ON OffeneMenge.kArtikel = WarenlagerArtikelOptionen.kArtikel
			LEFT JOIN	MengeAufWagen					 AS MengeAufWagen				 	ON MengeAufWagen.kArtikel = WarenlagerArtikelOptionen.kArtikel
		WHERE
			WarenLagerEingang.fAnzahlAktuell - ISNULL( WarenLagerEingang.fAnzahlReserviertPickpos , 0 ) > 0
			AND WmsLagerBereich.kWarenLager = @kWarenLager
			AND WmsLagerBereich.nTyp = 2
		GROUP BY
				WarenLagerEingang.kWarenLagerPlatz
			, 	WarenLagerEingang.kArtikel
			, 	OffeneMenge.BenoetigteMenge
			, 	OffeneMenge.fMengeImPickbereich
			,	WarenlagerArtikelOptionen.fNachschiebenAb
	)
	, 		NachschubArtikelBild
	AS
	(
		SELECT DISTINCT
			NachschubArtikel.BenoetigteMenge
		,	NachschubArtikel.dErstellt
		,	NachschubArtikel.fMenge
		,	NachschubArtikel.fMengeImPickbereich
		,	NachschubArtikel.fMengeMax
		,	NachschubArtikel.kArtikel
		,	NachschubArtikel.kWarenLagerPlatz
		,	NachschubArtikel.fNachschiebenAb
		,	CASE 	WHEN Bild.kBild IS NULL THEN 0
											ELSE 1 END AS nBild
		FROM
						NachschubArtikel			 AS NachschubArtikel	
			LEFT JOIN	dbo.tArtikelbildPlattform	 AS ArtikelbildPlattform 	ON ArtikelbildPlattform.kartikel = NachschubArtikel.kArtikel AND ArtikelbildPlattform.kplattform = 10002
			LEFT JOIN	tBild						 AS Bild				 	ON Bild.kBild = ArtikelbildPlattform.kbild
	)
	, 		OffeneArtikel
	AS
	(
		SELECT
			Reserviert.kArtikel
		,	SUM(Reserviert.fAnzahlOffen) OffeneMenge
		,	COUNT(DISTINCT Reserviert.kBestellung) Bestellungen
		FROM
			Versand.vBestellPosLieferInfo AS Reserviert
		GROUP BY
			Reserviert.kArtikel
	)
	SELECT
		Artikel.kArtikel
	,	Artikel.cArtNr
	,	Artikel.cName AS cArtName
	,	Artikel.cBarcode
	,	Artikel.cHAN
	,	Artikel.cISBN
	,	Artikel.cASIN
	,	Artikel.cUPC
	,	Artikel.nCharge
	,	Artikel.nMHD
	,	NachschubArtikel.kWarenLagerPlatz
	,	NachschubArtikel.BenoetigteMenge AS fBenoetigteMenge
	,	NachschubArtikel.fMenge AS fMenge
	,	WarenLagerPlatz.cName AS cWarenlagerPlatz
	,	WarenLagerPlatz.nSort
	,	NachschubArtikel.fMengeMax
	,	NachschubArtikel.nBild
	,	ROW_NUMBER( )OVER( ORDER BY WarenLagerPlatz.nSort ASC , WarenLagerPlatz.cName ASC ) AS nRow
	,	Reserviert.OffeneMenge
	,	Reserviert.Bestellungen
	,	NachschubArtikel.dErstellt
	,	NachschubArtikel.fMengeImPickbereich
	,	Reserviert.Bestellungen - ISNULL(NachschubArtikel.fMengeImPickbereich,0) AS fFehlendeMengeImPickbereich
	FROM
					NachschubArtikelBild AS NachschubArtikel
		JOIN		Standardartikel		 AS Artikel			 	ON NachschubArtikel.kArtikel = Artikel.kArtikel
		JOIN		dbo.tWarenLagerPlatz AS WarenLagerPlatz	 	ON WarenLagerPlatz.kWarenLagerPlatz = NachschubArtikel.kWarenLagerPlatz
		LEFT JOIN	OffeneArtikel		 AS Reserviert		 	ON Reserviert.kArtikel = Artikel.kArtikel

	WHERE NachschubArtikel.fMenge > 0
	AND NachschubArtikel.fMengeImPickbereich >= NachschubArtikel.fNachschiebenAb;
go

