--- 
--- spPicklisteposInBox
---

CREATE PROCEDURE [dbo].[spPicklisteposInBox]
  @kPicklistePos INT,               -- Die Pickposition die in Box gepackt werden soll
  @kLhm INT,               -- Das LHM auf das die Warenlagereinheit der Pickposition gestellt werden soll
  @kBenutzer INT,               
  @fPickMenge DECIMAL(28,14),     -- Die Menge die von dieser Pickposition in die Bos gepackt werden soll
  @dTimestamp DATETIME,          -- Falls nicht aus der DB aufgerufen, dann leer lassen
  @cMhd VARCHAR(255),      -- Falls eine MHD für die Pickposition erfasst wurde
  @cCharge VARCHAR(255),      -- Falls eine Charge für die Pickposition erfasst wurde
  @nPickposStatus INT,               -- Der Status ab welchen die Pickpositionen betrachtet werden. 20 = Pick, 30 = InBoxlegen. 
  @nRet INT OUT            -- FehlerCode
--  
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Datum: $Date$
-- Version: $Rev$
--

AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;
	DECLARE @fPPAnzahl          DECIMAL(28,14);
	DECLARE @fAufPlatzAnzahl    DECIMAL(28,14);
	DECLARE @cPPChargenNr       VARCHAR(255);
	DECLARE @cPPMHD             VARCHAR(255);
	DECLARE @kPPWarenLagerPlatz BIGINT;
	DECLARE @kArtikel           INT;
	DECLARE @dIsTimestamp       DATETIME;
  
	BEGIN TRAN T1
		BEGIN TRY
			SET @nRet = 0;

			IF(LEN(@cMhd) > 0)
			BEGIN
			  SET @cMhd = CONVERT(VARCHAR,CONVERT(DATETIME,@cMhd,104), 104);
			END;
  
			-- Holen der Daten der Pickposition und deren Warenlagereingang
			SELECT @fPPAnzahl = dbo.tPicklistePos.fAnzahl,@cPPChargenNr = dbo.tWarenLagerEingang.cChargenNr,@cPPMHD = CONVERT(VARCHAR,dbo.tWarenlagerEingang.dMHD, 104),@kPPWarenLagerPlatz = dbo.tWarenLagerEingang.kWarenLagerPlatz,@kArtikel = dbo.tWarenLagerEingang.kArtikel
			FROM dbo.tPicklistePos WITH(NOLOCK) 
			JOIN dbo.tWarenLagerEingang WITH(NOLOCK) on dbo.tWarenLagerEingang.kWarenLagerEingang = dbo.tPicklistePos.kWarenLagerEingang
			WHERE dbo.tPicklistePos.kPicklistePos = @kPicklistePos 
			AND dbo.tPicklistePos.nStatus < @nPickposStatus;

			IF(@kArtikel is not null)
			BEGIN	
				IF(@dTimestamp is null)   -- Falls kein Timestamp übergeben holen wir uns systemzeit
					SET @dIsTimestamp = GETDATE();
				ELSE
					SET @dIsTimestamp = @dTimestamp;

			-- Falls die übergebene Charge/MHD nicht mit der der Warenlagereingang der Pickpos übereinstimmt, müßen wir die Warenlagereingänge tauschen
			IF((@cPPChargenNr != @cCharge and @cCharge is not null) or (@cPPMHD != @cMhd  and @cMhd is not null ))
			BEGIN
				IF(@fPPAnzahl > @fPickMenge) -- Wenn PP mehr Menge hat als wir noch wollen, PP splitten
				BEGIN
					SET @fPPAnzahl = @fPickMenge;

					EXEC dbo.spPicklistePosSplitten
						@kPicklistePos  = @kPicklistePos,
						@nMenge  = @fPickMenge,
						@kNewPicklistePos = @kPicklistePos OUTPUT,
						@nRet = @nRet OUTPUT;
				END;


			    -- Hole Anzahl der Menge der passenden Artikel vom Platz wo die Pickpos drauf zeigt
			    SELECT @fAufPlatzAnzahl = ISNULL(SUM(ISNULL(dbo.tWarenLagerEingang.fAnzahlAktuell,0)),0)
		         FROM dbo.tWarenLagerEingang WITH(NOLOCK) 
		         WHERE dbo.tWarenLagerEingang.kArtikel = @kArtikel
		         AND dbo.tWarenLagerEingang.kWarenlagerplatz = @kPPWarenLagerPlatz
		         AND (dbo.tWarenLagerEingang.cChargenNr = @cCharge or @cCharge is null)
		         AND (CONVERT(VARCHAR,dbo.tWarenlagerEingang.dMHD, 104) = @cMhd or @cMhd is null);

			    -- Sind auf Platz nicht genug Artikel ? Wenn nicht Picken wir über Plätze
			    IF(@fAufPlatzAnzahl < @fPickMenge) 
			    BEGIN
				    -- Tausche und Pick der Pickpos mit einer auf einen anderen Platz (der selben Pickliste) wo es die Menge mit der Charge/MHD gibt
				    EXEC dbo.spTauschePicklistePosUeberPlaetze
							    @kPicklistePos  = @kPicklistePos,
							    @fPickMenge  = @fPickMenge,
							    @cMhd = @cMhd,
							    @cCharge = @cCharge,
							    @kLhm    =   @kLhm,  
							    @kBenutzer=  @kBenutzer,
							    @nStatusNachPick  = @nPickposStatus,
							    @nRet = @nRet OUTPUT;    
			    END;
			    ELSE
			    BEGIN

				    SELECT @fAufPlatzAnzahl = ISNULL(SUM(ISNULL(dbo.tWarenLagerEingang.fAnzahlAktuell,0)),0)
				    FROM dbo.tWarenLagerEingang WITH(NOLOCK) 
				    WHERE dbo.tWarenLagerEingang.kArtikel = @kArtikel
				    AND dbo.tWarenLagerEingang.kWarenlagerplatz = @kPPWarenLagerPlatz
				    AND (dbo.tWarenLagerEingang.cChargenNr = @cCharge or @cCharge is null)
				    AND (CONVERT(VARCHAR,dbo.tWarenlagerEingang.dMHD, 104) = @cMhd or @cMhd is null);

				    -- Sind auf Platz genug Artikel um das überhaupt zu picken ?
				    IF(@fAufPlatzAnzahl >= @fPickMenge) 
				    BEGIN
       
				      IF(@nRet >= 0) -- Falls keinen Fehler bisher, dann tauschen
				      BEGIN
					      EXEC dbo.spTauscheUndPicke
					      @kPicklistePos   = @kPicklistePos,  -- Für die Pickliste suchen wir einen Tauschpartner
					      @nMenge   =  @fPickMenge, -- die Menge die getaucht werden soll
					      @cCharge  = @cCharge, -- die Charge die wir suchen
					      @cMHD     = @cMhd , -- das MHD das wir suchen
					      @kLhm    =   @kLhm,  
					      @kBenutzer=  @kBenutzer,
					      @nStatusNachPick  = @nPickposStatus,
					      @nRestmengeLoeschen = 0,
					      @nRet  = @nRet OUTPUT; -- Tausch ok ?     
				      END;
			         END;
			    ELSE
			      SET @nRet = -203000005; -- nicht genug Menge auf den Platz
		         END;
               END;
               ELSE  -- Falls keine MHD oder Charge, picke die Pickposition
               BEGIN
		          IF(@fPPAnzahl >= @fPickMenge)  -- Übersteigt die eingegebene Menge nicht die Menge der Pickposition ?
		          BEGIN
		               -- Pickpos Picken
			          EXEC @nRet = dbo.spPicklisteposPicken
				          @kPicklistePos  = @kPicklistePos,
				          @kLhm  = @kLhm,
				          @kBenutzer  = @kBenutzer,
				          @fPickMenge = @fPickMenge,
				          @dTimestamp = @dTimestamp,
				          @nRestmengeLoeschen = 0,
				          @nStatusNachPick = @nPickposStatus;

		          END
		          ELSE
			          SET @nRet = -203000006; -- mehr Menge angegeben als in Pickposition vorhanden
		          END
               END
               ELSE
		          SET @nRet = -203000007; -- Pickpostition nicht gefunden


	          -- Kein Fehler im durchlauf ? TRANSACTION commiten
	          IF (@nRet >= 0)
		          COMMIT TRAN T1;
	          ELSE
		          ROLLBACK TRAN T1;

               SELECT @nRet;
	     END TRY
	BEGIN CATCH
		SELECT -203000008; -- unbekannter Fehler
		ROLLBACK TRAN T1;
	END CATCH
go

