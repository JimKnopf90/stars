--- 
--- spPicklisteErstellen
---

CREATE PROCEDURE [dbo].[spPicklisteErstellen] 
	@kWarenlager INT, 
	@kPicklisteVorlage INT, 
	@kBenutzer INT, 
	@kSessionID INT, 
	@nDebug INT, 
	@kRollendeKommissionierungWagen INT
--
-- Copyright (c) 2012-2017 by JTL Software GmbH
-- Version: $Rev$
-- Datum: $Date$
-- 22.09.2014
--
AS 
BEGIN	
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_NULL_DFLT_ON ON;
SET ANSI_PADDING ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET XACT_ABORT OFF;  
	--Returnwerte: 
	--positive Zahl X: Pickliste mit der Nummer X wurde erfolgreich angelegt 
	--0: Es konnte nichts reserviert werden, entweder weil kein BEstand da ist oder weil keine Aufträge reserviert werden sollen 
	--(-999999999): Es trat eine Exception auf und es war zu diesem Zeitpunkt noch nichts reserviert 
	--negative Zahl X: Es trat eine Exception auf, zu dem Zeitpunkt waren jedoch schon Positionen reserviert. Diese sind in der Pickliste X enthalten 

	--
	-- DECLARE
	--
	DECLARE @cSQLInsert VARCHAR(MAX), @cSQL nVARCHAR(MAX), @cSQLSelect VARCHAR(MAX), @cSQLFROM VARCHAR(MAX), @cSQLWHERE VARCHAR(MAX), @cSQLORDERBY VARCHAR(MAX), @cSQLGROUP VARCHAR(MAX), @cSQLHAVING VARCHAR(MAX);
	DECLARE @nAnzArtMax INT, @nAnzArtMin INT, @nAnzAuftraege INT, @kBestellNr INT, @nSortierung INT, @nBoxVon INT, @nBoxBis INT, @nIstNeueLHM INT , @kLHMStatus INT;
	DECLARE @kBestellung INT, @nTeilLiefErlaubt INT, @kVersandBox INT, @nAnzReservierterAuftraege INT, @kPickliste INT, @nAnzahlPositionen INT, @nWEPlatzReservieren INT, @nLadenlokalReservieren INT , @nEinartikelpickliste INT, @nRetourenPlatzReservieren INT;
	DECLARE @cVersandArten VARCHAR(255), @cWarengruppen VARCHAR(4000), @cShops VARCHAR(255), @cPlattformen VARCHAR(255), @cBoxId VARCHAR(30);
    DECLARE @fTeilliefPreis DECIMAL(28,14), @nGewMin DECIMAL(28,14), @nGewMax DECIMAL(28,14), @fMengeErfolgreichReserviert DECIMAL(28,14), @fMengeErfolgreichReserviertGesamt DECIMAL(28,14);
    DECLARE @cBestellung VARCHAR(255), @cYes VARCHAR(1), @nNichtBezahltVorkommissionieren INT, @cISO VARCHAR(3000);
	DECLARE @nIstVorlage INT, @nTeillieferungErlaubt INT, @nVorkommissionieren INT, @nTeillieferungSpeicher INT, @nBestellungWMSFreigabe INT, @nMaxAnzahlArtikel INT, @nArtikelAttributeBeachten TINYINT;
	
	--Der folgende Parameter gibt an, ob es sich um eine RollendeKommissionierung handelt und falls ja (> 0) um welchen kpickwagen
	--Der Pickwagen ist ein kwarenlagerplatz auf dem sich mehrere klhm befinden. Wenn sich X leere LHM auf dem Wagen befinden, wird versucht X bestellungen zu reservieren und jeweils einer BEstellung einer der lhms auf dem pickwagen zuzuweisen
	DECLARE @kRollendeKommissionierungPickwagen INT, @kPicklisteVorlageAktuell INT, @kReineRollendeKommissionierung INT;
	DECLARE @fPreisAuftragMax DECIMAL(28,14);
	DECLARE @fPreisAuftragMin DECIMAL(28,14);
	DECLARE @cAuftragkennzeichnung VARCHAR(MAX);
	DECLARE @cFirmen VARCHAR(MAX);
	DECLARE @cKundengruppen VARCHAR(MAX);
	DECLARE @cVersandklassen VARCHAR(MAX);
	DECLARE @cZahlungsarten VARCHAR(MAX);
	DECLARE @nEnthaeltArtAusWarengruppe TINYINT;
	DECLARE @nAlleOhneWarengruppe TINYINT;
	DECLARE @nAlleOhneVersandart TINYINT;
	DECLARE @nAlleOhneZahlungsart TINYINT;
	DECLARE @cBenutzer VARCHAR(MAX);
	DECLARE @kBestellungsBox INT;
	DECLARE @tempBestellungArtikel TABLE (kBestellung INT,kArtikel INT,nPrio INT);
	DECLARE @tempAktivArtikel TABLE (kArtikel INT);
	DECLARE @nLookForBestellung INT;
	DECLARE @nSortenrein TINYINT;
	DECLARE @nAuftragsArt TINYINT;
	DECLARE @cLHMIdForDebug VARCHAR(255);
	DECLARE @nArtikelBreiteVon INT;
	DECLARE @nArtikelBreiteBis INT;
	DECLARE @nArtikelHoeheVon INT;
	DECLARE @nArtikelHoeheBis INT;
	DECLARE @nArtikelLaengeVon INT;
	DECLARE @nArtikelLaengeBis INT;
	DECLARE @kSessionIDPickliste INT;
	DECLARE @nAuftragsVolumenVon BIGINT;
	DECLARE @nAuftragsVolumenBis BIGINT;
	DECLARE @nOhneVolumenAusschliessen INT;
	DECLARE @VersandBoxenProzessMitRoko INT = 0;
	DECLARE @FifoAktiv TINYINT = 0;

	BEGIN TRY 
	
		SET @nAnzReservierterAuftraege = 0;
		SET @kReineRollendeKommissionierung = 0;
		SET @fMengeErfolgreichReserviertGesamt = 0;

		IF (object_id('tempdb..#AttributString') IS NOT NULL)
		BEGIN
			DROP TABLE #AttributString
		END;

		CREATE TABLE #AttributString (cAttribut VARCHAR(255));
	
	     
          ------------Rollende Kommissionierung
		--Falls eine Vorlage übergeben wurde, welche wirklich nur eine Vorlage ist (nVorlage = 1) dann muss aus dieser noch eine Kopie erstellt werden, auf welcher dann gearbeitet wird
		--Dies ist der Fall bei der rollenden Kommissionierung, weil dort nur eine Vorlage ausgewählt wird, welche dann in dieser Prozedur noch kopiert werden muss
		SELECT @nIstVorlage = nIstVorlage 
		FROM  dbo.tpicklistevorlage  WITH(NOLOCK) 
		WHERE kPicklistevorlage = @kPicklisteVorlage;


		SELECT @kReineRollendeKommissionierung = COUNT(*)
		FROM dbo.twarenlageroptionen WITH(NOLOCK) 
		WHERE ISNULL(nRollendeKommissionierung,0) = 1
		AND kWarenlager = @kWarenlager;

		SELECT @VersandBoxenProzessMitRoko = COUNT(*)
		FROM dbo.twarenlageroptionen WITH(NOLOCK) 
		WHERE ISNULL(nVersandboxenProzess,0) = 1
		AND ISNULL(nVersandboxenProzessmitRoko,0) = 1
		AND kWarenlager = @kWarenlager;

		SELECT @FifoAktiv= cValue 
		FROM tOptions
		WHERE cKey = 'FIFOAktiv';

		IF (@nIstVorlage = 1 AND @kRollendeKommissionierungWagen > 0)
		BEGIN	
			-- Virtuelle Tabelle erstellen
			SELECT * INTO #picklistevorlage 
			FROM dbo.tpicklistevorlage  WITH(NOLOCK) 
			WHERE kPicklistevorlage = @kPicklisteVorlage;

			-- PK der Virtuellen Tabelle dropen, damit er in der realen erstellt werden kann
			ALTER TABLE #picklistevorlage 
			DROP COLUMN kPicklistevorlage;

			INSERT INTO dbo.tpicklistevorlage WITH(ROWLOCK) 
			SELECT #picklistevorlage.* 
			FROM #picklistevorlage;

			-- Neuen Pickpos wird aktuelle Pickpos
			SET @kPicklisteVorlageAktuell = SCOPE_IDENTITY();
	  
			UPDATE dbo.tpicklistevorlage WITH(ROWLOCK) 
			SET kWarenlager = @kWarenlager, nIstVorlage = 0, dAngelegt = GetDate(), kBenutzer = @kBenutzer, 
			    nBoxenVon = 0, nBoxenBis = 999999999, kPickliste = 0, kRollendeKommissionierungPickwagen = @kRollendeKommissionierungWagen
			WHERE kpicklistevorlage = @kPicklisteVorlageAktuell;
		   

		END;
		ELSE
			SET @kPicklisteVorlageAktuell = @kPicklisteVorlage;
	-----------------------
	

		     -- Alte Locks löschen (älter als 5 min). Können durch absturz der DB verursacht worden sein.
		    DELETE tBestellungPicklisteLock 
			FROM tBestellungPicklisteLock 
			WHERE tBestellungPicklisteLock.dZeitstempel < DateADD(mi, -5,   getdate())


			SELECT @nAnzArtMax = nAnzahlArtikelAuftragMax, @nAnzArtMin = nAnzahlArtikelAuftragMin, @nGewMin = fGewichtVon, @nGewMax = fGewichtBis, @nSortierung = nSortierung, 
					@cVersandArten = cVersandartNr, @cWarengruppen = cWarengruppen, @cPlattformen = cPlattformen, @cShops = cShops, @nAnzAuftraege = nAnzahlBestellungen, @kBestellNr = kBestellNr, 
					@nBoxVon = isnull(nBoxenVon,0), @nBoxBis = isnull(nBoxenBis,999999), @fTeilliefPreis = fTeillieferungenWert, 
					@nLadenlokalReservieren = nLadenlokalEinbeziehen, @nWEPlatzReservieren = nWEPlatzReservieren, @nEinartikelpickliste = nEinartikelpickliste ,
					@kRollendeKommissionierungPickwagen = isnull(kRollendeKommissionierungPickwagen,0), @nBestellungWMSFreigabe = isnull(nBestellungWMSFreigabe,0), @nMaxAnzahlArtikel = nMaxAnzahlArtikel, 
					@nNichtBezahltVorkommissionieren = isnull(nNichtBezahltVorkommissionieren,0), @cISO = cLieferlaender,@fPreisAuftragMax = fPreisAuftragMax, @fPreisAuftragMin = fPreisAuftragMin,
					@cAuftragkennzeichnung = cAuftragkennzeichnung,@cFirmen = cFirmen, @cKundengruppen = cKundengruppen, @cVersandklassen = cVersandklassen,@cZahlungsarten = cZahlungsarten,
					@nEnthaeltArtAusWarengruppe = nEnthaeltArtAusWarengruppe, @nAlleOhneWarengruppe= nAlleOhneWarengruppe, @nAlleOhneVersandart = nAlleOhneVersandart,@nAlleOhneZahlungsart = nAlleOhneZahlungsart, @cBenutzer = cBenutzer,
					@nSortenrein = nSortenrein,@nAuftragsArt = nAuftragsArt, @nArtikelBreiteVon = nArtikelBreiteVon, @nArtikelBreiteBis = nArtikelBreiteBis, @nArtikelHoeheVon = nArtikelHoeheVon,  @nArtikelHoeheBis = nArtikelHoeheBis,
					@nArtikelLaengeVon = nArtikelLaengeVon, @nArtikelLaengeBis = nArtikelLaengeBis, @nAuftragsVolumenVon = nAuftragsVolumenVon, @nAuftragsVolumenBis = nAuftragsVolumenBis, @nOhneVolumenAusschliessen = nOhneVolumenAusschliessen,
					@nRetourenPlatzReservieren = dbo.tPicklisteVorlage.nRetourenplatzReservieren
			FROM dbo.tPicklisteVorlage  WITH(NOLOCK) 
			WHERE kPicklisteVorlage = @kPicklisteVorlageAktuell;


			INSERT INTO tSessionId	(cRechnername,kBenutzer, dLastAction)
			VALUES ( 'WMS',  @kBenutzer, GETDATE());

			SET @kSessionIDPickliste = SCOPE_IDENTITY();

			INSERT INTO dbo.tPickliste (kWarenLager, kPicklistenVorlage, nStatus,kSessionId) 
			VALUES (@kWarenLager, @kPicklisteVorlageAktuell, 0,@kSessionIDPickliste);
	
			SET @kPickliste = SCOPE_IDENTITY();

 
			SET @cSQLInsert = N'INSERT INTO dbo.tBestellungPicklisteLock  WITH(ROWLOCK) (kBestellung, kpickliste, dZeitstempel) ' ; 
			SET @cSQLSelect = N'SELECT dbo.tBestellung.kBestellung, ' + CAST(@kPickliste AS VARCHAR) + N', GETDATE()  '; 
			SET @cSQLFROM = N' FROM dbo.tBestellung  WITH(NOLOCK) ' + 
							N' JOIN dbo.tBestellPos WITH(NOLOCK) ON (dbo.tBestellPos.tBestellung_kBestellung = tbestellung.kBestellung and (dbo.tBestellpos.nType = 1 OR dbo.tBestellpos.nType = 11)) ' +
						    N' JOIN Versand.vBestellPosLieferInfoProLager WITH(NOLOCK) ON Versand.vBestellPosLieferInfoProLager.kBestellpos = dbo.tBestellpos.kBestellpos  and Versand.vBestellPosLieferInfoProLager.kWarenlager = '  + CAST(@kWarenlager AS VARCHAR) + 
							N' LEFT JOIN dbo.tbestellungwmsfreigabe WITH(NOLOCK) on dbo.tbestellungwmsfreigabe.kbestellung = dbo.tbestellung.kBestellung and dbo.tBEstellungwmsFreigabe.naktiv = 1 ' +
							N' JOIN Versand.vBestellungLieferInfoProLager WITH(NOLOCK) ON Versand.vBestellungLieferInfoProLager.kBestellung = tBestellung.kBestellung ' +
							N' JOIN dbo.tArtikel WITH(NOLOCK) ON tArtikel.kArtikel = dbo.tBestellPos.tArtikel_kArtikel AND ISNULL(tArtikel.kStueckliste, 0) = 0 ' +
							N' LEFT JOIN dbo.tKunde WITH(NOLOCK) ON dbo.tKunde.kKunde = dbo.tBestellung.tKunde_kKunde' +
							N' LEFT JOIN dbo.tZahlungsart  WITH(NOLOCK) ON dbo.tZahlungsart.kZahlungsart = dbo.tBestellung.kZahlungsart ' +  
							N' LEFT JOIN dbo.tUmlagerung  WITH(NOLOCK) ON dbo.tUmlagerung.kBestellung = dbo.tBestellung.kBestellung ' +  
							N' LEFT JOIN dbo.teigenschaft  WITH(NOLOCK) ON teigenschaft.kArtikel = tArtikel.kArtikel  AND teigenschaft.cAktiv = ''Y''  AND tEigenschaft.cTyp != ''PFLICHT-FREIFELD'' ';
						 
			SET @cSQLWHERE = N'  WHERE (dbo.tBestellung.dBezahlt IS NOT NULL OR ISNULL(dbo.tZahlungsart.nAusliefernVorZahlung,0) = 1 OR (  ' + CAST(@nNichtBezahltVorkommissionieren AS VARCHAR) + N' = 1 AND dbo.tbestellungwmsfreigabe.nvorkommissionieren = 1) )' + 
							 N' AND (dbo.tbestellungwmsfreigabe.nSperre IS NULL OR dbo.tbestellungwmsfreigabe.nSperre = 0) ' +
							 N' AND dbo.tBestellung.nKomplettAusgeliefert = 0 ' + 
							 N' AND dbo.tBestellung.nStorno = 0 ' + 
							 N' AND (dbo.tartikel.cLagerAktiv = ''Y'') ' + 
							 N' AND (dbo.tartikel.cLagerVariation <> ''Y'') ' + 
							 N' AND dbo.teigenschaft.kEigenschaft IS NULL '+
						  	 N' AND (dbo.tBestellung.kRueckhalteGrund IS NULL OR dbo.tBestellung.kRueckhalteGrund = 0) ' + 
							 N' AND (dbo.tKunde.cSperre IS NULL OR dbo.tKunde.cSperre != ''Y'' )'+
							 N' AND (dbo.tUmlagerung.kUmlagerung IS NULL OR (dbo.tUmlagerung.kUmlagerung > 0 AND dbo.tUmlagerung.kQuellLager =  '  + CAST(@kWarenlager AS VARCHAR) + N' ))' +
							 N' AND ((Versand.vBestellungLieferInfoProLager.nLieferbarEigen = 2  OR (Versand.vBestellungLieferInfoProLager.nLieferbarEigen = 1 AND (dbo.tbestellungwmsfreigabe.nTeillieferungErlaubt = 1 OR dbo.tbestellungwmsfreigabe.nvorkommissionieren = 1) ) ) ) ' +
						  	 N' AND Versand.vBestellungLieferInfoProLager.kWarenlager = ' + CAST(@kWarenlager AS VARCHAR) + N' ' +
							 N' AND NOT EXISTS (SELECT kBestellung FROM dbo.tBestellungPicklisteLock  WITH(NOLOCK) WHERE dbo.tBestellungPicklisteLock.kBestellung = dbo.tBestellung.kBestellung) ' +					 
							 N' AND NOT EXISTS (SELECT * from dbo.tpickliste WITH(NOLOCK)' +
							 N' 		JOIN dbo.tpicklistevorlage  WITH(NOLOCK) ON dbo.tpicklistevorlage.kpicklistevorlage = dbo.tpickliste.kpicklistenvorlage  ' +
							 N' 		JOIN dbo.tpicklistepos  WITH(NOLOCK) ON dbo.tPicklistepos.kPickliste = dbo.tPickliste.kPickliste  ' +
							 N' 		WHERE dbo.tpicklistepos.kbestellung = dbo.tBestellung.kBestellung  ' +
							 N'         AND dbo.tpicklistepos.kWarenLager =  ' +  CAST(@kWarenlager AS VARCHAR) + N' ' +
							 N' 		AND (dbo.tpicklistevorlage.nEinArtikelPickliste = 1 OR ' +  CAST(ISNULL(@kReineRollendeKommissionierung,0) AS VARCHAR)  + ' > 0) ' +						
							 N' 		AND dbo.tPicklistePos.nStatus < 40)  '; 
					
			SET @cSQLGROUP = N' GROUP BY dbo.tBestellung.kBestellung, dbo.tbestellungWMSFreigabe.nTeillieferungErlaubt, dbo.tbestellungWMSFreigabe.nVorkommissionieren '; 
	 
	 
			--Menge einschränken, nur Aufträge die mindestens X Artikel enthalten.
			--Trotzdem muss auch bei 0 dies ausgeführt werden, damit keine Aufträge betrachtet werden, deren Positionen schon komplett reserviert sind 
			IF (@nAnzArtMin > 0)
				SET @cSQLHAVING = N' HAVING SUM(Versand.vBestellPosLieferInfoProLager.fAnzahlOffen) >= 0 AND SUM(Versand.vBestellPosLieferInfoProLager.fAnzahlOffen) >= ' +  CAST(@nAnzArtMin AS VARCHAR) + N' ';  	  
			ELSE
				SET @cSQLHAVING = N' HAVING SUM(Versand.vBestellPosLieferInfoProLager.fAnzahlOffen ) > 0 '; 
 
			IF (@nAnzArtMax != 999999) 
			   SET @cSQLHAVING = @cSQLHAVING + N' AND SUM(Versand.vBestellPosLieferInfoProLager.fAnzahlOffen) <= ' +  CAST(@nAnzArtMax AS VARCHAR) + N' '; 

			-- Gewicht der Bestellungen einschränken 
			IF (@nGewMax > 0) 
			BEGIN 
  				SET @cSQLHAVING = @cSQLHAVING + N' AND (1 = dbo.tbestellungwmsfreigabe.nteillieferungErlaubt OR SUM((Versand.vBestellPosLieferInfoProLager.fAnzahlOffen) * tArtikel.fGewicht) < ' + CAST(@nGewMax AS VARCHAR) + ') '; 
			END 
	
			IF (@nGewMin > 0) 
			BEGIN 
			   SET @cSQLHAVING = @cSQLHAVING + N' AND (1 = dbo.tbestellungwmsfreigabe.nteillieferungErlaubt OR SUM((Versand.vBestellPosLieferInfoProLager.fAnzahlOffen) * tArtikel.fGewicht) > ' + CAST(@nGewMin AS VARCHAR) + ') '; 
			END 
	
			IF(@fPreisAuftragMax > 0 OR @fPreisAuftragMin > 0)
			BEGIN
	
				SET @cSQLFROM = @cSQLFROM + N' LEFT JOIN (SELECT CAST(ROUND(SUM((dbo.tbestellpos.nAnzahl*dbo.tbestellpos.fVKNetto*(100-dbo.tbestellpos.fRabatt)/100.0)*(100+dbo.tbestellpos.fMwSt)/100), 2) AS DECIMAL(28,14)) fVKBrutto,dbo.tbestellpos.tBestellung_kBestellung ' +
									   N' FROM dbo.tbestellpos WITH(NOLOCK) ' +
									   N' GROUP by dbo.tbestellpos.tBestellung_kBestellung ) AS b1 ON b1.tBestellung_kBestellung  = dbo.tBestellung.kBestellung ';
	  
	  
				IF @fPreisAuftragMax > 0
					SET @cSQLHAVING = @cSQLHAVING + N' AND MAX (b1.fVKBrutto) <= ' + CAST (@fPreisAuftragMax AS VARCHAR);
	   
				IF @fPreisAuftragMin > 0
					SET @cSQLHAVING = @cSQLHAVING + N' AND MAX (b1.fVKBrutto) >= ' + CAST (@fPreisAuftragMin AS VARCHAR);
			END
	
			IF (LEN(ISNULL(@cFirmen,'')) > 0)
			BEGIN
				SET @cSQLWHERE = @cSQLWHERE + N' AND dbo.tBestellung.kFirma IN (' + @cFirmen + N') ';
			END
	
			IF (LEN(ISNULL(@cKundengruppen,'')) > 0)
			BEGIN
				SET @cSQLWHERE = @cSQLWHERE + N' AND dbo.tKunde.kKundengruppe IN (' + @cKundengruppen + N') ';
			END
	
			IF (LEN(ISNULL(@cVersandklassen,'')) > 0)
			BEGIN
				SET @cSQLWHERE = @cSQLWHERE + N' AND tArtikel.kVersandklasse IN (' + @cVersandklassen + N') ';
			END	
	
			IF (LEN(ISNULL(@cBenutzer,'')) > 0)
			BEGIN
				SET @cSQLWHERE = @cSQLWHERE + N' AND '  + CAST(@kBenutzer AS VARCHAR) + ' IN (' + @cBenutzer + N') ';
			END	
	
	
	
			IF @nAlleOhneZahlungsart > 0
			BEGIN
				IF(LEN(ISNULL(@cZahlungsarten,'')) > 0) 
					SET @cZahlungsarten = @cZahlungsarten + N',0';
				ELSE
					SET @cZahlungsarten = N'0';
			END
	
			IF (LEN(ISNULL(@cZahlungsarten,'')) > 0)
			BEGIN
				SET @cSQLWHERE = @cSQLWHERE + N' AND dbo.tBestellung.kZahlungsArt IN (' + @cZahlungsarten + N') ';
			END
	
	
			-- Wo versandart gebraucht wird, joinen
			IF (@cAuftragkennzeichnung like '%4%' OR @cAuftragkennzeichnung like '%8%')  
			BEGIN
				SET @cSQLFROM = @cSQLFROM + N' JOIN dbo.tversandart  WITH(NOLOCK) ON dbo.tVersandart.kVersandart = dbo.tBestellung.tVersandArt_kVersandArt '; 
			END
 
			--Auf Versandarten einschränken, PKs werden als Komma-separierter String übergeben 
			IF @nAlleOhneVersandart > 0
			BEGIN
				IF(LEN(ISNULL(@cVersandArten,'')) > 0) 
					SET @cVersandArten = @cVersandArten + N',0';
				ELSE
					SET @cVersandArten = N'0';
			END
	
			IF (LEN(ISNULL(@cVersandArten,'')) > 0) 
			BEGIN 
				SET @cSQLWHERE = @cSQLWHERE + N' AND (dbo.tBestellung.tVersandArt_kVersandArt IN (' + @cVersandArten + N') 
                                                          OR  dbo.tBestellung.tVersandArt_kVersandArt IN (  SELECT tversandart.kversandart  
																				    FROM dbo.tversandart WITH(NOLOCK)
																				    WHERE dbo.tversandart.nEigeneversandArt = 0
																				    AND dbo.tversandart.kMainVersandart IN (' + @cVersandArten + N',0))) ';
			END 
     
			IF(@nAuftragsArt = 1) 
			BEGIN
				SET @cSQLWHERE = @cSQLWHERE + N' AND dbo.tBestellung.cType = ''U'' ';
			END
			ELSE IF (@nAuftragsArt = 2) 
			BEGIN
				SET @cSQLWHERE = @cSQLWHERE + N' AND dbo.tBestellung.cType = ''B'' ';
			END
			ELSE
			BEGIN
				SET @cSQLWHERE = @cSQLWHERE + N' AND (dbo.tBestellung.cType = ''B'' OR dbo.tBestellung.cType = ''U'') ';
			END
      

			--Einschränken auf bestimmte Auftragskennzeichnungen z.b. priorisiert, vorkommissionieren, teilliefern
			IF (  @cAuftragkennzeichnung LIKE '%1%')
			BEGIN
				SET @cSQLWHERE = @cSQLWHERE + N' AND ISNULL(dbo.tBestellung.nPrio,0) > 0 ';
			END

			IF (@cAuftragkennzeichnung LIKE '%2%')
			BEGIN
				SET @cSQLWHERE = @cSQLWHERE + N' AND ISNULL(dbo.tBestellungWMSFreigabe.nVorkommissionieren,0) = 1 ';
			END

			IF (@cAuftragkennzeichnung LIKE '%3%')
			BEGIN
				SET @cSQLWHERE = @cSQLWHERE + N' AND ISNULL(dbo.tBestellungWMSFreigabe.nTeillieferungErlaubt,0) = 1 ';
			END	
	
			IF (@cAuftragkennzeichnung LIKE '%4%')
			BEGIN			
				SET @cSQLWHERE = @cSQLWHERE + N' AND ISNULL(dbo.tversandart.nPrioritaet,0) > 0 ';
			END

			IF (  @cAuftragkennzeichnung LIKE '%5%')
			BEGIN
				SET @cSQLWHERE = @cSQLWHERE + N' AND ISNULL(dbo.tBestellung.nPrio,0) = 0 ';
			END

			IF (@cAuftragkennzeichnung LIKE '%6%')
			BEGIN
				SET @cSQLWHERE = @cSQLWHERE + N' AND ISNULL(dbo.tBestellungWMSFreigabe.nVorkommissionieren,0) = 0 ';
			END

			IF (@cAuftragkennzeichnung LIKE '%7%')
			BEGIN
				SET @cSQLWHERE = @cSQLWHERE + N' AND ISNULL(dbo.tBestellungWMSFreigabe.nTeillieferungErlaubt,0) = 0 ';
			END	
	
			IF (@cAuftragkennzeichnung LIKE '%8%')
			BEGIN			
				SET @cSQLWHERE = @cSQLWHERE + N' AND ISNULL(dbo.tversandart.nPrioritaet,0) = 0 ';
			END
	
	
			IF @nAlleOhneWarengruppe > 0
			BEGIN
				IF(LEN(ISNULL(@cWarengruppen,'')) > 0) 
					SET @cWarengruppen = @cWarengruppen + N',0';
				ELSE
					SET @cWarengruppen = N'0';
			END
	   
			--Auf Warengruppen einschränken, PKs werden als Komma-separierter String übergeben 
		     IF (LEN(ISNULL(@cWarengruppen,'')) > 0) 
		     BEGIN 
	 	     
			      IF(@nEnthaeltArtAusWarengruppe > 0)
			      BEGIN
			  	   SET @cSQLFROM = @cSQLFROM + N' JOIN (  SELECT BestPos1.tBestellung_kBestellung 
													   FROM dbo.tbestellpos AS BestPos1 WITH(NOLOCK)
													   JOIN tartikel AS Art1 WITH(NOLOCK) ON BestPos1.tartikel_kartikel = Art1.kartikel
													   AND Art1.kwarengruppe IN  (' + @cWarengruppen + N')
													   GROUP BY BestPos1.tBestellung_kBestellung
								                     ) AS Warengruppen ON  Warengruppen.tBestellung_kBestellung = dbo.tBestellung.kBestellung '
			  	END
			  	ELSE
			  	BEGIN	
			  	    SET @cSQLWHERE = @cSQLWHERE + N' AND NOT EXISTS ( SELECT * FROM dbo.tbestellpos AS BestPos1  WITH(NOLOCK)  ' +
			  							N'  JOIN tartikel  AS Art1  WITH(NOLOCK) ON BestPos1.tartikel_kartikel = Art1.kartikel ' +
			  							N'  WHERE (BestPos1.ntype = 1 OR BestPos1.nType = 11)' +
			  							N'		AND BestPos1.tbestellung_kbestellung = dbo.tbestellung.kbestellung ' +
			  							N'		AND Art1.kwarengruppe NOT IN  (' + @cWarengruppen + N')) ';
			  						 
			      END							 
		     END 

			IF (@nArtikelBreiteBis > 0 OR @nArtikelHoeheBis > 0  OR @nArtikelLaengeBis > 0 ) 
			BEGIN

			SET @cSQLWHERE = @cSQLWHERE + N' AND EXISTS (SELECT count(*)
					  FROM dbo.tbestellpos  WITH(NOLOCK)
					  JOIN dbo.tartikel  WITH(NOLOCK) ON dbo.tbestellpos.tartikel_kartikel = dbo.tartikel.kartikel
					  JOIN Versand.vBestellPosLieferInfo WITH(NOLOCK) ON Versand.vBestellPosLieferInfo.kBestellPos = dbo.tbestellpos.kBestellpos
					  WHERE dbo.tbestellpos.tbestellung_kbestellung = dbo.tbestellung.kbestellung
					  HAVING ((MAX(dbo.tartikel.fBreite) <= '+CAST(@nArtikelBreiteBis AS VARCHAR)+'  OR '+CAST(@nArtikelBreiteBis AS VARCHAR)+' = 0) AND MIN(dbo.tartikel.fBreite) >= '+CAST(@nArtikelBreiteVon AS VARCHAR)+' 
					  AND (MAX(dbo.tartikel.fHoehe) <=  '+CAST(@nArtikelHoeheBis AS VARCHAR)+'  OR '+CAST(@nArtikelHoeheBis AS VARCHAR)+' = 0) AND MIN(dbo.tartikel.fHoehe) >= '+CAST(@nArtikelHoeheVon AS VARCHAR)+' 
					  AND (MAX(dbo.tartikel.fLaenge) <=  '+CAST(@nArtikelLaengeBis AS VARCHAR)+'  OR '+CAST(@nArtikelLaengeBis AS VARCHAR)+' = 0) AND MIN(dbo.tartikel.fLaenge) >= '+CAST(@nArtikelLaengeVon AS VARCHAR)+' )) ';
			END;


			IF (@nAuftragsVolumenBis > 0 AND @nAuftragsVolumenVon < @nAuftragsVolumenBis) 
			BEGIN

			SET @cSQLWHERE = @cSQLWHERE + N' AND 0 < ( SELECT COUNT(*) FROM
												   	    ( SELECT SUM(ArtikelVolumen.fVolumen) AS fVolumen, SUM(ArtikelVolumen.HasNullValues) AS HasNullValues
												   		  FROM
															( SELECT (MAX(VolArt.fBreite) * MAX(VolArt.fHoehe) *  MAX(VolArt.fLaenge) * SUM(tbestellpos.nAnzahl)) AS  fVolumen, CASE WHEN MAX(VolArt.fBreite) = 0 OR MAX(VolArt.fHoehe) = 0 OR  MAX(VolArt.fLaenge) = 0 THEN 1 ELSE 0 END AS HasNullValues
												   			  FROM dbo.tbestellpos  WITH(NOLOCK)
															  JOIN Versand.vBestellPosLieferInfo WITH(NOLOCK) ON Versand.vBestellPosLieferInfo.kBestellPos = dbo.tbestellpos.kBestellpos
												   			  JOIN dbo.tartikel VolArt WITH(NOLOCK) ON dbo.tbestellpos.tartikel_kartikel = VolArt.kartikel
												   			  WHERE dbo.tbestellpos.tbestellung_kbestellung =  dbo.tbestellung.kbestellung
												   			  GROUP BY VolArt.kArtikel ) AS ArtikelVolumen
												   		  HAVING  SUM(ArtikelVolumen.fVolumen) <=  '+CAST(@nAuftragsVolumenBis AS VARCHAR)+' AND  SUM(ArtikelVolumen.fVolumen) >= '+CAST(@nAuftragsVolumenVon AS VARCHAR)+' AND (('+CAST(@nOhneVolumenAusschliessen AS VARCHAR)+' = 1 AND  SUM(ArtikelVolumen.HasNullValues) = 0) OR  '+CAST(@nOhneVolumenAusschliessen AS VARCHAR)+' = 0)
												   		) AS VolumenTest) ';
			END;



			IF (LEN(ISNULL(@cShops,'')) > 0 AND LEN(ISNULL(@cPlattformen,'')) > 0) 
			BEGIN 
				SET @cSQLWHERE = @cSQLWHERE + N' AND (dbo.tBestellung.kShop IN (' + @cShops + N') OR dbo.tBestellung.nPlatform IN (' + @cPlattformen + N'))'; 
			END
 
			IF (LEN(ISNULL(@cShops,'')) > 0 AND LEN(ISNULL(@cPlattformen,'')) = 0) 
			BEGIN 
				SET @cSQLWHERE = @cSQLWHERE + N' AND dbo.tBestellung.kShop IN (' + @cShops + N') '; 
			END
 
			IF (LEN(ISNULL(@cPlattformen,'')) > 0 AND LEN(ISNULL(@cShops,'')) = 0) 
			BEGIN 		
				SET @cSQLWHERE = @cSQLWHERE + N' AND dbo.tBestellung.nPlatform IN (' + @cPlattformen + N') '; 
			END	
	  
			IF (LEN(ISNULL(@cISO,'')) > 0) 
			BEGIN 		
				SET @cSQLFROM = @cSQLFROM + N' JOIN dbo.tlieferadresse  WITH(NOLOCK) ON dbo.tlieferadresse.klieferadresse = dbo.tBestellung.klieferadresse ';
				SET @cSQLWHERE = @cSQLWHERE + N' AND dbo.tlieferadresse.cISO IN  (' + @cISO + N')' ;									    
			END
	  
			IF (@kBestellNr > 0) 
			BEGIN 
				SET @cSQLWHERE = @cSQLWHERE + N' AND dbo.tBestellung.kBestellung = ' + CAST(@kBestellNr AS VARCHAR); 
			END
	
			--Bei 1-Artikel-Picklisten (eazy-Shipping) darf keine Bestellung reserviert werden, welche schon für eine Versandbox vorgesehen ist,
			--da der Auftrag sonst in 2 Teilen rausgeht
			IF (@nEinartikelpickliste = 1)
			BEGIN
				SET @cSQLWHERE = @cSQLWHERE + N' AND NOT EXISTS (SELECT dbo.tlhm.kLhm FROM dbo.tlhm  WITH(NOLOCK)' +
											 N'                  JOIN dbo.tlhmstatus  WITH(NOLOCK) ON dbo.tlhmstatus.klhmstatus = dbo.tlhm.klhmstatus ' +
										 	 N'                  WHERE dbo.tlhmstatus.nstatus > 10 ' +
											 N'                  AND dbo.tlhm.kWarenlager = ' + CAST(@kWarenlager AS VARCHAR) + ' ' +
										  	 N'		             AND dbo.tlhmstatus.kbestellung = dbo.tbestellung.kBestellung) ';
			END;
 
			SET @cSQL = @cSQLInsert + @cSQLSelect + @cSQLFROM + @cSQLWHERE + @cSQLGROUP + @cSQLHAVING; 

			-- Für Debugfälle speichern wir das SQL in den logs
			IF (@nDebug = 1) 
			BEGIN
				INSERT INTO [dbo].[tLog]([dDatum],[kBenutzer],[cLog],[nTyp]	,[nVorgang])
				VALUES(getdate(),@kBenutzer,SUBSTRING(@cSQL,1,4000) ,888,88);
			END;
    
			EXEC sp_executesql @cSQL;


			IF (@nDebug = 1)
				INSERT INTO dbo.tFehler (kSessionId, cText, nValue1)
				VALUES (@kSessionID, 'Start der Reservierung für Pickliste ' + CAST(@kPickliste as varchar) + '.',1);  
	  
	  
			-- Spreichern aller gefundenen gültigen Bestellungen in Temp Tabelle
			INSERT INTO @tempBestellungArtikel (kbestellung, kartikel,nPrio)
			SELECT dbo.tBestellungPicklisteLock.kBestellung, tBestellPos.tArtikel_kArtikel , MAX(dbo.tBestellung.nPrio)
			FROM dbo.tBestellungPicklisteLock WITH(NOLOCK)
			JOIN dbo.tBestellPos ON dbo.tBestellPos.tbestellung_kbestellung = dbo.tBestellungPicklisteLock.kBestellung
			JOIN dbo.tBestellung ON dbo.tBestellPos.tbestellung_kbestellung = dbo.tBestellung.kBestellung
			JOIN vWMSArtikel ON vWMSArtikel.kArtikel = dbo.tbestellpos.tArtikel_kArtikel
			GROUP BY dbo.tBestellungPicklisteLock.kBestellung, dbo.tBestellPos.tArtikel_kArtikel;
	  
  
			SET @nLookForBestellung = 1;
			WHILE @nLookForBestellung = 1
			BEGIN   	
				SET @kBestellung = 0;
	    
				-- Holt die erste gültige bestellung, sortiert nach:
				-- 1. Prio
				-- 2. Express
				-- 3. Bestellungen die Artikel beinhalten welche die grad zuvor reservierte Bestellung hatte
				-- 4. Bezahlt bzw. Erstellt Datum
			     SELECT TOP 1 @kBestellung = tBestellung.kBestellung, @nTeillieferungErlaubt = ISNULL(tbestellungWMSFreigabe.nTeillieferungErlaubt,0), 
					      @nVorkommissionieren = ISNULL(tbestellungWMSFreigabe.nVorkommissionieren,0)
				FROM dbo.tBestellung  WITH(NOLOCK)
				LEFT JOIN dbo.tZahlungsart  WITH(NOLOCK) ON dbo.tZahlungsart.kZahlungsart = dbo.tBestellung.kZahlungsart 
				LEFT JOIN dbo.tbestellungWMSFreigabe  WITH(NOLOCK) ON dbo.tbestellungWMSFreigabe.kBEstellung = dbo.tBestellung.kBestellung and nAKtiv = 1		
				LEFT JOIN dbo.tVersandart  WITH(NOLOCK) ON dbo.tVersandart.kVersandart = dbo.tbestellung.tVersandart_kVersandart 
				JOIN  @tempBestellungArtikel tBA2 ON tBA2.kbestellung = dbo.tBestellung.kbestellung
				WHERE EXISTS (SELECT kBestellung  
						    FROM dbo.tBestellungPicklisteLock   WITH(NOLOCK) 
						    WHERE dbo.tBestellungPicklisteLock.kBestellung = dbo.tBestellung.kBestellung  
						    AND dbo.tBestellungPicklisteLock.kPickliste = @kPickliste)
				ORDER BY 	CASE 
							WHEN @nSortenrein = 0 
							THEN 1 
							WHEN tBA2.kArtikel IN (
											   SELECT kArtikel 
											   FROM @tempAktivArtikel
											  ) 
							THEN 0 
							ELSE 1 
						END,
                              ISNULL(tBA2.nPrio,0) DESC, 
						CASE dbo.tZahlungsart.nAusliefernVorZahlung 
                              WHEN 1 
						THEN dbo.tBEstellung.dERstellt 
						ELSE dBezahlt 
						END;
	     
				IF(@kBestellung is null OR @kBestellung = 0)
					SET @nLookForBestellung = 0; -- Keine Bestellung mehr gefunden. Raus hier.
				ELSE
				BEGIN
	
					DELETE FROM @tempBestellungArtikel -- Gefundene Bestellung aus Temp Tabelle löschen, da sie schon gefunden wurde.
					WHERE kBestellung = @kBestellung;
	     
					SELECT @cBestellung = cBEstellNr 
					FROM dbo.tBEstellung  WITH(NOLOCK) 
					WHERE kBestellung = @kBestellung;

					IF (@nDebug = 1)
						INSERT INTO dbo.tFehler  WITH(ROWLOCK) (kSessionId, cText, kkey1, cValue1, nValue1)
						VALUES (@kSessionID, 'Es wird Bestand für den Auftrag gesucht.', @kBestellung, @cBestellung,1);   
        
					SET @kVersandBox = 0;
					SET @nIstNeueLHM = 0;

					--Bei Picklisten für Versandboxen muss nicht nach einer freien Box gesucht werden
					IF ( @nEinartikelpickliste = 0)
					BEGIN

						SELECT @nArtikelAttributeBeachten = nArtikelAttributeBeachten
						FROM dbo.tWarenlagerOptionen WITH(NOLOCK) 
						WHERE kWarenlager = @kWarenlager;

						
						 --Falls mit Artikelattributen gearbeitet wird:
					     -- Option auf 0: Nicht beachten
						 -- Option auf 1: Es sollen wenn möglich Boxen genommen werden, die die gleichen Attribute haben wie die Artikel der BEstellung (Dient nur zur Sortierung)
						 -- Option auf 2: Es müssen Boxen genommen werden, die mindestens einem Attribut aus einer BEstellpos entsprechen
						
						DELETE FROM #AttributString;

						IF (@nArtikelAttributeBeachten > 0)
						BEGIN

							-- Alle Attribute der Artikel in der Sendung werden in die Temp table gespeichert (distinct)
							INSERT INTO #AttributString (cAttribut)
							SELECT DISTINCT dbo.tArtikelAttributSprache.cWertVarchar 
							FROM dbo.tbestellpos  WITH(NOLOCK) 
							JOIN dbo.tArtikel  WITH(NOLOCK) ON dbo.tArtikel.kArtikel = dbo.tBestellpos.tArtikel_kArtikel
													AND dbo.tArtikel.cLagerAktiv = 'Y'
													AND dbo.tArtikel.cLagerVariation <> 'Y' 
													AND (dbo.tArtikel.nIstVater = 0) 
							LEFT JOIN dbo.tArtikelAttribut WITH(NOLOCK) ON dbo.tArtikelAttribut.kArtikel = dbo.tArtikel.kArtikel -- Artikel von außen
							LEFT JOIN dbo.tArtikelAttributSprache WITH(NOLOCK) ON dbo.tArtikelAttributSprache.kSprache = 0
																		 AND dbo.tArtikelAttribut.kArtikelAttribut = dbo.tArtikelAttributSprache.kArtikelAttribut
							LEFT JOIN dbo.tAttribut WITH(NOLOCK) ON dbo.tAttribut.kAttribut = dbo.tArtikelAttribut.kAttribut
							LEFT JOIN dbo.tAttributSprache WITH(NOLOCK) ON dbo.tAttributSprache.kAttribut = dbo.tAttribut.kAttribut
							JOIN Versand.vBestellPosLieferInfo ON Versand.vBestellPosLieferInfo.kBestellPos =  dbo.tbestellpos.kbestellpos 	   
							WHERE dbo.tbestellpos.tBestellung_kBestellung = @kBestellung
							AND dbo.tAttributSprache.kSprache = 0
							AND dbo.tAttributSprache.cName = 'WMS_LagerEigenschaft'
							AND (NOT EXISTS (SELECT TOP(1) kEigenschaft
											FROM dbo.teigenschaft WITH(NOLOCK)
											WHERE cAktiv = 'Y' 
												AND kArtikel = dbo.tartikel.kArtikel));
						END;

						SET @kBestellungsBox = 0;
	
						SELECT @kBestellungsBox = tLHM.kLHM
						FROM dbo.tLHM WITH(NOLOCK)
						JOIN dbo.tLHMStatus WITH(NOLOCK) ON dbo.tLHMStatus.kLHMStatus = dbo.tLHM.kLHMStatus
											        AND dbo.tLHMStatus.kBestellung = @kBestellung
						WHERE dbo.tLHMStatus.nStatus < 30
						AND dbo.tlhm.klhmtyp = 4 
						AND ISNUMERIC(dbo.tLHM.cLHMId ) = 1
						AND dbo.tlhm.nSperre = 0
						AND dbo.tlhm.kWarenlager = @kWarenlager;

						--Gibt es eine freie Versandbox bzw. wurde der Bestellung schon eine Box zugewiesen 
						SELECT TOP(1) @kVersandBox = kLHM, @nIstNeueLHM = (CASE kBestellung WHEN @kBestellung THEN 0 ELSE 1 END)  
							FROM  
							( 
								SELECT DISTINCT (CASE WHEN ISNUMERIC(clhmid) = 1 
													THEN CAST(clhmid AS INT) 
													END
												) AS cTempLhmId, dbo.tLHM.kLHMStatus, kBestellung, dbo.tlhm.kLHM,
												CASE  WHEN (@nArtikelAttributeBeachten = 1 AND tLHMAttribut.cAttribut in (SELECT cAttribut FROM #AttributString)) 
													THEN 0 
													ELSE 1 
												END AS nReihenfolge
									FROM dbo.tlhm WITH(NOLOCK) 
									JOIN dbo.tLHMSTatus  WITH(NOLOCK) ON dbo.tLHMStatus.kLHMStatus = dbo.tLHM.kLHMSTatus
															AND (ISNULL(dbo.tlhmstatus.kbestellung,0) = 0 
															OR ( dbo.tLHMStatus.kBestellung = @kBestellung 
															     AND dbo.tlhmstatus.nStatus < 30)
															   ) 
									JOIN dbo.twarenlagerplatz  WITH(NOLOCK) ON dbo.twarenlagerplatz.kwarenlagerplatz = dbo.tlhm.kwarenlagerplatz
																     AND dbo.twarenlagerplatz.kWarenlager = @kWarenlager
									LEFT JOIN dbo.tLHMAttribut  WITH(NOLOCK) ON dbo.tLHMAttribut.kLHM = dbo.tLHM.kLHM
									WHERE dbo.tlhm.klhmtyp = 4 	
									AND NOT EXISTS (SELECT * FROM dbo.tWarenLagerEingang  WITH(NOLOCK) 
											    WHERE dbo.tWarenLagerEingang.fAnzahlAktuell > 0 
										        AND tWarenLagerEingang.klhm = dbo.tlhm.klhm 
										        AND dbo.tlhmstatus.nStatus = 10)
									--Wenn der RollendeKommissionierwagen gesetzt ist (dies ist ein Lagerplatz), werden nur Boxen auf diesem Platz reserviert
									--ansonsten werden nur normale Boxen auf einem Platz reserviert, der kein Pickwagen ist
									AND (
										(ISNULL(@kRollendeKommissionierungPickwagen,0) > 0 
										AND dbo.tlhm.kwarenlagerplatz = @kRollendeKommissionierungPickwagen
										)
									OR (
											(
											ISNULL(@kRollendeKommissionierungPickwagen,0) = 0 
											AND dbo.twarenlagerplatz.kwarenlagerplatztyp = 6)
											)
									   )
									AND ISNUMERIC(dbo.tLHM.cLHMId ) = 1
									AND dbo.tlhm.nSperre = 0
									AND (
										@nArtikelAttributeBeachten < 2 
										OR  NOT EXISTS(SELECT dbo.tLHMAttribut.kLHMAttribut 
													   FROM #AttributString
													   LEFT JOIN dbo.tLHMAttribut ON dbo.tLHMAttribut.cAttribut = #AttributString.cAttribut AND dbo.tLHMAttribut.kLHM = dbo.tlhm.kLHM
													   WHERE  dbo.tLHMAttribut.kLHMAttribut IS NULL)
										OR (
											NOT EXISTS (SELECT * FROM #AttributString)
											AND dbo.tLHMAttribut.cAttribut IS NULL
											)
										)
							) tLHMTEmp	
							-- Einschränken auf bestimmte Boxen falls gesetzt, sonst alle 
							WHERE NOT EXISTS (SELECT * FROM dbo.tPicklisteVorlageBoxen  WITH(NOLOCK) 
										      WHERE dbo.tPicklisteVorlageBoxen.kPicklisteVorlage = @kPicklisteVorlage)
							       OR tLHMTemp.kLHM IN (SELECT dbo.tPicklisteVorlageBoxen.kLHM FROM dbo.tPicklisteVorlageBoxen  WITH(NOLOCK) 
											            WHERE dbo.tPicklisteVorlageBoxen.kPicklisteVorlage = @kPicklisteVorlage) 		 
							ORDER BY (CASE tLHMTEmp.kBestellung  
								WHEN @kBestellung 
									THEN 1 
									ELSE 2 
								END), 
							nReihenfolge, 
							CAST(tLHMTemp.cTempLhmId AS INT);
					
					
					END;
		 
					--Keine freien Versandboxen mehr vorhanden, trotzdem die kompletten BEstellungen durchlaufen, 
					--weil für eine der Bestellungen evtl. schon eine Box reserviert/belegt sein kann 
					IF ((@kVersandBox is not null AND @kVersandBox > 0 AND (@kBestellungsBox = 0 OR @kBestellungsBox = @kVersandBox OR @VersandBoxenProzessMitRoko = 1) ) OR @nEinartikelpickliste = 1)
					BEGIN  
						IF (@nDebug = 1 AND @nEinartikelpickliste = 0)	
						BEGIN	   
							SELECT @cBoxId = cLHMID FROM dbo.tlhm  WITH(NOLOCK) WHERE klhm = @kVersandBox
							INSERT INTO dbo.tFehler WITH(ROWLOCK) (kSessionId, cText, kkey1, cValue1, nValue1)
							VALUES (@kSessionID, 'Versandbox ' + @cBoxId + ' wurde reserviert.', @kBestellung, @cBestellung,1);    
						END;
					
						SET @nTeillieferungSpeicher = @nTeilLiefErlaubt;
						--Wenn die Bestellung als Teillieferung oder als Zum Vorkommissionieren freigeben deklariert ist, darf auch 
						--bei der Reservierung nur eine Teilmenge reserviert werden. Vorkommissionieren werden darf jedoch nur, wenn mit Versandboxen gearbeitet wird
						IF(@nTeillieferungErlaubt = 1 OR (@nVorkommissionieren = 1 AND @nEinartikelpickliste = 0))
							SET @nTeilLiefErlaubt = 1;
					     ELSE
							SET @nTeilLiefErlaubt = 0;

						EXEC dbo.spBestellungReservieren @kPickliste = @kPickliste, @kBestellung = @kBestellung, @kWarenlager = @kWarenlager, @kPicklisteVorlage = @kPicklisteVorlageAktuell, @kBenutzer = @kBenutzer, @nAnzArtMin = @nAnzArtMin, @nAnzArtMax = @nAnzArtMax, @nGewMin = @nGewMin, @nGewMax = @nGewMax, @nTeilLiefErlaubt = @nTeilLiefErlaubt, @fTeilliefPreis = @fTeilliefPreis, 
											        @nWEPlatzReservieren = @nWEPlatzReservieren, @nLadenlokalReservieren = @nLadenlokalReservieren, @nRetourPlatzReservieren = @nRetourenPlatzReservieren, @nSortierung = @nSortierung, @nDebug = @nDebug, @kSessionID = @kSessionID, @nEinartikelpickliste = @nEinartikelpickliste, @kReineRollendeKommissionierung = @kReineRollendeKommissionierung, @fMengeErfolgreichReserviert = @fMengeErfolgreichReserviert OUTPUT;
	        			
						SET @fMengeErfolgreichReserviertGesamt = @fMengeErfolgreichReserviertGesamt + ISNULL(@fMengeErfolgreichReserviert,0);

						IF (ISNULL(@fMengeErfolgreichReserviert,0) > 0) 
						BEGIN     		   
							IF(@nSortenrein = 1)
							BEGIN		      
								INSERT INTO @tempAktivArtikel (kArtikel)
								SELECT tArtikel_kArtikel 
								FROM dbo.tbestellpos WITH(NOLOCK)
								JOIN dbo.vWMSArtikel WITH(NOLOCK) ON dbo.vWMSArtikel.kArtikel = dbo.tbestellpos.tArtikel_kArtikel
								WHERE dbo.tbestellpos.tBestellung_kBestellung = @kBestellung
								AND dbo.tbestellpos.tArtikel_kArtikel NOT IN (SELECT kArtikel FROM @tempAktivArtikel)
								GROUP BY tArtikel_kArtikel;
						END;	   
						IF (@nIstNeueLHM = 1 AND @nEinartikelpickliste = 0) -- Es wurde dem Auftrag eine neue LHM zugewiesen, welche nun wieder entfernt werden muss, weil nichts reserviert wurde 
						BEGIN 
							INSERT INTO dbo.tlhmstatus WITH(ROWLOCK) (klhm, nstatus, dzeitstempel, kbestellung)
							VALUES (@kVersandBox,20,GETDATE(),@kBestellung);

							SET @kLHMStatus = SCOPE_IDENTITY();

							UPDATE tlhm  WITH(ROWLOCK) 
							SET kLHMStatus = @kLHMStatus 
							WHERE klhm = @kVersandBox; 					
						END;

	   					SET @nAnzReservierterAuftraege =  @nAnzReservierterAuftraege + 1;

						IF (@nDebug = 1)
								INSERT INTO dbo.tFehler WITH(ROWLOCK) (kSessionId, cText, kkey1, cValue1, nValue1)
								VALUES (@kSessionID, 'Der Auftrag wurde erfolgreich reserviert.', @kBestellung, @cBestellung,1);

 						IF (@nMaxAnzahlArtikel > 0 AND @fMengeErfolgreichReserviertGesamt >= @nMaxAnzahlArtikel) 
						BEGIN 
							--Menge der gewünschten Artikel ist erreicht 
							IF (@nDebug = 1)
								INSERT INTO dbo.tFehler WITH(ROWLOCK) (kSessionId, cText, nValue1)
								VALUES (@kSessionID, 'Menge der gewünschten Artikel wurde erreicht: ' + CAST(@nMaxAnzahlArtikel AS VARCHAR),1);       
							
                                   SELECT @kPickliste;
							BREAK;
						END;
						IF (@nAnzAuftraege is not null and @nAnzAuftraege > 0 and @nAnzReservierterAuftraege >= @nAnzAuftraege) 
						BEGIN 
							--Menge der gewünschten Aufträge ist erreicht 
							IF (@nDebug = 1)
								INSERT INTO dbo.tFehler WITH(ROWLOCK) (kSessionId, cText, nValue1)
									VALUES (@kSessionID, 'Menge der gewünschten Aufträge wurde erreicht: ' + CAST(@nAnzAuftraege AS VARCHAR),1); 
                                                     
							SELECT @kPickliste;
							BREAK;
						END;
					END;
					ELSE 
						IF (@nDebug = 1)
							INSERT INTO dbo.tFehler WITH(ROWLOCK) (kSessionId, cText, kkey1, cValue1, nValue1)
							VALUES (@kSessionID, 'Der Auftrag wurde nicht vollständig reserviert und die Reservierungen wurden gelöscht.', @kBestellung,@cBestellung,2);        
				END; 
				ELSE	   
  					BEGIN
						IF (@nDebug = 1)
						BEGIN
							INSERT INTO dbo.tFehler WITH(ROWLOCK) (kSessionId, cText, kkey1, cValue1, nValue1)
							VALUES (@kSessionID, 'Es wurden keine freien Boxen für diesen Auftrag gefunden.', @kBestellung,@cBestellung,2);  
			    
	 
		  					SELECT @cLHMIdForDebug = tLHM.cLHMId
							FROM dbo.tLHM WITH (NOLOCK)
							JOIN dbo.tLHMStatus WITH (NOLOCK) on dbo.tLHMStatus.kLHMStatus = dbo.tLHM.kLHMStatus
							WHERE dbo.tLHMStatus.nStatus < 30
							AND dbo.tLHMStatus.kBestellung = @kBestellung
							AND klhmtyp = 4 
							AND dbo.tlhm.kWarenlager = @kWarenlager;
               
						IF(LEN(@cLHMIdForDebug) > 0)
							INSERT INTO dbo.tFehler WITH(ROWLOCK) (kSessionId, cText, kkey1, cValue1, nValue1)
							VALUES (@kSessionID, 'Von der Bestellung sind bereits Artikel in Box: ' + @cLHMIdForDebug + ', die Vorlage muß für diese Box gültig sein.', @kBestellung,@cBestellung,2);        
					
					
					
						IF(@nArtikelAttributeBeachten = 2 AND EXISTS (SELECT * FROM #AttributString))
						BEGIN

						    DECLARE @nLHMWithoutAttCount INT;
						    DECLARE @nLHMWithAttCount INT;
					
					         -- Alle freien Boxen Ohne das Artikel Attribut
					         SELECT @nLHMWithoutAttCount = count(dbo.tlhm.kLhm)
						    FROM dbo.tlhm WITH(NOLOCK) 
						    JOIN dbo.tLHMSTatus  WITH(NOLOCK) ON dbo.tLHMStatus.kLHMStatus = dbo.tLHM.kLHMSTatus
															AND (ISNULL(dbo.tlhmstatus.kbestellung,0) = 0 
															OR ( dbo.tLHMStatus.kBestellung = @kBestellung 
															     AND dbo.tlhmstatus.nStatus < 30)) 
						    LEFT JOIN dbo.tLHMAttribut  WITH(NOLOCK) ON dbo.tLHMAttribut.kLHM = dbo.tLHM.kLHM
						    WHERE dbo.tlhm.klhmtyp = 4 
							AND (dbo.tLHMAttribut.cAttribut NOT IN (SELECT cAttribut FROM #AttributString) OR dbo.tLHMAttribut.cAttribut IS NULL)

						    -- Alle freien Boxen Mit dem Artikel Attribut
						    SELECT @nLHMWithAttCount = count( dbo.tlhm.kLHM)
						    FROM dbo.tlhm WITH(NOLOCK) 
						    JOIN dbo.tLHMSTatus  WITH(NOLOCK) ON dbo.tLHMStatus.kLHMStatus = dbo.tLHM.kLHMSTatus
															AND (ISNULL(dbo.tlhmstatus.kbestellung,0) = 0 
															OR ( dbo.tLHMStatus.kBestellung = @kBestellung
															     AND dbo.tlhmstatus.nStatus < 30)) 
						    LEFT JOIN dbo.tLHMAttribut  WITH(NOLOCK) ON dbo.tLHMAttribut.kLHM = dbo.tLHM.kLHM
						    WHERE dbo.tlhm.klhmtyp = 4 
						    AND  NOT EXISTS(SELECT dbo.tLHMAttribut.kLHMAttribut 
											FROM #AttributString
											LEFT JOIN dbo.tLHMAttribut ON dbo.tLHMAttribut.cAttribut = #AttributString.cAttribut AND dbo.tLHMAttribut.kLHM = dbo.tlhm.kLHM
											WHERE  dbo.tLHMAttribut.kLHMAttribut IS NULL)
							

						    IF(@nLHMWithoutAttCount > 0 AND @nLHMWithAttCount = 0)
						    	   INSERT INTO dbo.tFehler WITH(ROWLOCK) (kSessionId, cText, kkey1, cValue1, nValue1)
							   VALUES (@kSessionID, 'Es gibt keine freien Boxen mit den erforderlichen Artikelattributen." .', @kBestellung,@cBestellung,2);        
					
						END;

					
					END;	        		
					IF (@nDebug = 1 AND @nArtikelAttributeBeachten = 2)
						INSERT INTO dbo.tFehler WITH(ROWLOCK) (kSessionId, cText, kkey1, cValue1, nValue1)
							VALUES (@kSessionID, 'Bitte prüfen Sie ob die Attribute der Artikel des Auftrags denen der Boxen entsprechen.', @kBestellung,@cBestellung,2);         		
				END;
			END;   
		END;

		IF (@nAnzReservierterAuftraege = 0) 
		BEGIN
			DELETE FROM dbo.tPickliste WITH(ROWLOCK) 
			WHERE kPickliste = @kPickliste;



			--Hier können wir bestellungen checken die nicht im SQL gefunden wurden, wenn wir einzellne Bestellungen reservieren
			IF( @nDebug = 1 AND @kBestellNr > 0)
			BEGIN

			  SELECT @cBestellung = cBEstellNr 
			  FROM dbo.tBEstellung  WITH(NOLOCK) 
			  WHERE kBestellung = @kBestellNr;

			  DECLARE @nLieferbarEigen INT;
			  DECLARE @cMissingArtikelNr VARCHAR(255);
			  DECLARE @fMengeOffenBestellung DECIMAL(28,14);
			  DECLARE @fMengeReserviertBestellung DECIMAL(28,14);


			  SELECT @nLieferbarEigen = ISNULL(Versand.vBestellungLieferInfoProLager.nLieferbarEigen,0)
			  FROM Versand.vBestellungLieferInfoProLager
			  LEFT JOIN dbo.tbestellungwmsfreigabe ON  Versand.vBestellungLieferInfoProLager.kBestellung = tbestellungwmsfreigabe.kBestellung
			  WHERE Versand.vBestellungLieferInfoProLager.kWarenlager = @kWarenlager
			  AND Versand.vBestellungLieferInfoProLager.kBestellung = @kBestellNr;


			  IF(@nLieferbarEigen = 0)
			  BEGIN

			     INSERT INTO dbo.tFehler  WITH(ROWLOCK) (kSessionId, cText, kkey1, cValue1, nValue1)
				 VALUES (@kSessionID, 'Bestellung ist nicht komplett lieferbar. Es wurde kein Bestand im Warenlager gefunden.', @kBestellNr, @cBestellung,1);   

			  END;

			  IF((@nLieferbarEigen = 1))
			  BEGIN
				
				 INSERT INTO dbo.tFehler  WITH(ROWLOCK) (kSessionId, cText, kkey1, cValue1, nValue1)
				 VALUES (@kSessionID, 'Bestellung ist vom Bestand her nur teillieferbar.', @kBestellNr, @cBestellung,1);   

			  END;


			  IF( @nLieferbarEigen IN (0,1))
			  BEGIN

				  DECLARE  CUR_FehlBestand CURSOR LOCAL FAST_FORWARD FOR
				  SELECT Versand.vBestellPosLieferInfoProLager.fAnzahlOffen, Versand.vBestellPosLieferInfoProLager.fAnzahlReserviertEigen, tArtikel.cArtNr
				  FROM Versand.vBestellPosLieferInfoProLager 
				  JOIN dbo.tArtikel ON tArtikel.kArtikel = Versand.vBestellPosLieferInfoProLager.kArtikel
				  WHERE Versand.vBestellPosLieferInfoProLager.kBestellung = @kBestellNr
				  AND Versand.vBestellPosLieferInfoProLager.kWarenLager = @kWarenlager
				  AND Versand.vBestellPosLieferInfoProLager.fAnzahlOffen > Versand.vBestellPosLieferInfoProLager.fAnzahlReserviertEigen;

				  OPEN CUR_FehlBestand
				  FETCH NEXT FROM CUR_FehlBestand INTO @fMengeOffenBestellung,@fMengeReserviertBestellung,@cMissingArtikelNr;

  				  WHILE (@@FETCH_STATUS = 0 ) 
				  BEGIN

					 INSERT INTO dbo.tFehler  WITH(ROWLOCK) (kSessionId, cText, kkey1, cValue1, nValue1)
					 VALUES (@kSessionID, 'Artikel ' + @cMissingArtikelNr + ' hat offene Menge (' + CAST(CAST(@fMengeOffenBestellung AS FLOAT) AS VARCHAR)  + ') , reservierbare Menge ist ('+   CAST(CAST(@fMengeReserviertBestellung AS FLOAT) AS VARCHAR) + ').' , @kBestellNr, @cBestellung,1);   

					 FETCH NEXT FROM CUR_FehlBestand INTO @fMengeOffenBestellung,@fMengeReserviertBestellung,@cMissingArtikelNr;
				  END;

				  CLOSE CUR_FehlBestand;
				  DEALLOCATE CUR_FehlBestand;

			  END;



			  IF( 0 < (SELECT count(*) FROM tBestellung
			           JOIN tkunde ON tKunde.kKunde  = tBestellung.tKunde_kKunde
			           WHERE kBestellung = @kBestellNr
			           AND tkunde.cSperre = 'Y'))
			  BEGIN

			      INSERT INTO dbo.tFehler  WITH(ROWLOCK) (kSessionId, cText, kkey1, cValue1, nValue1)
				  VALUES (@kSessionID, 'Der Kunde für diese Bestellung ist gesperrt.', @kBestellNr, @cBestellung,1);   

			  END;


			  IF( 0 < (SELECT count(*) FROM tBestellung
			           WHERE kBestellung = @kBestellNr
			           AND tBestellung.kRueckhalteGrund > 0 ))
			  BEGIN

			      INSERT INTO dbo.tFehler  WITH(ROWLOCK) (kSessionId, cText, kkey1, cValue1, nValue1)
				  VALUES (@kSessionID, 'Bestellung wird zurückgehalten.', @kBestellNr, @cBestellung,1);   

			  END;

			  IF( 0 < (SELECT count(*) FROM tBestellung
			           JOIN dbo.tbestellungwmsfreigabe WITH(NOLOCK) on dbo.tbestellungwmsfreigabe.kbestellung = dbo.tbestellung.kBestellung and dbo.tBEstellungwmsFreigabe.naktiv = 1 
			           WHERE tBestellung.kBestellung = @kBestellNr
			           AND tbestellungwmsfreigabe.nSperre = 1 ))
			  BEGIN

			     INSERT INTO dbo.tFehler  WITH(ROWLOCK) (kSessionId, cText, kkey1, cValue1, nValue1)
			     VALUES (@kSessionID, 'Bestellung ist für WMS gesperrt.', @kBestellNr, @cBestellung,1);   

			  END;


			  DECLARE @nRechnungsCount INT
			  SELECT @nRechnungsCount = count(*) 
						FROM tBestellung
						JOIN tRechnung ON tRechnung.tBestellung_kBestellung = tBestellung.kBestellung
						JOIN tgutschrift ON tgutschrift.kRechnung = tRechnung.kRechnung
			            WHERE kBestellung = @kBestellNr;


			  IF( 0 < @nRechnungsCount)
			  BEGIN

			      INSERT INTO dbo.tFehler  WITH(ROWLOCK) (kSessionId, cText, kkey1, cValue1, nValue1)
				  VALUES (@kSessionID, 'Bestellung hat ' + CAST(@nRechnungsCount AS varchar) + ' Gutschriften. Bitte beachten sie gutgeschriebene Artikel nicht reserviert werden.', @kBestellNr, @cBestellung,1);   

			  END;

			  IF( 1 = @FifoAktiv)
			  BEGIN

			    DECLARE @nStatusBestellung INT;
				SELECT @nStatusBestellung = Versand.vBestellungLieferInfoProLager.nLieferbarEigen
				FROM Versand.vBestellungLieferInfoProLager
				WHERE Versand.vBestellungLieferInfoProLager.kWarenLager = kWarenlager
				AND Versand.vBestellungLieferInfoProLager.kBestellung = @kBestellNr;

				IF(@nStatusBestellung = 0)
				BEGIN
				  INSERT INTO dbo.tFehler  WITH(ROWLOCK) (kSessionId, cText, kkey1, cValue1, nValue1)
				  VALUES (@kSessionID, 'FIFO ist aktiv. Bestellung ist nicht lieferbar. Kein freier Bestand vorhanden.', @kBestellNr, @cBestellung,1);   
				END;


				IF(@nStatusBestellung = 1)
				BEGIN
				  INSERT INTO dbo.tFehler  WITH(ROWLOCK) (kSessionId, cText, kkey1, cValue1, nValue1)
				  VALUES (@kSessionID, 'FIFO ist aktiv. Bestellung ist nur teilweise lieferbar. Nicht genug freier Bestand vorhanden.', @kBestellNr, @cBestellung,1);   
				END;

			  END;
			END;
			


	     END;
		ELSE
		BEGIN --Sicherung damit keine Pos ohne pickliste da sind

		  IF (NOT EXISTS (SELECT * FROM tPickliste WHERE kPickliste = @kPickliste)) AND 
		     (EXISTS (SELECT * FROM tPicklistePos WHERE kPickliste = @kPickliste))
			BEGIN

			  DELETE FROM tPicklistePos
			  WHERE tPicklistePos.kPickliste = @kPickliste;

			END
		END;

		-- Druch teillieferbate Stücklisten können picklistenpos mit bestellpos = 0 entstehen, die zählen wie gelöschte.
	     DELETE FROM dbo.tPicklistePos 
	     WHERE dbo.tPicklistePos.kBestellPos = 0 
	     AND dbo.tPicklistePos.kWarenLagerEingang = 0
	     AND dbo.tPicklistePos.kPickliste = @kPickliste;
	  
		DELETE FROM dbo.tBestellungPicklisteLock WITH(ROWLOCK) 
		WHERE kPickliste = @kPickliste;
	
		DELETE FROM dbo.tPicklisteVorlageBoxen WITH(ROWLOCK) 
		WHERE dbo.tPicklisteVorlageBoxen.kPicklisteVorlage = @kPicklisteVorlage;

		DELETE FROM tSessionId
		WHERE kSessionId = @kSessionIDPickliste;



		INSERT INTO dbo.tPicklisteStatus
		(
		    --kPicklisteStatus - this column value is auto-generated
		    kPickliste,
		    kBenutzer,
		    dZeitstempel,
		    nStatus
		)
		VALUES
		(
		    @kPickliste, -- kPickliste - int
		    @kBenutzer, -- kBenutzer - int
		     getdate(), -- dZeitstempel - datetime
		    10 -- nStatus - int
		);

		DECLARE @kPicklisteStatus INT = SCOPE_IDENTITY(); 

		UPDATE tPickliste SET kSessionId = null, kPicklisteStatus = @kPicklisteStatus, kPicklisteStatusAngelegt = @kPicklisteStatus, nStatus = 10
		WHERE kPickliste = @kPickliste;


		SELECT CASE @nAnzReservierterAuftraege WHEN 0  THEN 0  ELSE @kPickliste END; 

	END TRY 
	BEGIN CATCH	
		DELETE FROM dbo.tBestellungPicklisteLock WITH(ROWLOCK) 
		WHERE kPickliste = @kPickliste;	
		
		DELETE FROM dbo.tPicklistePos WITH(ROWLOCK) 
		WHERE kBestellung = 0 AND kPickliste = @kPickliste;
		
		SELECT @nAnzahlPositionen = count(*) 
		FROM dbo.tPicklistePos WITH(NOLOCK) 
		WHERE kPickliste = @kPickliste; 
		

		  INSERT INTO dbo.tFehler WITH(ROWLOCK) (kSessionId, cText, kkey1, cValue1, nValue1)
		  VALUES (@kSessionID, 'ERROR:' + ERROR_MESSAGE(), @kBestellung,@cBestellung,2);         		


		IF (@nAnzahlPositionen > 0) 
			SELECT -@kPickliste;
		ELSE 
		    SELECT -999999999; 
	END CATCH	 
END;
go

